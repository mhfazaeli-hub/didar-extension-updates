if (typeof importScripts === "function") importScripts("release-config.js", "team-checklists.js", "team-background.js");
(function initializeBackground() {
  "use strict";
  const chrome = globalThis.browser || globalThis.chrome;

  const RECEIVER_MISSING_PATTERN = /Receiving end does not exist|Could not establish connection/i;
  const RETRYABLE_DIDAR_CODES = new Set(["DIDAR_AUTH_REQUIRED", "DIDAR_ACCOUNT_REQUIRED"]);
  const DIDAR_DEAL_URL_PATTERN = /^https:\/\/app\.didar\.me\/deal\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  let preferredDidarTabId = null;

  async function didarTabs() {
    const tabs = await chrome.tabs.query({ url: "https://app.didar.me/*" });
    return tabs
      .filter((tab) => Number.isInteger(tab.id))
      .sort((left, right) => {
        if (left.id === preferredDidarTabId) {
          return -1;
        }
        if (right.id === preferredDidarTabId) {
          return 1;
        }
        return Number(right.lastAccessed || 0) - Number(left.lastAccessed || 0);
      });
  }

  function isReceiverMissing(error) {
    return RECEIVER_MISSING_PATTERN.test(String(error?.message || error || ""));
  }

  function isRetryableDidarResponse(response) {
    if (response?.ok !== false) {
      return false;
    }
    if (RETRYABLE_DIDAR_CODES.has(response.code)) {
      return true;
    }
    return /\b401\b|نشست دیدار.*(?:منقضی|نامعتبر)|حساب سازمانی دیدار.*مشخص نیست/i.test(
      String(response.error || "")
    );
  }

  async function restoreDidarReceiver(tabId) {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["page-context.js"],
      world: "MAIN"
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: globalThis.DidarRelease?.teamChecklists ? ["release-config.js", "team-checklists.js", "core.js", "plan-board.js", "content.js"] : ["core.js", "plan-board.js", "content.js"]
    });

    try {
      await chrome.scripting.insertCSS({
        target: { tabId },
        files: ["content.css", "plan-board.css"]
      });
    } catch (_error) {
      // The message receiver is operational even if Chrome declines duplicate CSS insertion.
    }
  }

  async function sendToTab(tabId, message) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (error) {
      if (!isReceiverMissing(error)) {
        throw error;
      }

      await restoreDidarReceiver(tabId);
      return chrome.tabs.sendMessage(tabId, message);
    }
  }

  async function sendToDidar(message) {
    const tabs = await didarTabs();
    if (!tabs.length) {
      throw new Error("برای بررسی اطلاعات، یک تب دیدار را باز نگه دارید.");
    }
    let lastError = null;
    let lastDidarResponse = null;
    for (const tab of tabs) {
      try {
        const response = await sendToTab(tab.id, message);
        if (isRetryableDidarResponse(response)) {
          lastDidarResponse = response;
          if (preferredDidarTabId === tab.id) {
            preferredDidarTabId = null;
          }
          continue;
        }
        if (response?.ok) {
          preferredDidarTabId = tab.id;
        }
        return response;
      } catch (error) {
        lastError = error;
      }
    }
    if (lastDidarResponse) {
      return lastDidarResponse;
    }
    throw lastError || new Error("اتصال به تب دیدار برقرار نشد.");
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const fromDidar = sender.tab?.url?.startsWith("https://app.didar.me/");
    if (fromDidar && message?.type === "DIDAR_OPEN_DEAL_TAB") {
      const url = String(message.url || "");
      if (!DIDAR_DEAL_URL_PATTERN.test(url)) {
        sendResponse({ ok: false, error: "نشانی معامله معتبر نیست." });
        return false;
      }
      chrome.tabs.create({ url })
        .then((tab) => sendResponse({ ok: true, tabId: tab.id }))
        .catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }

    const fromEtebarito = sender.tab?.url?.startsWith("https://etebaritoapp.ics24.ir/");
    const fromBeta = sender.tab?.url?.startsWith("https://beta.bkr724.ir/");
    const fromTamin = sender.tab?.url?.startsWith("https://eservices.tamin.ir/");
    const fromOlive = sender.tab?.url?.startsWith("https://my.olivecredit.ir/");
    const fromExtensionPopup = sender.id === chrome.runtime.id && !sender.tab;
    const supportedMessage = message?.type?.startsWith("ETEBARITO_DIDAR_") ||
      message?.type?.startsWith("BETA_DIDAR_") || message?.type?.startsWith("TAMIN_DIDAR_");
    if (!(fromEtebarito || fromBeta || fromTamin || fromOlive || fromExtensionPopup) || !supportedMessage ||
        (fromOlive && !message?.type?.startsWith("ETEBARITO_DIDAR_")) ||
        (fromTamin && !message?.type?.startsWith("TAMIN_DIDAR_"))) {
      return false;
    }
    sendToDidar(fromOlive ? { ...message, payload: { ...message.payload, provider: "olive" } } : message)
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({
        ok: false,
        error: error.message,
        code: error.code || "DIDAR_TAB_CONNECTION_FAILED"
      }));
    return true;
  });
})();
