(function initializeOliveCore(root) {
  "use strict";
  const E = root.EtebaritoCore;
  const normalize = (value) => E.normalizeText(value);
  function unwrap(value, label) {
    if (value?.isSuccess !== true || !value.data) throw new Error(`دریافت ${label} از الیو کردیت انجام نشد.`);
    return value.data;
  }
  function profile(value) {
    const p = unwrap(value, "پروفایل");
    const nationalCode = E.normalizeNationalCode(p.nationalCode);
    const firstName = normalize(p.firstName), lastName = normalize(p.lastName);
    if (!nationalCode || !E.isNameCandidate(`${firstName} ${lastName}`)) throw new Error("اطلاعات هویتی پروفایل الیو کردیت کامل نیست.");
    let birthDate = "";
    const date = String(p.birthDate || "").slice(0, 10);
    if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      const parts = new Intl.DateTimeFormat("fa-IR-u-ca-persian-nu-latn", {
        timeZone: "UTC", year: "numeric", month: "2-digit", day: "2-digit"
      }).formatToParts(new Date(`${date}T12:00:00Z`));
      const part = (type) => parts.find((p) => p.type === type)?.value || "";
      birthDate = `${part("year")}/${part("month")}/${part("day")}`;
    }
    return { nationalCode, fullName: `${firstName} ${lastName}`, fatherName: normalize(p.fatherName),
      mobile: E.normalizeMobile(p.mobileNumber), birthDate };
  }
  function score(value) {
    const s = unwrap(value, "آخرین گزارش");
    if (!/^[1-9]\d*$/.test(String(s.id)) || !s.hasReport) throw new Error("گزارش آماده‌ای در الیو کردیت وجود ندارد؛ واکشی، استعلام تازه ایجاد نمی‌کند.");
    const rank = normalize(s.risk).toUpperCase();
    if (!/^[A-E][1-3]$/.test(rank) || !/^\d{1,3}$/.test(String(s.score)) || Number(s.score) > 900) {
      throw new Error("امتیاز یا رتبهٔ گزارش الیو کردیت معتبر نیست.");
    }
    return { id: String(s.id), creditRatingScore: String(s.score), creditRank: rank, reportDate: normalize(s.createdAt) };
  }
  function lines(page) {
    const result = [];
    for (const item of page.items || []) {
      const value = normalize(item.str);
      if (!value) continue;
      let line = result.find((line) => Math.abs(line.y - item.y) < 2.5);
      if (!line) { line = { y: item.y, items: [] }; result.push(line); }
      line.items.push({ ...item, value });
    }
    return result.sort((a, b) => b.y - a.y).map((line) => ({ ...line,
      value: line.items.sort((a, b) => b.x - a.x).map((item) => item.value).join(" ") }));
  }
  function pdf(pages, identity, rating) {
    const first = lines(pages[0] || { items: [] });
    const nationalLine = first.find((line) => /شماره\s*ملی/.test(line.value));
    const nationalCodes = (nationalLine?.value || "").match(/\b\d{10}\b/g) || [];
    if (!nationalCodes.includes(identity.nationalCode)) throw new Error("کد ملی PDF با پروفایل الیو کردیت تطابق ندارد یا خوانده نشد؛ انتقال متوقف شد.");
    const firstText = first.map((line) => line.value).join("\n");
    if (!firstText.includes(rating.creditRank) || !first.some((line) => line.items.some((item) => item.value === rating.creditRatingScore))) {
      throw new Error("امتیاز یا رتبهٔ PDF با آخرین گزارش سامانه تطابق ندارد؛ صفحه را تازه‌سازی کنید.");
    }
    const codeItem = (pages[0]?.items || []).map((item) => normalize(item.str))
      .find((value) => /^(?:\d{4}\s+){4}\d{4}$/.test(value));
    const codeLine = first.find((line) => /شماره\s*[:：]/.test(line.value) && E.digits(line.value).length === 20);
    const reportUniqCode = E.digits(codeItem || codeLine?.value);
    if (reportUniqCode.length !== 20) throw new Error("شناسهٔ یکتای PDF خوانده نشد؛ گزارش ناقص منتقل نمی‌شود.");
    const allLines = pages.flatMap(lines);
    const text = allLines.map((line) => line.value).join("\n");
    const overdueContracts = [];
    let overdueStatus = "unknown";
    for (const page of pages) {
      const rows = lines(page);
      const summary = rows.findIndex((line) => /خلاصه\s+قراردادها/.test(line.value));
      if (summary < 0) continue;
      const header = rows.slice(summary).find((line) => line.items.some((item) => item.value === "پرداخت نشده") &&
        line.items.some((item) => item.value === "سررسید نشده"));
      if (!header) continue;
      const center = (item) => item.x + (item.width || 0) / 2;
      const unpaid = header.items.find((item) => item.value === "پرداخت نشده");
      const future = header.items.find((item) => item.value === "سررسید نشده");
      if (center(unpaid) >= center(future)) continue;
      const boundary = (center(unpaid) + center(future)) / 2;
      const amountIn = (line) => {
        const cells = line.items.filter((item) => center(item) < boundary)
          .map((item) => item.value.replace(/[,٬\s]/g, "")).filter((value) => /^(?:\d+|صفر)$/.test(value));
        return cells.length === 1 ? (cells[0] === "صفر" ? "0" : cells[0]) : undefined;
      };
      let role = "";
      for (const row of rows.slice(summary + 1)) {
        if (/مجموع\s+کل\s+نقش\s+متقاضی\s+و\s+ضامن/.test(row.value)) {
          const total = amountIn(row);
          if (total !== undefined) overdueStatus = /^0+$/.test(total) ? "clear" : "present";
          break;
        }
        if (/^نقش\s+متقاضی/.test(row.value)) role = "متقاضی";
        if (/^نقش\s+ضامن/.test(row.value)) role = "ضامن";
        if (!role || row.y >= header.y || /مجموع/.test(row.value)) continue;
        const amount = amountIn(row);
        if (!amount || /^0+$/.test(amount)) continue;
        const contractType = row.items.filter((item) => item.x > page.width * .8).map((item) => item.value).join(" ");
        if (!contractType || /نوع قرارداد/.test(contractType)) continue;
        // A bank name may wrap above and below the numeric cells. Limit the
        // vertical band to this contract so adjacent lenders cannot be joined.
        const otherContracts = rows.filter((line) => line !== row && line.items.some((item) =>
          item.x > page.width * .8 && item.value === contractType));
        const nearest = Math.min(20, ...otherContracts.map((line) => Math.abs(line.y - row.y)));
        const lender = rows.filter((line) => Math.abs(line.y - row.y) < nearest / 2)
          .flatMap((line) => line.items.filter((item) => item.x > page.width * .63 && item.x < page.width * .8 && item.value !== "ریال"))
          .map((item) => item.value).join(" ");
        if (contractType && lender) overdueContracts.push({ role, contractType, lender, amount, pageNumber: page.pageNumber || 0 });
      }
    }
    if (overdueContracts.length) overdueStatus = "present";
    const limitedHistory = /به دلیل ناکافی بودن اطلاعات سوابق تسهیلاتی/.test(firstText);
    const completePages = pages.length > 0 && pages.every((page, index) => lines(page).some((line) =>
      new RegExp(`صفحه\\s*${index + 1}\\s*از\\s*${pages.length}(?:\\D|$)`).test(line.value)));
    if (overdueStatus === "unknown" && limitedHistory && completePages && !/خلاصه\s+قراردادها/.test(text)) {
      overdueStatus = "not_provided";
    }
    const checkClear = /فاقد\s+سابقه\s+چک\s+برگشتی/.test(text);
    const unpaidCheck = /(?:فرد|شخص)\s+چک\s+برگشتی\s+رفع\s+سوء\s*اثر\s+نشده\s+دارد/.test(firstText);
    const checkNegative = unpaidCheck || /دارای\s+سابقه\s+چک\s+برگشتی/.test(text);
    const checkDetail = unpaidCheck ? "در دلایل کاهش امتیاز، چک برگشتی رفع سوءاثر نشده ثبت شده است." : "";
    const checks = [{ label: "چک برگشتی", status: checkNegative ? "fail" : checkClear ? "pass" : "unknown",
      ...(checkNegative && checkClear ? { detail: `${checkDetail} بخش جزئیات چک، فاقد سابقه نوشته است و دو بخش PDF با یکدیگر مغایرت دارند.`.trim() }
        : checkDetail ? { detail: checkDetail } : {}) }];
    const legalStart = allLines.findIndex((line) => /وضعیت\s+محکومیت\s*های?\s+مالی/.test(line.value));
    const legalRows = [];
    for (const line of legalStart < 0 ? [] : allLines.slice(legalStart + 1)) {
      if (/وضعیت\s+سوابق\s+مالیاتی|توضیحات\s+گزارش/.test(line.value)) break;
      legalRows.push(line);
    }
    const legal = legalRows.map((line) => line.value).join("\n");
    const headings = legalRows.find((line) => line.items.some((item) => item.value === "تعداد") && line.items.some((item) => item.value === "مبلغ کل"));
    const judgments = [];
    const judgmentTitles = ["حکم اجرا شده", "حکم اجرا نشده", "حکم اعسار"];
    if (headings) {
      const center = (item) => item.x + (item.width || 0) / 2;
      const countX = center(headings.items.find((item) => item.value === "تعداد"));
      const amountX = center(headings.items.find((item) => item.value === "مبلغ کل"));
      for (const row of legalRows) {
        const title = judgmentTitles.find((title) => row.items.some((item) => item.value === title));
        if (!title || countX <= amountX) continue;
        const cells = row.items.map((item) => ({ x: center(item), value: item.value.replace(/[,٬\s]/g, "") }))
          .map((item) => ({ ...item, value: item.value === "صفر" ? "0" : item.value }))
          .filter((item) => /^\d{1,30}$/.test(item.value));
        const count = cells.filter((item) => Math.abs(item.x - countX) < Math.abs(item.x - amountX) && Math.abs(item.x - countX) < 60);
        const amount = cells.filter((item) => Math.abs(item.x - amountX) < Math.abs(item.x - countX) && Math.abs(item.x - amountX) < 60);
        if (count.length === 1 && amount.length === 1) judgments.push({ title, count: count[0].value, amount: amount[0].value });
      }
    }
    const hasJudgment = judgments.some((item) => !/^0+$/.test(item.count) || !/^0+$/.test(item.amount));
    const completeJudgments = judgmentTitles.every((title) => judgments.filter((item) => item.title === title).length === 1);
    checks.push({ label: "محکومیت مالی", status: hasJudgment ? "fail" : completeJudgments ? "pass"
      : /فاقد\s+سابقه\s+منفی/.test(legal) ? "pass" : /دارای\s+سابقه\s+منفی/.test(legal) ? "fail" : "unknown" });
    return { sourceSystem: "olive", reportUniqCode, creditScore: rating.creditRatingScore, creditRank: rating.creditRank,
      reportDate: rating.reportDate, overdueContracts, overdueStatus, checks, judgments };
  }
  root.OliveCreditCore = { profile, score, pdf, lines };
  if (typeof module === "object" && module.exports) module.exports = root.OliveCreditCore;
})(globalThis);
