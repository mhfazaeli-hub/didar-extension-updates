(function initializePopup() {
  "use strict";
  const chrome = globalThis.browser || globalThis.chrome;
  const Calls = globalThis.DidarCallChecklists;

  const DEFAULT_SETTINGS = {
    enabled: true,
    confirmBeforeSave: false,
    autoPlanChecklist: true,
    autoCallChecklist: true,
    callChecklistColumns: 3,
    callChecklistTemplates: Calls.defaultTemplates(),
    autoAddPlanProduct: false,
    etebaritoPreviewEnabled: false,
    etebaritoKeepAliveEnabled: true,
    connectionMode: "automatic",
    manualToken: "",
    manualBizDomain: ""
  };
  const RECEIVER_MISSING_PATTERN = /Receiving end does not exist|Could not establish connection/i;

  const elements = {
    appSubtitle: document.getElementById("appSubtitle"),
    form: document.getElementById("settingsForm"),
    enabled: document.getElementById("enabled"),
    confirmBeforeSave: document.getElementById("confirmBeforeSave"),
    autoPlanChecklist: document.getElementById("autoPlanChecklist"),
    autoCallChecklist: document.getElementById("autoCallChecklist"),
    callChecklistColumns: document.getElementById("callChecklistColumns"),
    beforePurchaseItems: document.getElementById("beforePurchaseItems"),
    afterPurchaseItems: document.getElementById("afterPurchaseItems"),
    autoAddPlanProduct: document.getElementById("autoAddPlanProduct"),
    etebaritoPreviewEnabled: document.getElementById("etebaritoPreviewEnabled"),
    etebaritoKeepAliveEnabled: document.getElementById("etebaritoKeepAliveEnabled"),
    manualFields: document.getElementById("manualFields"),
    manualToken: document.getElementById("manualToken"),
    manualBizDomain: document.getElementById("manualBizDomain"),
    statusDot: document.getElementById("statusDot"),
    statusTitle: document.getElementById("statusTitle"),
    userName: document.getElementById("userName"),
    userAccount: document.getElementById("userAccount"),
    diagnostics: document.getElementById("diagnostics"),
    lastInteraction: document.getElementById("lastInteraction"),
    refreshButton: document.getElementById("refreshButton"),
    formMessage: document.getElementById("formMessage"),
    submitButton: document.querySelector('.primary-button[type="submit"]')
  };
  elements.appSubtitle.textContent =
    `نسخه ${chrome.runtime.getManifest().version} · ذخیره با هویت کاربر جاری`;

  function selectedMode() {
    return document.querySelector('input[name="connectionMode"]:checked')?.value || "automatic";
  }

  function showManualFields() {
    elements.manualFields.hidden = selectedMode() !== "manual";
  }

  function setStatus(type, title, name = "", account = "") {
    elements.statusDot.className = `status-dot is-${type}`;
    elements.statusTitle.textContent = title;
    elements.userName.textContent = name || (type === "loading" ? "..." : "شناسایی نشد");
    elements.userAccount.textContent = account;
  }

  function setFormMessage(message, error = false) {
    elements.formMessage.textContent = message;
    elements.formMessage.classList.toggle("is-error", error);
  }

  async function activeSupportedTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (
      !tab?.id ||
      (!tab.url?.startsWith("https://app.didar.me/") &&
        !tab.url?.startsWith("https://etebaritoapp.ics24.ir/") &&
        !tab.url?.startsWith("https://my.olivecredit.ir/") &&
        !tab.url?.startsWith("https://beta.bkr724.ir/") &&
        !tab.url?.startsWith("https://eservices.tamin.ir/view/"))
    ) {
      throw new Error("ابتدا یک صفحه از دیدار یا سامانه اعتبارسنجی را باز کنید.");
    }
    return tab;
  }

  function isReceiverMissing(error) {
    return RECEIVER_MISSING_PATTERN.test(String(error?.message || error || ""));
  }

  async function restoreActiveReceiver(tab) {
    const isOlive = tab.url.startsWith("https://my.olivecredit.ir/");
    const isPortal = isOlive || tab.url.startsWith("https://etebaritoapp.ics24.ir/");
    const isTamin = tab.url.startsWith("https://eservices.tamin.ir/view/");
    const isBeta = isTamin || tab.url.startsWith("https://beta.bkr724.ir/");
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (marker) => {
        delete globalThis[marker];
      },
      args: [isPortal
        ? "__didarEtebaritoContentLoaded"
        : isBeta
          ? "__didarBetaIntegrationLoaded"
          : "__didarQuickChecklistContentLoaded"]
    });
    if (!isBeta) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: isOlive ? ["olive-page-context.js"] : isPortal ? ["etebarito-page-context.js"] : ["page-context.js"],
        world: "MAIN"
      });
    }
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: isOlive ? ["etebarito-core.js", "olive-core.js", "etebarito-content.js", "olive-content.js"] : isPortal
        ? ["etebarito-core.js", "etebarito-content.js"]
        : isBeta
          ? (isTamin ? ["beta-core.js", "tamin-core.js", "beta-content.js"] : ["beta-core.js", "beta-content.js"])
          : ["core.js", "plan-board.js", "content.js"]
    });
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: isOlive ? ["etebarito-content.css", "olive-content.css"] : isPortal
          ? ["etebarito-content.css"]
          : isBeta
            ? ["etebarito-content.css", "beta-content.css"]
            : ["content.css", "plan-board.css"]
      });
    } catch (_error) {
      // The receiver works even when Chrome refuses to insert an already loaded stylesheet.
    }
  }

  async function sendToTab(tab, message) {
    try {
      return await chrome.tabs.sendMessage(tab.id, message);
    } catch (error) {
      if (!isReceiverMissing(error)) {
        throw error;
      }
      await restoreActiveReceiver(tab);
      return chrome.tabs.sendMessage(tab.id, message);
    }
  }

  async function sendToActiveTab(message) {
    const tab = await activeSupportedTab();
    return sendToTab(tab, message);
  }

  async function refreshStatus() {
    setStatus("loading", "در حال بررسی اتصال");
    try {
      const tab = await activeSupportedTab();
      const isOlive = tab.url.startsWith("https://my.olivecredit.ir/");
      const isPortal = isOlive || tab.url.startsWith("https://etebaritoapp.ics24.ir/");
      const isTamin = tab.url.startsWith("https://eservices.tamin.ir/view/");
      const isBeta = isTamin || tab.url.startsWith("https://beta.bkr724.ir/");
      const result = await sendToTab(tab, {
        type: isPortal
          ? "ETEBARITO_PREVIEW_GET_STATUS"
          : isBeta
            ? (isTamin ? "TAMIN_DIDAR_GET_STATUS" : "BETA_DIDAR_GET_STATUS")
            : "DIDAR_TODO_GET_STATUS"
      });
      if (!result?.ok) {
        throw new Error(result?.error || "اتصال برقرار نشد.");
      }
      if (isPortal) {
        const didar = await chrome.runtime.sendMessage({ type: "ETEBARITO_DIDAR_GET_CONFIG", ...(isOlive ? { payload: { provider: "olive" } } : {}) });
        if (!didar?.ok) {
          throw new Error(didar?.error || "تب معتبر دیدار پیدا نشد.");
        }
        const mode = didar.identity?.connectionMode === "manual" ? "اتصال دستی" : "نشست همین مرورگر";
        setStatus(
          "ready",
          `${isOlive ? "الیو کردیت" : "اعتباریتو"} و دیدار متصل · ${mode}`,
          didar.identity?.displayName || "کاربر دیدار",
          didar.identity?.username || "مقصد: پرونده اعتباری / اعتبار سنجی اولیه"
        );
        const diagnostics = result.diagnostics || {};
        elements.diagnostics.textContent = `نتایج شناسایی‌شده: ${diagnostics.capturedRows || 0}`;
        elements.lastInteraction.textContent = `آخرین رویداد: ${diagnostics.lastInteraction || "نامشخص"}`;
        return;
      }
      if (isBeta) {
        const didar = await chrome.runtime.sendMessage({ type: isTamin ? "TAMIN_DIDAR_GET_CONFIG" : "BETA_DIDAR_GET_CONFIG" });
        if (!didar?.ok) {
          throw new Error(didar?.error || "تب معتبر دیدار پیدا نشد.");
        }
        const mode = didar.identity?.connectionMode === "manual" ? "اتصال دستی" : "نشست همین مرورگر";
        setStatus(
          "ready",
          `${isTamin ? "تأمین اجتماعی" : "بتا"} و دیدار متصل · ${mode}`,
          didar.identity?.displayName || "کاربر دیدار",
          didar.identity?.username || "مقصد: پرونده اعتباری / اعتبار سنجی اولیه"
        );
        elements.diagnostics.textContent = result.diagnostics?.launcherReady
          ? "دکمه انتقال بتا آماده است"
          : "صفحه مشتری بتا آماده انتقال نیست";
        elements.lastInteraction.textContent = result.diagnostics?.previewOpen
          ? "پنجره انتقال باز است"
          : "پنجره انتقال بسته است";
        return;
      }
      const mode = result.identity.connectionMode === "manual" ? "اتصال دستی" : "نشست همین مرورگر";
      setStatus(
        "ready",
        `متصل · ${mode}`,
        result.identity.displayName,
        result.identity.username
      );
      const diagnostics = result.diagnostics || {};
      elements.diagnostics.textContent =
        `شناسایی: ${diagnostics.checkboxes || 0} مربع، ` +
        `${diagnostics.ready || 0} آماده کلیک، ${diagnostics.resolved || 0} فعالیت متصل، ` +
        `${diagnostics.editorExcluded || 0} داخل ویرایشگر`;
      elements.lastInteraction.textContent = `آخرین رویداد: ${diagnostics.lastInteraction || "نامشخص"}`;
    } catch (error) {
      setStatus("error", "اتصال برقرار نیست", error.message);
      elements.diagnostics.textContent = "";
      elements.lastInteraction.textContent = "";
    }
  }

  async function load() {
    const values = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
    elements.enabled.checked = values.enabled;
    elements.confirmBeforeSave.checked = values.confirmBeforeSave;
    elements.autoPlanChecklist.checked = values.autoPlanChecklist;
    elements.autoCallChecklist.checked = values.autoCallChecklist;
    elements.callChecklistColumns.value = String(Calls.columns(values.callChecklistColumns));
    const templates = Calls.normalizeTemplates(values.callChecklistTemplates);
    elements.beforePurchaseItems.value = templates.beforePurchase.join("\n");
    elements.afterPurchaseItems.value = templates.afterPurchase.join("\n");
    elements.autoAddPlanProduct.checked = values.autoAddPlanProduct;
    elements.etebaritoPreviewEnabled.checked = values.etebaritoPreviewEnabled;
    elements.etebaritoKeepAliveEnabled.checked = values.etebaritoKeepAliveEnabled;
    const modeInput = document.querySelector(
      `input[name="connectionMode"][value="${values.connectionMode}"]`
    );
    if (modeInput) {
      modeInput.checked = true;
    }
    elements.manualToken.value = values.manualToken;
    elements.manualBizDomain.value = values.manualBizDomain;
    showManualFields();
    await refreshStatus();
  }

  document.querySelectorAll('input[name="connectionMode"]').forEach((input) => {
    input.addEventListener("change", showManualFields);
  });
  elements.refreshButton.addEventListener("click", refreshStatus);
  function callSettingsFromForm() {
    return { autoCallChecklist: elements.autoCallChecklist.checked,
      callChecklistColumns: Calls.columns(elements.callChecklistColumns.value),
      callChecklistTemplates: { beforePurchase: Calls.itemsFromLines(elements.beforePurchaseItems.value),
        afterPurchase: Calls.itemsFromLines(elements.afterPurchaseItems.value) } };
  }
  const backupFile = document.getElementById("callBackupFile");
  document.getElementById("downloadCallBackup").addEventListener("click", () => {
    try {
      const blob = new Blob([Calls.exportBackup(callSettingsFromForm())], { type: "application/json;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `didar-call-checklists-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.append(link); link.click(); link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setFormMessage("فایل پشتیبان برای دانلود آماده شد.");
    } catch (error) { setFormMessage(error.message, true); }
  });
  document.getElementById("uploadCallBackup").addEventListener("click", () => backupFile.click());
  backupFile.addEventListener("change", async () => {
    const file = backupFile.files?.[0];
    if (!file) return;
    try {
      if (file.size > 512 * 1024) throw new Error("حداکثر حجم فایل پشتیبان ۵۱۲ کیلوبایت است.");
      const imported = Calls.importBackup(await file.text());
      await chrome.storage.local.set(imported);
      elements.autoCallChecklist.checked = imported.autoCallChecklist;
      elements.callChecklistColumns.value = String(imported.callChecklistColumns);
      elements.beforePurchaseItems.value = imported.callChecklistTemplates.beforePurchase.join("\n");
      elements.afterPurchaseItems.value = imported.callChecklistTemplates.afterPurchase.join("\n");
      await sendToActiveTab({ type: "DIDAR_TODO_SETTINGS_UPDATED" }).catch(() => {});
      setFormMessage("پشتیبان بارگذاری و تنظیمات چک‌لیست ذخیره شد.");
    } catch (error) { setFormMessage(error.message || "بارگذاری فایل انجام نشد.", true); }
    finally { backupFile.value = ""; }
  });
  elements.form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const mode = selectedMode();
    let callChecklistTemplates;
    try {
      callChecklistTemplates = {
        beforePurchase: Calls.itemsFromLines(elements.beforePurchaseItems.value),
        afterPurchase: Calls.itemsFromLines(elements.afterPurchaseItems.value)
      };
    } catch (error) {
      setFormMessage(error.message, true);
      return;
    }
    const values = {
      enabled: elements.enabled.checked,
      confirmBeforeSave: elements.confirmBeforeSave.checked,
      autoPlanChecklist: elements.autoPlanChecklist.checked,
      autoCallChecklist: elements.autoCallChecklist.checked,
      callChecklistColumns: Calls.columns(elements.callChecklistColumns.value),
      callChecklistTemplates,
      autoAddPlanProduct: elements.autoAddPlanProduct.checked,
      etebaritoPreviewEnabled: elements.etebaritoPreviewEnabled.checked,
      etebaritoKeepAliveEnabled: elements.etebaritoKeepAliveEnabled.checked,
      connectionMode: mode,
      manualToken: elements.manualToken.value.trim(),
      manualBizDomain: elements.manualBizDomain.value.trim()
    };
    if (mode === "manual" && (!values.manualToken || !values.manualBizDomain)) {
      setFormMessage("برای اتصال دستی، هر دو مقدار لازم است.", true);
      return;
    }

    elements.submitButton.disabled = true;
    setFormMessage("در حال ذخیره...");
    try {
      await chrome.storage.local.set(values);
      await sendToActiveTab({ type: "DIDAR_TODO_SETTINGS_UPDATED" }).catch(() => {});
      setFormMessage("تنظیمات ذخیره شد.");
      await refreshStatus();
    } catch (error) {
      setFormMessage(error.message || "ذخیره تنظیمات انجام نشد.", true);
    } finally {
      elements.submitButton.disabled = false;
    }
  });

  void load();
})();
