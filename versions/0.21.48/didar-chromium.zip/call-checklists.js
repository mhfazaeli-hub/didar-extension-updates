(function initializeCallChecklists(root) {
  "use strict";
  const DEFINITIONS = [
    { key: "beforePurchase", title: "تماس خروجی قبل خرید", items: ["پایین بودن توان قسط", "بد رفتاری اعتباری", "سخت بودن پروسه خرید"] },
    { key: "afterPurchase", title: "تماس خروجی بعد خرید", items: ["رضایت از کالا", "رضایت از تحویل", "درخواست پیگیری"] }
  ];
  const MAX_ITEMS = 100;
  const MAX_ITEM_LENGTH = 300;
  const text = (value) => value == null ? "" : String(value).trim();
  const normalize = (value) => text(value).normalize("NFKC").replace(/ي/g, "ی").replace(/ك/g, "ک")
    .replace(/[\u200c\u200e\u200f]/g, " ").replace(/\s+/g, " ").trim();
  const defaultTemplates = () => Object.fromEntries(DEFINITIONS.map((item) => [item.key, [...item.items]]));
  function itemsFromLines(value) {
    const values = text(value).split(/\r?\n/).map((line) => text(line).replace(/\s+/g, " ")).filter(Boolean);
    if (values.length > MAX_ITEMS) throw new Error(`برای هر فعالیت حداکثر ${MAX_ITEMS} گزینه وارد کنید.`);
    if (values.some((item) => item.length > MAX_ITEM_LENGTH)) throw new Error(`متن هر گزینه حداکثر ${MAX_ITEM_LENGTH} نویسه باشد.`);
    const seen = new Set();
    return values.filter((item) => {
      const key = normalize(item);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function normalizeTemplates(value) {
    return Object.fromEntries(DEFINITIONS.map((definition) => {
      const source = Array.isArray(value?.[definition.key]) ? value[definition.key] : definition.items;
      const items = source.slice(0, MAX_ITEMS).map((item) => text(item).slice(0, MAX_ITEM_LENGTH)).filter(Boolean);
      return [definition.key, itemsFromLines(items.join("\n"))];
    }));
  }
  function templateForTitle(title, templates) {
    const definition = DEFINITIONS.find((item) => normalize(item.title) === normalize(title));
    return definition ? { ...definition, items: normalizeTemplates(templates)[definition.key] } : null;
  }
  function templateForKey(key, templates) {
    const definition = DEFINITIONS.find((item) => item.key === key);
    return definition ? { ...definition, items: normalizeTemplates(templates)[key] } : null;
  }
  const columns = (value) => Number(value) === 4 ? 4 : 3;
  const parse = (html) => new root.DOMParser().parseFromString(typeof html === "string" ? html : "", "text/html");
  const rows = (list) => Array.from(list.querySelectorAll(":scope > li")).map((item) => ({
    label: normalize(item.querySelector(".todo-list__label__description")?.textContent || item.textContent),
    checked: Boolean(item.querySelector('input[type="checkbox"]')?.hasAttribute("checked"))
  }));
  function todoItem(documentNode, label, checked = false) {
    const item = documentNode.createElement("li");
    const wrapper = documentNode.createElement("label");
    wrapper.className = "todo-list__label";
    const input = documentNode.createElement("input");
    input.type = "checkbox";
    input.setAttribute("disabled", "disabled");
    if (checked) input.setAttribute("checked", "checked");
    const description = documentNode.createElement("span");
    description.className = "todo-list__label__description";
    description.textContent = label;
    wrapper.append(input, description);
    item.append(wrapper);
    return item;
  }
  function ensure(note, template, { replaceUnmarked = false } = {}) {
    if (!template?.items?.length) return typeof note === "string" ? note : "";
    const documentNode = parse(note);
    const owned = documentNode.querySelector(`ul.todo-list[data-didar-call-template="${template.key}"]`);
    if (owned && !replaceUnmarked && rows(owned).some((row) => row.label)) return note;
    let target = owned || documentNode.querySelector("ul.todo-list");
    const existing = target ? rows(target) : [];
    if (!target) {
      target = documentNode.createElement("ul");
      target.className = "todo-list";
      documentNode.body.append(target);
    }
    if (replaceUnmarked) {
      const checked = new Set(existing.filter((item) => item.checked).map((item) => item.label));
      target.replaceChildren(...template.items.map((label) => todoItem(documentNode, label, checked.has(normalize(label)))));
      documentNode.querySelectorAll("ul.todo-list[data-didar-call-template]").forEach((list) => {
        if (list !== target) list.remove();
      });
    } else {
      const seen = new Set(existing.map((item) => item.label));
      template.items.forEach((label) => {
        if (!seen.has(normalize(label))) { target.append(todoItem(documentNode, label)); seen.add(normalize(label)); }
      });
    }
    target.dataset.didarCallTemplate = template.key;
    return documentNode.body.innerHTML;
  }
  function completedNotes(note, resultNote) {
    const noteDocument = parse(note);
    const lists = Array.from(noteDocument.querySelectorAll("ul.todo-list"));
    if (!lists.length) return { note, resultNote };
    const resultDocument = parse(resultNote);
    lists.forEach((list) => {
      const labels = rows(list).map((row) => row.label);
      const matched = Array.from(resultDocument.querySelectorAll("ul.todo-list")).some((other) => {
        const otherLabels = rows(other).map((row) => row.label);
        return labels.length === otherLabels.length && labels.every((label, index) => label === otherLabels[index]);
      });
      if (!matched) resultDocument.body.append(list.cloneNode(true));
      list.remove();
    });
    return { note: noteDocument.body.innerHTML.trim(), resultNote: resultDocument.body.innerHTML.trim() };
  }
  const isNewActivity = (activity) => !text(activity?.Id) || /^00000000-0000-0000-0000-000000000000$/i.test(text(activity.Id));
  const hasChecklist = (note) => Array.from(parse(note).querySelectorAll("ul.todo-list"))
    .some((list) => rows(list).some((row) => row.label));
  const BACKUP_FORMAT = "didar-quick-checklist/call-settings";
  function validateBackupSettings(value) {
    if (typeof value?.autoCallChecklist !== "boolean" || ![3, 4].includes(value.callChecklistColumns)) {
      throw new Error("تنظیمات چک‌لیست در فایل معتبر نیست.");
    }
    const templates = {};
    DEFINITIONS.forEach(({ key }) => {
      const items = value.callChecklistTemplates?.[key];
      if (!Array.isArray(items) || items.length > MAX_ITEMS || items.some((item) =>
        typeof item !== "string" || item.length > MAX_ITEM_LENGTH || /[\r\n]/.test(item))) {
        throw new Error("فهرست گزینه‌های فایل معتبر نیست.");
      }
      templates[key] = itemsFromLines(items.join("\n"));
    });
    return { autoCallChecklist: value.autoCallChecklist, callChecklistColumns: value.callChecklistColumns,
      callChecklistTemplates: templates };
  }
  function exportBackup(settings) {
    return JSON.stringify({ format: BACKUP_FORMAT, version: 1, exportedAt: new Date().toISOString(),
      settings: validateBackupSettings(settings) }, null, 2);
  }
  function importBackup(source) {
    if (typeof source !== "string" || source.length > 512 * 1024) throw new Error("حجم فایل پشتیبان بیش از حد مجاز است.");
    let value;
    try { value = JSON.parse(source); } catch { throw new Error("فایل انتخاب‌شده JSON معتبر نیست."); }
    if (value?.format !== BACKUP_FORMAT || value?.version !== 1) throw new Error("این فایل پشتیبان چک‌لیست تماس نیست یا نسخهٔ آن پشتیبانی نمی‌شود.");
    return validateBackupSettings(value.settings);
  }
  const api = { DEFINITIONS, MAX_ITEMS, MAX_ITEM_LENGTH, normalize, defaultTemplates, itemsFromLines,
    normalizeTemplates, templateForTitle, templateForKey, columns, ensure, completedNotes, isNewActivity, hasChecklist,
    exportBackup, importBackup };
  root.DidarCallChecklists = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
