globalThis.DidarRelease = {
  "channel": "chromium",
  "downloadUrl": "https://github.com/mhfazaeli-hub/didar-extension-updates",
  "nativeHost": "ir.sarika.didar_updater"
};
