/* BEGIN GENERATED CALL CHECKLISTS — edit call-checklists.js, then npm run build */
(function initializeCallChecklists(root) {
  "use strict";
  const DEFINITIONS = [
    { key: "beforePurchase", title: "تماس خروجی قبل خرید", items: ["پایین بودن توان قسط", "بد رفتاری اعتباری", "سخت بودن پروسه خرید"] },
    { key: "afterPurchase", title: "تماس خروجی بعد خرید", items: ["رضایت از کالا", "رضایت از تحویل", "درخواست پیگیری"] }
  ];
  const MAX_ITEMS = 100;
  const MAX_ITEM_LENGTH = 300;
  const text = (value) => value == null ? "" : String(value).trim();
  const normalize = (value) => text(value).normalize("NFKC").replace(/ي/g, "ی").replace(/ك/g, "ک")
    .replace(/[\u200c\u200e\u200f]/g, " ").replace(/\s+/g, " ").trim();
  const defaultTemplates = () => Object.fromEntries(DEFINITIONS.map((item) => [item.key, [...item.items]]));
  function itemsFromLines(value) {
    const values = text(value).split(/\r?\n/).map((line) => text(line).replace(/\s+/g, " ")).filter(Boolean);
    if (values.length > MAX_ITEMS) throw new Error(`برای هر فعالیت حداکثر ${MAX_ITEMS} گزینه وارد کنید.`);
    if (values.some((item) => item.length > MAX_ITEM_LENGTH)) throw new Error(`متن هر گزینه حداکثر ${MAX_ITEM_LENGTH} نویسه باشد.`);
    const seen = new Set();
    return values.filter((item) => {
      const key = normalize(item);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function normalizeTemplates(value) {
    return Object.fromEntries(DEFINITIONS.map((definition) => {
      const source = Array.isArray(value?.[definition.key]) ? value[definition.key] : definition.items;
      const items = source.slice(0, MAX_ITEMS).map((item) => text(item).slice(0, MAX_ITEM_LENGTH)).filter(Boolean);
      return [definition.key, itemsFromLines(items.join("\n"))];
    }));
  }
  function templateForTitle(title, templates) {
    const definition = DEFINITIONS.find((item) => normalize(item.title) === normalize(title));
    return definition ? { ...definition, items: normalizeTemplates(templates)[definition.key] } : null;
  }
  function templateForKey(key, templates) {
    const definition = DEFINITIONS.find((item) => item.key === key);
    return definition ? { ...definition, items: normalizeTemplates(templates)[key] } : null;
  }
  const columns = (value) => Number(value) === 4 ? 4 : 3;
  const parse = (html) => new root.DOMParser().parseFromString(typeof html === "string" ? html : "", "text/html");
  const rows = (list) => Array.from(list.querySelectorAll(":scope > li")).map((item) => ({
    label: normalize(item.querySelector(".todo-list__label__description")?.textContent || item.textContent),
    checked: Boolean(item.querySelector('input[type="checkbox"]')?.hasAttribute("checked"))
  }));
  function todoItem(documentNode, label, checked = false) {
    const item = documentNode.createElement("li");
    const wrapper = documentNode.createElement("label");
    wrapper.className = "todo-list__label";
    const input = documentNode.createElement("input");
    input.type = "checkbox";
    input.setAttribute("disabled", "disabled");
    if (checked) input.setAttribute("checked", "checked");
    const description = documentNode.createElement("span");
    description.className = "todo-list__label__description";
    description.textContent = label;
    wrapper.append(input, description);
    item.append(wrapper);
    return item;
  }
  function ensure(note, template, { replaceUnmarked = false } = {}) {
    if (!template?.items?.length) return typeof note === "string" ? note : "";
    const documentNode = parse(note);
    const owned = documentNode.querySelector(`ul.todo-list[data-didar-call-template="${template.key}"]`);
    if (owned && !replaceUnmarked && rows(owned).some((row) => row.label)) return note;
    let target = owned || documentNode.querySelector("ul.todo-list");
    const existing = target ? rows(target) : [];
    if (!target) {
      target = documentNode.createElement("ul");
      target.className = "todo-list";
      documentNode.body.append(target);
    }
    if (replaceUnmarked) {
      const checked = new Set(existing.filter((item) => item.checked).map((item) => item.label));
      target.replaceChildren(...template.items.map((label) => todoItem(documentNode, label, checked.has(normalize(label)))));
      documentNode.querySelectorAll("ul.todo-list[data-didar-call-template]").forEach((list) => {
        if (list !== target) list.remove();
      });
    } else {
      const seen = new Set(existing.map((item) => item.label));
      template.items.forEach((label) => {
        if (!seen.has(normalize(label))) { target.append(todoItem(documentNode, label)); seen.add(normalize(label)); }
      });
    }
    target.dataset.didarCallTemplate = template.key;
    return documentNode.body.innerHTML;
  }
  function completedNotes(note, resultNote) {
    const noteDocument = parse(note);
    const lists = Array.from(noteDocument.querySelectorAll("ul.todo-list"));
    if (!lists.length) return { note, resultNote };
    const resultDocument = parse(resultNote);
    lists.forEach((list) => {
      const labels = rows(list).map((row) => row.label);
      const matched = Array.from(resultDocument.querySelectorAll("ul.todo-list")).some((other) => {
        const otherLabels = rows(other).map((row) => row.label);
        return labels.length === otherLabels.length && labels.every((label, index) => label === otherLabels[index]);
      });
      if (!matched) resultDocument.body.append(list.cloneNode(true));
      list.remove();
    });
    return { note: noteDocument.body.innerHTML.trim(), resultNote: resultDocument.body.innerHTML.trim() };
  }
  const isNewActivity = (activity) => !text(activity?.Id) || /^00000000-0000-0000-0000-000000000000$/i.test(text(activity.Id));
  const hasChecklist = (note) => Array.from(parse(note).querySelectorAll("ul.todo-list"))
    .some((list) => rows(list).some((row) => row.label));
  const BACKUP_FORMAT = "didar-quick-checklist/call-settings";
  function validateBackupSettings(value) {
    if (typeof value?.autoCallChecklist !== "boolean" || ![3, 4].includes(value.callChecklistColumns)) {
      throw new Error("تنظیمات چک‌لیست در فایل معتبر نیست.");
    }
    const templates = {};
    DEFINITIONS.forEach(({ key }) => {
      const items = value.callChecklistTemplates?.[key];
      if (!Array.isArray(items) || items.length > MAX_ITEMS || items.some((item) =>
        typeof item !== "string" || item.length > MAX_ITEM_LENGTH || /[\r\n]/.test(item))) {
        throw new Error("فهرست گزینه‌های فایل معتبر نیست.");
      }
      templates[key] = itemsFromLines(items.join("\n"));
    });
    return { autoCallChecklist: value.autoCallChecklist, callChecklistColumns: value.callChecklistColumns,
      callChecklistTemplates: templates };
  }
  function exportBackup(settings) {
    return JSON.stringify({ format: BACKUP_FORMAT, version: 1, exportedAt: new Date().toISOString(),
      settings: validateBackupSettings(settings) }, null, 2);
  }
  function importBackup(source) {
    if (typeof source !== "string" || source.length > 512 * 1024) throw new Error("حجم فایل پشتیبان بیش از حد مجاز است.");
    let value;
    try { value = JSON.parse(source); } catch { throw new Error("فایل انتخاب‌شده JSON معتبر نیست."); }
    if (value?.format !== BACKUP_FORMAT || value?.version !== 1) throw new Error("این فایل پشتیبان چک‌لیست تماس نیست یا نسخهٔ آن پشتیبانی نمی‌شود.");
    return validateBackupSettings(value.settings);
  }
  const api = { DEFINITIONS, MAX_ITEMS, MAX_ITEM_LENGTH, normalize, defaultTemplates, itemsFromLines,
    normalizeTemplates, templateForTitle, templateForKey, columns, ensure, completedNotes, isNewActivity, hasChecklist,
    exportBackup, importBackup };
  root.DidarCallChecklists = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
/* END GENERATED CALL CHECKLISTS */
(function initializeDidarPageBridge() {
  "use strict";

  if (globalThis.__didarQuickChecklistPageBridgeLoaded) {
    return;
  }
  globalThis.__didarQuickChecklistPageBridgeLoaded = true;

  const GUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";
  const RESOLVE_EVENT = "didar-quick-checklist:resolve";
  const PLAN_ACTIVITY_CREATED_EVENT = "didar-quick-checklist:plan-activity-created";
  const PLAN_ACTIVITY_DELETED_EVENT = "didar-quick-checklist:plan-activity-deleted";
  const DEAL_PRODUCTS_UPDATED_EVENT = "didar-quick-checklist:deal-products-updated";
  const DEAL_PRODUCTS_SYNCED_EVENT = "didar-quick-checklist:deal-products-synced";
  const ACTIVITY_COMPLETED_EVENT = "didar-quick-checklist:activity-completed";
  const ACTIVITY_SAVED_EVENT = "didar-quick-checklist:activity-saved";
  const ACTIVITY_COMPLETION_SYNCED_EVENT = "didar-quick-checklist:activity-completion-synced";
  const ACTIVITY_CREATED_REFRESH_EVENT = "didar-quick-checklist:activity-created-refresh";
  const ACTIVITY_CREATED_REFRESHED_EVENT = "didar-quick-checklist:activity-created-refreshed";
  const NATIVE_QUICK_ACTIVITY_CREATE_EVENT = "didar-quick-checklist:native-quick-activity-create";
  const NATIVE_QUICK_ACTIVITY_STARTED_EVENT = "didar-quick-checklist:native-quick-activity-started";
  const NATIVE_ACTIVITY_DONE_ARM_EVENT = "didar-quick-checklist:native-activity-done-arm";
  const NATIVE_ACTIVITY_DONE_ARMED_EVENT = "didar-quick-checklist:native-activity-done-armed";
  const NATIVE_ACTIVITY_DONE_FINISHED_EVENT = "didar-quick-checklist:native-activity-done-finished";
  const DEAL_ADD_PERSON_SELECTED_EVENT = "didar-quick-checklist:deal-add-person-selected";
  const MANUAL_DEAL_ATTACH_EVENT = "didar-quick-checklist:manual-deal-attach";
  const MANUAL_DEAL_ATTACH_DONE_EVENT = "didar-quick-checklist:manual-deal-attach-done";
  const GLOBAL_SEARCH_RESULTS_EVENT = "didar-quick-checklist:global-search-results";
  const PIPELINE_ACTIVITY_FILTER_EVENT = "didar-quick-checklist:pipeline-activity-filter";
  const PLAN_TITLE_PREFIX = "شروع طرح";
  const PLAN_TODO_LABELS = [
    "تشکیل پرونده",
    "ارجاع به بانک",
    "نوبت امضا",
    "تحویل کالا کارت",
    "ناموفق شدن طرح"
  ];
  const capturedActivities = new Map();
  const CallChecklists = globalThis.DidarCallChecklists;
  const callActivityTypeKeys = new Map();
  const callEditorControllers = new WeakMap();
  const callEditorHooks = new WeakSet();
  const initializedCallDrafts = new WeakMap();
  let capturedActivitiesPage = location.pathname;
  const publishedPlanActivities = new Set();
  const publishedPlanActivityDeletions = new Set();
  const pendingNativeActivityCompletions = new Map();
  let scanTimer = null;
  let planCreationSequence = 0;
  let planDeletionSequence = 0;
  let pipelineActivityDealFilter = { active: false, dealIds: new Set() };
  const pipelineFilteredXhrResponses = new WeakMap();
  let angularViewRegistry = null;
  const originalMapSet = Map.prototype.set;
  function captureAngularViewRegistry(key, value) {
    // Angular's production build patches DOM nodes with an LView number and
    // stores the corresponding view in a module-private Map.
    if (!angularViewRegistry && Number.isInteger(key) && Array.isArray(value) &&
      value[19] === key && Array.isArray(value[1]?.blueprint) &&
      Array.isArray(value[1]?.data)) {
      angularViewRegistry = this;
      if (Map.prototype.set === captureAngularViewRegistry) {
        Map.prototype.set = originalMapSet;
      }
    }
    return originalMapSet.call(this, key, value);
  }
  Map.prototype.set = captureAngularViewRegistry;
  window.setTimeout(() => {
    if (!angularViewRegistry && Map.prototype.set === captureAngularViewRegistry) {
      Map.prototype.set = originalMapSet;
    }
  }, 60000);

  function normalize(value) {
    return String(value == null ? "" : value)
      .replace(/\s+/g, " ")
      .trim();
  }

  function activityBelongsToPage(activity) {
    const dealId = location.pathname.match(/\/deal\/([0-9a-f-]{36})/i)?.[1]?.toLowerCase();
    const caseId = location.pathname.match(/\/case\/([0-9a-f-]{36})/i)?.[1]?.toLowerCase();
    const activityDealId = normalize(activity?.DealId).toLowerCase();
    const activityCaseId = normalize(activity?.CaseId).toLowerCase();
    return activity?.IsDeleted !== true &&
      (!caseId || !GUID_PATTERN.test(activityCaseId) || activityCaseId === caseId) &&
      (!dealId || !GUID_PATTERN.test(activityDealId) || activityDealId === dealId);
  }

  function matchesRowLabels(activity, rows) {
    const activityRows = rowsFromHtml(activityTodoNote(activity));
    return rows.length > 0 && activityRows.length === rows.length &&
      activityRows.every((row, index) => row.label === rows[index].label);
  }

  function createTodoItem(documentNode, label) {
    const item = documentNode.createElement("li");
    const wrapper = documentNode.createElement("label");
    wrapper.className = "todo-list__label";
    const input = documentNode.createElement("input");
    input.type = "checkbox";
    input.disabled = true;
    input.setAttribute("disabled", "disabled");
    const description = documentNode.createElement("span");
    description.className = "todo-list__label__description";
    description.textContent = label;
    wrapper.append(input, description);
    item.appendChild(wrapper);
    return item;
  }

  function ensurePlanChecklist(note) {
    const documentNode = new DOMParser().parseFromString(
      typeof note === "string" ? note : "",
      "text/html"
    );
    const lists = Array.from(documentNode.querySelectorAll("ul.todo-list"));
    let targetList = null;
    let bestOverlap = 0;
    lists.forEach((list) => {
      const labels = new Set(rowsFromList(list).map((row) => row.label));
      const overlap = PLAN_TODO_LABELS.filter((label) => labels.has(label)).length;
      if (overlap > bestOverlap) {
        bestOverlap = overlap;
        targetList = list;
      }
    });
    if (!targetList) {
      targetList = documentNode.createElement("ul");
      targetList.className = "todo-list";
      documentNode.body.appendChild(targetList);
    }
    const existing = new Set(rowsFromList(targetList).map((row) => row.label));
    PLAN_TODO_LABELS.forEach((label) => {
      if (!existing.has(label)) {
        targetList.appendChild(createTodoItem(documentNode, label));
      }
    });
    return documentNode.body.innerHTML;
  }

  function planChecklistElement(documentNode) {
    let targetList = null;
    let bestOverlap = 0;
    Array.from(documentNode.querySelectorAll("ul.todo-list")).forEach((list) => {
      const labels = new Set(rowsFromList(list).map((row) => row.label));
      const overlap = PLAN_TODO_LABELS.filter((label) => labels.has(label)).length;
      if (overlap > bestOverlap) {
        bestOverlap = overlap;
        targetList = list;
      }
    });
    return targetList;
  }

  function completedPlanNotes(note, resultNote) {
    const noteDocument = new DOMParser().parseFromString(
      typeof note === "string" ? note : "",
      "text/html"
    );
    const sourceChecklist = planChecklistElement(noteDocument);
    const resultDocument = new DOMParser().parseFromString(
      typeof resultNote === "string" ? resultNote : "",
      "text/html"
    );
    if (!planChecklistElement(resultDocument) && sourceChecklist) {
      resultDocument.body.appendChild(sourceChecklist.cloneNode(true));
    }
    if (sourceChecklist) {
      sourceChecklist.remove();
    }
    return {
      note: noteDocument.body.innerHTML.trim(),
      resultNote: ensurePlanChecklist(resultDocument.body.innerHTML)
    };
  }

  function rewriteSaveBody(url, body) {
    if (
      !/activity\/(?:SaveActivity|save)\/?(?:\?|$)/i.test(String(url || "")) ||
      typeof body !== "string"
    ) {
      return body;
    }
    try {
      const payload = JSON.parse(body);
      const activity = payload?.Activity;
      if (!activity) {
        return body;
      }
      if (activity.IsDeleted === true || payload.IsDeleted === true) {
        return body;
      }
      const callConfig = readCallChecklistConfig();
      const callTemplate = callTemplateForActivity(activity, callConfig);
      if (callConfig.enabled && callTemplate) {
        // Match the start-plan save path: a native/client-assigned Id or an
        // existing empty activity must not prevent checklist insertion.
        // Any existing checklist is a snapshot; never regenerate its rows.
        const completed = payload.SetDone === true || activity.IsDone === true;
        if (!CallChecklists.hasChecklist(activity.Note) && !CallChecklists.hasChecklist(activity.ResultNote)) {
          const field = completed ? "ResultNote" : "Note";
          activity[field] = CallChecklists.ensure(activity[field], callTemplate);
        }
        if (completed) {
          const completed = CallChecklists.completedNotes(activity.Note, activity.ResultNote);
          activity.Note = completed.note;
          activity.ResultNote = completed.resultNote;
        }
        return JSON.stringify(payload);
      }
      if (document.documentElement?.dataset.didarAutoPlanChecklist !== "true" ||
          !normalize(activity.Title).startsWith(PLAN_TITLE_PREFIX)) return body;
      if (payload.SetDone === true || activity.IsDone === true) {
        const completedNotes = completedPlanNotes(activity.Note, activity.ResultNote);
        activity.Note = completedNotes.note;
        activity.ResultNote = completedNotes.resultNote;
      } else {
        activity.Note = ensurePlanChecklist(activity.Note);
        if (
          typeof activity.ResultNote === "string" &&
          rowsFromHtml(activity.ResultNote).length
        ) {
          activity.ResultNote = ensurePlanChecklist(activity.ResultNote);
        }
      }
      return JSON.stringify(payload);
    } catch {
      return body;
    }
  }

  function readCallChecklistConfig() {
    if (!CallChecklists) return { enabled: false };
    try {
      const marker = document.getElementById("didar-call-checklist-config");
      const value = JSON.parse(marker?.getAttribute("content") || marker?.textContent || "null");
      return { enabled: value?.enabled === true || document.documentElement?.dataset.didarAutoCallChecklist === "true",
        templates: CallChecklists.normalizeTemplates(value?.templates) };
    } catch { return { enabled: false }; }
  }

  function callTemplateForActivity(activity, config, controller) {
    if (!CallChecklists || !activity) return null;
    const typeId = normalize(activity.ActivityTypeId).toLowerCase();
    const type = controller?.activityService?.getById?.(activity.ActivityTypeId) ||
      controller?.activityService?.enabledTaskTypes?.find((item) => normalize(item.Id).toLowerCase() === typeId);
    const fromType = type && CallChecklists.templateForTitle(type.Title || type.Name, config.templates);
    if (fromType && GUID_PATTERN.test(typeId)) callActivityTypeKeys.set(typeId, fromType.key);
    return fromType || CallChecklists.templateForKey(callActivityTypeKeys.get(typeId), config.templates) ||
      CallChecklists.templateForTitle(activity.Title, config.templates);
  }

  function captureCallActivityTypes(url, payload) {
    if (!CallChecklists || !/activity\/GetActivityType(?:\?|$)/i.test(String(url || ""))) return;
    const queue = [payload];
    let count = 0;
    while (queue.length && count++ < 1000) {
      const value = queue.shift();
      if (!value || typeof value !== "object") continue;
      const template = CallChecklists.templateForTitle(value.Title || value.Name);
      if (template && GUID_PATTERN.test(normalize(value.Id))) callActivityTypeKeys.set(normalize(value.Id).toLowerCase(), template.key);
      queue.push(...Object.values(value).filter((item) => item && typeof item === "object"));
    }
  }

  function applyCallDraft(controller, host, replaceUnmarked = false) {
    const config = readCallChecklistConfig();
    if (!config.enabled || !controller?.activity || controller.isLoading) return;
    let template;
    try { template = callTemplateForActivity(controller.activity, config, controller); } catch { return; }
    if (!template) { host.removeAttribute("data-didar-call-template"); return; }
    host.dataset.didarCallTemplate = template.key;
    const field = controller.isDone || controller.setDone || controller.activity.IsDone ? "ResultNote" : "Note";
    const draftKey = `${template.key}:${field}`;
    if (!CallChecklists.isNewActivity(controller.activity) || !template.items.length ||
        (!replaceUnmarked && initializedCallDrafts.get(controller.activity) === draftKey)) return;
    if (field === "ResultNote" && CallChecklists.hasChecklist(controller.activity.Note)) {
      const moved = CallChecklists.completedNotes(controller.activity.Note, controller.activity.ResultNote);
      controller.activity.Note = moved.note;
      controller.activity.ResultNote = moved.resultNote;
    }
    const before = typeof controller.activity[field] === "string" ? controller.activity[field] : "";
    const next = CallChecklists.ensure(before, template, { replaceUnmarked: replaceUnmarked || host.dataset.didarCallDraftDirty !== "true" });
    initializedCallDrafts.set(controller.activity, draftKey);
    if (field === "Note") controller.hasDesc = true;
    if (next === before) return;
    controller.activity[field] = next;
    // Native forms can contain BOTH Note (isMention=false) and ResultNote
    // (isMention=true). Writing the first CKEditor can update the wrong model.
    const wrappers = Array.from(host.querySelectorAll("app-ckeditor"));
    let editor = null;
    for (const wrapper of wrappers) {
      const component = componentCandidates(wrapper).find((value) =>
        value?.editorComponent?.editorInstance && value.isMention === (field === "ResultNote"));
      if (component) { editor = component.editorComponent.editorInstance; break; }
    }
    for (const value of wrappers.length ? [] : componentCandidates(host)) {
      if (typeof value?.getData !== "function" || typeof value?.setData !== "function") continue;
      const editable = value.ui?.view?.editable?.element || value.sourceElement;
      if (!editable || !host.contains(editable)) continue;
      editor = value;
      break;
    }
    try { editor?.setData(next); } catch {}
    try { controller.cdr?.markForCheck?.(); controller.cdr?.detectChanges?.(); } catch {}
  }

  function enhanceCallActivityEditors() {
    if (!CallChecklists || document.readyState === "loading" || !readCallChecklistConfig().enabled) return;
    document.querySelectorAll("lc-activity-add, lc-activity-add-inline").forEach((host) => {
      let controller = callEditorControllers.get(host);
      if (!controller) {
        controller = componentCandidates(host).find((item) => item?.activity &&
          typeof item.selectActivityType === "function" && typeof item.save === "function");
        if (controller) callEditorControllers.set(host, controller);
      }
      if (!controller) return;
      if (!callEditorHooks.has(controller)) {
        const original = controller.selectActivityType;
        try {
          controller.selectActivityType = function selectActivityWithCallChecklist(...args) {
            const result = original.apply(this, args);
            const finish = () => {
              const config = readCallChecklistConfig();
              const type = args[0];
              const template = CallChecklists.templateForTitle(type?.Title || type?.Name, config.templates);
              if (template && GUID_PATTERN.test(normalize(type?.Id))) callActivityTypeKeys.set(normalize(type.Id).toLowerCase(), template.key);
              applyCallDraft(this, host, true);
              scheduleScan();
            };
            finish();
            if (result && typeof result.then === "function") void result.then(finish).catch(() => {});
            return result;
          };
          callEditorHooks.add(controller);
        } catch { /* The save-request fallback still inserts the checklist. */ }
      }
      applyCallDraft(controller, host);
    });
  }

  function planCreationContext(url, body) {
    if (
      document.documentElement?.dataset.didarAutoAddPlanProduct !== "true" ||
      !/activity\/SaveActivity(?:\?|$)/i.test(String(url || "")) ||
      typeof body !== "string"
    ) {
      return null;
    }
    try {
      const payload = JSON.parse(body);
      const activity = payload?.Activity;
      const activityId = normalize(activity?.Id).toLowerCase();
      const dealId = normalize(activity?.DealId);
      const title = normalize(activity?.Title);
      const isNew = !activityId || activityId === EMPTY_GUID;
      if (!GUID_PATTERN.test(dealId) || !title.startsWith(PLAN_TITLE_PREFIX) ||
          activity?.IsDeleted === true || payload?.IsDeleted === true) {
        return null;
      }
      planCreationSequence += 1;
      return {
        creationId: `${Date.now()}-${planCreationSequence}`,
        activityId: isNew ? "" : activityId,
        bindCreatedCard: isNew,
        dealId,
        title
      };
    } catch {
      return null;
    }
  }

  function planDeletionContext(url, body) {
    const requestUrl = String(url || "");
    const isSaveRequest = /activity\/(?:SaveActivity|save)(?:\?|$)/i.test(requestUrl);
    const isDeleteRequest = /activity\/(?:DeleteActivity|RemoveActivity)(?:\?|$)/i.test(requestUrl);
    if ((!isSaveRequest && !isDeleteRequest) || typeof body !== "string") {
      return null;
    }
    try {
      const payload = JSON.parse(body);
      const activity = payload?.Activity || payload;
      const isDeletion = isDeleteRequest || activity?.IsDeleted === true || payload?.IsDeleted === true;
      if (!isDeletion) {
        return null;
      }
      const activityId = normalize(
        activity?.Id || activity?.ActivityId || payload?.ActivityId || payload?.Id
      ).toLowerCase();
      if (!GUID_PATTERN.test(activityId) || activityId === EMPTY_GUID) {
        return null;
      }
      const capturedKey = Array.from(capturedActivities.keys()).find(
        (id) => normalize(id).toLowerCase() === activityId
      );
      const captured = capturedActivities.get(activityId) || capturedActivities.get(capturedKey);
      const dealId = normalize(
        activity?.DealId || payload?.DealId || captured?.DealId ||
          location.pathname.match(/\/deal\/([0-9a-f-]{36})/i)?.[1]
      ).toLowerCase();
      const title = normalize(activity?.Title || captured?.Title);
      planDeletionSequence += 1;
      return {
        requestId: `${Date.now()}-${planDeletionSequence}`,
        activityId,
        dealId: GUID_PATTERN.test(dealId) ? dealId : "",
        title
      };
    } catch {
      return null;
    }
  }

  function publishPlanActivityCreated(context, payload) {
    if (!context || payload?.Error || payload?.Message || payload?.Response?.Error || payload?.Response?.Message) {
      return;
    }
    const response = payload?.Response ?? payload;
    const activityId = normalize(response?.Id || response?.Activity?.Id || response?.ActivityId ||
      (typeof response === "string" ? response : context.activityId));
    if (response === false || response?.IsDeleted === true ||
        !GUID_PATTERN.test(activityId) || activityId === EMPTY_GUID) {
      return;
    }
    if (publishedPlanActivities.has(context.creationId)) {
      return;
    }
    publishedPlanActivities.add(context.creationId);
    document.dispatchEvent(
      new CustomEvent(PLAN_ACTIVITY_CREATED_EVENT, {
        detail: {
          activityId,
          creationId: context.creationId,
          dealId: context.dealId,
          title: context.title,
          bindCreatedCard: context.bindCreatedCard
        }
      })
    );
  }

  function publishPlanActivityDeleted(context, payload) {
    if (!context || payload?.Error || payload?.Message) {
      return;
    }
    if (publishedPlanActivityDeletions.has(context.requestId)) {
      return;
    }
    publishedPlanActivityDeletions.add(context.requestId);
    capturedActivities.delete(context.activityId);
    document.dispatchEvent(
      new CustomEvent(PLAN_ACTIVITY_DELETED_EVENT, {
        detail: {
          activityId: context.activityId,
          dealId: context.dealId,
          title: context.title
        }
      })
    );
  }

  function captureDealDetailResponse(url, payload) {
    if (!/deal\/GetDealDetail(?:_v2)?(?:\?|$)/i.test(String(url || ""))) {
      return;
    }
    const deal = payload?.Response ?? payload?.data ?? payload;
    const dealId = normalize(deal?.Id).toLowerCase();
    if (!GUID_PATTERN.test(dealId)) {
      return;
    }
  }

  function publishDealAddPersonSelected(url) {
    let requestUrl;
    try {
      requestUrl = new URL(String(url || ""), location.href);
    } catch {
      return;
    }
    if (!/\/api\/datawarehouse\/GetPersonSummary$/i.test(requestUrl.pathname)) {
      return;
    }
    const personId = normalize(requestUrl.searchParams.get("personId")).toLowerCase();
    if (!GUID_PATTERN.test(personId)) {
      return;
    }
    const marker = document.createElement("meta");
    marker.hidden = true;
    marker.dataset.didarDealAddPersonId = personId;
    marker.dataset.didarDealAddPersonTime = String(Date.now());
    document.documentElement.appendChild(marker);
    marker.dispatchEvent(
      new CustomEvent(DEAL_ADD_PERSON_SELECTED_EVENT, {
        bubbles: true,
        detail: { personId }
      })
    );
    window.setTimeout(() => marker.remove(), 15000);
  }

  function globalSearchDealsFromPayload(payload) {
    const deals = [];
    const queue = [payload?.Response ?? payload?.data ?? payload];
    const visited = new WeakSet();
    let inspected = 0;
    while (queue.length && inspected < 5000) {
      const value = queue.shift();
      if (!value || typeof value !== "object" || visited.has(value)) {
        continue;
      }
      visited.add(value);
      inspected += 1;
      if (isGlobalSearchDeal(value)) {
        deals.push({
          id: normalize(value.Id ?? value.id).toLowerCase(),
          title: normalize(value.Title ?? value.title)
        });
        continue;
      }
      if (Array.isArray(value)) {
        value.forEach((item) => queue.push(item));
        continue;
      }
      Object.keys(value).forEach((key) => {
        try {
          const child = value[key];
          if (child && typeof child === "object") {
            queue.push(child);
          }
        } catch {
          // Ignore response properties that cannot be read.
        }
      });
    }
    return deals;
  }

  function publishGlobalSearchResults(url, payload) {
    if (!/search\/search(?:\?|$)/i.test(String(url || ""))) {
      return;
    }
    const marker = document.createElement("meta");
    marker.hidden = true;
    marker.dataset.didarGlobalSearchResults = String(Date.now());
    marker.textContent = JSON.stringify({ deals: globalSearchDealsFromPayload(payload) });
    document.documentElement.appendChild(marker);
    marker.dispatchEvent(new CustomEvent(GLOBAL_SEARCH_RESULTS_EVENT, { bubbles: true }));
    window.setTimeout(() => marker.remove(), 15000);
  }

  function markerDetail(marker) {
    try {
      return JSON.parse(marker?.textContent || "{}");
    } catch {
      return {};
    }
  }

  function handleNativeQuickActivityCreate(event) {
    const marker = event.target?.matches?.("meta[data-didar-native-quick-activity-request]")
      ? event.target
      : null;
    const detail = markerDetail(marker);
    const requestId = normalize(detail?.requestId);
    const dealId = normalize(detail?.dealId).toLowerCase();
    const activityTypeId = normalize(detail?.activityTypeId).toLowerCase();
    const title = normalize(detail?.title);
    if (
      !marker ||
      !requestId ||
      !GUID_PATTERN.test(dealId) ||
      !GUID_PATTERN.test(activityTypeId) ||
      !title.startsWith(PLAN_TITLE_PREFIX)
    ) {
      if (marker) {
        marker.dataset.didarNativeQuickActivityResult = "false";
        marker.dataset.didarNativeQuickActivityMethod = "invalid";
        marker.dispatchEvent(new Event(NATIVE_QUICK_ACTIVITY_STARTED_EVENT));
      }
      return;
    }

    let attempt = 0;
    const finish = (succeeded, method) => {
      marker.dataset.didarNativeQuickActivityResult = succeeded ? "true" : "false";
      marker.dataset.didarNativeQuickActivityMethod = method;
      marker.dispatchEvent(new Event(NATIVE_QUICK_ACTIVITY_STARTED_EVENT));
    };
    const tryStart = () => {
      attempt += 1;
      const hosts = Array.from(document.querySelectorAll("lc-activity-add"));
      for (const host of hosts.reverse()) {
        const controller = componentCandidates(host).find(
          (value) =>
            typeof value?.selectActivityType === "function" &&
            typeof value?.save === "function" &&
            value?.activity &&
            value?.activityService
        );
        if (!controller || controller.isLoading) {
          continue;
        }
        const controllerDealId = normalize(
          controller.activity?.DealId || controller.dealId || controller.deal?.Id
        ).toLowerCase();
        if (controllerDealId && controllerDealId !== dealId) {
          continue;
        }
        const type = controller.activityService.getById?.(activityTypeId) ||
          controller.activityService.enabledTaskTypes?.find(
            (item) => normalize(item?.Id).toLowerCase() === activityTypeId
          );
        if (!type) {
          continue;
        }
        try {
          controller.selectActivityType(type);
          controller.activity.Title = title;
          controller.activity.DealId = dealId;
          controller.save(false);
          finish(true, "didar-native-component");
          return;
        } catch {
          finish(false, "didar-native-component-error");
          return;
        }
      }
      if (attempt < 30) {
        window.setTimeout(tryStart, 100);
      } else {
        finish(false, "didar-native-component-unavailable");
      }
    };
    tryStart();
  }

  function finishNativeActivityCompletion(pending, succeeded, method) {
    if (!pending || !pendingNativeActivityCompletions.delete(pending.requestId)) {
      return;
    }
    window.clearTimeout(pending.timeoutId);
    pending.marker.dataset.didarNativeActivityDoneResult = succeeded ? "true" : "false";
    pending.marker.dataset.didarNativeActivityDoneMethod = method;
    pending.marker.dispatchEvent(new Event(NATIVE_ACTIVITY_DONE_FINISHED_EVENT));
  }

  function handleNativeActivityDoneArm(event) {
    const marker = event.target?.matches?.("meta[data-didar-native-activity-done-request]")
      ? event.target
      : null;
    const detail = markerDetail(marker);
    const requestId = normalize(detail?.requestId);
    const activityId = normalize(detail?.activityId).toLowerCase();
    if (!marker || !requestId || !GUID_PATTERN.test(activityId)) {
      if (marker) {
        marker.dataset.didarNativeActivityDoneArmed = "false";
        marker.dispatchEvent(new Event(NATIVE_ACTIVITY_DONE_ARMED_EVENT));
      }
      return;
    }
    const pending = {
      requestId,
      activityId,
      resultNote: typeof detail.resultNote === "string" ? detail.resultNote : "",
      marker,
      requestStarted: false,
      timeoutId: null
    };
    pending.timeoutId = window.setTimeout(() => {
      finishNativeActivityCompletion(
        pending,
        false,
        pending.requestStarted ? "didar-done-timeout" : "didar-done-not-started"
      );
    }, 9000);
    pendingNativeActivityCompletions.set(requestId, pending);
    marker.dataset.didarNativeActivityDoneArmed = "true";
    marker.dispatchEvent(new Event(NATIVE_ACTIVITY_DONE_ARMED_EVENT));
  }

  function rewriteNativeActivityDoneBody(url, body) {
    if (!/activity\/DoneActivity(?:\?|$)/i.test(String(url || "")) || typeof body !== "string") {
      return { body, pending: null };
    }
    try {
      const submitted = JSON.parse(body);
      const activityId = normalize(submitted?.Id).toLowerCase();
      const pending = Array.from(pendingNativeActivityCompletions.values()).find(
        (item) => item.activityId === activityId && !item.requestStarted
      );
      if (!pending) {
        return { body, pending: null };
      }
      pending.requestStarted = true;
      return {
        body: JSON.stringify({ ...submitted, ResultNote: pending.resultNote }),
        pending
      };
    } catch {
      return { body, pending: null };
    }
  }

  function captureNativeActivityDoneResponse(pending, succeeded) {
    finishNativeActivityCompletion(
      pending,
      succeeded,
      succeeded ? "didar-native-done" : "didar-native-done-failed"
    );
  }

  function rowsFromList(todoList) {
    return Array.from(todoList.querySelectorAll(":scope > li")).map((item) => {
      const input = item.querySelector('input[type="checkbox"]');
      const description = item.querySelector(".todo-list__label__description");
      return {
        label: normalize(description?.textContent || item.textContent),
        checked: Boolean(input?.checked || input?.hasAttribute("checked"))
      };
    });
  }

  function rowsFromHtml(note) {
    const documentNode = new DOMParser().parseFromString(normalize(note), "text/html");
    return Array.from(documentNode.querySelectorAll("ul.todo-list > li")).map((item) => {
      const input = item.querySelector('input[type="checkbox"]');
      const description = item.querySelector(".todo-list__label__description");
      return {
        label: normalize(description?.textContent || item.textContent),
        checked: Boolean(input?.checked || input?.hasAttribute("checked"))
      };
    });
  }

  function isActivity(value) {
    return Boolean(
      value &&
        typeof value === "object" &&
        GUID_PATTERN.test(normalize(value.Id)) &&
        (typeof value.ResultNote === "string" || typeof value.Note === "string") &&
        ("ActivityTypeId" in value || "DueDate" in value)
    );
  }

  function activityTodoNote(activity) {
    const candidates = activity?.IsDone === false
      ? [activity.Note, activity.ResultNote]
      : [activity.ResultNote, activity.Note];
    for (const note of candidates) {
      if (typeof note !== "string") {
        continue;
      }
      try {
        if (rowsFromHtml(note).length) {
          return note;
        }
      } catch {
        // Try the other note field.
      }
    }
    return "";
  }

  function captureActivities(payload) {
    if (capturedActivitiesPage !== location.pathname) {
      capturedActivities.clear();
      capturedActivitiesPage = location.pathname;
    }
    const queue = [payload];
    const visited = new WeakSet();
    let inspected = 0;
    while (queue.length && inspected < 30000) {
      const value = queue.shift();
      if (!value || typeof value !== "object" || visited.has(value)) {
        continue;
      }
      visited.add(value);
      inspected += 1;
      if (isActivity(value)) {
        capturedActivities.set(normalize(value.Id).toLowerCase(), value);
      }
      if (Array.isArray(value)) {
        queue.push(...value);
      } else {
        Object.values(value).forEach((child) => {
          if (child && typeof child === "object") {
            queue.push(child);
          }
        });
      }
    }
    scheduleScan();
  }

  function captureJsonText(value) {
    if (typeof value !== "string" || !value.trim().startsWith("{")) {
      return;
    }
    try {
      captureActivities(JSON.parse(value));
    } catch {
      // Only JSON API responses are relevant.
    }
  }

  function isPipelineRequest(url) {
    return /deal\/GetPipeline(?:\?|$)/i.test(String(url || ""));
  }

  function rewritePipelineRequestBody(url, body) {
    if (!pipelineActivityDealFilter.active || !isPipelineRequest(url) || typeof body !== "string") {
      return body;
    }
    try {
      const payload = JSON.parse(body);
      payload.From = 0;
      payload.Limit = Math.max(10000, Number(payload.Limit) || 0);
      return JSON.stringify(payload);
    } catch {
      return body;
    }
  }

  function pipelineDealRow(value) {
    return Boolean(
      value &&
      typeof value === "object" &&
      GUID_PATTERN.test(normalize(value.Id)) &&
      ("PipelineStageId" in value || "Status" in value || "Title" in value)
    );
  }

  function pipelineDealValue(deal) {
    for (const key of ["Value", "Amount", "Price", "TotalValue"]) {
      const value = Number(deal?.[key]);
      if (Number.isFinite(value)) {
        return value;
      }
    }
    return 0;
  }

  function adjustPipelineSummary(summary, deals) {
    if (!summary || typeof summary !== "object" || Array.isArray(summary)) {
      return;
    }
    const totalValue = deals.reduce((sum, deal) => sum + pipelineDealValue(deal), 0);
    Object.keys(summary).forEach((key) => {
      const normalizedKey = key.toLowerCase();
      if (summary[key] && typeof summary[key] === "object") {
        let scopedDeals = deals;
        if (normalizedKey.includes("pending")) {
          scopedDeals = deals.filter((deal) => normalize(deal.Status).toLowerCase() === "pending");
        } else if (normalizedKey.includes("won")) {
          scopedDeals = deals.filter((deal) => normalize(deal.Status).toLowerCase() === "won");
        } else if (normalizedKey.includes("lost")) {
          scopedDeals = deals.filter((deal) => normalize(deal.Status).toLowerCase() === "lost");
        }
        adjustPipelineSummary(summary[key], scopedDeals);
      } else if (/^(count|totalcount|dealcount|number)$/.test(normalizedKey)) {
        summary[key] = deals.length;
      } else if (/^(value|totalvalue|amount|totalamount|sum)$/.test(normalizedKey)) {
        summary[key] = totalValue;
      }
    });
  }

  function filterPipelinePayload(payload) {
    if (!pipelineActivityDealFilter.active || !payload || typeof payload !== "object") {
      return { payload, changed: false };
    }
    let clone;
    try {
      clone = JSON.parse(JSON.stringify(payload));
    } catch {
      return { payload, changed: false };
    }
    let changed = false;
    const visited = new Set();
    const walk = (value) => {
      if (!value || typeof value !== "object" || visited.has(value)) {
        return;
      }
      visited.add(value);
      if (Array.isArray(value.List) && value.List.some(pipelineDealRow)) {
        value.List = value.List.filter((deal) =>
          pipelineActivityDealFilter.dealIds.has(normalize(deal.Id).toLowerCase())
        );
        for (const key of ["Count", "Total", "TotalCount", "DealCount"]) {
          if (Object.prototype.hasOwnProperty.call(value, key)) {
            value[key] = value.List.length;
          }
        }
        adjustPipelineSummary(value.Info, value.List);
        changed = true;
      }
      Object.values(value).forEach(walk);
    };
    walk(clone);
    return { payload: clone, changed };
  }

  async function filterPipelineFetchResponse(url, response) {
    if (!pipelineActivityDealFilter.active || !isPipelineRequest(url) || !response?.clone) {
      return response;
    }
    try {
      const originalPayload = await response.clone().json();
      const filtered = filterPipelinePayload(originalPayload);
      if (!filtered.changed || typeof Response !== "function") {
        return response;
      }
      const headers = new Headers(response.headers || undefined);
      headers.delete("content-length");
      return new Response(JSON.stringify(filtered.payload), {
        status: response.status,
        statusText: response.statusText,
        headers
      });
    } catch {
      return response;
    }
  }

  function patchPipelineXhrResponse(xhr, url) {
    if (!pipelineActivityDealFilter.active || !isPipelineRequest(url)) {
      return;
    }
    try {
      const originalPayload = xhr.responseType === "json"
        ? xhr.response
        : JSON.parse(xhr.responseText);
      const filtered = filterPipelinePayload(originalPayload);
      if (!filtered.changed) {
        return;
      }
      const replacement = {
        payload: filtered.payload,
        text: JSON.stringify(filtered.payload)
      };
      pipelineFilteredXhrResponses.set(xhr, replacement);
      try {
        Object.defineProperty(xhr, "responseText", {
          configurable: true,
          get: () => replacement.text
        });
        Object.defineProperty(xhr, "response", {
          configurable: true,
          get: () => xhr.responseType === "json" ? replacement.payload : replacement.text
        });
      } catch {
        // Prototype-level getters below cover browsers that reject instance properties.
      }
    } catch {
      // Leave Didar's native response untouched if its schema changes.
    }
  }

  function installFilteredXhrGetter(property, transform) {
    const descriptor = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, property);
    if (!descriptor?.get || descriptor.configurable === false) {
      return;
    }
    Object.defineProperty(XMLHttpRequest.prototype, property, {
      ...descriptor,
      get() {
        const replacement = pipelineFilteredXhrResponses.get(this);
        return replacement ? transform(replacement, this) : descriptor.get.call(this);
      }
    });
  }

  installFilteredXhrGetter("responseText", (replacement) => replacement.text);
  installFilteredXhrGetter(
    "response",
    (replacement, xhr) => xhr.responseType === "json" ? replacement.payload : replacement.text
  );

  function handlePipelineActivityFilter(event) {
    const marker = event.target?.matches?.("meta[data-didar-pipeline-activity-filter]")
      ? event.target
      : null;
    const detail = markerDetail(marker);
    pipelineActivityDealFilter = {
      active: detail?.active === true,
      dealIds: new Set(
        Array.isArray(detail?.dealIds)
          ? detail.dealIds.map((id) => normalize(id).toLowerCase()).filter((id) => GUID_PATTERN.test(id))
          : []
      )
    };
  }

  const nativeFetch = window.fetch;
  if (typeof nativeFetch === "function") {
    window.fetch = async function didarTodoObservedFetch(...args) {
      const requestUrl = typeof args[0] === "string" ? args[0] : args[0]?.url;
      const creationContext = planCreationContext(requestUrl, args[1]?.body);
      const deletionContext = planDeletionContext(requestUrl, args[1]?.body);
      let nativeActivityDoneContext = null;
      if (args[1]?.body !== undefined) {
        args[1] = {
          ...args[1],
          body: rewritePipelineRequestBody(requestUrl, args[1].body)
        };
        const rewrittenActivityDone = rewriteNativeActivityDoneBody(
          requestUrl,
          args[1].body
        );
        nativeActivityDoneContext = rewrittenActivityDone.pending;
        args[1] = {
          ...args[1],
          body: rewriteSaveBody(requestUrl, rewrittenActivityDone.body)
        };
      }
      let response = await Reflect.apply(nativeFetch, window, args);
      response = await filterPipelineFetchResponse(requestUrl, response);
      captureNativeActivityDoneResponse(nativeActivityDoneContext, response.ok !== false);
      if (response.ok !== false) {
        publishDealAddPersonSelected(requestUrl);
      }
      try {
        response
          .clone()
          .json()
          .then((payload) => {
            captureCallActivityTypes(requestUrl, payload);
            captureActivities(payload);
            captureDealDetailResponse(requestUrl, payload);
            publishGlobalSearchResults(requestUrl, payload);
            if (response.ok !== false) {
              publishPlanActivityCreated(creationContext, payload);
              publishPlanActivityDeleted(deletionContext, payload);
            }
          })
          .catch(() => {
            if (response.ok !== false) {
              publishPlanActivityDeleted(deletionContext, null);
            }
          });
      } catch {
        // Preserve the page request even if cloning is unavailable.
      }
      return response;
    };
  }

  const nativeXhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function didarTodoObservedXhrOpen(...args) {
    this.__didarTodoRequestUrl = args[1];
    this.addEventListener(
      "load",
      () => {
        patchPipelineXhrResponse(this, this.__didarTodoRequestUrl);
        let payload = null;
        if (this.responseType === "json") {
          payload = this.response;
          captureActivities(payload);
        } else if (!this.responseType || this.responseType === "text") {
          captureJsonText(this.responseText);
          try {
            payload = JSON.parse(this.responseText);
          } catch {
            // Non-JSON requests are unrelated to this feature.
          }
        }
        const succeeded = this.status >= 200 && this.status < 300;
        if (succeeded) captureCallActivityTypes(this.__didarTodoRequestUrl, payload);
        captureNativeActivityDoneResponse(this.__didarNativeActivityDoneContext, succeeded);
        if (succeeded) {
          publishDealAddPersonSelected(this.__didarTodoRequestUrl);
          captureDealDetailResponse(this.__didarTodoRequestUrl, payload);
          publishGlobalSearchResults(this.__didarTodoRequestUrl, payload);
          publishPlanActivityCreated(this.__didarPlanCreationContext, payload);
          publishPlanActivityDeleted(this.__didarPlanDeletionContext, payload);
        }
      },
      { once: true }
    );
    return nativeXhrOpen.apply(this, args);
  };
  const nativeXhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function didarTodoObservedXhrSend(body) {
    body = rewritePipelineRequestBody(this.__didarTodoRequestUrl, body);
    this.__didarPlanCreationContext = planCreationContext(
      this.__didarTodoRequestUrl,
      body
    );
    this.__didarPlanDeletionContext = planDeletionContext(
      this.__didarTodoRequestUrl,
      body
    );
    const rewrittenActivityDone = rewriteNativeActivityDoneBody(
      this.__didarTodoRequestUrl,
      body
    );
    this.__didarNativeActivityDoneContext = rewrittenActivityDone.pending;
    return nativeXhrSend.call(
      this,
      rewriteSaveBody(this.__didarTodoRequestUrl, rewrittenActivityDone.body)
    );
  };

  function matchesRows(activity, visibleRows, changedIndex) {
    let rows;
    try {
      rows = rowsFromHtml(activityTodoNote(activity));
    } catch {
      return false;
    }
    if (!rows.length || rows.length !== visibleRows.length) {
      return false;
    }
    return rows.every((row, index) => {
      if (row.label !== visibleRows[index].label) {
        return false;
      }
      return index === changedIndex || row.checked === visibleRows[index].checked;
    });
  }

  function contextValues(element) {
    const values = [];
    const contextId = element.__ngContext__;
    if (Number.isInteger(contextId)) {
      const view = angularViewRegistry?.get(contextId);
      if (view) {
        values.push(view);
      }
    }
    if (window.ng?.getContext) {
      try {
        values.push(window.ng.getContext(element));
      } catch {
        // Production builds may expose ng without debug context support.
      }
    }
    for (const key of Object.getOwnPropertyNames(element)) {
      if (key.startsWith("__ngContext__")) {
        values.push(element[key]);
      }
    }
    return values;
  }

  function componentCandidates(host) {
    const queue = [];
    if (window.ng?.getOwningComponent) {
      try {
        queue.push({ value: window.ng.getOwningComponent(host), depth: 0 });
      } catch {
        // Production Angular may hide the debug component helper.
      }
    }
    if (window.ng?.getComponent) {
      try {
        queue.push({ value: window.ng.getComponent(host), depth: 0 });
      } catch {
        // Production Angular may hide the debug component helper.
      }
    }
    contextValues(host).forEach((value) => queue.push({ value, depth: 0 }));
    const visited = new WeakSet();
    const candidates = [];
    let inspected = 0;
    while (queue.length && inspected < 2500) {
      const current = queue.shift();
      const value = current.value;
      if (!value || (typeof value !== "object" && typeof value !== "function")) {
        continue;
      }
      if (visited.has(value)) {
        continue;
      }
      visited.add(value);
      inspected += 1;
      candidates.push(value);
      if (current.depth >= 6 || value instanceof Node) {
        continue;
      }
      const keys = Array.isArray(value) ? value.keys() : Object.keys(value);
      for (const key of keys) {
        try {
          const child = value[key];
          if (child && (typeof child === "object" || typeof child === "function")) {
            queue.push({ value: child, depth: current.depth + 1 });
          }
        } catch {
          // Angular services can expose getters that throw during teardown.
        }
      }
    }
    return candidates;
  }

  function handleManualDealAttach(event) {
    const marker = event.target?.matches?.("meta[data-didar-manual-deal-attach-request]")
      ? event.target
      : null;
    const contactId = normalize(marker?.dataset.didarManualDealAttachRequest).toLowerCase();
    if (!marker || !GUID_PATTERN.test(contactId)) {
      return;
    }
    marker.dataset.didarManualDealAttachStarted = "true";
    const finish = (succeeded, method) => {
      marker.dataset.didarManualDealAttachResult = succeeded ? "true" : "false";
      marker.dataset.didarManualDealAttachMethod = method;
      marker.dispatchEvent(new Event(MANUAL_DEAL_ATTACH_DONE_EVENT));
    };
    const hosts = Array.from(document.querySelectorAll("lc-deal-add"));
    const host = hosts.find((node) =>
      node.dataset.didarManualDealAttachTarget === contactId && node.isConnected
    ) || hosts.reverse().find((node) => node.isConnected && !node.hidden &&
      node.getAttribute("aria-hidden") !== "true" && node.getClientRects().length);
    const candidates = host ? componentCandidates(host) : [];
    const controller = candidates.find((value) =>
      typeof value?.selectContact === "function" &&
      typeof value?.setTitle === "function" &&
      value?.contactService && value?.deal
    );
    if (!controller) {
      const contextType = host ? typeof host.__ngContext__ : "no-host";
      const debugApi = window.ng?.getComponent ? "debug-api" : "no-debug-api";
      finish(false, `component-unavailable:${contextType}:${debugApi}:${candidates.length}`);
      return;
    }
    try {
      controller.contactId = contactId;
    } catch {
      finish(false, "contact-load-error");
      return;
    }
    let attempts = 0;
    const check = () => {
      if (!host.isConnected) {
        finish(false, "form-closed");
        return;
      }
      const selectedId = normalize(controller.contact?.Id).toLowerCase();
      if (selectedId === contactId) {
        const name = normalize(controller.contact?.DisplayName ||
          [controller.contact?.FirstName, controller.contact?.LastName].filter(Boolean).join(" "));
        if (!controller.dirtyTitle && name &&
          !normalize(controller.deal?.Title).includes(name)) {
          controller.setTitle();
        }
        marker.dataset.didarManualDealAttachName = name;
        marker.dataset.didarManualDealAttachTitle = normalize(controller.deal?.Title);
        finish(true, "native-contact-id");
        return;
      }
      attempts += 1;
      if (attempts >= 100) {
        finish(false, "contact-load-timeout");
        return;
      }
      window.setTimeout(check, 100);
    };
    check();
  }

  function isGlobalSearchDeal(value) {
    if (!value || typeof value !== "object") {
      return false;
    }
    const objectType = normalize(
      value._Type ?? value.ObjectType ?? value.Type ?? value.type
    ).toLowerCase();
    return GUID_PATTERN.test(normalize(value.Id ?? value.id)) &&
      (objectType === "8783" || objectType === "deal");
  }

  function globalSearchDealForRow(row) {
    const rowTitle = normalize(row.querySelector("h1")?.textContent);
    const queue = contextValues(row).map((value) => ({ value, depth: 0, implicit: false }));
    const visited = new WeakSet();
    const candidates = new Map();
    let inspected = 0;

    while (queue.length && inspected < 900) {
      const current = queue.shift();
      const value = current.value;
      if (!value || (typeof value !== "object" && typeof value !== "function")) {
        continue;
      }
      if (visited.has(value)) {
        continue;
      }
      visited.add(value);
      inspected += 1;

      if (isGlobalSearchDeal(value)) {
        const id = normalize(value.Id).toLowerCase();
        const title = normalize(value.Title);
        const score = current.depth * 20 +
          (current.implicit ? -100 : 0) +
          (rowTitle && title === rowTitle ? -40 : 0);
        const previous = candidates.get(id);
        if (!previous || score < previous.score) {
          candidates.set(id, { id, score });
        }
      }
      if (current.depth >= 4 || value instanceof Node) {
        continue;
      }

      const keys = Array.isArray(value) ? Array.from(value.keys()) : Object.keys(value);
      for (const key of keys) {
        try {
          const child = value[key];
          if (child && (typeof child === "object" || typeof child === "function")) {
            queue.push({
              value: child,
              depth: current.depth + 1,
              implicit: current.implicit || key === "$implicit"
            });
          }
        } catch {
          // Ignore Angular getters that become unavailable while search results rerender.
        }
      }
    }

    return Array.from(candidates.values())
      .sort((left, right) => left.score - right.score)[0]?.id || "";
  }

  function bindGlobalSearchDealRows() {
    document.querySelectorAll("lc-global-search .search-res-list li").forEach((row) => {
      if (!row.querySelector(".icon-srch.Deal")) {
        row.removeAttribute("data-didar-search-deal-id");
        return;
      }
      if (row.dataset.didarSearchDealSource === "response") {
        return;
      }
      const dealId = globalSearchDealForRow(row);
      if (dealId && row.dataset.didarSearchDealId !== dealId) {
        row.dataset.didarSearchDealId = dealId;
      }
    });
  }

  function cloneJson(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function findDealControllers(
    dealId,
    hostSelector = "lc-deal-details, add-product",
    allowUnidentifiedProductState = false
  ) {
    const normalizedDealId = normalize(dealId).toLowerCase();
    const hosts = Array.from(document.querySelectorAll(hostSelector));
    const controllers = [];
    const seen = new WeakSet();
    for (const host of hosts) {
      for (const value of componentCandidates(host)) {
        const candidateDealId = normalize(
          value.deal?.Id ||
          value.product?.DealId ||
          value.productClone?.DealId ||
          value.DealId
        ).toLowerCase();
        const hasProductState = Boolean(
          Array.isArray(value.product?.DealProducts) ||
          Array.isArray(value.productClone?.DealProducts) ||
          Array.isArray(value.productService?.productItems) ||
          Array.isArray(value.productItems) ||
          Array.isArray(value.DealProducts)
        );
        if (
          !seen.has(value) &&
          (
            candidateDealId === normalizedDealId ||
            (allowUnidentifiedProductState && !candidateDealId && hasProductState)
          )
        ) {
          seen.add(value);
          controllers.push(value);
        }
      }
    }
    return controllers;
  }

  function findDealController(dealId) {
    const controllers = findDealControllers(dealId);
    return controllers.find((value) => value.product || value.productService) || controllers[0] || null;
  }

  function findActivityPageController(dealId) {
    const normalizedDealId = normalize(dealId).toLowerCase();
    for (const host of document.querySelectorAll("lc-deal-details")) {
      for (const value of componentCandidates(host)) {
        if (
          normalize(value.deal?.Id).toLowerCase() === normalizedDealId &&
          Array.isArray(value.activities?.Planned)
        ) {
          return value;
        }
      }
    }
    return findDealController(dealId);
  }

  function syncCompletedActivity(activity, requestedDealId = "") {
    const activityId = normalize(activity?.Id).toLowerCase();
    const routeDealId = normalize(location.pathname.match(/\/deal\/([0-9a-f-]{36})/i)?.[1]);
    const dealId = normalize(activity?.DealId || requestedDealId || routeDealId).toLowerCase();
    if (!GUID_PATTERN.test(activityId)) {
      return "invalid";
    }

    const controllers = [];
    const seen = new WeakSet();
    for (const host of document.querySelectorAll("lc-activity-list-brief")) {
      for (const value of componentCandidates(host)) {
        if (
          !seen.has(value) &&
          Array.isArray(value.activities) &&
          (typeof value.deleteActivityFromList === "function" || typeof value._reload === "function")
        ) {
          seen.add(value);
          controllers.push(value);
        }
      }
    }

    const plannedController = controllers.find((controller) =>
      controller.activities.some(
        (item) => normalize(item?.Id).toLowerCase() === activityId && item?.IsDone === false
      )
    );
    let completedListSynchronized = false;
    controllers.forEach((controller) => {
      const completedIndex = controller.activities.findIndex(
        (item) =>
          normalize(item?.Id).toLowerCase() === activityId && item?.IsDone === true
      );
      if (completedIndex < 0) {
        return;
      }
      const completed = cloneJson(activity);
      completed.IsDone = true;
      controller.activities.splice(completedIndex, 1, completed);
      try {
        controller.cdr?.detectChanges();
      } catch {
        // The updated activity remains available for Angular's next render cycle.
      }
      try {
        controller._reload?.(true);
      } catch {
        // The DOM fallback removes the stale duplicate until a later native reload succeeds.
      }
      completedListSynchronized = true;
    });
    let childSynchronized = false;
    if (
      plannedController &&
      typeof plannedController.deleteActivityFromList === "function" &&
      typeof plannedController.activityDone?.emit === "function"
    ) {
      try {
        const current = plannedController.activities.find(
          (item) => normalize(item?.Id).toLowerCase() === activityId
        );
        const completed = cloneJson(activity);
        completed.IsDone = true;
        plannedController.deleteActivityFromList(current);
        plannedController.activityDone.emit(completed);
        plannedController.cdr?.detectChanges();
        childSynchronized = true;
      } catch {
        childSynchronized = false;
      }
    }

    const dealController = GUID_PATTERN.test(dealId) ? findActivityPageController(dealId) : null;
    if (dealController) {
      const completed = cloneJson(activity);
      completed.IsDone = true;
      const planned = dealController.activities?.Planned;
      if (Array.isArray(planned)) {
        const plannedIndex = planned.findIndex(
          (item) => normalize(item?.Id).toLowerCase() === activityId
        );
        if (plannedIndex >= 0) {
          planned.splice(plannedIndex, 1);
          if (Number.isFinite(dealController.activities.PlannedTotal)) {
            dealController.activities.PlannedTotal = Math.max(
              0,
              dealController.activities.PlannedTotal - 1
            );
          }
        }
      }
      if (!childSynchronized && !completedListSynchronized) {
        if (typeof dealController.setActivityDone === "function") {
          dealController.setActivityDone(completed);
        } else {
          dealController.doneActivity = completed;
        }
      }
      try {
        dealController.cdr?.detectChanges();
      } catch {
        // Assigning the native input state is sufficient for the next render cycle.
      }
      return childSynchronized || completedListSynchronized ? "native-state" : "deal-state";
    }
    if (childSynchronized || completedListSynchronized) {
      return "native-state";
    }

    const matchingControllers = controllers.filter((controller) => {
      const controllerDealId = normalize(controller.dealId || controller.deal?.Id).toLowerCase();
      return !dealId || !controllerDealId || controllerDealId === dealId;
    });
    const reloadableControllers = matchingControllers.filter(
      (controller) => typeof controller._reload === "function"
    );
    if (reloadableControllers.length) {
      reloadableControllers.forEach((controller) => {
        try {
          controller._reload(true);
        } catch {
          // Continue refreshing the other activity lists.
        }
      });
      return "list-reload";
    }
    return "unavailable";
  }

  function handleActivityCompleted(event) {
    const marker = event.target?.matches?.("meta[data-didar-activity-completion-request]")
      ? event.target
      : null;
    if (!marker) {
      return;
    }
    let detail = {};
    try {
      detail = JSON.parse(marker.textContent || "{}");
    } catch {
      detail = {};
    }
    let attempt = 0;
    const finish = (method) => {
      marker.dataset.didarActivityCompletionResult = method !== "unavailable" && method !== "invalid"
        ? "true"
        : "false";
      marker.dataset.didarActivityCompletionMethod = method;
      marker.dispatchEvent(new Event(ACTIVITY_COMPLETION_SYNCED_EVENT));
    };
    const trySync = () => {
      attempt += 1;
      const method = syncCompletedActivity(detail.activity, detail.dealId);
      if (method !== "unavailable" || attempt >= 3) {
        finish(method);
      } else {
        window.setTimeout(trySync, 80);
      }
    };
    trySync();
  }

  function refreshActivityLists(dealId) {
    const normalizedDealId = normalize(dealId).toLowerCase();
    if (!GUID_PATTERN.test(normalizedDealId)) {
      return false;
    }
    const controllers = [];
    const seen = new WeakSet();
    for (const host of document.querySelectorAll("lc-activity-list-brief")) {
      for (const value of componentCandidates(host)) {
        if (!seen.has(value) && typeof value?._reload === "function") {
          seen.add(value);
          controllers.push(value);
        }
      }
    }
    const dealController = findActivityPageController(normalizedDealId);
    if (dealController && !seen.has(dealController) && typeof dealController._reload === "function") {
      controllers.push(dealController);
    }
    let refreshed = false;
    controllers.forEach((controller) => {
      try {
        controller._reload(true);
        controller.cdr?.detectChanges?.();
        refreshed = true;
      } catch {
        // Continue refreshing other native activity-list controllers.
      }
    });
    return refreshed;
  }

  function syncCreatedActivity(activity, requestedDealId = "") {
    const activityId = normalize(activity?.Id).toLowerCase();
    const routeDealId = normalize(location.pathname.match(/\/deal\/([0-9a-f-]{36})/i)?.[1]);
    const dealId = normalize(activity?.DealId || requestedDealId || routeDealId).toLowerCase();
    if (
      !GUID_PATTERN.test(activityId) ||
      !GUID_PATTERN.test(dealId) ||
      (requestedDealId && normalize(requestedDealId).toLowerCase() !== dealId)
    ) {
      return false;
    }

    const created = cloneJson(activity);
    created.DealId = dealId;
    created.IsDone = false;
    created.IsDeleted = false;
    let synchronized = false;
    const seen = new WeakSet();

    for (const host of document.querySelectorAll("lc-activity-list-brief")) {
      for (const controller of componentCandidates(host)) {
        if (seen.has(controller) || !Array.isArray(controller?.activities)) {
          continue;
        }
        const controllerDealId = normalize(controller.dealId || controller.deal?.Id).toLowerCase();
        if (controllerDealId && controllerDealId !== dealId) {
          continue;
        }
        seen.add(controller);
        if (!controller.activities.some((item) => normalize(item?.Id).toLowerCase() === activityId)) {
          controller.activities = [cloneJson(created), ...controller.activities];
        }
        try {
          controller.cdr?.markForCheck?.();
          controller.cdr?.detectChanges?.();
        } catch {
          // The new array reference remains ready for Angular's next change-detection pass.
        }
        synchronized = true;
      }
    }

    const dealController = findActivityPageController(dealId);
    if (dealController && Array.isArray(dealController.activities?.Planned)) {
      const planned = dealController.activities.Planned;
      const alreadyPresent = planned.some(
        (item) => normalize(item?.Id).toLowerCase() === activityId
      );
      if (!alreadyPresent) {
        if (typeof dealController.activityAfterAdd === "function") {
          dealController.activityAfterAdd(cloneJson(created));
          if (Number.isFinite(dealController.activities.PlannedTotal)) {
            dealController.activities.PlannedTotal += 1;
          }
        } else {
          dealController.activities = {
            ...dealController.activities,
            Planned: [cloneJson(created), ...planned],
            PlannedTotal: Number.isFinite(dealController.activities.PlannedTotal)
              ? dealController.activities.PlannedTotal + 1
              : planned.length + 1
          };
        }
      }
      try {
        dealController.cdr?.markForCheck?.();
        dealController.cdr?.detectChanges?.();
      } catch {
        // The assigned Planned collection is picked up by the next native render.
      }
      synchronized = true;
    }
    return synchronized;
  }

  function handleActivityCreatedRefresh(event) {
    const marker = event.target?.matches?.("meta[data-didar-activity-created-refresh-request]")
      ? event.target
      : null;
    if (!marker) {
      return;
    }
    const detail = markerDetail(marker);
    let attempt = 0;
    const tryRefresh = () => {
      attempt += 1;
      const synchronized = syncCreatedActivity(detail.activity, detail.dealId);
      const refreshed = refreshActivityLists(detail.dealId);
      if (synchronized || refreshed || attempt >= 4) {
        const succeeded = synchronized || refreshed;
        marker.dataset.didarActivityCreatedRefreshResult = succeeded ? "true" : "false";
        marker.dataset.didarActivityCreatedRefreshMethod = synchronized
          ? refreshed ? "native-state-and-reload" : "native-state"
          : refreshed ? "native-reload" : "unavailable";
        marker.dispatchEvent(new Event(ACTIVITY_CREATED_REFRESHED_EVENT));
        if (synchronized) {
          [180, 700].forEach((delay) => {
            window.setTimeout(() => syncCreatedActivity(detail.activity, detail.dealId), delay);
          });
        }
        return;
      }
      window.setTimeout(tryRefresh, 100);
    };
    tryRefresh();
  }

  function syncDealProducts(detail) {
    const dealId = normalize(detail?.dealId);
    const items = Array.isArray(detail?.items) ? detail.items : null;
    if (!GUID_PATTERN.test(dealId) || !items) {
      return false;
    }
    const controllers = findDealControllers(
      dealId,
      detail.requireProductEditor ? "add-product" : "lc-deal-details, add-product",
      Boolean(detail.requireProductEditor)
    );
    if (!controllers.length) {
      return false;
    }
    const dealItems = cloneJson(items);
    controllers.forEach((controller) => {
      if (controller.deal && typeof controller.deal === "object") {
        controller.deal.Items = cloneJson(dealItems);
        if (Array.isArray(controller.deal.DealProducts)) {
          controller.deal.DealProducts = cloneJson(dealItems);
        }
        if (detail.adjustment !== undefined) {
          controller.deal.Adjustment = detail.adjustment;
        }
        if (detail.estimatedPrice !== undefined) {
          controller.deal.EstimatedPrice = detail.estimatedPrice;
        }
      }
      if (controller.product && typeof controller.product === "object") {
        controller.product.DealId = dealId;
        controller.product.DealProducts = cloneJson(dealItems);
        if (detail.adjustment !== undefined) {
          controller.product.Adjustment = detail.adjustment;
        }
      }
      if (controller.productClone && typeof controller.productClone === "object") {
        controller.productClone = {
          ...controller.productClone,
          DealId: dealId,
          DealProducts: cloneJson(dealItems),
          Adjustment: detail.adjustment
        };
      }
      if (controller.productService && typeof controller.productService === "object") {
        controller.productService.productItems = cloneJson(dealItems);
      }
      if (Array.isArray(controller.productItems)) {
        controller.productItems = cloneJson(dealItems);
      }
      if (
        normalize(controller.DealId).toLowerCase() === dealId.toLowerCase() &&
        Array.isArray(controller.DealProducts)
      ) {
        controller.DealProducts = cloneJson(dealItems);
        if (detail.adjustment !== undefined) {
          controller.Adjustment = detail.adjustment;
        }
      }
      try {
        controller.cdr?.detectChanges();
        controller.cdr?.markForCheck();
      } catch {
        // The synchronized model remains available for Angular's next render cycle.
      }
    });
    return true;
  }

  function handleDealProductsUpdated(event) {
    const marker = event.target?.matches?.("meta[data-didar-product-sync-request]")
      ? event.target
      : null;
    let detail = event.detail || {};
    if (marker) {
      try {
        detail = JSON.parse(marker.textContent || "{}");
      } catch {
        detail = {};
      }
    }
    let attempt = 0;
    const finish = (synced, method = "direct") => {
      if (marker) {
        marker.dataset.didarProductSyncResult = synced ? "true" : "false";
        marker.dataset.didarProductSyncMethod = method;
        marker.dispatchEvent(new Event(DEAL_PRODUCTS_SYNCED_EVENT));
        return;
      }
      document.dispatchEvent(
        new CustomEvent(DEAL_PRODUCTS_SYNCED_EVENT, {
          detail: { requestId: detail.requestId, synced }
        })
      );
    };
    const trySync = () => {
      attempt += 1;
      if (syncDealProducts(detail)) {
        if (detail.requireProductEditor) {
          [80, 240, 600].forEach((wait) => {
            window.setTimeout(() => syncDealProducts(detail), wait);
          });
        }
        finish(true, "direct");
      } else if (attempt < 12) {
        window.setTimeout(trySync, 120);
      } else {
        finish(false, "direct-unavailable");
      }
    };
    trySync();
  }

  function collectCandidates(value, rows, changedIndex, expectedTitle = "", maxDepth = 7) {
    const queue = [{ value, depth: 0 }];
    const visited = new WeakSet();
    const candidates = [];
    let inspected = 0;

    while (queue.length && inspected < 1800) {
      const current = queue.shift();
      const node = current.value;
      if (!node || (typeof node !== "object" && typeof node !== "function")) {
        continue;
      }
      if (visited.has(node)) {
        continue;
      }
      visited.add(node);
      inspected += 1;

      if (
        isActivity(node) &&
        activityBelongsToPage(node) &&
        (!expectedTitle || normalize(node.Title) === expectedTitle) &&
        matchesRows(node, rows, changedIndex)
      ) {
        candidates.push({ id: normalize(node.Id).toLowerCase(), depth: current.depth });
        continue;
      }
      if (current.depth >= maxDepth || node instanceof Node) {
        continue;
      }

      const nextValues = [];
      if (node.$implicit) {
        nextValues.push(node.$implicit);
      }
      if (Array.isArray(node)) {
        nextValues.push(...node);
      } else {
        for (const key of Object.keys(node)) {
          if (key === "parent" || key === "__proto__") {
            continue;
          }
          try {
            nextValues.push(node[key]);
          } catch {
            // Ignore getters from views that Angular is currently destroying.
          }
        }
      }
      nextValues.forEach((next) => queue.push({ value: next, depth: current.depth + 1 }));
    }
    return candidates;
  }

  function activityIdByListPosition(todoList, rows, changedIndex) {
    const host = todoList.closest("lc-activity-list-brief");
    const card = todoList.closest(".activity-item");
    if (!host || !card) {
      return "";
    }
    const cards = Array.from(host.querySelectorAll(".activity-item")).filter(
      (item) => item.closest("lc-activity-list-brief") === host
    );
    const cardIndex = cards.indexOf(card);
    if (cardIndex < 0) {
      return "";
    }
    const controllers = componentCandidates(host).filter(
      (value) => Array.isArray(value.activities) && value.activities.length === cards.length
    );
    const cardTitle = normalize(card.querySelector("h2")?.textContent);
    const ids = new Set();
    for (const controller of controllers) {
      if (!controller.activities.every((activity, index) =>
        normalize(activity?.Title) === normalize(cards[index].querySelector("h2")?.textContent)
      )) {
        continue;
      }
      const activity = controller.activities[cardIndex];
      const activityTitle = normalize(activity?.Title);
      if (
        isActivity(activity) &&
        activityBelongsToPage(activity) &&
        (!cardTitle || !activityTitle || cardTitle === activityTitle) &&
        matchesRowLabels(activity, rows)
      ) {
        ids.add(normalize(activity.Id).toLowerCase());
      }
    }
    return ids.size === 1 ? Array.from(ids)[0] : "";
  }

  function resolve(todoList, changedIndex = -1) {
    if (capturedActivitiesPage !== location.pathname) {
      capturedActivities.clear();
      capturedActivitiesPage = location.pathname;
    }
    const previousId = normalize(
      todoList.dataset.didarStableActivityId || todoList.dataset.didarActivityId
    ).toLowerCase();
    const rows = rowsFromList(todoList);
    const cardTitle = normalize(todoList.closest(".activity-item, article")?.querySelector("h2")?.textContent);
    const positionalId = activityIdByListPosition(todoList, rows, changedIndex);
    if (GUID_PATTERN.test(positionalId)) {
      todoList.dataset.didarActivityId = positionalId;
      todoList.dataset.didarActivityResolution = "resolved-position";
      return;
    }
    const previousActivity = capturedActivities.get(previousId);
    if (GUID_PATTERN.test(previousId) && todoList.dataset.didarStableActivityId &&
        (!previousActivity || (activityBelongsToPage(previousActivity) &&
          (!cardTitle || normalize(previousActivity.Title) === cardTitle) &&
          matchesRowLabels(previousActivity, rows)))) {
      todoList.dataset.didarActivityId = previousId;
      todoList.dataset.didarActivityResolution = "resolved-cached";
      return;
    }
    const scored = [];
    const activityContainerText = normalize(
      todoList.closest("article, section, li, .activity-item")?.textContent || ""
    );

    capturedActivities.forEach((activity) => {
      const title = normalize(activity.Title);
      if (!activityBelongsToPage(activity) ||
          (cardTitle && title !== cardTitle) || !matchesRows(activity, rows, changedIndex)) {
        return;
      }
      let score = 500;
      if (title && activityContainerText.includes(title)) {
        score -= 20;
      }
      scored.push({ id: normalize(activity.Id).toLowerCase(), score });
    });

    let element = todoList;
    let ancestorDistance = 0;

    while (element && ancestorDistance < 14) {
      for (const context of contextValues(element)) {
        collectCandidates(context, rows, changedIndex, cardTitle).forEach((candidate) => {
          scored.push({ id: candidate.id, score: ancestorDistance * 20 + candidate.depth });
        });
      }
      element = element.parentElement;
      ancestorDistance += 1;
    }

    const bestById = new Map();
    scored.forEach((candidate) => {
      const prior = bestById.get(candidate.id);
      if (prior === undefined || candidate.score < prior) {
        bestById.set(candidate.id, candidate.score);
      }
    });
    const ranked = Array.from(bestById, ([id, score]) => ({ id, score })).sort(
      (left, right) => left.score - right.score
    );

    todoList.removeAttribute("data-didar-activity-id");
    todoList.removeAttribute("data-didar-activity-resolution");
    if (!ranked.length) {
      if (GUID_PATTERN.test(previousId)) {
        todoList.dataset.didarActivityId = previousId;
        todoList.dataset.didarActivityResolution = "resolved-cached";
        return;
      }
      todoList.dataset.didarActivityResolution = "not-found";
      return;
    }
    if (ranked.length > 1 && ranked[0].score === ranked[1].score) {
      if (GUID_PATTERN.test(previousId) && bestById.has(previousId)) {
        todoList.dataset.didarActivityId = previousId;
        todoList.dataset.didarActivityResolution = "resolved-cached";
        return;
      }
      todoList.dataset.didarActivityResolution = "ambiguous";
      return;
    }
    todoList.dataset.didarActivityId = ranked[0].id;
    todoList.dataset.didarActivityResolution = "resolved";
  }

  function scan() {
    enhanceCallActivityEditors();
    bindGlobalSearchDealRows();
    document.querySelectorAll("ul.todo-list").forEach((todoList) => {
      resolve(todoList);
      if (!CallChecklists) return;
      const activity = capturedActivities.get(normalize(todoList.dataset.didarActivityId).toLowerCase());
      const template = callTemplateForActivity(activity, readCallChecklistConfig());
      if (template && todoList.dataset.didarCallTemplate !== template.key) todoList.dataset.didarCallTemplate = template.key;
    });
  }

  function handleActivitySaved(event) {
    const marker = event.target?.closest?.("meta[data-didar-activity-save-request]");
    if (!marker) {
      return;
    }
    let detail;
    try {
      detail = JSON.parse(marker.dataset.didarActivitySaveRequest);
    } catch {
      return;
    }
    const activity = detail?.activity;
    const dealId = normalize(detail?.dealId).toLowerCase();
    const pageDealId = location.pathname.match(/\/deal\/([0-9a-f-]{36})/i)?.[1]?.toLowerCase();
    if (!isActivity(activity) || !activityBelongsToPage(activity) || dealId !== pageDealId) {
      return;
    }
    const id = normalize(activity.Id).toLowerCase();
    capturedActivities.set(id, activity);
    // Isolated-world saves do not pass through the native fetch observer.
    // Update only the exact saved record, never another activity with the same title.
    document.querySelectorAll("lc-deal-details, lc-activity-list-brief, .activity-item").forEach((host) => {
      const candidates = componentCandidates(host);
      candidates.forEach((value) => {
        if (isActivity(value) && normalize(value.Id).toLowerCase() === id) {
          try {
            ["Note", "ResultNote", "LastUpdateTime"].forEach((key) => {
              if (Object.hasOwn(activity, key)) {
                value[key] = activity[key];
              }
            });
          } catch {
            // A view being destroyed can expose a read-only activity model.
          }
        }
      });
      candidates.forEach((value) => {
        if (value.cdr?.markForCheck) {
          try {
            value.cdr.markForCheck();
          } catch {
            // A destroyed view must not interrupt the confirmed save notification.
          }
        }
      });
    });
    scheduleScan();
  }

  function scheduleScan() {
    window.clearTimeout(scanTimer);
    scanTimer = window.setTimeout(scan, 100);
  }

  document.addEventListener(
    RESOLVE_EVENT,
    (event) => {
      const todoList = event.target?.closest?.("ul.todo-list");
      if (!todoList) {
        return;
      }
      const changedIndex = Number(todoList.dataset.didarTodoChangedIndex);
      resolve(todoList, Number.isInteger(changedIndex) ? changedIndex : -1);
      todoList.removeAttribute("data-didar-todo-changed-index");
    },
    true
  );
  document.addEventListener(DEAL_PRODUCTS_UPDATED_EVENT, handleDealProductsUpdated);
  document.addEventListener(MANUAL_DEAL_ATTACH_EVENT, handleManualDealAttach);
  document.addEventListener(ACTIVITY_COMPLETED_EVENT, handleActivityCompleted);
  document.addEventListener(ACTIVITY_SAVED_EVENT, handleActivitySaved);
  document.addEventListener(ACTIVITY_CREATED_REFRESH_EVENT, handleActivityCreatedRefresh);
  document.addEventListener(NATIVE_QUICK_ACTIVITY_CREATE_EVENT, handleNativeQuickActivityCreate);
  document.addEventListener(NATIVE_ACTIVITY_DONE_ARM_EVENT, handleNativeActivityDoneArm);
  document.addEventListener(PIPELINE_ACTIVITY_FILTER_EVENT, handlePipelineActivityFilter);
  document.addEventListener("didar-quick-checklist:call-settings-updated", scheduleScan);
  document.addEventListener("didar-quick-checklist:case-call-created", (event) => {
    const marker = event.target?.closest?.("meta[data-didar-case-call-created]");
    if (!marker) return;
    try {
      const { caseId, activity } = JSON.parse(marker.dataset.didarCaseCallCreated);
      const routeCase = normalize(location.pathname.match(/\/case\/([0-9a-f-]{36})/i)?.[1]).toLowerCase();
      if (caseId !== routeCase || normalize(activity?.CaseId).toLowerCase() !== caseId ||
          !GUID_PATTERN.test(normalize(activity?.Id)) || activity.IsDone !== true) return;
      captureActivities([activity]);
      const seen = new WeakSet();
      for (const host of document.querySelectorAll("lc-case-details, lc-activity-list-brief")) {
        for (const controller of componentCandidates(host)) {
          if (seen.has(controller)) continue;
          const owner = normalize(controller.caseId || controller.case?.Id).toLowerCase();
          if (owner !== caseId) continue;
          seen.add(controller);
          if (typeof controller.activityAfterAdd === "function") controller.activityAfterAdd(cloneJson(activity));
          else if (typeof controller.loadActivities === "function") controller.loadActivities();
          else if (controller.isDone !== false && typeof controller._reload === "function") controller._reload(true);
        }
      }
      scheduleScan();
    } catch { /* A closed or changed view must not affect the confirmed save. */ }
  });
  document.addEventListener("DOMContentLoaded", scheduleScan, { once: true });
  document.addEventListener("click", (event) => {
    if (event.target?.closest?.("lc-activity-add, lc-activity-add-inline")) scheduleScan();
  }, true);
  document.addEventListener("input", (event) => {
    if (!event.target?.closest?.('[contenteditable="true"], .ck-editor__editable')) return;
    const host = event.target.closest("lc-activity-add, lc-activity-add-inline");
    if (host) host.dataset.didarCallDraftDirty = "true";
  }, true);

  function startObserver() {
    if (!document.documentElement) {
      window.setTimeout(startObserver, 0);
      return;
    }
    const observer = new MutationObserver(scheduleScan);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    scan();
  }

  startObserver();
})();
