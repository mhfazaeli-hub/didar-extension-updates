if (typeof importScripts === "function") importScripts("release-config.js", "diagnostics.js", "diagnostics-background.js", "team-checklists.js", "team-background.js", "cloud-background.js");
(function initializeBackground() {
  "use strict";
  const chrome = globalThis.browser || globalThis.chrome;

  const RECEIVER_MISSING_PATTERN = /Receiving end does not exist|Could not establish connection/i;
  const RETRYABLE_DIDAR_CODES = new Set(["DIDAR_AUTH_REQUIRED", "DIDAR_ACCOUNT_REQUIRED"]);
  const DIDAR_DEAL_URL_PATTERN = /^https:\/\/app\.didar\.me\/deal\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const CSPF_DASHBOARD = /^https:\/\/eservices\.cspf\.ir\/Auth-api\/?(?:[?#]|$)/i;
  const CSPF_CERTIFICATE_ENTRY = "https://eservices.cspf.ir/Certificate/Default.aspx";
  const CSPF_CERTIFICATE_LIST = "https://eservices.cspf.ir/Certificate/MainList.aspx";
  const CSPF_CERTIFICATE_PAGE = /^https:\/\/eservices\.cspf\.ir\/Certificate\/(?:Default|MainList)\.aspx(?:[?#]|$)/i;
  const CSPF_COOKIE_URL = "https://eservices.cspf.ir/";
  const CSPF_CERTIFICATE_COOKIE = ".AspNet.Cookies";
  const cspfSessionOpenings = new Map();
  let preferredDidarTabId = null;

  async function forgetCspfCertificateCookie(sourceTab) {
    const stores = await chrome.cookies.getAllCookieStores();
    const store = stores.find((item) => item.tabIds.includes(sourceTab.id));
    if (!store) throw new Error("نشست همین تب صندوق در مرورگر پیدا نشد.");
    const query = { url: CSPF_COOKIE_URL, name: CSPF_CERTIFICATE_COOKIE, storeId: store.id };
    const cookies = await chrome.cookies.getAll(query);
    if (!cookies.length) return;
    const [cookie] = cookies;
    if (cookies.length !== 1 || cookie.domain !== "eservices.cspf.ir" || cookie.path !== "/" ||
        !cookie.hostOnly || !cookie.httpOnly || !cookie.secure || cookie.partitionKey || cookie.firstPartyDomain) {
      throw new Error("مرورگر کوکی اختصاصی نشست گواهی را با مشخصات مورد انتظار پیدا نکرد.");
    }
    if (!await chrome.cookies.remove(query)) throw new Error("نشست قبلی گواهی از مرورگر پاک نشد.");
  }

  function readVisibleCertificate() {
    if (location.origin !== "https://eservices.cspf.ir" ||
        location.pathname.toLowerCase() !== "/certificate/mainlist.aspx") return "";
    return (document.body?.innerText || "").split("راهنمای آخرین وضعیت گواهی")[0].slice(0, 12000);
  }

  async function openCspfCertificateSession(sourceTab, action) {
    const current = await chrome.tabs.get(sourceTab.id);
    if (!CSPF_DASHBOARD.test(current.url || "")) throw new Error("پیشخوان صندوق تغییر کرده است.");
    if (action === "renew") {
      await forgetCspfCertificateCookie(current);
    }
    const tab = await chrome.tabs.create({
      url: "about:blank", active: false, openerTabId: current.id, windowId: current.windowId
    });
    try {
      // Opening the official entry as a browser document initializes the certificate session.
      if (current.cookieStoreId && tab.cookieStoreId !== current.cookieStoreId) {
        throw new Error("مرورگر نتوانست صفحهٔ گواهی را در همان نشست صندوق باز کند.");
      }
      await chrome.tabs.update(tab.id, { url: action === "render" ? CSPF_CERTIFICATE_LIST : CSPF_CERTIFICATE_ENTRY });
      const deadline = Date.now() + 12000;
      while (Date.now() < deadline) {
        const certificate = await chrome.tabs.get(tab.id);
        if (certificate.status === "complete" && CSPF_CERTIFICATE_PAGE.test(certificate.url || "") &&
            (!certificate.pendingUrl || CSPF_CERTIFICATE_PAGE.test(certificate.pendingUrl))) {
          if (/Web Page Blocked|The URL you requested has been blocked/i.test(certificate.title || "")) {
            return { ok: false, error: "صندوق دسترسی به گواهی کسر از حقوق را مسدود کرده است. مبلغ تتمه و توان قسط از صندوق دریافت نشد." };
          }
          if (action === "render") {
            if (new URL(certificate.url).pathname.toLowerCase() !== "/certificate/mainlist.aspx") {
              return { ok: true, certificateText: "" };
            }
            const [reading] = await chrome.scripting.executeScript({
              target: { tabId: tab.id, frameIds: [0] },
              func: readVisibleCertificate
            });
            const certificateText = typeof reading?.result === "string" ? reading.result : "";
            if (/Web Page Blocked|The URL you requested has been blocked/i.test(certificateText)) {
              return { ok: false, error: "صندوق دسترسی به گواهی کسر از حقوق را مسدود کرده است. مبلغ تتمه و توان قسط از صندوق دریافت نشد." };
            }
            return { ok: true, certificateText };
          }
          return { ok: true };
        }
        await new Promise((resolve) => setTimeout(resolve, 200));
      }
      throw new Error("صندوق نشست گواهی را آماده نکرد؛ وضعیت ورود به حساب صندوق را بررسی کنید.");
    } finally {
      await chrome.tabs.remove(tab.id).catch(() => {});
    }
  }

  async function configReply(operation, message) {
    if (!message.type?.endsWith("_GET_CONFIG")) return operation;
    let timer;
    try {
      return await Promise.race([operation, new Promise((_resolve, reject) => {
        timer = setTimeout(() => reject(Object.assign(new Error("دریافت تنظیمات دیدار بیش از حد طول کشید؛ بررسی مجدد اتصال را بزنید."),
          { code: "TIMEOUT" })), 35000);
      })]);
    } finally { clearTimeout(timer); }
  }

  async function diagnosticResponse(message, response, source) {
    const logger=globalThis.DidarDiagnosticBackground;
    if (!logger) return response;
    const suffix=message.type.replace(/^(?:ETEBARITO|BETA|TAMIN|CSPF)_DIDAR_/, "");
    const operation={LOOKUP:"lookup",GET_CONFIG:"config",TRANSFER:"transfer",UPDATE:"update",MOBILE_LOOKUP:"mobile_lookup",APPEND_MOBILE_REPORT:"append_mobile_report"}[suffix] || "client";
    const lookup=operation==="lookup" && response?.ok;
    if (!lookup && response?.ok && !["transfer","update","append_mobile_report"].includes(operation)) return response;
    const code=response?.partial ? "PARTIAL_SAVE" : lookup
      ? response.conflict ? "LOOKUP_CONFLICT" : response.contacts?.length ? "LOOKUP_FOUND" : "LOOKUP_EMPTY"
      : response?.ok ? "WRITE_VERIFIED" : globalThis.DidarDiagnostics.classify(response);
    let timer;
    try {
      const record=logger.record({source,operation,stage:"crm",code,httpStatus:response?.httpStatus,endpoint:response?.endpoint,
        metrics:{...response?.lookupDiagnostics,contacts:response?.contacts?.length,deals:response?.deals?.length,
          activityCreated:Number(Boolean(response?.noteCreated)),activityReused:Number(Boolean(response?.noteReused))}});
      const id=await Promise.race([record,new Promise(resolve=>{timer=setTimeout(()=>resolve(null),1500);})]);
      if (!id) return response;
      return {...response,diagnosticId:id};
    } catch { return response; }
    finally { clearTimeout(timer); }
  }

  async function didarTabs() {
    const tabs = await chrome.tabs.query({ url: "https://app.didar.me/*" });
    return tabs
      .filter((tab) => Number.isInteger(tab.id))
      .sort((left, right) => {
        if (left.id === preferredDidarTabId) {
          return -1;
        }
        if (right.id === preferredDidarTabId) {
          return 1;
        }
        return Number(right.lastAccessed || 0) - Number(left.lastAccessed || 0);
      });
  }

  function isReceiverMissing(error) {
    return RECEIVER_MISSING_PATTERN.test(String(error?.message || error || ""));
  }

  function isRetryableDidarResponse(response) {
    if (response?.ok !== false) {
      return false;
    }
    if (RETRYABLE_DIDAR_CODES.has(response.code)) {
      return true;
    }
    return /\b401\b|نشست دیدار.*(?:منقضی|نامعتبر)|حساب سازمانی دیدار.*مشخص نیست/i.test(
      String(response.error || "")
    );
  }

  async function restoreDidarReceiver(tabId) {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["page-context.js"],
      world: "MAIN"
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: [
        ...(globalThis.DidarDiagnostics ? ["diagnostics.js"] : []),
        ...(globalThis.DidarRelease?.teamChecklists ? ["release-config.js", "team-checklists.js"] : []),
        "cspf-core.js", "core.js", "plan-board.js", "content.js"
      ]
    });

    try {
      await chrome.scripting.insertCSS({
        target: { tabId },
        files: ["content.css", "plan-board.css"]
      });
    } catch (_error) {
      // The message receiver is operational even if Chrome declines duplicate CSS insertion.
    }
  }

  async function sendToTab(tabId, message) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (error) {
      if (!isReceiverMissing(error)) {
        throw error;
      }

      await restoreDidarReceiver(tabId);
      return chrome.tabs.sendMessage(tabId, message);
    }
  }

  async function sendToDidar(message) {
    if (globalThis.DidarCloudBackground && (await chrome.storage.local.get("connectionMode")).connectionMode === "cloud") {
      return configReply(globalThis.DidarCloudBackground.execute(message), message);
    }
    const tabs = await didarTabs();
    if (!tabs.length) {
      throw new Error("برای بررسی اطلاعات، یک تب دیدار را باز نگه دارید.");
    }
    let lastError = null;
    let lastDidarResponse = null;
    for (const tab of tabs) {
      try {
        const response = await configReply(sendToTab(tab.id, message), message);
        if (isRetryableDidarResponse(response)) {
          lastDidarResponse = response;
          if (preferredDidarTabId === tab.id) {
            preferredDidarTabId = null;
          }
          continue;
        }
        if (response?.ok) {
          preferredDidarTabId = tab.id;
        }
        return response;
      } catch (error) {
        lastError = error;
      }
    }
    if (lastDidarResponse) {
      return lastDidarResponse;
    }
    throw lastError || new Error("اتصال به تب دیدار برقرار نشد.");
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const fromDidar = sender.tab?.url?.startsWith("https://app.didar.me/");
    if (fromDidar && message?.type === "DIDAR_OPEN_DEAL_TAB") {
      const url = String(message.url || "");
      if (!DIDAR_DEAL_URL_PATTERN.test(url)) {
        sendResponse({ ok: false, error: "نشانی معامله معتبر نیست." });
        return false;
      }
      chrome.tabs.create({ url })
        .then((tab) => sendResponse({ ok: true, tabId: tab.id }))
        .catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }

    const fromEtebarito = sender.tab?.url?.startsWith("https://etebaritoapp.ics24.ir/");
    const fromBeta = sender.tab?.url?.startsWith("https://beta.bkr724.ir/");
    const fromTamin = sender.tab?.url?.startsWith("https://eservices.tamin.ir/");
    const fromCspf = CSPF_DASHBOARD.test(sender.url || sender.tab?.url || "") && CSPF_DASHBOARD.test(sender.tab?.url || "");
    const cspfAction = message?.type === "CSPF_OPEN_CERTIFICATE_SESSION" ? "warm" :
      message?.type === "CSPF_RENEW_CERTIFICATE_SESSION" ? "renew" :
      message?.type === "CSPF_READ_RENDERED_CERTIFICATE" ? "render" : "";
    if (cspfAction) {
      if (!CSPF_DASHBOARD.test(sender.url || sender.tab?.url || "") || sender.frameId > 0 ||
          !Number.isInteger(sender.tab?.id)) {
        sendResponse({ ok: false, error: "آماده‌سازی نشست گواهی فقط از پیشخوان صندوق در دسترس است." });
        return false;
      }
      const store = sender.tab.cookieStoreId || (sender.tab.incognito ? "private" : "default");
      const previous = cspfSessionOpenings.get(store);
      if (previous?.action !== cspfAction) {
        const operation = Promise.resolve(previous?.operation)
          .then(() => openCspfCertificateSession(sender.tab, cspfAction))
          .catch((error) => ({ ok: false, error: error.message }))
          .finally(() => {
            if (cspfSessionOpenings.get(store)?.operation === operation) cspfSessionOpenings.delete(store);
          });
        cspfSessionOpenings.set(store, { operation, action: cspfAction });
      }
      cspfSessionOpenings.get(store).operation.then(sendResponse);
      return true;
    }
    const cspfMessage = /^CSPF_DIDAR_(?:GET_CONFIG|LOOKUP|TRANSFER|UPDATE)$/.test(message?.type || "");
    const fromOlive = sender.tab?.url?.startsWith("https://my.olivecredit.ir/");
    const popupURL = chrome.runtime.getURL?.("popup.html");
    const fromExtensionPopup = sender.id === chrome.runtime.id && (!sender.tab || Boolean(popupURL && sender.url === popupURL));
    if (fromExtensionPopup && message?.type === "DIDAR_POPUP_GET_STATUS") {
      sendToDidar({ type: "DIDAR_TODO_GET_STATUS" })
        .catch((error) => ({ ok: false, error: error.message }))
        .then(sendResponse);
      return true;
    }
    const supportedMessage = message?.type?.startsWith("ETEBARITO_DIDAR_") ||
      message?.type?.startsWith("BETA_DIDAR_") || message?.type?.startsWith("TAMIN_DIDAR_") || cspfMessage;
    if (fromCspf !== cspfMessage ||
        !(fromEtebarito || fromBeta || fromTamin || fromOlive || fromCspf || fromExtensionPopup) || !supportedMessage ||
        (fromOlive && !message?.type?.startsWith("ETEBARITO_DIDAR_")) ||
        (fromTamin && !message?.type?.startsWith("TAMIN_DIDAR_"))) {
      return false;
    }
    const source=fromOlive ? "olive" : fromBeta ? "beta" : fromTamin ? "tamin" : fromCspf ? "cspf" : "etebarito";
    sendToDidar(fromOlive ? { ...message, payload: { ...message.payload, provider: "olive" } } : message)
      .catch((error) => ({
        ok: false,
        error: error.message,
        code: error.code || "DIDAR_TAB_CONNECTION_FAILED",
        httpStatus: error.status, endpoint: error.endpoint
      }))
      .then(response=>diagnosticResponse(message,response,source))
      .then(sendResponse);
    return true;
  });
})();
