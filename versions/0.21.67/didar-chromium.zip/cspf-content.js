(function initializeCspfDashboard() {
  "use strict";

  if (globalThis.__didarCspfDashboardLoaded) {
    return;
  }
  globalThis.__didarCspfDashboardLoaded = true;

  const Core = globalThis.CspfCreditCore;
  const browserApi = globalThis.browser || globalThis.chrome;
  const PANEL_ID = "didar-cspf-credit-panel";
  const PROFILE_PATH = "/Auth-api/Api/user/profile";
  const PENSION_PATH = "/Auth-api/Api/user/pensionaryDetails";
  const CERTIFICATE_ENTRY = "/Certificate/Default.aspx";
  const CERTIFICATE_LIST = "/Certificate/MainList.aspx";
  const CONTINUE_ID = "ContentPlaceHolder1_ContentPlaceHolder_detail_btnShowLoan";
  let pendingReport;
  let previewOpening = false;
  let scheduled = 0;

  function isDashboard() {
    return /^\/auth-api\/?$/i.test(location.pathname);
  }

  function element(tag, className, value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value !== undefined) node.textContent = value;
    return node;
  }

  function metric(label, key) {
    const wrapper = element("div", "didar-cspf-panel__metric");
    const title = element("span", "didar-cspf-panel__label", label);
    if (key === "remainingToman") {
      const warning = element("span", "didar-cspf-panel__warning-icon", "❌");
      warning.hidden = true;
      warning.setAttribute("aria-hidden", "true");
      title.append(" ", warning);
    }
    const value = element("strong", "didar-cspf-panel__value", "در حال دریافت...");
    value.dataset.metric = key;
    wrapper.append(title, value);
    return wrapper;
  }

  function dashboardAnchor() {
    const exact = Array.from(document.querySelectorAll("h1,h2,h3,h4,h5,h6,p,div,span"))
      .find((node) => Core.text(node.textContent) === "خدمات پر کاربرد");
    if (exact) {
      return exact.closest("section, article, .card, .grid") || exact;
    }
    const outlet = document.querySelector("router-outlet");
    return outlet?.nextElementSibling || document.querySelector("main, .layout-main, .layout-main-container");
  }

  function createPanel() {
    const panel = element("section", "didar-cspf-panel");
    panel.id = PANEL_ID;
    panel.dir = "rtl";
    panel.setAttribute("aria-label", "خلاصه اعتبار کشوری");

    const header = element("div", "didar-cspf-panel__header");
    const titles = element("div", "didar-cspf-panel__titles");
    titles.append(
      element("h2", "didar-cspf-panel__title", "خلاصه اعتبار کشوری"),
      element("p", "didar-cspf-panel__subtitle", "محاسبه توان قسط بر مبنای ۷۰٪ تتمه سقف مجاز")
    );
    const refresh = element("button", "didar-cspf-panel__refresh", "بروزرسانی");
    refresh.type = "button";
    refresh.title = "دریافت دوباره اطلاعات از سامانه صندوق";
    refresh.addEventListener("click", () => void loadSummary(panel));
    const transfer = element("button", "didar-cspf-panel__refresh didar-cspf-panel__transfer", "واکشی کشوری برای دیدار");
    transfer.type = "button";
    transfer.addEventListener("click", () => void showTransfer(panel, transfer));
    const actions = element("div", "didar-cspf-panel__actions");
    actions.append(refresh, transfer);
    header.append(titles, actions);

    const metrics = element("div", "didar-cspf-panel__metrics");
    metrics.append(
      metric("دفترکل", "daftarKol"),
      metric("شماره حساب", "bankAccount"),
      metric("تتمه سقف مجاز", "remainingToman"),
      metric("توان قسط", "installmentToman")
    );
    const status = element("p", "didar-cspf-panel__status", "");
    status.setAttribute("role", "status");
    panel.append(header, metrics, status);
    return panel;
  }

  function mountPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (!isDashboard()) {
      existing?.remove();
      return null;
    }
    if (existing) {
      return existing;
    }
    const anchor = dashboardAnchor();
    if (!anchor?.parentElement) {
      return null;
    }
    const panel = createPanel();
    anchor.parentElement.insertBefore(panel, anchor);
    void loadSummary(panel);
    return panel;
  }

  function setMetric(panel, key, value) {
    const target = panel.querySelector(`[data-metric="${key}"]`);
    if (target) target.textContent = value || "ناموجود";
  }

  function visibleDaftarKol() {
    const header = document.querySelector("app-topbar");
    const text = header?.innerText ?? header?.textContent ?? "";
    const readable = text.replace(/[\u200c-\u200f:\uFF1A]/g, " ");
    const numbers = new Set(Array.from(readable.matchAll(/دفتر\s*کل\s+([\d۰-۹٠-٩]{4,20})(?![\d۰-۹٠-٩])/g),
      (match) => Core.digits(match[1])));
    return numbers.size === 1 ? [...numbers][0] : "";
  }

  function setStatus(panel, value, state = "") {
    panel.dataset.state = state;
    panel.querySelector(".didar-cspf-panel__warning-icon").hidden = state !== "warning";
    const status = panel.querySelector(".didar-cspf-panel__status");
    if (status) status.textContent = value;
  }

  function documentFromHtml(value) {
    return new DOMParser().parseFromString(value, "text/html");
  }

  async function request(path, accept, options = {}) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch(path, {
        ...options,
        credentials: "include",
        cache: "no-store",
        headers: { Accept: accept },
        signal: controller.signal
      });
      const finalUrl = new URL(response.url, location.origin);
      const certificateRoute = /^\/certificate\//i.test(path);
      const body = finalUrl.origin === location.origin ? await response.text() : "";
      if (certificateRoute && /Web Page Blocked|The URL you requested has been blocked/i.test(body)) {
        throw Object.assign(new Error("صندوق دسترسی به گواهی کسر از حقوق را مسدود کرده است. مبلغ تتمه و توان قسط از صندوق دریافت نشد."),
          { code: "PERMISSION_DENIED", status: response.status });
      }
      if (response.status === 401 || response.status === 403 ||
          finalUrl.origin !== location.origin || /^\/auth-api\/auth\/login/i.test(finalUrl.pathname)) {
        throw Object.assign(new Error("نشست صندوق برای دریافت اطلاعات معتبر نیست؛ دوباره وارد صندوق شوید و واکشی را بزنید."),
          { code: "CSPF_AUTH_REQUIRED" });
      }
      if (!response.ok) {
        const source = certificateRoute ? "دریافت گواهی از صندوق" : "دریافت اطلاعات پیشخوان صندوق";
        throw Object.assign(new Error(`${source} انجام نشد (HTTP ${response.status}).`), { status: response.status });
      }
      return { url: finalUrl, body };
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new Error("پاسخ سامانه صندوق بیش از حد طول کشید؛ دوباره تلاش کنید.");
      }
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  async function currentProfile() {
    const { url, body } = await request(PROFILE_PATH, "application/json");
    if (url.pathname.toLowerCase() !== PROFILE_PATH.toLowerCase() || !body.trimStart().startsWith("{")) {
      throw new Error("پروفایل از نشست صندوق دریافت نشد؛ دوباره وارد صندوق شوید.");
    }
    const data = JSON.parse(body);
    const fullName = [data.firstName, data.lastName].map(Core.text).filter(Boolean).join(" ");
    const nationalCode = Core.digits(data.nationalCode);
    if (fullName.trim().split(/\s+/).length < 2 || !/^\d{10}$/.test(nationalCode)) {
      throw new Error("نام و کد ملی کامل در پروفایل صندوق پیدا نشد.");
    }
    return { fullName, nationalCode, mobile: globalThis.BetaCreditCore.normalizeMobile(data.phoneNumber), birthDateJalali: "" };
  }

  async function certificatePage(path, options) {
    const { url, body } = await request(path, "text/html,application/xhtml+xml", options);
    if (![CERTIFICATE_ENTRY.toLowerCase(), CERTIFICATE_LIST.toLowerCase()].includes(url.pathname.toLowerCase())) {
      throw Object.assign(new Error("صندوق صفحهٔ گواهی را در نشست فعلی باز نکرد."),
        { code: "CSPF_CERTIFICATE_SESSION" });
    }
    return { url, document: documentFromHtml(body) };
  }

  async function openCertificateSession(type) {
    let opened;
    try {
      opened = await browserApi.runtime.sendMessage({ type });
    } catch (error) {
      if (!/receiving end does not exist|message port closed|extension context invalidated/i.test(error?.message || "")) throw error;
    }
    if (!opened) throw new Error("پیشخوان پاسخی از بخش آماده‌سازی گواهی افزونه نگرفت. همین تب صندوق را تازه‌سازی کنید.");
    if (!opened.ok) throw new Error(opened.error || "افزونه نتوانست نشست گواهی صندوق را آماده کند.");
    return opened;
  }

  async function certificateEntry(allowWarmup) {
    try {
      return await certificatePage(CERTIFICATE_ENTRY);
    } catch (error) {
      if (!allowWarmup || !["CSPF_AUTH_REQUIRED", "CSPF_CERTIFICATE_SESSION"].includes(error?.code) || !isDashboard()) throw error;
      await openCertificateSession("CSPF_OPEN_CERTIFICATE_SESSION");
      return certificatePage(CERTIFICATE_ENTRY);
    }
  }

  async function certificateDocument(allowWarmup = true) {
    let page = await certificateEntry(allowWarmup);
    if (page.url.pathname.toLowerCase() === CERTIFICATE_LIST.toLowerCase()) return page.document;
    const button = page.document.getElementById(CONTINUE_ID);
    const form = button?.form;
    const action = form && new URL(form.getAttribute("action") || page.url, page.url);
    if (button?.type !== "submit" || !button.name.endsWith("$btnShowLoan") || !action ||
        form.method.toLowerCase() !== "post" || action.origin !== location.origin ||
        action.pathname.toLowerCase() !== CERTIFICATE_ENTRY.toLowerCase()) {
      throw new Error("دکمهٔ «ادامه» گواهی در نشست صندوق پیدا نشد؛ نشست را دوباره بررسی کنید.");
    }
    const body = new URLSearchParams();
    for (const input of form.querySelectorAll('input[type="hidden"][name]')) {
      if (!input.disabled) body.append(input.name, input.value);
    }
    body.set(button.name, button.value);
    page = await certificatePage(action.pathname + action.search, { method: "POST", body });
    if (page.url.pathname.toLowerCase() !== CERTIFICATE_LIST.toLowerCase()) {
      throw new Error("صندوق پس از «ادامه» فهرست گواهی را نمایش نداد.");
    }
    return page.document;
  }

  async function selectedPensionDetails() {
    const { url, body } = await request(PENSION_PATH, "application/json");
    if (url.pathname.toLowerCase() !== PENSION_PATH.toLowerCase()) return {};
    const rows = JSON.parse(body);
    if (!Array.isArray(rows)) return {};
    const selected = rows.filter((row) => row?.isSelected === true);
    const pension = selected.length === 1 ? selected[0] : selected.length === 0 && rows.length === 1 ? rows[0] : null;
    return {
      daftarKol: Core.digits(pension?.pensionaryIdentifier),
      bankAccount: Core.digits(pension?.bankAccountNumber)
    };
  }

  async function verifiedCertificateFormat(identity, allowWarmup = true) {
    const certificate = await certificateDocument(allowWarmup);
    if (Core.isEmptyCertificate(certificate) || Core.certificateMatchesName(certificate, identity.fullName)) return certificate;
    const reading = await openCertificateSession("CSPF_READ_RENDERED_CERTIFICATE");
    return reading.certificateText ? { body: { innerText: reading.certificateText } } : certificate;
  }

  async function readRemainingRials(identity, verify) {
    let certificate = await verifiedCertificateFormat(identity);
    if (!Core.isEmptyCertificate(certificate) && !Core.certificateMatchesName(certificate, identity.fullName)) {
      await verify();
      await openCertificateSession("CSPF_RENEW_CERTIFICATE_SESSION");
      certificate = await verifiedCertificateFormat(identity, false);
    }
    const remainingRials = Core.extractRemainingRials(certificate);
    if (!remainingRials || Core.isEmptyCertificate(certificate)) {
      throw new Error("تتمه سقف مجاز در گواهی این مشتری قابل خواندن نبود.");
    }
    if (!Core.certificateMatchesName(certificate, identity.fullName)) {
      throw new Error("صندوق پس از تازه‌سازی نشست، گواهی همین مشتری را برنگرداند. اطلاعات گواهی به دیدار منتقل نشد.");
    }
    return remainingRials;
  }

  async function readReport(renderPension) {
    const identity = await currentProfile();
    const verify = async () => {
      if (!isDashboard() || (await currentProfile()).nationalCode !== identity.nationalCode) {
        throw new Error("حساب صندوق تغییر کرده است؛ از پیشخوان مشتری دوباره واکشی کنید.");
      }
    };
    const [report, pensionResult] = await Promise.allSettled([
      readRemainingRials(identity, verify),
      selectedPensionDetails()
    ]);
    await verify();
    const pension = pensionResult.status === "fulfilled" ? pensionResult.value : {};
    const claims = Core.findPensionClaims(localStorage);
    const matchingClaims = (claims.nationalCode === identity.nationalCode ||
      (!claims.nationalCode && Core.nameKey(claims.fullName) === Core.nameKey(identity.fullName))) &&
      (!pension.daftarKol || claims.daftarKol === pension.daftarKol);
    const stored = report.status === "fulfilled" && matchingClaims ? claims : {};
    renderPension({
      daftarKol: pension.daftarKol || stored.daftarKol,
      bankAccount: pension.bankAccount || stored.bankAccount
    });
    if (report.status === "rejected") throw report.reason;
    return {
      identity,
      creditReport: { provider: "cspf", nationalCode: identity.nationalCode, remainingRials: report.value },
      verify
    };
  }

  async function loadSummary(panel) {
    if (pendingReport) return pendingReport;
    if (!panel?.isConnected) return null;
    panel.classList.add("is-loading");
    const refresh = panel.querySelector(".didar-cspf-panel__refresh");
    refresh.disabled = true;
    setMetric(panel, "daftarKol", visibleDaftarKol());
    setStatus(panel, "در حال دریافت اطلاعات از سامانه صندوق...");
    pendingReport = updateSummary(panel, refresh);
    return pendingReport;
  }

  async function updateSummary(panel, refresh) {
    let pension = {};
    try {
      const report = await readReport((value) => { pension = value; });
      const { remaining, installment, warning } = Core.formatAmounts(report.creditReport.remainingRials);
      setMetric(panel, "remainingToman", `${remaining} تومان`);
      setMetric(panel, "installmentToman", `${installment} تومان`);
      setStatus(panel, warning || "اطلاعات از نشست جاری صندوق دریافت شد.", warning ? "warning" : "ready");
      return report;
    } catch (error) {
      setStatus(panel, error?.message || "دریافت اطلاعات انجام نشد.", "error");
      void globalThis.DidarDiagnostics?.report({source:"cspf",operation:"fetch",error});
      setMetric(panel, "remainingToman", "");
      setMetric(panel, "installmentToman", "");
      return null;
    } finally {
      setMetric(panel, "daftarKol", pension.daftarKol || visibleDaftarKol());
      setMetric(panel, "bankAccount", pension.bankAccount);
      pendingReport = null;
      refresh.disabled = false;
      panel.classList.remove("is-loading");
    }
  }

  async function showTransfer(panel, button) {
    if (previewOpening) return;
    previewOpening = true;
    button.disabled = true;
    try {
      const report = await loadSummary(panel);
      if (report && panel.isConnected && isDashboard()) {
        await globalThis.DidarOpenCspfPreview(report);
      }
    } catch (error) {
      setStatus(panel, error?.message || "پیش‌نمایش دیدار باز نشد.", "error");
      void globalThis.DidarDiagnostics?.report({ source: "cspf", operation: "fetch", error });
    } finally {
      previewOpening = false;
      button.disabled = false;
    }
  }

  function scheduleMount() {
    window.clearTimeout(scheduled);
    scheduled = window.setTimeout(mountPanel, 80);
  }

  const observer = new MutationObserver(scheduleMount);
  function start() {
    observer.observe(document.documentElement, { childList: true, subtree: true });
    scheduleMount();
    window.addEventListener("popstate", scheduleMount);
    window.addEventListener("hashchange", scheduleMount);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
