(function initializeCloudClient() {
  "use strict";
  const api = globalThis.browser || globalThis.chrome;
  let queue = Promise.resolve();
  let connection = null;
  let executionKey = "";
  async function send(message) {
    const result = await api.runtime.sendMessage(message);
    if (!result?.ok) {
      const error = new Error(result?.error || "پاسخ اتصال ابری دریافت نشد.");
      Object.assign(error, { code: result?.code, status: result?.httpStatus });
      throw error;
    }
    return result.value;
  }
  const storage = {};
  for (const method of ["get", "set", "remove"]) {
    storage[method] = value => send({ type: "DIDAR_CLOUD_STORAGE", method, value });
  }
  globalThis.DidarCloudExtensionAPI = { runtime: api.runtime, storage: { local: storage, onChanged: {} } };
  globalThis.DidarCloudClient = {
    request(path, options) {
      return send({ type: "DIDAR_CLOUD_API", route: "/request", connection, input: { path, options, executionKey } });
    },
    async identity() {
      const value = await send({ type: "DIDAR_CLOUD_API", route: "/identity", connection, input: {} });
      return value.identity;
    },
    install(handler) {
      api.runtime.onMessage.addListener((message, sender, respond) => {
        if (message?.type !== "DIDAR_CLOUD_EXECUTE" || sender.id !== api.runtime.id || sender.tab) return false;
        if (message.ping) { respond({ ok: true }); return false; }
        const operation = queue.then(async () => {
          connection = await send({ type: "DIDAR_CLOUD_CONNECTION" });
          const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(message.message)));
          executionKey = Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
          localStorage.setItem("account", "cloud-credit");
          return handler(message.message);
        });
        queue = operation.catch(() => {});
        operation.then(respond, error => respond({ ok: false, error: error.message, code: error.code }));
        return true;
      });
    }
  };
})();
