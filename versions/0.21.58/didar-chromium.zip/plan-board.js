(function initializeDidarPlanBoard() {
  "use strict";

  if (globalThis.DidarPlanBoard) {
    return;
  }

  const Core = globalThis.DidarTodoCore;

  const GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const DEFAULT_PIPELINE = "پرونده اعتباری";
  const TITLE_PREFIX = "شروع طرح";
  const FAILED_PLAN_LABEL = "ناموفق شدن طرح";
  const PAGE_SIZE = 100;
  const ACTIVITY_PAGE_SIZE = 100;
  const MAX_ACTIVITY_PAGES = 200;
  const DEAL_DETAIL_WORKERS = 8;
  const DEAL_CACHE_MS = 2 * 60 * 1000;
  const RECENT_DAYS = 30;
  const STORAGE_PREFIX = "didar-plan-board:pipeline:v1:";
  const ORDER_PREFIX = "didar-plan-board:order:v1:";
  const FILTER_PREFIX = "didar-plan-board:filters:v1:";
  const DRAFT_PREFIX = "didar-plan-board:product-draft:v1:";
  const persianDate = new Intl.DateTimeFormat("en-US-u-ca-persian-nu-latn", {
    timeZone: "Asia/Tehran", year: "numeric", month: "numeric", day: "numeric"
  });
  const persianDateUtc = new Intl.DateTimeFormat("en-US-u-ca-persian-nu-latn", {
    timeZone: "UTC", year: "numeric", month: "numeric", day: "numeric"
  });
  const gregorianDate = new Intl.DateTimeFormat("en-US-u-ca-gregory-nu-latn", {
    timeZone: "Asia/Tehran", year: "numeric", month: "numeric", day: "numeric"
  });
  const persianMonth = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
    timeZone: "UTC", month: "long"
  });
  const WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];

  function text(value) {
    return String(value == null ? "" : value).replace(/\s+/g, " ").trim();
  }

  function id(value) {
    const candidate = text(value).toLowerCase();
    return GUID.test(candidate) ? candidate : "";
  }

  function list(value) {
    return Array.isArray(value) ? value : Array.isArray(value?.List) ? value.List : [];
  }

  function count(value) {
    const number = Number(value?.TotalCount ?? value?.Total);
    return Number.isFinite(number) ? number : null;
  }

  function labelIds(value) {
    const values = Array.isArray(value) ? value : typeof value === "string" ? value.split("#") : [];
    return values.map((item) => id(item)).filter(Boolean);
  }

  function dateParts(formatter, date) {
    return Object.fromEntries(formatter.formatToParts(date)
      .filter((part) => ["year", "month", "day"].includes(part.type))
      .map((part) => [part.type, Number(part.value)]));
  }

  function jalaliDay(value, utc = false) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    const parts = dateParts(utc ? persianDateUtc : persianDate, date);
    return `${parts.year}/${String(parts.month).padStart(2, "0")}/${String(parts.day).padStart(2, "0")}`;
  }

  function localIsoDay(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    const parts = dateParts(gregorianDate, date);
    return `${parts.year}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}`;
  }

  function recentStartDate(today) {
    const current = localIsoDay(today);
    return current
      ? new Date(Date.parse(`${current}T00:00:00Z`) - (RECENT_DAYS - 1) * 86400000).toISOString().slice(0, 10)
      : "";
  }

  function parseJalaliDay(value) {
    const digits = text(value).replace(/[۰-۹]/g, (digit) => String(digit.charCodeAt(0) - 1776))
      .replace(/[٠-٩]/g, (digit) => String(digit.charCodeAt(0) - 1632));
    const match = /^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/.exec(digits);
    if (!match) return "";
    const target = Number(match[1]) * 10000 + Number(match[2]) * 100 + Number(match[3]);
    let low = Date.UTC(Number(match[1]) + 620, 0, 1) / 86400000;
    let high = Date.UTC(Number(match[1]) + 623, 0, 1) / 86400000;
    while (low < high) {
      const mid = Math.floor((low + high) / 2);
      const parts = dateParts(persianDateUtc, new Date(mid * 86400000));
      const current = parts.year * 10000 + parts.month * 100 + parts.day;
      if (current < target) low = mid + 1;
      else high = mid;
    }
    const date = new Date(low * 86400000);
    return jalaliDay(date, true) === `${match[1]}/${match[2].padStart(2, "0")}/${match[3].padStart(2, "0")}`
      ? date.toISOString().slice(0, 10) : "";
  }

  function persianDigits(value) {
    return String(value).replace(/\d/g, (digit) => String.fromCharCode(1776 + Number(digit)));
  }

  function normalizeMoneyText(value) {
    return text(value)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/[\s,٬،]/g, "");
  }

  function formatMoney(value) {
    const normalized = normalizeMoneyText(value);
    const match = normalized.match(/^(\d*)(?:\.(\d*))?$/);
    if (!match) return normalized;
    const whole = match[1] || "0";
    const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return match[2] === undefined ? grouped : `${grouped}.${match[2]}`;
  }

  function formatMoneyInput(input) {
    const caret = input.selectionStart ?? input.value.length;
    const significantBeforeCaret = normalizeMoneyText(input.value.slice(0, caret))
      .replace(/[^\d.]/g, "").length;
    const formatted = formatMoney(input.value);
    input.value = formatted;
    if (document.activeElement !== input) return;
    if (!significantBeforeCaret) {
      input.setSelectionRange(0, 0);
      return;
    }
    let nextCaret = formatted.length;
    let seen = 0;
    for (let index = 0; index < formatted.length; index += 1) {
      if (/[\d.]/.test(formatted[index])) seen += 1;
      if (seen >= significantBeforeCaret) {
        nextCaret = index + 1;
        break;
      }
    }
    input.setSelectionRange(nextCaret, nextCaret);
  }

  function delay(milliseconds) {
    return new Promise((resolve) => setTimeout(resolve, milliseconds));
  }

  function olderActivitiesError(error, loadedCount) {
    const raw = text(error?.message);
    const prefix = loadedCount
      ? `${persianDigits(loadedCount)} فعالیت دریافت‌شده حفظ شد. `
      : "";
    if (error?.code === "DIDAR_TRANSIENT_SERVER_ERROR" ||
        /object reference not set to an instance of an object/i.test(raw)) {
      return `${prefix}دیدار هنگام دریافت فعالیت‌های قدیمی پاسخ موقت نامعتبر داد؛ برای ادامه دوباره روی دکمه دریافت کلیک کنید.`;
    }
    return `${prefix}${raw || "دریافت فعالیت‌های قدیمی‌تر انجام نشد؛ دوباره تلاش کنید."}`;
  }

  function calendarMonth(year, month) {
    const first = parseJalaliDay(`${year}/${month}/1`);
    const nextYear = month === 12 ? year + 1 : year;
    const nextMonth = month === 12 ? 1 : month + 1;
    const next = parseJalaliDay(`${nextYear}/${nextMonth}/1`);
    if (!first || !next) return null;
    const firstDate = new Date(`${first}T00:00:00Z`);
    return {
      first,
      days: Math.round((Date.parse(next) - Date.parse(first)) / 86400000),
      offset: (firstDate.getUTCDay() + 1) % 7,
      title: persianMonth.format(firstDate)
    };
  }

  function activityStart(activity) {
    return activity?.StartDate || activity?.RegisterDate || activity?.OriginalDueDate || activity?.DueDate || "";
  }

  function planFailureState(activity) {
    try {
      const failed = Core.parseTodoRows(Core.todoNote(activity))
        .find((item) => Core.normalizeLabel(item.label) === Core.normalizeLabel(FAILED_PLAN_LABEL));
      return failed ? failed.checked : null;
    } catch {
      return null;
    }
  }

  function activityStatusView(activity) {
    if (planFailureState(activity) === true) {
      return { key: "failed", label: "ناموفق" };
    }
    return activity?.IsDone
      ? { key: "done", label: "تکمیل‌شده" }
      : { key: "open", label: "باز" };
  }

  function filterRows(rows, filters) {
    const query = text(filters.query).toLocaleLowerCase("fa");
    return rows.filter(({ activity, deal }) => {
      if (query && !`${text(deal.Title)} ${text(activity.Title)} ${text(deal.Code)}`
        .toLocaleLowerCase("fa").includes(query)) return false;
      const planStatus = activityStatusView(activity).key;
      if (filters.activityStatus && filters.activityStatus !== "all" && filters.activityStatus !== planStatus) return false;
      if (filters.dealStatus && text(deal.Status).toLowerCase() !== filters.dealStatus.toLowerCase()) return false;
      const start = activityStart(activity);
      const day = start ? localIsoDay(start) : "";
      if (filters.from && (!day || day < filters.from)) return false;
      if (filters.to && (!day || day > filters.to)) return false;
      if (filters.labelIds && !labelIds(deal.LabelIds).some((label) => filters.labelIds.has(label))) return false;
      return true;
    });
  }

  function planTypes(value) {
    const seen = new Set();
    return list(value)
      .map((item) => ({
        id: id(item?.Id),
        title: text(item?.Title),
        index: Number.isFinite(Number(item?.Index)) ? Number(item.Index) : Number.MAX_SAFE_INTEGER
      }))
      .filter((item) => item.id && item.title.startsWith(`${TITLE_PREFIX} `))
      .filter((item) => {
        if (seen.has(item.id)) {
          return false;
        }
        seen.add(item.id);
        return true;
      })
      .sort((left, right) => left.index - right.index || left.title.localeCompare(right.title, "fa"));
  }

  function matchingActivities(activities, deals, types) {
    const dealById = new Map(deals.map((deal) => [id(deal.Id), deal]));
    const typeById = new Map(types.map((type) => [type.id, type]));
    const seen = new Set();
    return activities.flatMap((activity) => {
      const activityId = id(activity?.Id);
      const deal = dealById.get(id(activity?.DealId || activity?.Deal?.Id));
      const type = typeById.get(id(activity?.ActivityTypeId));
      if (!activityId || !deal || !type || activity?.IsDeleted === true || seen.has(activityId) ||
          !text(activity?.Title).startsWith(TITLE_PREFIX)) {
        return [];
      }
      seen.add(activityId);
      return [{ activity, deal, type }];
    });
  }

  async function paged(apiRequest, path, baseBody, limit, onProgress, onPage) {
    const result = [];
    const seen = new Set();
    let offset = 0;
    while (offset < limit) {
      const response = await apiRequest(path, {
        body: { ...baseBody, From: offset, Limit: PAGE_SIZE },
        retry: true
      });
      const rows = list(response);
      const total = count(response);
      if (!rows.length) {
        if (total !== null && offset < total) {
          throw new Error("فهرست از دیدار به‌طور کامل دریافت نشد. دوباره تلاش کنید.");
        }
        return result;
      }
      let added = 0;
      const page = [];
      rows.forEach((row) => {
        const rowId = id(row?.Id);
        if (rowId && !seen.has(rowId)) {
          seen.add(rowId);
          result.push(row);
          page.push(row);
          added += 1;
        }
      });
      if (!added) {
        throw new Error("صفحه‌بندی دیدار یک صفحه تکراری برگرداند؛ فهرست ناقص نمایش داده نمی‌شود.");
      }
      offset += rows.length;
      onPage?.(page);
      onProgress?.(result.length);
      if (total !== null && offset >= total) {
        return result;
      }
      if (rows.length < PAGE_SIZE && total === null) {
        return result;
      }
    }
    throw new Error("تعداد رکوردها از سقف این نما بیشتر است؛ فهرست ناقص نمایش داده نمی‌شود.");
  }

  function create({ apiRequest, accountKey = () => "", userKey = () => "", today = () => new Date(),
    resolveProduct = () => ({ item: null }), saveChecklist = null, saveProduct = null,
    createActivity = null, loadProductLabels = null }) {
    const state = {
      open: false,
      loading: false,
      pipelines: [],
      types: [],
      selectedPipelineId: "",
      rows: [],
      query: "",
      userId: "",
      columnOrder: [],
      labels: [],
      selectedLabelIds: null,
      activityStatus: "all",
      dealStatus: "Pending",
      defaultActivityStatus: "all",
      defaultDealStatus: "Pending",
      from: recentStartDate(today()),
      to: localIsoDay(today()),
      loadedFrom: "",
      activityOffset: 0,
      activityTotal: null,
      hasMoreActivities: false,
      loadingMore: false,
      loadingFailureStatus: false,
      sequence: 0,
      error: "",
      progress: "",
      filterError: "",
      labelError: ""
    };
    let panel = null;
    let navButton = null;
    let openedLocation = "";
    let expandedActivityId = "";
    let rowsRenderTimer = 0;
    const cardDetails = new Map();
    const cardLoads = new Map();
    const dealLoads = new Map();
    const recentDeals = new Map();
    const dealActivityLoads = new Map();
    const drafts = new Map();
    const savingActivities = new Set();
    const savingProducts = new Set();
    const activityIds = new Set();
    const activityRecords = new Map();
    let createSearchTimer = 0;
    let createSearchSequence = 0;
    let selectedCreateTypeId = "";
    let selectedCreateDeal = null;
    let creatingActivity = false;
    let dealById = new Map();
    let failureHydration = null;
    const calendar = { field: "", year: 0, month: 0, selection: "" };

    function storageKey() {
      return `${STORAGE_PREFIX}${text(accountKey())}:${state.userId}`;
    }

    function orderKey() {
      return `${ORDER_PREFIX}${text(accountKey())}:${state.userId}:${state.selectedPipelineId}`;
    }

    function filterKey() {
      return `${FILTER_PREFIX}${text(accountKey())}:${state.userId}:${state.selectedPipelineId}`;
    }

    function draftKey(activityId) {
      return `${DRAFT_PREFIX}${text(accountKey())}:${activityId}`;
    }

    function readDraft(activityId) {
      try {
        return JSON.parse(sessionStorage.getItem(draftKey(activityId)) || "null");
      } catch {
        return null;
      }
    }

    function writeDraft(activityId, draft) {
      try {
        sessionStorage.setItem(draftKey(activityId), JSON.stringify(draft));
      } catch {
        // The in-memory draft remains available until the board is closed.
      }
    }

    function removeDraft(activityId) {
      try {
        sessionStorage.removeItem(draftKey(activityId));
      } catch {
        // A confirmed server save is not failed by unavailable session storage.
      }
    }

    function loadFilterDefaults() {
      let saved = null;
      try {
        saved = JSON.parse(localStorage.getItem(filterKey()) || "null");
      } catch {
        // Use the useful operational default when site storage is unavailable.
      }
      const activityStatus = ["all", "open", "done", "failed"].includes(saved?.activityStatus)
        ? saved.activityStatus : "all";
      const dealStatus = ["", "Pending", "Won", "Lost"].includes(saved?.dealStatus)
        ? saved.dealStatus : "Pending";
      state.defaultActivityStatus = activityStatus;
      state.defaultDealStatus = dealStatus;
      state.activityStatus = activityStatus;
      state.dealStatus = dealStatus;
    }

    function saveFilterDefaults() {
      state.defaultActivityStatus = state.activityStatus;
      state.defaultDealStatus = state.dealStatus;
      try {
        localStorage.setItem(filterKey(), JSON.stringify({
          activityStatus: state.activityStatus,
          dealStatus: state.dealStatus
        }));
      } catch {
        // Defaults remain active for the current board session.
      }
      state.progress = "وضعیت‌های فعلی به‌عنوان پیش‌فرض ذخیره شدند.";
      render();
    }

    function orderedTypes() {
      const positions = new Map(state.columnOrder.map((typeId, index) => [typeId, index]));
      return [...state.types].sort((left, right) =>
        (positions.get(left.id) ?? Number.MAX_SAFE_INTEGER) -
        (positions.get(right.id) ?? Number.MAX_SAFE_INTEGER));
    }

    function loadOrder() {
      try {
        const saved = JSON.parse(localStorage.getItem(orderKey()) || "[]");
        state.columnOrder = Array.isArray(saved) ? saved.filter((item) => state.types.some((type) => type.id === item)) : [];
      } catch {
        state.columnOrder = [];
      }
    }

    function moveColumn(sourceId, targetId) {
      const order = orderedTypes().map((type) => type.id);
      const sourceIndex = order.indexOf(sourceId);
      const targetIndex = order.indexOf(targetId);
      if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
      order.splice(sourceIndex, 1);
      order.splice(targetIndex, 0, sourceId);
      state.columnOrder = order;
      try {
        localStorage.setItem(orderKey(), JSON.stringify(order));
      } catch {
        // Keep the reordered columns usable in the current session.
      }
      renderCards();
    }

    function saveSelection() {
      try {
        localStorage.setItem(storageKey(), state.selectedPipelineId);
      } catch {
        // The current selection still works when site storage is unavailable.
      }
    }

    function selectedPipeline() {
      return state.pipelines.find((item) => item.id === state.selectedPipelineId);
    }

    function button(label, className, action, title = "") {
      const element = document.createElement("button");
      element.type = "button";
      element.className = className;
      element.textContent = label;
      if (title) {
        element.title = title;
      }
      element.addEventListener("click", action);
      return element;
    }

    function closeCreateDialog() {
      const overlay = panel?.querySelector(".didar-plan-board__create-backdrop");
      if (overlay) overlay.hidden = true;
      window.clearTimeout(createSearchTimer);
      createSearchSequence += 1;
      selectedCreateTypeId = "";
      selectedCreateDeal = null;
    }

    function openCreateDialog(typeId) {
      const overlay = panel?.querySelector(".didar-plan-board__create-backdrop");
      const type = state.types.find((item) => item.id === typeId);
      if (!overlay || !type || !createActivity) return;
      selectedCreateTypeId = type.id;
      selectedCreateDeal = null;
      overlay.querySelector(".didar-plan-board__create-title").textContent =
        `افزودن فعالیت «${text(type.title.slice(TITLE_PREFIX.length))}»`;
      const search = overlay.querySelector(".didar-plan-board__create-search");
      search.value = "";
      overlay.querySelector(".didar-plan-board__create-results").replaceChildren();
      overlay.querySelector(".didar-plan-board__create-message").textContent =
        "نام مشتری، عنوان یا کد معامله را وارد کنید.";
      overlay.querySelector(".didar-plan-board__create-submit").disabled = true;
      overlay.hidden = false;
      search.focus();
    }

    async function searchCreateDeals(query) {
      const overlay = panel?.querySelector(".didar-plan-board__create-backdrop");
      if (!overlay || overlay.hidden) return;
      const requestId = ++createSearchSequence;
      const results = overlay.querySelector(".didar-plan-board__create-results");
      const message = overlay.querySelector(".didar-plan-board__create-message");
      results.replaceChildren();
      selectedCreateDeal = null;
      overlay.querySelector(".didar-plan-board__create-submit").disabled = true;
      if (query.length < 2) {
        message.textContent = "برای جست‌وجوی معامله دست‌کم دو نویسه وارد کنید.";
        return;
      }
      message.textContent = "در حال جست‌وجوی معاملات...";
      try {
        const response = await apiRequest("deal/search", {
          body: { Criteria: { Keywords: query }, From: 0, Limit: 30 }, retry: true
        });
        if (requestId !== createSearchSequence || overlay.hidden) return;
        const deals = list(response).filter((deal) => id(deal?.Id) && !deal.IsDeleted);
        message.textContent = deals.length ? "معامله موردنظر را انتخاب کنید." : "معامله‌ای پیدا نشد.";
        const pending = [];
        deals.forEach((deal) => {
          const label = `${text(deal.Title) || "معامله بدون عنوان"}${deal.Code ? ` · کد ${text(deal.Code)}` : ""}`;
          const result = button("", "didar-plan-board__create-result", () => {
            selectedCreateDeal = deal;
            results.querySelectorAll("button").forEach((item) =>
              item.setAttribute("aria-pressed", String(item === result)));
            overlay.querySelector(".didar-plan-board__create-submit").disabled = false;
            message.textContent = `معامله انتخاب‌شده: ${label}`;
          });
          result.setAttribute("aria-pressed", "false");
          const caption = document.createElement("span");
          caption.className = "didar-plan-board__create-result-title";
          caption.textContent = label;
          const products = document.createElement("span");
          products.className = "didar-plan-board__create-result-products";
          products.setAttribute("aria-label", "محصولات این معامله");
          products.textContent = loadProductLabels ? "در حال دریافت محصولات..." : "اطلاعات محصولات در دسترس نیست";
          result.append(caption, products);
          result.disabled = Boolean(loadProductLabels);
          results.appendChild(result);
          if (loadProductLabels) pending.push({ deal, result, products });
        });
        let cursor = 0;
        const worker = async () => {
          while (cursor < pending.length && requestId === createSearchSequence && !overlay.hidden) {
            const { deal, result, products } = pending[cursor++];
            try {
              const labels = await loadProductLabels(deal);
              if (requestId !== createSearchSequence || overlay.hidden || !result.isConnected) return;
              products.replaceChildren();
              const unique = Array.from(new Set((Array.isArray(labels) ? labels : []).map(text).filter(Boolean)));
              if (unique.length) {
                unique.forEach((title) => {
                  const chip = document.createElement("span");
                  chip.className = "didar-plan-board__create-product";
                  chip.textContent = title;
                  products.appendChild(chip);
                });
              } else {
                products.textContent = "محصول طرحی ثبت نشده";
              }
            } catch {
              if (requestId !== createSearchSequence || overlay.hidden || !result.isConnected) return;
              products.textContent = "دریافت محصولات انجام نشد";
            } finally {
              if (requestId === createSearchSequence && result.isConnected) result.disabled = false;
            }
          }
        };
        void Promise.all(Array.from({ length: Math.min(6, pending.length) }, worker));
      } catch (error) {
        if (requestId === createSearchSequence) {
          message.textContent = error?.message || "جست‌وجوی معاملات انجام نشد.";
        }
      }
    }

    async function submitCreateActivity() {
      const overlay = panel?.querySelector(".didar-plan-board__create-backdrop");
      if (!overlay || overlay.hidden || creatingActivity || !selectedCreateDeal || !createActivity) return;
      const selectedType = state.types.find((type) => type.id === selectedCreateTypeId);
      if (!selectedType) return;
      const deal = selectedCreateDeal;
      const submit = overlay.querySelector(".didar-plan-board__create-submit");
      const message = overlay.querySelector(".didar-plan-board__create-message");
      creatingActivity = true;
      submit.disabled = true;
      message.textContent = "در حال ثبت فعالیت در معامله انتخاب‌شده...";
      try {
        await createActivity({ dealId: id(deal.Id), typeId: selectedType.id, title: selectedType.title });
        const pipelineId = id(deal.PipelineId);
        if (pipelineId && state.pipelines.some((pipeline) => pipeline.id === pipelineId) &&
            pipelineId !== state.selectedPipelineId) {
          state.selectedPipelineId = pipelineId;
          saveSelection();
          loadOrder();
          loadFilterDefaults();
        }
        closeCreateDialog();
        void loadRows(true);
      } catch (error) {
        message.textContent = error?.message || "ثبت فعالیت انجام نشد.";
        submit.disabled = false;
      } finally {
        creatingActivity = false;
      }
    }

    function hideCalendar() {
      const overlay = panel?.querySelector(".didar-plan-board__calendar-overlay");
      if (overlay) overlay.hidden = true;
      calendar.field = "";
    }

    function renderCalendar() {
      const dialog = panel?.querySelector(".didar-plan-board__calendar");
      const month = calendarMonth(calendar.year, calendar.month);
      if (!dialog || !month) return;
      dialog.querySelector(".didar-plan-board__calendar-caption").textContent =
        calendar.field === "from" ? "از تاریخ شروع فعالیت" : "تا تاریخ شروع فعالیت";
      dialog.querySelector(".didar-plan-board__calendar-month").value = String(calendar.month);
      dialog.querySelector(".didar-plan-board__calendar-year").value = String(calendar.year);
      const days = dialog.querySelector(".didar-plan-board__calendar-days");
      days.replaceChildren();
      for (let index = 0; index < 42; index += 1) {
        const day = index - month.offset + 1;
        if (day < 1 || day > month.days) {
          days.appendChild(document.createElement("span"));
          continue;
        }
        const iso = new Date(Date.parse(month.first) + (day - 1) * 86400000).toISOString().slice(0, 10);
        const dateButton = button(persianDigits(day), "didar-plan-board__calendar-day", () => {
          calendar.selection = iso;
          renderCalendar();
          dialog.querySelector(`.didar-plan-board__calendar-day[data-day="${day}"]`)?.focus();
        }, `${persianDigits(calendar.year)}/${persianDigits(String(calendar.month).padStart(2, "0"))}/${persianDigits(String(day).padStart(2, "0"))}`);
        dateButton.dataset.day = String(day);
        dateButton.setAttribute("aria-pressed", String(calendar.selection === iso));
        if (localIsoDay(today()) === iso) dateButton.classList.add("is-today");
        days.appendChild(dateButton);
      }
    }

    function openCalendar(field) {
      const overlay = panel?.querySelector(".didar-plan-board__calendar-overlay");
      if (!overlay) return;
      const selected = state[field];
      const current = selected ? jalaliDay(`${selected}T00:00:00Z`, true) : jalaliDay(today());
      [calendar.year, calendar.month] = current.split("/").map(Number);
      calendar.field = field;
      calendar.selection = selected;
      panel.querySelector(".didar-plan-board__labels").open = false;
      overlay.hidden = false;
      renderCalendar();
      (overlay.querySelector('.didar-plan-board__calendar-day[aria-pressed="true"]') ||
        overlay.querySelector(".didar-plan-board__calendar-day.is-today") ||
        overlay.querySelector(".didar-plan-board__calendar-year")).focus();
    }

    function createCalendar() {
      const overlay = document.createElement("div");
      overlay.className = "didar-plan-board__calendar-overlay";
      overlay.hidden = true;
      overlay.addEventListener("click", (event) => {
        if (event.target === overlay) hideCalendar();
      });
      const dialog = document.createElement("div");
      dialog.className = "didar-plan-board__calendar";
      dialog.setAttribute("role", "dialog");
      dialog.setAttribute("aria-modal", "true");
      dialog.setAttribute("aria-label", "انتخاب تاریخ شمسی شروع فعالیت");
      const heading = document.createElement("div");
      heading.className = "didar-plan-board__calendar-heading";
      const caption = document.createElement("strong");
      caption.className = "didar-plan-board__calendar-caption";
      heading.append(caption, button("×", "didar-plan-board__calendar-close", hideCalendar, "بستن تقویم"));
      const navigation = document.createElement("div");
      navigation.className = "didar-plan-board__calendar-navigation";
      function stepMonth(delta) {
        const serial = calendar.year * 12 + calendar.month - 1 + delta;
        calendar.year = Math.floor(serial / 12);
        calendar.month = ((serial % 12) + 12) % 12 + 1;
        renderCalendar();
      }
      const previous = button("›", "didar-plan-board__calendar-previous", () => stepMonth(-1), "ماه قبل");
      const monthSelect = document.createElement("select");
      monthSelect.className = "didar-plan-board__calendar-month";
      for (let month = 1; month <= 12; month += 1) {
        const option = document.createElement("option");
        option.value = String(month);
        option.textContent = calendarMonth(1400, month).title;
        monthSelect.appendChild(option);
      }
      monthSelect.setAttribute("aria-label", "ماه شمسی");
      monthSelect.addEventListener("change", () => {
        calendar.month = Number(monthSelect.value);
        renderCalendar();
      });
      const yearInput = document.createElement("input");
      yearInput.className = "didar-plan-board__calendar-year";
      yearInput.type = "number";
      yearInput.min = "1";
      yearInput.max = "9998";
      yearInput.setAttribute("aria-label", "سال شمسی");
      yearInput.addEventListener("change", () => {
        const year = Number(yearInput.value);
        if (Number.isInteger(year) && year > 0 && year < 9999) calendar.year = year;
        renderCalendar();
      });
      const next = button("‹", "didar-plan-board__calendar-next", () => stepMonth(1), "ماه بعد");
      navigation.append(previous, monthSelect, yearInput, next);
      const weekdays = document.createElement("div");
      weekdays.className = "didar-plan-board__calendar-weekdays";
      WEEKDAYS.forEach((day) => {
        const cell = document.createElement("span");
        cell.textContent = day.slice(0, 1);
        cell.title = day;
        weekdays.appendChild(cell);
      });
      const days = document.createElement("div");
      days.className = "didar-plan-board__calendar-days";
      const actions = document.createElement("div");
      actions.className = "didar-plan-board__calendar-actions";
      actions.append(
        button("امروز", "didar-plan-board__calendar-today", () => {
          calendar.selection = localIsoDay(today());
          [calendar.year, calendar.month] = jalaliDay(today()).split("/").map(Number);
          renderCalendar();
        }),
        button("پاک کردن", "didar-plan-board__calendar-clear", () => {
          calendar.selection = "";
          renderCalendar();
        }),
        button("تأیید", "didar-plan-board__calendar-confirm", () => {
          const field = calendar.field;
          state[field] = calendar.selection;
          panel.querySelector(`.didar-plan-board__date-${field}`).value = calendar.selection
            ? persianDigits(jalaliDay(`${calendar.selection}T00:00:00Z`, true)) : "";
          state.filterError = "";
          hideCalendar();
          if (field === "from" && state.loadedFrom && (!state.from || state.from < state.loadedFrom)) {
            void loadRows();
          } else {
            render();
          }
        })
      );
      dialog.append(heading, navigation, weekdays, days, actions);
      overlay.appendChild(dialog);
      return overlay;
    }

    function renderLabels() {
      const listElement = panel?.querySelector(".didar-plan-board__label-options");
      if (!listElement) return;
      const scrollTop = listElement.scrollTop;
      listElement.replaceChildren();
      const used = new Set(state.rows.flatMap(({ deal }) => labelIds(deal.LabelIds)));
      const labels = state.labels.filter((label) => used.has(label.id));
      const all = document.createElement("label");
      const allInput = document.createElement("input");
      allInput.type = "checkbox";
      allInput.checked = state.selectedLabelIds === null;
      allInput.addEventListener("change", () => {
        state.selectedLabelIds = null;
        renderLabels();
        renderCards();
      });
      all.append(allInput, document.createTextNode("همه برچسب‌ها"));
      listElement.appendChild(all);
      labels.forEach((label) => {
        const item = document.createElement("label");
        const input = document.createElement("input");
        input.type = "checkbox";
        input.value = label.id;
        input.checked = state.selectedLabelIds === null || state.selectedLabelIds.has(label.id);
        input.addEventListener("change", () => {
          const selected = state.selectedLabelIds === null
            ? new Set(labels.map((entry) => entry.id)) : new Set(state.selectedLabelIds);
          if (input.checked) selected.add(label.id);
          else selected.delete(label.id);
          state.selectedLabelIds = selected.size === labels.length ? null : selected;
          renderLabels();
          renderCards();
        });
        item.append(input, document.createTextNode(label.title));
        listElement.appendChild(item);
      });
      listElement.appendChild(button("تأیید", "didar-plan-board__labels-done", () => {
        panel.querySelector(".didar-plan-board__labels").open = false;
      }));
      const summary = panel.querySelector(".didar-plan-board__labels summary");
      summary.textContent = state.selectedLabelIds === null ? "همه برچسب‌ها" :
        `${state.selectedLabelIds.size} برچسب`;
      listElement.scrollTop = scrollTop;
    }

    function closeCardDetails() {
      expandedActivityId = "";
      const backdrop = panel?.querySelector(".didar-plan-board__detail-backdrop");
      if (backdrop) backdrop.hidden = true;
      panel?.querySelectorAll(".didar-plan-board__card.is-selected")
        .forEach((card) => card.classList.remove("is-selected"));
    }

    function renderDetailsDrawer() {
      if (!expandedActivityId || !panel) return;
      const row = state.rows.find((entry) => id(entry.activity.Id) === expandedActivityId);
      if (!row) return closeCardDetails();
      const drawer = panel.querySelector(".didar-plan-board__detail-drawer");
      if (!drawer) return;
      drawer.querySelector(".didar-plan-board__detail-title").textContent =
        text(row.deal.Title) || "معامله بدون عنوان";
      const dealLink = drawer.querySelector(".didar-plan-board__detail-link");
      dealLink.href = `/deal/${id(row.deal.Id)}`;
      const view = activityStatusView(row.activity);
      const status = drawer.querySelector(".didar-plan-board__detail-status");
      status.className = `didar-plan-board__status didar-plan-board__detail-status is-${view.key}`;
      status.textContent = view.label;
      const start = jalaliDay(activityStart(row.activity));
      drawer.querySelector(".didar-plan-board__detail-meta").textContent =
        [text(row.deal.Code) ? `کد ${text(row.deal.Code)}` : "", start ? `شروع ${start}` : ""]
          .filter(Boolean).join(" · ");
      const details = drawer.querySelector(".didar-plan-board__card-details");
      if (cardDetails.has(expandedActivityId)) renderCardDetails(drawer, row);
      else details.textContent = "در حال دریافت جزئیات فعالیت و محصول...";
    }

    function openCardDetails(row) {
      expandedActivityId = id(row.activity.Id);
      const backdrop = panel?.querySelector(".didar-plan-board__detail-backdrop");
      if (!backdrop) return;
      backdrop.hidden = false;
      panel.querySelectorAll(".didar-plan-board__card").forEach((card) =>
        card.classList.toggle("is-selected", card.dataset.activityId === expandedActivityId)
      );
      renderDetailsDrawer();
      backdrop.querySelector(".didar-plan-board__detail-close")?.focus();
      if (!cardDetails.has(expandedActivityId)) void loadCardDetails(row);
    }

    function refreshCard(activityId) {
      const row = state.rows.find((entry) => id(entry.activity.Id) === activityId);
      if (!row) return;
      panel?.querySelectorAll(`.didar-plan-board__card[data-activity-id="${activityId}"]`)
        .forEach((card) => {
          const status = card.querySelector(".didar-plan-board__status");
          const view = activityStatusView(row.activity);
          status.className = `didar-plan-board__status is-${view.key}`;
          status.textContent = view.label;
        });
      if (expandedActivityId === activityId) renderDetailsDrawer();
    }

    async function saveCardChecklist(row, index, label, targetChecked) {
      const activityId = id(row.activity.Id);
      const detail = cardDetails.get(activityId);
      if (!detail || savingActivities.has(activityId) || !saveChecklist) return;
      savingActivities.add(activityId);
      detail.error = "";
      refreshCard(activityId);
      try {
        const activity = await saveChecklist({
          activityId, dealId: id(row.deal.Id), index, label, targetChecked
        });
        if (id(activity?.Id) !== activityId) throw new Error("تأیید فعالیت اشتباه از سرور دریافت شد.");
        detail.activity = activity;
        row.activity = activity;
        renderCards();
      } catch (error) {
        detail.error = error?.message || "ذخیره چک‌باکس انجام نشد.";
        refreshCard(activityId);
      } finally {
        savingActivities.delete(activityId);
        refreshCard(activityId);
      }
    }

    async function saveCardProduct(row) {
      const activityId = id(row.activity.Id);
      const detail = cardDetails.get(activityId);
      const draft = drafts.get(activityId);
      if (!detail?.product?.item || !draft || savingProducts.has(activityId) || !saveProduct) return;
      savingProducts.add(activityId);
      detail.error = "";
      refreshCard(activityId);
      try {
        const verified = await saveProduct({
          activityId, dealId: id(row.deal.Id), itemId: id(detail.product.item.Id),
          description: draft.description, unitPrice: draft.unitPrice,
          baseDescription: text(detail.product.item.Description),
          baseUnitPrice: String(detail.product.item.UnitPrice ?? 0)
        });
        if (id(verified?.item?.Id) !== id(detail.product.item.Id)) {
          throw new Error("تأیید محصول اشتباه از سرور دریافت شد.");
        }
        detail.deal = verified.deal;
        detail.product = { ...detail.product, item: verified.item };
        drafts.delete(activityId);
        removeDraft(activityId);
        detail.notice = "ذخیره شد";
      } catch (error) {
        detail.error = error?.message || "ذخیره محصول انجام نشد.";
      } finally {
        savingProducts.delete(activityId);
        refreshCard(activityId);
      }
    }

    function renderCardDetails(card, row) {
      const activityId = id(row.activity.Id);
      const detail = cardDetails.get(activityId);
      const host = card.querySelector(".didar-plan-board__card-details");
      if (!host || !detail) return;
      host.replaceChildren();
      if (!detail.activity) {
        const error = document.createElement("p");
        error.className = "didar-plan-board__card-notice is-error";
        error.textContent = detail.error || "جزئیات دریافت نشد";
        host.append(error, button("تلاش دوباره", "didar-plan-board__card-retry", () => {
          cardDetails.delete(activityId);
          void loadCardDetails(row);
        }));
        return;
      }
      const activity = detail.activity;
      const canEdit = activity.CanEdit === true;
      const rows = Core.parseTodoRows(Core.todoNote(activity));
      const checklist = document.createElement("div");
      checklist.className = "didar-plan-board__checklist";
      rows.slice(0, 5).forEach((item, index) => {
        const label = document.createElement("label");
        label.title = item.label;
        const input = document.createElement("input");
        input.type = "checkbox";
        input.checked = item.checked;
        input.disabled = !canEdit || !saveChecklist || savingActivities.has(activityId);
        input.addEventListener("change", () => {
          const targetChecked = input.checked;
          input.checked = !targetChecked;
          void saveCardChecklist(row, index, item.label, targetChecked);
        });
        const caption = document.createElement("span");
        caption.textContent = item.label;
        label.append(input, caption);
        checklist.appendChild(label);
      });
      if (!rows.length) {
        const empty = document.createElement("span");
        empty.className = "didar-plan-board__card-notice";
        empty.textContent = "چک‌لیست موجود نیست";
        checklist.appendChild(empty);
      }
      host.appendChild(checklist);
      if (rows.length > 5) {
        const extra = document.createElement("small");
        extra.textContent = `${rows.length - 5} گزینه دیگر در معامله`;
        host.appendChild(extra);
      }
      const item = detail.product?.item;
      let draft = drafts.get(activityId);
      if (!draft) {
        draft = readDraft(activityId);
        if (draft) drafts.set(activityId, draft);
      }
      const editableProduct = Boolean(item && saveProduct && detail.deal?.CanEdit !== false);
      function productField(caption, className, value) {
        const field = document.createElement("label");
        field.className = "didar-plan-board__product-field";
        const name = document.createElement("span");
        name.textContent = caption;
        const input = document.createElement("input");
        const isPrice = className.endsWith("price");
        input.className = className;
        input.type = "text";
        input.inputMode = isPrice ? "decimal" : "text";
        input.value = isPrice ? formatMoney(value) : value;
        input.title = input.value;
        input.disabled = !editableProduct || savingProducts.has(activityId);
        input.addEventListener("input", () => {
          if (isPrice) formatMoneyInput(input);
          const current = drafts.get(activityId) || {
            description: text(item?.Description), unitPrice: String(item?.UnitPrice ?? 0)
          };
          current[isPrice ? "unitPrice" : "description"] = isPrice
            ? normalizeMoneyText(input.value)
            : input.value;
          drafts.set(activityId, current);
          writeDraft(activityId, current);
          detail.notice = "";
          input.title = input.value;
          const save = card.querySelector(".didar-plan-board__product-save");
          if (save) save.disabled = false;
        });
        field.append(name, input);
        return field;
      }
      host.append(
        productField("مبلغ", "didar-plan-board__product-price", draft?.unitPrice ?? String(item?.UnitPrice ?? "")),
        productField("توضیحات", "didar-plan-board__product-description", draft?.description ?? text(item?.Description))
      );
      const footer = document.createElement("div");
      footer.className = "didar-plan-board__card-footer";
      const save = button("ذخیره محصول", "didar-plan-board__product-save", () => void saveCardProduct(row));
      save.disabled = !editableProduct || !draft || savingProducts.has(activityId);
      const notice = document.createElement("span");
      notice.className = `didar-plan-board__card-notice${detail.error ? " is-error" : ""}`;
      notice.textContent = detail.error || (savingActivities.has(activityId) || savingProducts.has(activityId)
        ? "در حال ذخیره..." : detail.notice || (!item ? "محصول متناظر مشخص نیست" : ""));
      notice.title = notice.textContent;
      footer.append(save, notice);
      host.appendChild(footer);
    }

    function cachedRequest(cache, key, path, body) {
      if (!cache.has(key)) {
        const request = apiRequest(path, { body, retry: true }).catch((error) => {
          if (cache.get(key) === request) cache.delete(key);
          throw error;
        });
        cache.set(key, request);
      }
      return cache.get(key);
    }

    async function loadCardDetails(row) {
      const activityId = id(row.activity.Id);
      const dealId = id(row.deal.Id);
      if (cardDetails.has(activityId)) return refreshCard(activityId);
      if (cardLoads.has(activityId)) return cardLoads.get(activityId);
      const sequence = state.sequence;
      const request = (async () => {
        try {
          const [activity, deal, history] = await Promise.all([
            apiRequest("activity/GetActivityById", { body: { Id: activityId }, retry: true }),
            cachedRequest(dealLoads, dealId, "deal/GetDealDetail", { Id: dealId }),
            cachedRequest(dealActivityLoads, dealId, "activity/GetDetailActivities", { DealId: dealId })
          ]);
          if (sequence !== state.sequence) return;
          if (id(activity?.Id) !== activityId || id(activity?.DealId) !== dealId ||
              id(deal?.Id) !== dealId || id(deal?.PipelineId) !== state.selectedPipelineId) {
            throw new Error("شناسه فعالیت یا معامله با کاریز انتخاب‌شده همخوانی ندارد.");
          }
          const activities = [...list(history?.Planned), ...list(history?.Done), ...list(history?.Pinned)];
          const product = await resolveProduct(deal, activity, activities);
          cardDetails.set(activityId, { activity, deal, product, error: "", notice: "" });
          row.activity = activity;
        } catch (error) {
          if (sequence === state.sequence) cardDetails.set(activityId, { error: error?.message || "جزئیات دریافت نشد" });
        } finally {
          if (cardLoads.get(activityId) === request) cardLoads.delete(activityId);
          if (sequence === state.sequence) refreshCard(activityId);
        }
      })();
      cardLoads.set(activityId, request);
      return request;
    }

    function hydrateFailureStatuses() {
      if (!state.open || state.activityStatus !== "failed") return Promise.resolve();
      const sequence = state.sequence;
      if (failureHydration?.sequence === sequence) return failureHydration.promise;
      const unknown = state.rows.filter(({ activity }) => planFailureState(activity) === null);
      if (!unknown.length) return Promise.resolve();

      const task = (async () => {
        state.loadingFailureStatus = true;
        state.progress = `در حال بررسی وضعیت ناموفق ${persianDigits(unknown.length)} فعالیت...`;
        render();
        let cursor = 0;
        let failures = 0;
        const worker = async () => {
          while (cursor < unknown.length && sequence === state.sequence && state.activityStatus === "failed") {
            const row = unknown[cursor++];
            const activityId = id(row.activity.Id);
            try {
              const activity = await apiRequest("activity/GetActivityById", {
                body: { Id: activityId }, retry: true
              });
              if (sequence !== state.sequence || id(activity?.Id) !== activityId) continue;
              row.activity = activity;
              activityRecords.set(activityId, activity);
            } catch {
              failures += 1;
            }
          }
        };
        await Promise.all(Array.from({ length: Math.min(4, unknown.length) }, worker));
        if (sequence !== state.sequence) return;
        state.loadingFailureStatus = false;
        if (state.activityStatus !== "failed") {
          updateLoadedMessage();
          render();
          return;
        }
        const failedCount = state.rows.filter(({ activity }) => planFailureState(activity) === true).length;
        state.progress = failures
          ? `وضعیت ${persianDigits(unknown.length - failures)} فعالیت بررسی شد؛ ${persianDigits(failures)} مورد از دیدار پاسخ نگرفت.`
          : `${persianDigits(failedCount)} طرح ناموفق پیدا شد.`;
        render();
      })().finally(() => {
        if (failureHydration?.promise === task) failureHydration = null;
      });
      failureHydration = { sequence, promise: task };
      return task;
    }

    function renderCards() {
      const board = panel?.querySelector(".didar-plan-board__columns");
      if (!board) {
        return;
      }
      const horizontalScroll = board.scrollLeft;
      const verticalScroll = new Map(Array.from(board.querySelectorAll(".didar-plan-board__column"))
        .map((column) => [column.dataset.typeId, column.querySelector(".didar-plan-board__cards")?.scrollTop || 0]));
      board.replaceChildren();
      const filtered = filterRows(state.rows, { ...state, labelIds: state.selectedLabelIds });
      const types = orderedTypes();
      types.forEach((type, index) => {
        const rows = filtered.filter((row) => row.type.id === type.id);
        const column = document.createElement("section");
        column.className = "didar-plan-board__column";
        column.dataset.typeId = type.id;
        const header = document.createElement("header");
        header.className = "didar-plan-board__column-header";
        const titleActions = document.createElement("div");
        titleActions.className = "didar-plan-board__column-title-actions";
        const title = document.createElement("h2");
        title.textContent = text(type.title.slice(TITLE_PREFIX.length));
        const add = button("+", "didar-plan-board__column-add", () =>
          openCreateDialog(type.id), `افزودن فعالیت ${type.title}`);
        add.setAttribute("aria-label", `افزودن فعالیت ${type.title}`);
        add.disabled = !createActivity;
        titleActions.append(title, add);
        const counter = document.createElement("span");
        counter.className = "didar-plan-board__count";
        counter.textContent = String(rows.length);
        const orderControls = document.createElement("div");
        orderControls.className = "didar-plan-board__order-controls";
        const right = button("›", "didar-plan-board__move-right", () =>
          moveColumn(type.id, types[index - 1]?.id), "انتقال ستون به راست");
        const left = button("‹", "didar-plan-board__move-left", () =>
          moveColumn(type.id, types[index + 1]?.id), "انتقال ستون به چپ");
        right.disabled = index === 0;
        left.disabled = index === types.length - 1;
        orderControls.append(left, right);
        header.draggable = true;
        header.title = "برای تغییر ترتیب ستون بکشید";
        header.addEventListener("dragstart", (event) => {
          event.dataTransfer?.setData("text/plain", type.id);
        });
        header.addEventListener("dragover", (event) => event.preventDefault());
        header.addEventListener("drop", (event) => {
          event.preventDefault();
          moveColumn(event.dataTransfer?.getData("text/plain"), type.id);
        });
        header.append(titleActions, counter, orderControls);
        column.appendChild(header);
        const cards = document.createElement("div");
        cards.className = "didar-plan-board__cards";
        rows.forEach((row) => {
          const { activity, deal } = row;
          const card = document.createElement("article");
          const dealState = text(deal.Status).toLowerCase();
          card.className = `didar-plan-board__card is-deal-${dealState || "unknown"}`;
          card.dataset.activityId = id(activity.Id);
          if (expandedActivityId === id(activity.Id)) card.classList.add("is-selected");
          const title = document.createElement("h3");
          title.className = "didar-plan-board__card-title";
          title.textContent = text(deal.Title) || "معامله بدون عنوان";
          card.tabIndex = 0;
          card.setAttribute("aria-label", `مشاهده جزئیات ${title.textContent}`);
          card.addEventListener("click", (event) => {
            if (!event.target.closest("button, a, input")) openCardDetails(row);
          });
          card.addEventListener("keydown", (event) => {
            if (event.target === card && (event.key === "Enter" || event.key === " ")) {
              event.preventDefault();
              openCardDetails(row);
            }
          });
          const statuses = document.createElement("div");
          statuses.className = "didar-plan-board__statuses";
          const activityStatus = document.createElement("span");
          const activityView = activityStatusView(activity);
          activityStatus.className = `didar-plan-board__status is-${activityView.key}`;
          activityStatus.textContent = activityView.label;
          const dealStatus = document.createElement("span");
          dealStatus.className = `didar-plan-board__deal-status-badge is-${dealState || "unknown"}`;
          dealStatus.textContent = dealState === "won" ? "معامله موفق" :
            dealState === "lost" ? "معامله ناموفق" : dealState === "pending" ? "معامله جاری" : "وضعیت نامشخص";
          statuses.append(activityStatus, dealStatus);
          const meta = document.createElement("div");
          meta.className = "didar-plan-board__card-meta";
          const day = jalaliDay(activityStart(activity));
          meta.textContent = [text(deal.Code) ? `کد ${text(deal.Code)}` : "", day ? `شروع ${day}` : ""]
            .filter(Boolean).join(" · ");
          const openDetails = button("مشاهده جزئیات و ویرایش", "didar-plan-board__card-open", () =>
            openCardDetails(row));
          openDetails.setAttribute("aria-label", `مشاهده جزئیات ${title.textContent}`);
          card.append(statuses, title, meta, openDetails);
          cards.appendChild(card);
        });
        if (!rows.length) {
          const empty = document.createElement("p");
          empty.className = "didar-plan-board__column-empty";
          empty.textContent = "فعالیتی پیدا نشد";
          cards.appendChild(empty);
        }
        column.appendChild(cards);
        board.appendChild(column);
        cards.scrollTop = verticalScroll.get(type.id) || 0;
      });
      board.scrollLeft = horizontalScroll;
      if (expandedActivityId) renderDetailsDrawer();
    }

    function render() {
      if (!panel) {
        return;
      }
      const select = panel.querySelector(".didar-plan-board__pipeline");
      const prior = select.value;
      select.replaceChildren();
      const placeholder = document.createElement("option");
      placeholder.value = "";
      placeholder.textContent = "انتخاب کاریز";
      select.appendChild(placeholder);
      state.pipelines.forEach((pipeline) => {
        const option = document.createElement("option");
        option.value = pipeline.id;
        option.textContent = pipeline.title;
        select.appendChild(option);
      });
      select.value = state.selectedPipelineId || prior;
      select.disabled = state.loading && !state.pipelines.length;
      panel.querySelector(".didar-plan-board__refresh").disabled = state.loading;
      panel.querySelector(".didar-plan-board__activity-status").value = state.activityStatus;
      panel.querySelector(".didar-plan-board__deal-status").value = state.dealStatus;
      for (const field of ["from", "to"]) {
        panel.querySelector(`.didar-plan-board__date-${field}`).value = state[field]
          ? persianDigits(jalaliDay(`${state[field]}T00:00:00Z`, true)) : "";
      }
      const recent = panel.querySelector(".didar-plan-board__recent");
      recent.classList.toggle("is-active", state.from === recentStartDate(today()) &&
        state.to === localIsoDay(today()));
      const defaults = panel.querySelector(".didar-plan-board__save-defaults");
      const defaultsActive = state.activityStatus === state.defaultActivityStatus &&
        state.dealStatus === state.defaultDealStatus;
      defaults.classList.toggle("is-active", defaultsActive);
      defaults.setAttribute("aria-pressed", String(defaultsActive));
      const loadMore = panel.querySelector(".didar-plan-board__load-more");
      loadMore.hidden = !state.hasMoreActivities;
      loadMore.disabled = state.loading || state.loadingMore;
      const remaining = state.activityTotal === null
        ? ACTIVITY_PAGE_SIZE
        : Math.max(0, state.activityTotal - state.activityOffset);
      loadMore.textContent = state.loadingMore
        ? "در حال دریافت..."
        : `دریافت موارد باقی‌مانده (${persianDigits(remaining)})`;
      const message = panel.querySelector(".didar-plan-board__message");
      message.textContent = state.error || state.filterError || state.labelError || state.progress ||
        (state.selectedPipelineId && !state.rows.length ? "فعالیتی در این کاریز پیدا نشد" : "");
      message.dataset.state = state.error || state.filterError || state.labelError ? "error" :
        state.loading || state.loadingMore || state.loadingFailureStatus ? "loading" : "ready";
      renderLabels();
      renderCards();
    }

    function activitySearchBody(from) {
      const requestedFrom = state.from;
      return {
        FromDate: requestedFrom
          ? new Date(Date.parse(`${requestedFrom}T00:00:00Z`) - 86400000).toISOString()
          : "1800-01-01T00:00:00.000Z",
        ToDate: state.to
          ? new Date(Date.parse(`${state.to}T00:00:00Z`) + 86400000).toISOString()
          : "9999-12-28T20:30:00.000Z",
        SortType: 1,
        ActivityTypeIds: state.types.map((type) => type.id),
        IsDeleted: false,
        From: from,
        Limit: ACTIVITY_PAGE_SIZE
      };
    }

    function consumeActivityPage(response) {
      const activities = list(response);
      const total = count(response);
      const fresh = activities.filter((activity) => {
        const activityId = id(activity?.Id);
        if (!activityId || activityIds.has(activityId)) return false;
        activityIds.add(activityId);
        activityRecords.set(activityId, activity);
        return true;
      });
      state.activityOffset += activities.length;
      if (total !== null) state.activityTotal = total;
      state.hasMoreActivities = total !== null
        ? state.activityOffset < total
        : activities.length === ACTIVITY_PAGE_SIZE;
      return { received: activities.length, fresh };
    }

    function rebuildRows() {
      state.rows = matchingActivities(
        Array.from(activityRecords.values()), Array.from(dealById.values()), state.types
      );
      state.rows.sort((left, right) =>
        (Date.parse(activityStart(right.activity)) || 0) - (Date.parse(activityStart(left.activity)) || 0));
    }

    function updateLoadedMessage() {
      const scope = state.from === recentStartDate(today()) && state.to === localIsoDay(today())
        ? "۳۰ روز اخیر" : "بازه انتخابی";
      const suffix = state.hasMoreActivities ? " · در حال تکمیل فهرست" : "";
      state.progress = `${persianDigits(state.rows.length)} فعالیت در ${scope}${suffix}`;
    }

    function scheduleRowsRender(sequence) {
      if (rowsRenderTimer) return;
      rowsRenderTimer = window.setTimeout(() => {
        rowsRenderTimer = 0;
        if (sequence !== state.sequence) return;
        rebuildRows();
        updateLoadedMessage();
        render();
      }, 300);
    }

    async function resolveActivityDeals(activities, sequence) {
      const dealIds = Array.from(new Set(activities.map((activity) =>
        id(activity?.DealId || activity?.Deal?.Id)
      ).filter(Boolean))).filter((dealId) => !dealLoads.has(dealId));
      const now = Date.now();
      dealIds.forEach((dealId) => {
        const cached = recentDeals.get(dealId);
        if (!cached || now - cached.at >= DEAL_CACHE_MS) return;
        dealLoads.set(dealId, Promise.resolve(cached.deal));
        if (id(cached.deal?.PipelineId) === state.selectedPipelineId && cached.deal.IsDeleted !== true) {
          dealById.set(dealId, cached.deal);
        }
      });
      if (dealById.size) scheduleRowsRender(sequence);
      const missing = dealIds.filter((dealId) => !dealLoads.has(dealId));
      let cursor = 0;
      let failed = 0;
      const worker = async () => {
        while (cursor < missing.length && sequence === state.sequence) {
          const dealId = missing[cursor++];
          try {
            const deal = await cachedRequest(dealLoads, dealId, "deal/GetDealDetail", { Id: dealId });
            if (sequence !== state.sequence) return;
            if (id(deal?.Id) === dealId) recentDeals.set(dealId, { deal, at: Date.now() });
            if (id(deal?.Id) === dealId && id(deal?.PipelineId) === state.selectedPipelineId &&
                deal.IsDeleted !== true) {
              dealById.set(dealId, deal);
              scheduleRowsRender(sequence);
            }
          } catch {
            failed += 1;
          }
        }
      };
      await Promise.all(Array.from({ length: Math.min(DEAL_DETAIL_WORKERS, missing.length) }, worker));
      return failed;
    }

    async function loadMoreRows(loadAll = false) {
      if (!state.open || state.loading || state.loadingMore || !state.hasMoreActivities) return;
      const sequence = state.sequence;
      state.loadingMore = true;
      state.error = "";
      state.progress = "در حال دریافت فعالیت‌های قدیمی‌تر...";
      render();
      try {
        let pages = 0;
        const freshActivities = [];
        do {
          const response = await apiRequest("activity/search", {
            body: activitySearchBody(state.activityOffset), retry: true
          });
          if (sequence !== state.sequence) return;
          const result = consumeActivityPage(response);
          freshActivities.push(...result.fresh);
          pages += 1;
          if (!result.received) state.hasMoreActivities = false;
          if (sequence !== state.sequence) return;
          const remaining = state.activityTotal === null
            ? ""
            : `؛ ${persianDigits(Math.max(0, state.activityTotal - state.activityOffset))} مورد باقی مانده`;
          state.progress = `${persianDigits(state.activityOffset)} فعالیت بررسی شد${remaining}`;
          const message = panel?.querySelector(".didar-plan-board__message");
          if (message) message.textContent = state.progress;
          if (pages >= MAX_ACTIVITY_PAGES && state.hasMoreActivities) {
            throw new Error("تعداد فعالیت‌ها از سقف ایمن دریافت این نما بیشتر است؛ بازه تاریخ را محدود کنید.");
          }
          if (loadAll && state.hasMoreActivities) await delay(120);
        } while (loadAll && state.hasMoreActivities);
        await resolveActivityDeals(freshActivities, sequence);
        if (sequence !== state.sequence) return;
        rebuildRows();
        state.error = "";
        updateLoadedMessage();
      } catch (error) {
        if (sequence === state.sequence) {
          state.error = olderActivitiesError(error, state.activityOffset);
        }
      } finally {
        if (sequence === state.sequence) {
          state.loadingMore = false;
          render();
          if (state.activityStatus === "failed") void hydrateFailureStatuses();
        }
      }
    }

    async function loadRows(force = false) {
      const pipelineId = state.selectedPipelineId;
      const sequence = ++state.sequence;
      const requestedFrom = state.from;
      if (force) recentDeals.clear();
      state.loading = true;
      state.loadingMore = false;
      state.loadingFailureStatus = false;
      state.error = "";
      state.progress = "در حال دریافت آخرین فعالیت‌ها...";
      state.rows = [];
      state.activityOffset = 0;
      state.activityTotal = null;
      state.hasMoreActivities = false;
      closeCardDetails();
      dealById = new Map();
      activityIds.clear();
      activityRecords.clear();
      window.clearTimeout(rowsRenderTimer);
      rowsRenderTimer = 0;
      cardDetails.clear();
      cardLoads.clear();
      dealLoads.clear();
      dealActivityLoads.clear();
      drafts.clear();
      render();
      if (!pipelineId) {
        state.loading = false;
        state.progress = "یک کاریز انتخاب کنید";
        render();
        return;
      }
      try {
        const response = await apiRequest("activity/search", {
          body: activitySearchBody(0), retry: true
        });
        if (sequence !== state.sequence) return;
        const firstPage = consumeActivityPage(response);
        state.progress = "در حال دریافت معاملات فعالیت‌های اخیر...";
        render();
        void resolveActivityDeals(firstPage.fresh, sequence).then(() => {
          if (sequence !== state.sequence) return;
          rebuildRows();
          updateLoadedMessage();
          render();
        });
        state.loadedFrom = requestedFrom;
        updateLoadedMessage();
      } catch (error) {
        if (sequence !== state.sequence) return;
        state.error = error?.message || "دریافت اطلاعات دیدار انجام نشد";
        state.rows = [];
      } finally {
        if (sequence === state.sequence) {
          state.loading = false;
          render();
          if (state.activityStatus === "failed") void hydrateFailureStatuses();
          if (state.hasMoreActivities && state.from === recentStartDate(today()) &&
              state.to === localIsoDay(today())) {
            void loadMoreRows(true);
          }
        }
      }
    }

    async function loadConfiguration() {
      const sequence = ++state.sequence;
      state.loading = true;
      state.error = "";
      state.progress = "در حال دریافت کاریزها و نوع فعالیت‌ها...";
      render();
      const labelLoad = apiRequest("label/Get", { body: {}, retry: true }).then((response) => {
        if (sequence !== state.sequence) return;
        state.labels = list(response)
          .filter((label) => id(label?.Id) && text(label?.Title))
          .map((label) => ({ id: id(label.Id), title: text(label.Title) }));
        state.labelError = "";
        render();
      }).catch(() => {
        if (sequence !== state.sequence) return;
        state.labelError = "برچسب‌ها دریافت نشدند؛ فیلتر برچسب فعلاً در دسترس نیست.";
        render();
      });
      try {
        const [pipelinesResponse, typesResponse, identity] = await Promise.all([
          apiRequest("pipeline/list/0", { body: {}, retry: true }),
          apiRequest("activity/GetActivityType", { body: {}, retry: true }),
          userKey()
        ]);
        if (sequence !== state.sequence) {
          return;
        }
        state.pipelines = list(pipelinesResponse)
          .filter((pipeline) => id(pipeline?.Id) && pipeline?.IsDeleted !== true)
          .map((pipeline) => ({ id: id(pipeline.Id), title: text(pipeline.Title) }))
          .filter((pipeline) => pipeline.title);
        state.types = planTypes(typesResponse);
        state.userId = text(identity);
        if (!state.userId) {
          throw new Error("شناسه کاربر دیدار برای ذخیره ترتیب ستون‌ها پیدا نشد.");
        }
        let saved = "";
        try {
          saved = localStorage.getItem(storageKey()) || "";
        } catch {
          // Use the default pipeline if site storage is unavailable.
        }
        state.selectedPipelineId = state.pipelines.find((pipeline) => pipeline.id === saved)?.id ||
          state.pipelines.find((pipeline) => pipeline.title === DEFAULT_PIPELINE)?.id || "";
        loadOrder();
        loadFilterDefaults();
        state.loading = false;
        if (!state.types.length) {
          state.error = "نوع فعالیت «شروع طرح ...» در دیدار پیدا نشد";
          render();
          return;
        }
        await loadRows();
        await labelLoad;
      } catch (error) {
        if (sequence === state.sequence) {
          state.loading = false;
          state.error = error?.message || "دریافت تنظیمات دیدار انجام نشد";
          render();
        }
      }
    }

    function close() {
      state.open = false;
      state.sequence += 1;
      openedLocation = "";
      window.clearTimeout(rowsRenderTimer);
      rowsRenderTimer = 0;
      closeCardDetails();
      closeCreateDialog();
      hideCalendar();
      panel?.remove();
      panel = null;
      document.body.classList.remove("didar-plan-board-open");
      navButton?.setAttribute("aria-pressed", "false");
    }

    function open() {
      if (state.open) {
        return;
      }
      state.open = true;
      state.from = recentStartDate(today());
      state.to = localIsoDay(today());
      openedLocation = location.href;
      panel = document.createElement("main");
      panel.className = "didar-plan-board";
      panel.setAttribute("dir", "rtl");
      panel.setAttribute("aria-label", "کاریز فعالیت‌های شروع طرح");
      const toolbar = document.createElement("header");
      toolbar.className = "didar-plan-board__toolbar";
      const title = document.createElement("h1");
      title.textContent = "کاریز فعالیت‌های شروع طرح";
      const subtitle = document.createElement("p");
      subtitle.className = "didar-plan-board__subtitle";
      subtitle.textContent = "پیگیری طرح‌ها، چک‌لیست‌ها و محصولات در یک نما";
      const heading = document.createElement("div");
      heading.className = "didar-plan-board__heading";
      heading.append(title, subtitle);
      const controls = document.createElement("div");
      controls.className = "didar-plan-board__controls";
      const pipelineLabel = document.createElement("label");
      pipelineLabel.textContent = "کاریز";
      const pipeline = document.createElement("select");
      pipeline.className = "didar-plan-board__pipeline";
      pipeline.setAttribute("aria-label", "انتخاب کاریز معاملات");
      pipeline.addEventListener("change", () => {
        state.selectedPipelineId = pipeline.value;
        state.selectedLabelIds = null;
        saveSelection();
        loadOrder();
        loadFilterDefaults();
        void loadRows();
      });
      pipelineLabel.appendChild(pipeline);
      const search = document.createElement("input");
      search.type = "search";
      search.className = "didar-plan-board__search";
      search.placeholder = "جست‌وجوی معامله";
      search.setAttribute("aria-label", "جست‌وجوی معامله");
      search.addEventListener("input", () => {
        state.query = search.value;
        renderCards();
      });
      const refresh = button("↻", "didar-plan-board__refresh", () => void loadRows(true), "بروزرسانی فهرست");
      const exit = button("×", "didar-plan-board__close", close, "بستن کاریز فعالیت‌ها");
      controls.append(pipelineLabel, search, refresh, exit);
      const filters = document.createElement("div");
      filters.className = "didar-plan-board__filters";
      function selectFilter(labelText, className, choices, onChange) {
        const label = document.createElement("label");
        label.textContent = labelText;
        const select = document.createElement("select");
        select.className = className;
        choices.forEach(([value, caption]) => {
          const option = document.createElement("option");
          option.value = value;
          option.textContent = caption;
          select.appendChild(option);
        });
        select.addEventListener("change", () => onChange(select.value));
        label.appendChild(select);
        return label;
      }
      filters.append(
        selectFilter("وضعیت طرح", "didar-plan-board__activity-status", [
          ["all", "طرح: همه"], ["open", "طرح: باز"],
          ["done", "طرح: تکمیل‌شده"], ["failed", "طرح: ناموفق"]
        ], (value) => {
          state.activityStatus = value;
          render();
          if (value === "failed") void hydrateFailureStatuses();
        }),
        selectFilter("وضعیت معامله", "didar-plan-board__deal-status", [
          ["", "معامله: همه"], ["Pending", "معامله: جاری"],
          ["Won", "معامله: موفق"], ["Lost", "معامله: ناموفق"]
        ], (value) => { state.dealStatus = value; render(); }),
        button("۳۰ روز اخیر", "didar-plan-board__recent", () => {
          const start = recentStartDate(today());
          const end = localIsoDay(today());
          if (state.from === start && state.to === end) return;
          state.from = start;
          state.to = end;
          void loadRows();
        }, "نمایش فعالیت‌های ۳۰ روز اخیر"),
        button("☆", "didar-plan-board__save-defaults", saveFilterDefaults,
          "ذخیره وضعیت فعالیت و معامله به‌عنوان پیش‌فرض"),
        button("دریافت موارد باقی‌مانده", "didar-plan-board__load-more", () => void loadMoreRows(true),
          "دریافت باقی‌مانده فعالیت‌ها در بازه انتخابی")
      );
      for (const [field, caption] of [["from", "از تاریخ شروع"], ["to", "تا تاریخ شروع"]]) {
        const label = document.createElement("label");
        label.textContent = caption;
        const input = document.createElement("input");
        input.className = `didar-plan-board__date-${field}`;
        input.readOnly = true;
        input.placeholder = "انتخاب تاریخ";
        input.setAttribute("aria-label", `${caption} فعالیت به شمسی`);
        input.addEventListener("click", () => openCalendar(field));
        input.addEventListener("keydown", (event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            openCalendar(field);
          }
        });
        label.appendChild(input);
        filters.appendChild(label);
      }
      const labels = document.createElement("details");
      labels.className = "didar-plan-board__labels";
      const labelSummary = document.createElement("summary");
      labelSummary.textContent = "همه برچسب‌ها";
      const labelOptions = document.createElement("div");
      labelOptions.className = "didar-plan-board__label-options";
      labels.append(labelSummary, labelOptions);
      filters.appendChild(labels);
      filters.appendChild(button("مشاهده سوابق قدیمی‌تر", "didar-plan-board__history", () => {
        state.from = "";
        state.to = "";
        void loadRows();
      }, "گسترش بازه زمانی به کل سوابق"));
      const message = document.createElement("div");
      message.className = "didar-plan-board__message";
      message.setAttribute("role", "status");
      const navigation = document.createElement("div");
      navigation.className = "didar-plan-board__navigation";
      const columns = document.createElement("div");
      columns.className = "didar-plan-board__columns";
      const scrollLeft = button("‹", "didar-plan-board__scroll-left", () =>
        columns.scrollBy({ left: -420, behavior: "smooth" }), "پیمایش ستون‌ها به چپ");
      const scrollRight = button("›", "didar-plan-board__scroll-right", () =>
        columns.scrollBy({ left: 420, behavior: "smooth" }), "پیمایش ستون‌ها به راست");
      navigation.append(scrollLeft, message, scrollRight);
      toolbar.append(heading, controls, filters);
      const backdrop = document.createElement("div");
      backdrop.className = "didar-plan-board__detail-backdrop";
      backdrop.hidden = true;
      backdrop.addEventListener("click", (event) => {
        if (event.target === backdrop) closeCardDetails();
      });
      const drawer = document.createElement("aside");
      drawer.className = "didar-plan-board__detail-drawer";
      drawer.setAttribute("role", "dialog");
      drawer.setAttribute("aria-label", "جزئیات فعالیت طرح");
      drawer.setAttribute("aria-modal", "true");
      const drawerHeader = document.createElement("header");
      drawerHeader.className = "didar-plan-board__detail-header";
      const drawerHeading = document.createElement("div");
      drawerHeading.append(
        Object.assign(document.createElement("span"), { className: "didar-plan-board__detail-eyebrow", textContent: "جزئیات فعالیت" }),
        Object.assign(document.createElement("h2"), { className: "didar-plan-board__detail-title" })
      );
      drawerHeader.append(drawerHeading, button("×", "didar-plan-board__detail-close", closeCardDetails, "بستن جزئیات"));
      const drawerBody = document.createElement("div");
      drawerBody.className = "didar-plan-board__detail-body";
      const drawerSummary = document.createElement("div");
      drawerSummary.className = "didar-plan-board__detail-summary";
      const drawerStatus = document.createElement("span");
      drawerStatus.className = "didar-plan-board__detail-status";
      const drawerMeta = document.createElement("span");
      drawerMeta.className = "didar-plan-board__detail-meta";
      drawerSummary.append(drawerStatus, drawerMeta);
      const drawerDetails = document.createElement("div");
      drawerDetails.className = "didar-plan-board__card-details";
      const drawerLink = document.createElement("a");
      drawerLink.className = "didar-plan-board__detail-link";
      drawerLink.target = "_blank";
      drawerLink.rel = "noopener noreferrer";
      drawerLink.textContent = "بازکردن معامله در دیدار ↗";
      drawerBody.append(drawerSummary, drawerDetails, drawerLink);
      drawer.append(drawerHeader, drawerBody);
      backdrop.appendChild(drawer);
      const createBackdrop = document.createElement("div");
      createBackdrop.className = "didar-plan-board__create-backdrop";
      createBackdrop.hidden = true;
      createBackdrop.addEventListener("click", (event) => {
        if (event.target === createBackdrop && !creatingActivity) closeCreateDialog();
      });
      const createDialog = document.createElement("section");
      createDialog.className = "didar-plan-board__create-dialog";
      createDialog.setAttribute("role", "dialog");
      createDialog.setAttribute("aria-modal", "true");
      createDialog.setAttribute("aria-label", "افزودن فعالیت به معامله");
      const createHeader = document.createElement("header");
      const createTitle = document.createElement("h2");
      createTitle.className = "didar-plan-board__create-title";
      createHeader.append(createTitle, button("×", "didar-plan-board__create-close", () => {
        if (!creatingActivity) closeCreateDialog();
      }, "بستن"));
      const createSearch = document.createElement("input");
      createSearch.type = "search";
      createSearch.className = "didar-plan-board__create-search";
      createSearch.placeholder = "جست‌وجوی نام مشتری، عنوان یا کد معامله";
      createSearch.setAttribute("aria-label", "جست‌وجوی معامله برای فعالیت تازه");
      createSearch.addEventListener("input", () => {
        window.clearTimeout(createSearchTimer);
        createSearchSequence += 1;
        const query = text(createSearch.value);
        createSearchTimer = window.setTimeout(() => void searchCreateDeals(query), 250);
      });
      const createMessage = document.createElement("p");
      createMessage.className = "didar-plan-board__create-message";
      createMessage.setAttribute("role", "status");
      const createResults = document.createElement("div");
      createResults.className = "didar-plan-board__create-results";
      const createSubmit = button("تأیید و ایجاد فعالیت", "didar-plan-board__create-submit",
        () => void submitCreateActivity());
      createSubmit.disabled = true;
      createDialog.append(createHeader, createSearch, createMessage, createResults, createSubmit);
      createBackdrop.appendChild(createDialog);
      panel.append(toolbar, navigation, columns, createCalendar(), backdrop, createBackdrop);
      document.body.appendChild(panel);
      document.body.classList.add("didar-plan-board-open");
      navButton?.setAttribute("aria-pressed", "true");
      void loadConfiguration();
    }

    function mount(enabled) {
      if (!enabled) {
        navButton?.closest("li")?.remove();
        navButton = null;
        if (state.open) {
          close();
        }
        return;
      }
      if (state.open && openedLocation && location.href !== openedLocation) {
        close();
      }
      const nativeActivityLink = Array.from(document.querySelectorAll('a[href]')).find((anchor) => {
        try {
          return new URL(anchor.href, location.href).pathname === "/activity" && anchor.closest("li");
        } catch {
          return false;
        }
      });
      const nativeItem = nativeActivityLink?.closest("li");
      if (!nativeItem) {
        return;
      }
      if (navButton?.isConnected) {
        return;
      }
      const item = document.createElement("li");
      item.className = "didar-plan-board-nav";
      navButton = button("☷", "didar-plan-board-nav__button", () => {
        if (state.open) close();
        else open();
      }, "کاریز فعالیت‌های شروع طرح");
      navButton.setAttribute("aria-label", "کاریز فعالیت‌های شروع طرح");
      navButton.setAttribute("aria-pressed", state.open ? "true" : "false");
      item.appendChild(navButton);
      nativeItem.after(item);
    }

    document.addEventListener("pointerdown", (event) => {
      const labels = panel?.querySelector(".didar-plan-board__labels");
      if (state.open && labels?.open && !labels.contains(event.target)) labels.open = false;
    });

    document.addEventListener("click", (event) => {
      if (!state.open || !panel || panel.contains(event.target) || navButton?.contains(event.target)) return;
      if (event.target?.closest?.('a[href], button, [role="button"]')) close();
    }, true);

    document.addEventListener("keydown", (event) => {
      if (!state.open || event.key !== "Escape") return;
      if (!panel.querySelector(".didar-plan-board__create-backdrop").hidden) {
        if (!creatingActivity) closeCreateDialog();
      } else if (!panel.querySelector(".didar-plan-board__calendar-overlay").hidden) hideCalendar();
      else if (panel.querySelector(".didar-plan-board__labels").open) {
        panel.querySelector(".didar-plan-board__labels").open = false;
      } else if (expandedActivityId) closeCardDetails();
      else close();
      event.preventDefault();
    });

    return { mount, open, close };
  }

  globalThis.DidarPlanBoard = {
    create, matchingActivities, planTypes, paged, filterRows, parseJalaliDay, jalaliDay, labelIds, planFailureState
  };
})();
