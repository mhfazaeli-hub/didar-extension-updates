(function initializeDiagnostics(root) {
  "use strict";
  if (root.DidarDiagnostics) return;
  const sources = [
    "didar",
    "etebarito",
    "beta",
    "tamin",
    "cspf",
    "olive",
    "extension",
  ];
  const operations = [
    "lookup",
    "config",
    "transfer",
    "update",
    "mobile_lookup",
    "append_mobile_report",
    "fetch",
    "activity",
    "client",
    "test",
  ];
  const stages = [
    "client",
    "profile",
    "score",
    "history",
    "pdf",
    "parse",
    "preview",
    "crm",
  ];
  const codes = [
    "LOOKUP_FOUND",
    "LOOKUP_EMPTY",
    "LOOKUP_CONFLICT",
    "WRITE_VERIFIED",
    "PARTIAL_SAVE",
    "CLIENT_ERROR",
    "HTTP_ERROR",
    "TIMEOUT",
    "REQUEST_FAILED",
    "PROFILE_UNAVAILABLE",
    "REPORT_UNAVAILABLE",
    "RESULT_INCOMPLETE",
    "HISTORY_UNAVAILABLE",
    "IDENTITY_MISMATCH",
    "CONTEXT_INVALIDATED",
    "PDF_PARSE_FAILED",
    "AUTH_REQUIRED",
    "PERMISSION_DENIED",
    "DUPLICATE_CONTACT",
    "READBACK_FAILED",
    "SEARCH_INVALID",
    "CRM_OPERATION_FAILED",
    "UNHANDLED_ERROR",
    "TEST_EVENT",
  ];
  const metricKeys = [
    "contacts",
    "deals",
    "directCandidates",
    "globalCandidates",
    "matches",
    "activityCreated",
    "activityReused",
  ];
  const hosts = {
    "app.didar.me": "didar",
    "etebaritoapp.ics24.ir": "etebarito",
    "beta.bkr724.ir": "beta",
    "eservices.tamin.ir": "tamin",
    "eservices.cspf.ir": "cspf",
    "my.olivecredit.ir": "olive",
  };
  function sourceForURL(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" ? hosts[url.hostname] || "" : "";
    } catch {
      return "";
    }
  }
  function classify(error) {
    if (codes.includes(error?.code)) return error.code;
    const message = String(error?.message || error?.error || error || "");
    if (
      /DIDAR_SEARCH|جست.وجو.*(?:معتبر نیست|قابل بررسی نیست)/i.test(
        String(error?.code || "") + message,
      )
    )
      return "SEARCH_INVALID";
    if (
      /extension context invalidated|receiving end does not exist/i.test(
        message,
      )
    )
      return "CONTEXT_INVALIDATED";
    if (
      /401|نشست|ورود به|وارد دیدار|DIDAR_AUTH|DIDAR_ACCOUNT/i.test(
        String(error?.code || "") + message,
      )
    )
      return "AUTH_REQUIRED";
    if (/403|مجوز|permission denied/i.test(message)) return "PERMISSION_DENIED";
    if (/duplicate contact|شماره.*تکراری/i.test(message))
      return "DUPLICATE_CONTACT";
    if (/تأیید نشد|تایید نشد|بازخوانی/.test(message)) return "READBACK_FAILED";
    if (/timeout|abort|به.موقع|بیش از حد طول/i.test(message)) return "TIMEOUT";
    if (/HTTP\s+[45]\d{2}/i.test(message)) return "HTTP_ERROR";
    return "CLIENT_ERROR";
  }
  function event(input, context = {}) {
    if (
      !input ||
      !sources.includes(input.source) ||
      !operations.includes(input.operation) ||
      !codes.includes(input.code)
    )
      throw Error("Invalid diagnostic category");
    const id = context.id || input.id;
    const timestamp = context.timestamp || input.timestamp;
    const extensionVersion = context.extensionVersion || input.extensionVersion;
    const browser = context.browser || input.browser;
    if (
      !/^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(id || "") ||
      !/^\d{4}-\d{2}-\d{2}T[\d:.]+Z$/.test(timestamp || "") ||
      !Number.isFinite(Date.parse(timestamp)) ||
      !/^\d{1,5}(?:\.\d{1,5}){1,3}$/.test(extensionVersion || "") ||
      !["chrome", "edge", "firefox", "unknown"].includes(browser)
    )
      throw Error("Invalid diagnostic metadata");
    const metrics = {};
    for (const key of metricKeys)
      if (
        Number.isSafeInteger(input.metrics?.[key]) &&
        input.metrics[key] >= 0 &&
        input.metrics[key] <= 100000
      )
        metrics[key] = input.metrics[key];
    return {
      schemaVersion: 1,
      id,
      timestamp,
      extensionVersion,
      browser,
      source: input.source,
      operation: input.operation,
      stage: stages.includes(input.stage) ? input.stage : "client",
      code: input.code,
      ...(Number.isInteger(input.httpStatus) &&
      input.httpStatus >= 100 &&
      input.httpStatus <= 599
        ? { httpStatus: input.httpStatus }
        : {}),
      metrics,
    };
  }
  async function report(input) {
    const api = root.browser || root.chrome;
    try {
      const safe = event(
        { ...input, code: input.code || classify(input.error) },
        {
          id: crypto.randomUUID(),
          timestamp: new Date().toISOString(),
          extensionVersion: api.runtime.getManifest().version,
          browser: "unknown",
        },
      );
      return await api.runtime.sendMessage({
        type: "DIDAR_DIAGNOSTIC",
        event: safe,
      });
    } catch {
      return null;
    }
  }
  root.DidarDiagnostics = { event, classify, report, sourceForURL };
  if (typeof module === "object" && module.exports)
    module.exports = root.DidarDiagnostics;
  const api = root.browser || root.chrome;
  if (typeof window === "object" && api?.runtime?.getURL) {
    const base = api.runtime.getURL("");
    const capture = (error, filename) => {
      if (String(filename || error?.stack || "").includes(base))
        void report({
          source: sourceForURL(location.href) || "extension",
          operation: "client",
          code: "UNHANDLED_ERROR",
        });
    };
    window.addEventListener("error", (e) => capture(e.error, e.filename));
    window.addEventListener("unhandledrejection", (e) => capture(e.reason));
  }
})(globalThis);
