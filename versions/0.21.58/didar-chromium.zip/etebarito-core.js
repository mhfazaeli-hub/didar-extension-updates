(function initializeEtebaritoCore(root) {
  "use strict";

  function text(value) {
    return value == null ? "" : String(value).trim();
  }

  function normalizeText(value) {
    return text(value)
      .normalize("NFKC")
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/ي/g, "ی")
      .replace(/ك/g, "ک")
      .replace(/[\u200c\u200d\u200e\u200f]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function digits(value) {
    return normalizeText(value).replace(/\D/g, "");
  }

  function normalizeMobile(value) {
    let result = digits(value);
    if (result.startsWith("0098")) {
      result = `0${result.slice(4)}`;
    } else if (result.startsWith("98") && result.length === 12) {
      result = `0${result.slice(2)}`;
    } else if (result.startsWith("9") && result.length === 10) {
      result = `0${result}`;
    }
    return /^09\d{9}$/.test(result) ? result : "";
  }

  function normalizeNationalCode(value) {
    const result = digits(value);
    return /^\d{10}$/.test(result) ? result : "";
  }

  function candidateMobile(value) {
    const normalized = normalizeText(value);
    const matches = normalized.match(/(?:\+?98|0098|0)?9[\d\s-]{9,14}/g) || [];
    for (const match of matches) {
      const mobile = normalizeMobile(match);
      if (mobile) {
        return mobile;
      }
    }
    return "";
  }

  function isNameCandidate(value) {
    const normalized = normalizeText(value);
    if (!/^[آ-یء][آ-یء\s]{3,60}$/.test(normalized) || normalized.split(" ").length < 2) {
      return false;
    }
    return !/(اطلاعات|شماره|تلفن|نشانی|آدرس|توضیحات|مطابق|پست\s*الکترونیکی|ایمیل|تولد|جنسیت|تاهل|گزارش|اعتبار|نام پدر|محل تولد|وضعیت تاهل)/.test(normalized);
  }

  function nameWithoutIdentifier(value) {
    return normalizeText(value).replace(/(?:\s+[0-9]{10,11})+$/, "").trim();
  }

  function nameWithNationalCode(value, nationalCode) {
    const name = nameWithoutIdentifier(value);
    const code = normalizeNationalCode(nationalCode);
    return name && code ? `${name} ${code}` : name;
  }

  function identityTextLines(items) {
    const lines = [];
    const sorted = [...items].sort((left, right) => right.y - left.y || right.x - left.x);
    for (const item of sorted) {
      let line = lines.find((candidate) => Math.abs(candidate.y - item.y) <= 3);
      if (!line) {
        line = { y: item.y, items: [] };
        lines.push(line);
      }
      line.items.push(item);
    }
    return lines.map((line) => {
      const values = line.items
        .sort((left, right) => right.x - left.x || left.index - right.index)
        .map((item) => item.value)
        .filter(Boolean);
      return {
        y: line.y,
        x: Math.max(...line.items.map((item) => item.x)),
        index: Math.min(...line.items.map((item) => item.index)),
        value: normalizeText(values.join(" "))
      };
    });
  }

  function cleanNameCandidate(value) {
    return normalizeText(value)
      .replace(/^(?:نام\s*(?:و\s*)?نام\s*خانوادگی|نام\s*خانوادگی)\s*[:：-]?\s*/u, "")
      .replace(/\s*(?:شماره|کد)\s*ملی\s*[:：-]?.*$/u, "")
      .trim();
  }

  function normalizeJalaliDate(value) {
    const normalized = normalizeText(value).replace(/[.\-]/g, "/");
    const match = normalized.match(/\b(1[34]\d{2})\s*\/\s*(\d{1,2})\s*\/\s*(\d{1,2})\b/);
    if (!match) {
      return "";
    }
    const month = Number(match[2]);
    const day = Number(match[3]);
    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return "";
    }
    return `${match[1]}/${String(month).padStart(2, "0")}/${String(day).padStart(2, "0")}`;
  }

  function pdfItems(items) {
    return (items || [])
      .map((item, index) => ({
        index,
        value: normalizeText(item?.str ?? item?.value),
        x: Number(item?.x ?? item?.transform?.[4] ?? 0),
        y: Number(item?.y ?? item?.transform?.[5] ?? 0),
        width: Number(item?.width ?? 0)
      }))
      .filter((item) => item.value);
  }

  function pdfLines(items) {
    const lines = [];
    for (const item of [...items].sort((left, right) => right.y - left.y || right.x - left.x)) {
      let line = lines.find((candidate) => Math.abs(candidate.y - item.y) <= 2.5);
      if (!line) {
        line = { y: item.y, items: [] };
        lines.push(line);
      }
      line.items.push(item);
    }
    return lines
      .map((line) => ({
        ...line,
        items: line.items.sort((left, right) => right.x - left.x),
        value: normalizeText(
          line.items.sort((left, right) => right.x - left.x).map((item) => item.value).join(" ")
        )
      }))
      .sort((left, right) => right.y - left.y);
  }

  function moneyDigits(value) {
    const normalized = normalizeText(value);
    if (normalized === "صفر") {
      return "0";
    }
    const compact = normalized.replace(/[\s,٬،]/g, "");
    return /^\d+$/.test(compact) ? compact.replace(/^0+(?=\d)/, "") : "";
  }

  function formatMoney(value) {
    const amount = moneyDigits(value);
    return amount ? amount.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : "";
  }

  function uniqueText(items) {
    const seen = new Set();
    return items
      .map((item) => normalizeText(item.value))
      .filter((value) => value && !seen.has(value) && seen.add(value))
      .join(" ");
  }

  function extractOverdueContracts(pages) {
    const contracts = [];
    let activeRole = "";

    for (const page of pages || []) {
      const width = Number(page?.width) || 595;
      const items = pdfItems(page?.items);
      const lines = pdfLines(items);

      for (const line of lines) {
        if (/^نقش\s+متقاضی\s+اصلی\s+یا\s+شریک$/.test(line.value)) {
          activeRole = "متقاضی";
          continue;
        }
        if (/^نقش\s+ضامن$/.test(line.value)) {
          activeRole = "ضامن";
          continue;
        }
        if (/جزئیات\s+وضعیت\s+منفی|ریز\s+تعهدات/.test(line.value)) {
          activeRole = "";
          continue;
        }
        if (!activeRole || /مجموع/.test(line.value)) {
          continue;
        }

        const amountItem = line.items.find((item) => {
          const amount = moneyDigits(item.value);
          return item.x < width * 0.19 && amount && amount !== "0";
        });
        if (!amountItem) {
          continue;
        }

        const nearby = items.filter((item) => Math.abs(item.y - amountItem.y) <= 13);
        const typeItems = nearby.filter((item) =>
          item.x >= width * 0.76 &&
          /تسهیلات|تعهدات|اعتبار|قرض|وام/.test(item.value) &&
          !/نوع\s+قرارداد|مجموع/.test(item.value)
        );
        const lenderItems = nearby.filter((item) =>
          item.x >= width * 0.56 &&
          item.x < width * 0.76 &&
          !moneyDigits(item.value) &&
          !/اعتبار\s+دهنده|تعداد\s+قرارداد|در\s+جریان|خاتمه\s+یافته|مبلغ|مجموع/.test(item.value)
        );
        const contractType = uniqueText(
          typeItems.sort((left, right) => right.y - left.y || right.x - left.x)
        ).replace(/\)([^()]+)\(/g, "($1)");
        const lender = uniqueText(lenderItems.sort((left, right) => right.y - left.y || right.x - left.x));
        if (!contractType || !lender) {
          continue;
        }

        const amount = moneyDigits(amountItem.value);
        contracts.push({
          role: activeRole,
          contractType,
          lender,
          amount,
          amountFormatted: formatMoney(amount),
          pageNumber: Number(page?.pageNumber) || 0
        });
      }
    }

    return contracts.filter((contract, index) => {
      const key = [contract.role, contract.contractType, contract.lender, contract.amount, contract.pageNumber].join("|");
      return contracts.findIndex((candidate) =>
        [candidate.role, candidate.contractType, candidate.lender, candidate.amount, candidate.pageNumber].join("|") === key
      ) === index;
    });
  }

  function extractIdentity(items, pageWidth = 600) {
    const normalizedItems = (items || [])
      .map((item, index) => ({
        index,
        value: normalizeText(item?.str),
        x: Number(item?.x ?? item?.transform?.[4] ?? 0),
        y: Number(item?.y ?? item?.transform?.[5] ?? 0)
      }))
      .filter((item) => item.value);

    let mobile = "";
    for (const item of normalizedItems) {
      mobile = candidateMobile(item.value);
      if (mobile) {
        break;
      }
    }

    // Identity and contact details sit side by side in the report. A contact
    // value can be closer to the national code than the person's actual name.
    const personalItems = normalizedItems.filter((item) => item.x >= pageWidth * 0.5);
    const personalLines = identityTextLines(personalItems);
    const fatherName = personalLines
      .map((line) => line.value.match(/(?:^|\s)نام\s*پدر\s*[:：-]?\s*(.+)$/u)?.[1] || "")
      .find(isNameCandidate) || "";
    const nationalItem = personalItems.find((item) => /(?:شماره|کد)\s*ملی/.test(item.value)) ||
      personalLines.find((line) => /(?:شماره|کد)\s*ملی/.test(line.value));
    const otherFieldRows = personalLines.filter((line) =>
      /نام\s*پدر|جنسیت|تاریخ\s*تولد|وضعیت\s*تاهل|محل\s*تولد/.test(line.value));
    let fullName = "";
    if (nationalItem) {
      const nearby = [...personalItems, ...personalLines]
        .map((item) => ({
          ...item,
          name: cleanNameCandidate(item.value),
          distance: Math.abs(item.y - nationalItem.y) + Math.abs(item.x - nationalItem.x) * 0.08
        }))
        .filter((item) =>
          Math.abs(item.y - nationalItem.y) > 3 &&
          !otherFieldRows.some((row) => Math.abs(row.y - item.y) <= 8) &&
          item.distance <= 150 &&
          isNameCandidate(item.name)
        )
        .sort((left, right) =>
          Number(right.y > nationalItem.y) - Number(left.y > nationalItem.y) ||
          left.distance - right.distance || right.x - left.x);
      fullName = nearby[0]?.name || "";
    }
    if (!fullName) {
      const labeled = [...personalItems, ...personalLines]
        .filter((item) => /نام\s*(?:و\s*)?نام\s*خانوادگی|نام\s*خانوادگی/.test(item.value))
        .map((item) => cleanNameCandidate(item.value))
        .find(isNameCandidate);
      fullName = labeled || "";
    }

    const birthLabel = normalizedItems.find((item) => /تاریخ\s*تولد/.test(item.value));
    let birthDate = normalizeJalaliDate(birthLabel?.value);
    if (!birthDate && birthLabel) {
      const nearbyDates = normalizedItems
        .map((item) => ({
          ...item,
          date: normalizeJalaliDate(item.value),
          distance: Math.abs(item.index - birthLabel.index) + Math.abs(item.y - birthLabel.y) / 12
        }))
        .filter((item) => item.date && (Math.abs(item.y - birthLabel.y) <= 30 || Math.abs(item.index - birthLabel.index) <= 8))
        .sort((left, right) => left.distance - right.distance);
      birthDate = nearbyDates[0]?.date || "";
    }

    return { fullName, fatherName, mobile, birthDate };
  }

  const api = {
    text,
    normalizeText,
    digits,
    normalizeMobile,
    normalizeNationalCode,
    candidateMobile,
    isNameCandidate,
    nameWithoutIdentifier,
    nameWithNationalCode,
    extractOverdueContracts,
    formatMoney,
    normalizeJalaliDate,
    extractIdentity
  };
  root.EtebaritoCore = api;
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
