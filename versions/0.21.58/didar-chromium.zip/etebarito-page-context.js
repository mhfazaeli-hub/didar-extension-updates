(function initializeEtebaritoBridge() {
  "use strict";

  if (globalThis.__didarEtebaritoPageBridgeLoaded) {
    return;
  }
  globalThis.__didarEtebaritoPageBridgeLoaded = true;

  const RESULTS_EVENT = "didar-etebarito:sharing-results";
  const REPORT_EVENT = "didar-etebarito:report-pdf";
  const REPORT_REQUEST_EVENT = "didar-etebarito:request-report";
  const REPORT_REQUEST_RESULT_EVENT = "didar-etebarito:request-report-result";
  const REPORT_REQUEST_MARKER = "data-didar-etebarito-report-request";
  const RESULTS_PATH = "/api/Request/GetCurrentUserSharingResults";
  const REPORT_PATH = "/api/ShareReportWithOtp/GetResultShare";
  const KEEPALIVE_PATH = "/api/ICS24Account/UserProfileGet";
  const KEEPALIVE_MIN_DELAY_MS = 75 * 1000;
  const KEEPALIVE_MAX_DELAY_MS = 105 * 1000;
  const KEEPALIVE_MIN_GAP_MS = 60 * 1000;
  const portalApiHeaders = new Map();
  let keepAlivePending = false;
  let keepAliveStopped = false;
  let keepAliveTimer = 0;
  let lastPortalActivityAt = Date.now();

  function absoluteUrl(value) {
    try {
      return new URL(String(value || ""), location.href);
    } catch {
      return null;
    }
  }

  function reportId(url) {
    return url?.searchParams.get("ShareReportId") || "";
  }

  function isPortalApiUrl(url) {
    return url?.origin === location.origin && url.pathname.toLowerCase().startsWith("/api/");
  }

  function bytesToBase64(buffer) {
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 32768) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
    }
    return btoa(binary);
  }

  function dispatch(name, detail) {
    document.dispatchEvent(new CustomEvent(name, { detail }));
  }

  function rememberPortalHeaders(url, source) {
    if (!isPortalApiUrl(url) || !source) {
      return;
    }
    try {
      const headers = new Headers(source);
      for (const [name, value] of headers.entries()) {
        const normalizedName = name.toLowerCase();
        if (!["accept", "content-type"].includes(normalizedName)) {
          portalApiHeaders.set(normalizedName, value);
        }
      }
    } catch {}
  }

  function reportRequestHeaders() {
    const headers = new Headers();
    for (const [name, value] of portalApiHeaders) {
      try {
        headers.set(name, value);
      } catch {}
    }
    headers.set("Accept", "application/json, text/plain, */*");
    if (!headers.has("Access-Control-Allow-Origin")) {
      headers.set("Access-Control-Allow-Origin", "*");
    }
    return headers;
  }

  async function portalSessionIsValid() {
    try {
      const response = await originalFetch.call(
        window,
        new URL(KEEPALIVE_PATH, location.origin).href,
        {
          method: "GET",
          credentials: "include",
          cache: "no-store",
          headers: reportRequestHeaders()
        }
      );
      if (response?.ok) {
        keepAliveStopped = false;
        lastPortalActivityAt = Date.now();
        return true;
      }
    } catch {}
    keepAliveStopped = true;
    return false;
  }

  async function inspectFetchResponse(url, response) {
    if (!url) {
      return;
    }
    if (isPortalApiUrl(url)) {
      if (response?.status === 401 || response?.status === 403) {
        keepAliveStopped = true;
      } else if (response?.ok) {
        keepAliveStopped = false;
        lastPortalActivityAt = Date.now();
      }
    }
    if (!response?.ok) {
      return;
    }
    if (url.pathname.toLowerCase() === RESULTS_PATH.toLowerCase()) {
      const payload = await response.clone().json();
      dispatch(RESULTS_EVENT, { rows: payload?.data?.list || [] });
      return;
    }
    if (url.pathname.toLowerCase() === REPORT_PATH.toLowerCase()) {
      const buffer = await response.clone().arrayBuffer();
      dispatch(REPORT_EVENT, { shareReportId: reportId(url), base64: bytesToBase64(buffer) });
    }
  }

  const originalFetch = window.fetch;

  async function keepPortalSessionAlive() {
    if (
      keepAlivePending ||
      keepAliveStopped ||
      document.documentElement?.dataset.didarEtebaritoKeepAlive !== "true" ||
      Date.now() - lastPortalActivityAt < KEEPALIVE_MIN_GAP_MS
    ) {
      return;
    }
    keepAlivePending = true;
    try {
      const response = await originalFetch.call(
        window,
        new URL(KEEPALIVE_PATH, location.origin).href,
        {
          method: "GET",
          credentials: "include",
          cache: "no-store",
          keepalive: true,
          headers: reportRequestHeaders()
        }
      );
      if (response?.status === 401 || response?.status === 403) {
        keepAliveStopped = true;
      } else if (response?.ok) {
        lastPortalActivityAt = Date.now();
      }
    } catch {
      // Network failures are left to the next interval; the portal is never reloaded.
    } finally {
      keepAlivePending = false;
    }
  }

  function nextKeepAliveDelay() {
    return Math.round(
      KEEPALIVE_MIN_DELAY_MS +
      Math.random() * (KEEPALIVE_MAX_DELAY_MS - KEEPALIVE_MIN_DELAY_MS)
    );
  }

  function scheduleKeepAlive(delay = nextKeepAliveDelay()) {
    window.clearTimeout(keepAliveTimer);
    keepAliveTimer = window.setTimeout(async () => {
      await keepPortalSessionAlive();
      scheduleKeepAlive();
    }, delay);
  }

  function refreshSessionAfterReturn() {
    if (
      document.documentElement?.dataset.didarEtebaritoKeepAlive === "true" &&
      !keepAliveStopped &&
      Date.now() - lastPortalActivityAt >= KEEPALIVE_MIN_GAP_MS
    ) {
      void keepPortalSessionAlive();
    }
  }

  scheduleKeepAlive();
  window.addEventListener("focus", refreshSessionAfterReturn);
  window.addEventListener("pageshow", refreshSessionAfterReturn);
  window.addEventListener("online", refreshSessionAfterReturn);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      refreshSessionAfterReturn();
    }
  });

  document.addEventListener(REPORT_REQUEST_EVENT, (event) => {
    const marker = event.target?.closest?.(`meta[${REPORT_REQUEST_MARKER}]`);
    let detail = event.detail || {};
    if (marker) {
      try {
        detail = JSON.parse(marker.textContent || "{}");
      } catch {
        detail = {};
      }
    }
    const shareReportId = String(detail.shareReportId || "").trim();
    const requestId = String(detail.requestId || "").trim();
    if (!shareReportId || !requestId) {
      return;
    }
    const publishResult = (result) => {
      if (marker) {
        marker.textContent = JSON.stringify(result);
        marker.dispatchEvent(new Event(REPORT_REQUEST_RESULT_EVENT, { bubbles: true }));
      } else {
        dispatch(REPORT_REQUEST_RESULT_EVENT, result);
      }
    };
    const url = new URL(REPORT_PATH, location.origin);
    url.searchParams.set("ShareReportId", shareReportId);
    void originalFetch.call(window, url.href, {
      method: "GET",
      credentials: "include",
      cache: "no-store",
      headers: reportRequestHeaders()
    }).then(async (response) => {
      if (response?.status === 401 || response?.status === 403) {
        const sessionIsValid = await portalSessionIsValid();
        const error = new Error(
          sessionIsValid
            ? "این گزارش دیگر قابل دریافت نیست یا مجوز دسترسی آن منقضی شده است."
            : "نشست اعتباریتو منقضی شده است؛ صفحه برای ورود مجدد تازه‌سازی می‌شود."
        );
        error.authExpired = !sessionIsValid;
        throw error;
      }
      if (!response?.ok) {
        throw new Error(`HTTP ${response?.status || 0}`);
      }
      await inspectFetchResponse(url, response);
      publishResult({ requestId, shareReportId, ok: true });
    }).catch((error) => {
      publishResult({
        requestId,
        shareReportId,
        ok: false,
        error: String(error?.message || error || "خطای واکشی گزارش"),
        authExpired: Boolean(error?.authExpired)
      });
    });
  });

  window.fetch = function didarEtebaritoFetch(...args) {
    const requestUrl = absoluteUrl(args[0]?.url || args[0]);
    if (isPortalApiUrl(requestUrl)) {
      keepAliveStopped = false;
    }
    rememberPortalHeaders(requestUrl, args[0]?.headers);
    rememberPortalHeaders(requestUrl, args[1]?.headers);
    const request = Reflect.apply(originalFetch, window, args);
    void Promise.resolve(request)
      .then((response) => inspectFetchResponse(requestUrl, response))
      .catch(() => {});
    return request;
  };

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  const originalSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function didarEtebaritoOpen(method, url, ...rest) {
    this.__didarEtebaritoUrl = absoluteUrl(url);
    return originalOpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.setRequestHeader = function didarEtebaritoSetRequestHeader(name, value) {
    const url = this.__didarEtebaritoUrl;
    if (isPortalApiUrl(url)) {
      const normalizedName = String(name || "").toLowerCase();
      if (normalizedName && !["accept", "content-type"].includes(normalizedName)) {
        portalApiHeaders.set(normalizedName, String(value || ""));
      }
    }
    return originalSetRequestHeader.call(this, name, value);
  };
  XMLHttpRequest.prototype.send = function didarEtebaritoSend(...args) {
    this.addEventListener(
      "loadend",
      () => {
        const url = this.__didarEtebaritoUrl;
        if (
          isPortalApiUrl(url) &&
          (this.status === 401 || this.status === 403)
        ) {
          keepAliveStopped = true;
        }
        if (!url || this.status < 200 || this.status >= 300) {
          return;
        }
        if (isPortalApiUrl(url)) {
          keepAliveStopped = false;
          lastPortalActivityAt = Date.now();
        }
        if (url.pathname.toLowerCase() === RESULTS_PATH.toLowerCase()) {
          try {
            const payload = this.responseType === "json" ? this.response : JSON.parse(this.responseText);
            dispatch(RESULTS_EVENT, { rows: payload?.data?.list || [] });
          } catch {}
          return;
        }
        if (url.pathname.toLowerCase() !== REPORT_PATH.toLowerCase()) {
          return;
        }
        const publish = (buffer) =>
          dispatch(REPORT_EVENT, { shareReportId: reportId(url), base64: bytesToBase64(buffer) });
        if (this.response instanceof Blob) {
          void this.response.arrayBuffer().then(publish).catch(() => {});
        } else if (this.response instanceof ArrayBuffer) {
          publish(this.response);
        }
      },
      { once: true }
    );
    return originalSend.apply(this, args);
  };
})();
