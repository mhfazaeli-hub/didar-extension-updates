// Parse in an extension document: Firefox page-owned streams cannot consume
// PDF.js callbacks created in a privileged content-script compartment.
import { getDocument, GlobalWorkerOptions } from "./vendor/pdf.min.mjs";
GlobalWorkerOptions.workerSrc = new URL("./vendor/pdf.worker.min.mjs", import.meta.url).href;
let busy = false;
window.addEventListener("message", async (event) => {
  if (event.source !== parent || event.origin !== "https://my.olivecredit.ir" || typeof event.data !== "string") return;
  let request;
  try { request = JSON.parse(event.data); } catch { return; }
  if (request.type !== "didar-olive-pdf" || typeof request.id !== "string" || request.id.length > 100 || busy) return;
  busy = true;
  const reply = (value) => parent.postMessage(JSON.stringify({ type: "didar-olive-pdf-result", id: request.id, ...value }), event.origin);
  let document;
  try {
    if (typeof request.base64 !== "string" || request.base64.length > 14 * 1024 * 1024) throw Error("فایل گزارش بیش از حد بزرگ است.");
    const binary = atob(request.base64);
    const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
    document = await getDocument({ data: bytes }).promise;
    if (document.numPages > 100) throw Error("گزارش بیش از حد بزرگ است.");
    const pages = [];
    for (let number = 1; number <= document.numPages; number++) {
      const page = await document.getPage(number), content = await page.getTextContent();
      pages.push({ pageNumber: number, width: Math.abs(page.view[2] - page.view[0]),
        items: content.items.map((item) => ({ str: item.str, x: item.transform[4], y: item.transform[5], width: item.width })) });
    }
    reply({ ok: true, pages });
  } catch (error) { reply({ ok: false, error: error.message || "خواندن PDF انجام نشد." }); }
  finally { if (document) await document.destroy(); busy = false; }
});
parent.postMessage(JSON.stringify({ type: "didar-olive-pdf-ready" }), "https://my.olivecredit.ir");
