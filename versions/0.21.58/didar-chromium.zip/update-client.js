(function initializeUpdater() {
  "use strict";
  const api = globalThis.browser || globalThis.chrome;
  const config = globalThis.DidarRelease;
  const button = document.getElementById("extensionUpdateButton");
  const status = document.getElementById("extensionUpdateStatus");
  const installer = document.getElementById("extensionInstallerLink");
  installer.href = config.downloadUrl;
  let availableVersion = "";
  if (config.channel === "firefox") {
    button.hidden = true;
    status.textContent = "بروزرسانی خودکار از مسیر تیم. بررسی دستی از about:addons و Check for Updates.";
    return;
  }
  if (config.channel === "development") {
    button.hidden = true;
    status.textContent = "برای دریافت بروزرسانی از داخل افزونه، نسخهٔ تیم را یک بار نصب کنید.";
    return;
  }
  status.textContent = "دریافت نسخه‌های جدید از مسیر تیم";
  button.addEventListener("click", async () => {
    button.disabled = true;
    status.textContent = availableVersion ? "در حال دریافت و نصب نسخهٔ جدید…" : "در حال بررسی نسخهٔ منتشرشده…";
    try {
      const result = await api.runtime.sendNativeMessage(config.nativeHost, {
        command: availableVersion ? "update" : "check",
        currentVersion: api.runtime.getManifest().version
      });
      if (!result?.ok) throw new Error(result?.error || "پاسخ ابزار بروزرسانی معتبر نیست.");
      if (result.updated || (result.installedVersion && result.installedVersion !== api.runtime.getManifest().version)) {
        status.textContent = "نسخهٔ جدید نصب شد. افزونه دوباره بارگذاری می‌شود. صفحه‌های دیدار و سامانه‌ها را پس از پایان کار جاری تازه‌سازی کنید.";
        window.setTimeout(() => api.runtime.reload(), 700);
        return;
      }
      availableVersion = result.updateAvailable ? result.version : "";
      status.textContent = availableVersion ? `نسخهٔ ${availableVersion} آمادهٔ نصب است.` : "افزونه به‌روز است.";
      button.textContent = availableVersion ? `نصب نسخهٔ ${availableVersion}` : "بررسی بروزرسانی";
    } catch (error) {
      status.textContent = /Another update is running/i.test(error.message || "")
        ? "بروزرسانی دیگری در حال اجراست. پس از پایان آن دوباره بررسی کنید."
        : /native|host|specified|not found/i.test(error.message || "")
        ? "ابزار محلی بروزرسانی در دسترس نیست. بستهٔ نصب اولیهٔ تیم را روی این ویندوز اجرا کنید."
        : error.message;
    } finally {
      button.disabled = false;
    }
  });
})();
