/* BEGIN GENERATED CALL CHECKLISTS — edit call-checklists.js, then npm run build */
(function initializeCallChecklists(root) {
  "use strict";
  const DEFINITIONS = [
    { key: "beforePurchase", title: "تماس خروجی قبل خرید", items: ["پایین بودن توان قسط", "بد رفتاری اعتباری", "سخت بودن پروسه خرید"] },
    { key: "afterPurchase", title: "تماس خروجی بعد خرید", items: ["رضایت از کالا", "رضایت از تحویل", "درخواست پیگیری"] }
  ];
  const MAX_ITEMS = 100;
  const MAX_ITEM_LENGTH = 300;
  const text = (value) => value == null ? "" : String(value).trim();
  const normalize = (value) => text(value).normalize("NFKC").replace(/ي/g, "ی").replace(/ك/g, "ک")
    .replace(/[\u200c\u200e\u200f]/g, " ").replace(/\s+/g, " ").trim();
  const defaultTemplates = () => Object.fromEntries(DEFINITIONS.map((item) => [item.key, [...item.items]]));
  function itemsFromLines(value) {
    const values = text(value).split(/\r?\n/).map((line) => text(line).replace(/\s+/g, " ")).filter(Boolean);
    if (values.length > MAX_ITEMS) throw new Error(`برای هر فعالیت حداکثر ${MAX_ITEMS} گزینه وارد کنید.`);
    if (values.some((item) => item.length > MAX_ITEM_LENGTH)) throw new Error(`متن هر گزینه حداکثر ${MAX_ITEM_LENGTH} نویسه باشد.`);
    const seen = new Set();
    return values.filter((item) => {
      const key = normalize(item);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
  function normalizeTemplates(value) {
    return Object.fromEntries(DEFINITIONS.map((definition) => {
      const source = Array.isArray(value?.[definition.key]) ? value[definition.key] : definition.items;
      const items = source.slice(0, MAX_ITEMS).map((item) => text(item).slice(0, MAX_ITEM_LENGTH)).filter(Boolean);
      return [definition.key, itemsFromLines(items.join("\n"))];
    }));
  }
  function templateForTitle(title, templates) {
    const definition = DEFINITIONS.find((item) => normalize(item.title) === normalize(title));
    return definition ? { ...definition, items: normalizeTemplates(templates)[definition.key], ...teamVersion() } : null;
  }
  function templateForKey(key, templates) {
    const definition = DEFINITIONS.find((item) => item.key === key);
    return definition ? { ...definition, items: normalizeTemplates(templates)[key], ...teamVersion() } : null;
  }
  function teamVersion() {
    const version = root.document?.documentElement?.dataset.didarTeamChecklistVersion;
    return version ? {teamVersion:version} : {};
  }
  const columns = (value) => Number(value) === 4 ? 4 : 3;
  const parse = (html) => new root.DOMParser().parseFromString(typeof html === "string" ? html : "", "text/html");
  const rows = (list) => Array.from(list.querySelectorAll(":scope > li")).map((item) => ({
    label: normalize(item.querySelector(".todo-list__label__description")?.textContent || item.textContent),
    checked: Boolean(item.querySelector('input[type="checkbox"]')?.hasAttribute("checked"))
  }));
  function todoItem(documentNode, label, checked = false) {
    const item = documentNode.createElement("li");
    const wrapper = documentNode.createElement("label");
    wrapper.className = "todo-list__label";
    const input = documentNode.createElement("input");
    input.type = "checkbox";
    input.setAttribute("disabled", "disabled");
    if (checked) input.setAttribute("checked", "checked");
    const description = documentNode.createElement("span");
    description.className = "todo-list__label__description";
    description.textContent = label;
    wrapper.append(input, description);
    item.append(wrapper);
    return item;
  }
  function ensure(note, template, { replaceUnmarked = false } = {}) {
    if (!template?.items?.length) return typeof note === "string" ? note : "";
    const documentNode = parse(note);
    const owned = documentNode.querySelector(`ul.todo-list[data-didar-call-template="${template.key}"]`);
    if (owned && !replaceUnmarked && rows(owned).some((row) => row.label)) return note;
    let target = owned || documentNode.querySelector("ul.todo-list");
    const existing = target ? rows(target) : [];
    if (!target) {
      target = documentNode.createElement("ul");
      target.className = "todo-list";
      documentNode.body.append(target);
    }
    if (replaceUnmarked) {
      const checked = new Set(existing.filter((item) => item.checked).map((item) => item.label));
      target.replaceChildren(...template.items.map((label) => todoItem(documentNode, label, checked.has(normalize(label)))));
      documentNode.querySelectorAll("ul.todo-list[data-didar-call-template]").forEach((list) => {
        if (list !== target) list.remove();
      });
    } else {
      const seen = new Set(existing.map((item) => item.label));
      template.items.forEach((label) => {
        if (!seen.has(normalize(label))) { target.append(todoItem(documentNode, label)); seen.add(normalize(label)); }
      });
    }
    target.dataset.didarCallTemplate = template.key;
    if (template.teamVersion) target.dataset.didarCallTemplateVersion = template.teamVersion;
    return documentNode.body.innerHTML;
  }
  function completedNotes(note, resultNote) {
    const noteDocument = parse(note);
    const lists = Array.from(noteDocument.querySelectorAll("ul.todo-list"));
    if (!lists.length) return { note, resultNote };
    const resultDocument = parse(resultNote);
    lists.forEach((list) => {
      const labels = rows(list).map((row) => row.label);
      const matched = Array.from(resultDocument.querySelectorAll("ul.todo-list")).some((other) => {
        const otherLabels = rows(other).map((row) => row.label);
        return labels.length === otherLabels.length && labels.every((label, index) => label === otherLabels[index]);
      });
      if (!matched) resultDocument.body.append(list.cloneNode(true));
      list.remove();
    });
    return { note: noteDocument.body.innerHTML.trim(), resultNote: resultDocument.body.innerHTML.trim() };
  }
  const isNewActivity = (activity) => !text(activity?.Id) || /^00000000-0000-0000-0000-000000000000$/i.test(text(activity.Id));
  const hasChecklist = (note) => Array.from(parse(note).querySelectorAll("ul.todo-list"))
    .some((list) => rows(list).some((row) => row.label));
  const BACKUP_FORMAT = "didar-quick-checklist/call-settings";
  function validateBackupSettings(value) {
    if (typeof value?.autoCallChecklist !== "boolean" || ![3, 4].includes(value.callChecklistColumns)) {
      throw new Error("تنظیمات چک‌لیست در فایل معتبر نیست.");
    }
    const templates = {};
    DEFINITIONS.forEach(({ key }) => {
      const items = value.callChecklistTemplates?.[key];
      if (!Array.isArray(items) || items.length > MAX_ITEMS || items.some((item) =>
        typeof item !== "string" || item.length > MAX_ITEM_LENGTH || /[\r\n]/.test(item))) {
        throw new Error("فهرست گزینه‌های فایل معتبر نیست.");
      }
      templates[key] = itemsFromLines(items.join("\n"));
    });
    return { autoCallChecklist: value.autoCallChecklist, callChecklistColumns: value.callChecklistColumns,
      callChecklistTemplates: templates };
  }
  function exportBackup(settings) {
    return JSON.stringify({ format: BACKUP_FORMAT, version: 1, exportedAt: new Date().toISOString(),
      settings: validateBackupSettings(settings) }, null, 2);
  }
  function importBackup(source) {
    if (typeof source !== "string" || source.length > 512 * 1024) throw new Error("حجم فایل پشتیبان بیش از حد مجاز است.");
    let value;
    try { value = JSON.parse(source); } catch { throw new Error("فایل انتخاب‌شده JSON معتبر نیست."); }
    if (value?.format !== BACKUP_FORMAT || value?.version !== 1) throw new Error("این فایل پشتیبان چک‌لیست تماس نیست یا نسخهٔ آن پشتیبانی نمی‌شود.");
    return validateBackupSettings(value.settings);
  }
  const api = { DEFINITIONS, MAX_ITEMS, MAX_ITEM_LENGTH, normalize, defaultTemplates, itemsFromLines,
    normalizeTemplates, templateForTitle, templateForKey, columns, ensure, completedNotes, isNewActivity, hasChecklist,
    exportBackup, importBackup };
  root.DidarCallChecklists = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
/* END GENERATED CALL CHECKLISTS */
(function initializeDidarTodoCore(root) {
  "use strict";

  const GUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

  function text(value) {
    return value == null ? "" : String(value).trim();
  }

  function normalizeLabel(value) {
    return text(value).replace(/\s+/g, " ");
  }

  function cloneJson(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function responseNode(payload) {
    if (payload && typeof payload === "object" && "Response" in payload) {
      return payload.Response;
    }
    return payload;
  }

  function errorMessage(payload, fallback) {
    if (!payload || typeof payload !== "object") {
      return fallback;
    }
    return text(
      payload.Error ||
        payload.Message ||
        payload.message ||
        payload.Response?.Error ||
        payload.Response?.Message
    ) || fallback;
  }

  function userDisplayName(session) {
    const fullName = [text(session?.FirstName), text(session?.LastName)]
      .filter(Boolean)
      .join(" ");
    return fullName || text(session?.DisplayName) || text(session?.UserName) || "کاربر دیدار";
  }

  function parseTodoRows(note) {
    if (typeof DOMParser === "undefined") {
      throw new Error("DOMParser is not available");
    }
    const documentNode = new DOMParser().parseFromString(text(note), "text/html");
    return Array.from(documentNode.querySelectorAll("ul.todo-list > li")).map((item) => {
      const input = item.querySelector('input[type="checkbox"]');
      const description = item.querySelector(".todo-list__label__description");
      return {
        label: normalizeLabel(description?.textContent || item.textContent),
        checked: Boolean(input?.checked || input?.hasAttribute("checked"))
      };
    });
  }

  function todoRowsFromList(list) {
    return Array.from(list.querySelectorAll(":scope > li")).map((item) => {
      const input = item.querySelector('input[type="checkbox"]');
      const description = item.querySelector(".todo-list__label__description");
      return {
        label: normalizeLabel(description?.textContent || item.textContent),
        checked: Boolean(input?.checked || input?.hasAttribute("checked"))
      };
    });
  }

  function matchingTodoLists(note, referenceNote) {
    if (typeof DOMParser === "undefined") {
      throw new Error("DOMParser is not available");
    }
    const referenceRows = Array.isArray(referenceNote)
      ? referenceNote
      : parseTodoRows(referenceNote);
    if (!referenceRows.length) {
      return { documentNode: null, lists: [] };
    }
    const expectedLabels = referenceRows.map((row) => normalizeLabel(row.label));
    const documentNode = new DOMParser().parseFromString(
      note == null ? "" : String(note),
      "text/html"
    );
    const lists = Array.from(documentNode.querySelectorAll("ul.todo-list")).filter((list) => {
      const labels = todoRowsFromList(list).map((row) => row.label);
      return labels.length === expectedLabels.length &&
        labels.every((label, index) => label === expectedLabels[index]);
    });
    return { documentNode, lists };
  }

  function hasMatchingTodoList(note, referenceNote) {
    return matchingTodoLists(note, referenceNote).lists.length > 0;
  }

  function removeMatchingTodoLists(note, referenceNote) {
    const matched = matchingTodoLists(note, referenceNote);
    if (!matched.documentNode || !matched.lists.length) {
      return note == null ? "" : String(note);
    }
    matched.lists.forEach((list) => list.remove());
    return matched.documentNode.body.innerHTML.trim();
  }

  function replaceMatchingTodoLists(note, referenceNote) {
    const source = matchingTodoLists(referenceNote, referenceNote);
    if (!source.documentNode || !source.lists.length) {
      return note == null ? "" : String(note);
    }
    const target = matchingTodoLists(note, referenceNote);
    const documentNode = target.documentNode || new DOMParser().parseFromString(
      note == null ? "" : String(note),
      "text/html"
    );
    target.lists.forEach((list) => list.remove());
    source.lists.forEach((list) => documentNode.body.appendChild(list.cloneNode(true)));
    return documentNode.body.innerHTML.trim();
  }

  function patchTodo(note, index, expectedLabel, targetChecked) {
    if (typeof DOMParser === "undefined") {
      throw new Error("DOMParser is not available");
    }
    const documentNode = new DOMParser().parseFromString(text(note), "text/html");
    const items = Array.from(documentNode.querySelectorAll("ul.todo-list > li"));
    const item = items[index];
    if (!item) {
      throw new Error("گزینه انتخاب‌شده در نسخه تازه فعالیت پیدا نشد.");
    }

    const input = item.querySelector('input[type="checkbox"]');
    const description = item.querySelector(".todo-list__label__description");
    const actualLabel = normalizeLabel(description?.textContent || item.textContent);
    if (!input || actualLabel !== normalizeLabel(expectedLabel)) {
      throw new Error("متن چک‌لیست از زمان نمایش صفحه تغییر کرده است.");
    }

    const before = parseTodoRows(note);
    if (before[index].checked === Boolean(targetChecked)) {
      throw new Error("این گزینه قبلاً با همین وضعیت در سرور ذخیره شده است.");
    }

    const sourceNote = note == null ? "" : String(note);
    const sourceItems = Array.from(
      sourceNote.matchAll(/<li\b[^>]*>[\s\S]*?<\/li>/gi)
    ).filter((match) => {
      const fragment = new DOMParser().parseFromString(match[0], "text/html");
      return Boolean(
        fragment.querySelector('input[type="checkbox"]') &&
          fragment.querySelector(".todo-list__label__description")
      );
    });
    if (sourceItems.length !== before.length || !sourceItems[index]) {
      throw new Error("محل دقیق گزینه در متن فعالیت پیدا نشد.");
    }
    const sourceItem = sourceItems[index];
    const inputMatch = /<input\b[^>]*>/i.exec(sourceItem[0]);
    if (!inputMatch) {
      throw new Error("تگ چک‌باکس در متن فعالیت پیدا نشد.");
    }

    const checkedPattern = /\schecked(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?/gi;
    const originalTag = inputMatch[0];
    const closing = originalTag.endsWith("/>") ? "/>" : ">";
    const cleanTag = originalTag.replace(checkedPattern, "");
    const tagBody = cleanTag.slice(0, -closing.length).trimEnd();
    const replacementTag = targetChecked
      ? `${tagBody} checked="checked"${closing}`
      : `${tagBody}${closing}`;
    const tagStart = sourceItem.index + inputMatch.index;
    const tagEnd = tagStart + originalTag.length;
    const result = sourceNote.slice(0, tagStart) + replacementTag + sourceNote.slice(tagEnd);
    const after = parseTodoRows(result);
    if (after.length !== before.length) {
      throw new Error("ساختار چک‌لیست هنگام ویرایش تغییر کرد.");
    }
    before.forEach((row, rowIndex) => {
      if (row.label !== after[rowIndex].label) {
        throw new Error("عنوان یکی از گزینه‌های چک‌لیست تغییر کرد.");
      }
      const expected = rowIndex === index ? Boolean(targetChecked) : row.checked;
      if (after[rowIndex].checked !== expected) {
        throw new Error("بیش از یک گزینه چک‌لیست تغییر کرده است.");
      }
    });
    return result;
  }

  function todoField(activity) {
    const candidates = activity?.IsDone === false
      ? ["Note", "ResultNote"]
      : ["ResultNote", "Note"];
    for (const field of candidates) {
      const note = activity?.[field];
      if (typeof note !== "string") {
        continue;
      }
      try {
        if (parseTodoRows(note).length) {
          return field;
        }
      } catch {
        // Try the other activity note field.
      }
    }
    return activity?.IsDone === false ? "Note" : "ResultNote";
  }

  function todoNote(activity) {
    return text(activity?.[todoField(activity)]);
  }

  function buildSavePayload(activity, fieldOrNote, maybeNote, setDone = false) {
    const field = maybeNote === undefined ? "ResultNote" : fieldOrNote;
    const note = maybeNote === undefined ? fieldOrNote : maybeNote;
    const editable = cloneJson(activity);
    editable[field] = note;
    ["Case", "Deal", "Creator", "Owner"].forEach((key) => delete editable[key]);
    (editable.Contacts || []).forEach((contact) => {
      if (contact && typeof contact === "object") {
        delete contact.Contact;
        delete contact.Status;
      }
    });
    if (editable.RecurrenceType !== "OneTime" && editable.RecurrenceCount) {
      delete editable.RecurrenceEndDate;
    }
    return {
      Activity: editable,
      NewAttachments: [],
      SetDone: Boolean(setDone)
    };
  }

  function isActivity(value) {
    return Boolean(
      value &&
        typeof value === "object" &&
        GUID_PATTERN.test(text(value.Id)) &&
        (typeof value.ResultNote === "string" || typeof value.Note === "string") &&
        ("ActivityTypeId" in value || "DueDate" in value)
    );
  }

  function rowsMatchActivity(activity, visibleRows, changedIndex) {
    let rows;
    try {
      rows = parseTodoRows(todoNote(activity));
    } catch {
      return false;
    }
    if (!rows.length || rows.length !== visibleRows.length) {
      return false;
    }
    return rows.every((row, index) => {
      if (row.label !== visibleRows[index].label) {
        return false;
      }
      return index === changedIndex || row.checked === visibleRows[index].checked;
    });
  }

  root.DidarTodoCore = {
    GUID_PATTERN,
    buildSavePayload,
    cloneJson,
    errorMessage,
    hasMatchingTodoList,
    isActivity,
    normalizeLabel,
    parseTodoRows,
    patchTodo,
    removeMatchingTodoLists,
    replaceMatchingTodoLists,
    responseNode,
    rowsMatchActivity,
    text,
    todoField,
    todoNote,
    userDisplayName
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = root.DidarTodoCore;
  }
})(typeof globalThis !== "undefined" ? globalThis : window);
