(function initializeTaminCore(root) {
  "use strict";
  const text = (value) => value == null ? "" : String(value).trim();
  const digits = (value) => text(value).replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d))).replace(/\D/g, "");
  const normalizeName = (value) => text(value).replace(/ي/g, "ی").replace(/ك/g, "ک").replace(/\s+/g, " ");

  function creditAmount(value) {
    if (typeof value === "number" && (!Number.isSafeInteger(value) || value < 0)) throw new Error("مبلغ اعتبار معتبر نیست.");
    const amount = text(value);
    if (!/^\d{1,30}$/.test(amount)) throw new Error("مبلغ اعتبار معتبر نیست.");
    return amount.replace(/^0+(?=\d)/, "");
  }

  function isWagePage(location) {
    return location.hostname === "eservices.tamin.ir" && /^\/view\/?$/.test(location.pathname) && /^#\/wage-assignment(?:[/?]|$)/.test(location.hash);
  }

  function selectedPension(documentNode) {
    const scope = documentNode.querySelector("app-wage-assignment-edit");
    if (!scope) throw new Error("فرم کسر اقساط تأمین اجتماعی باز نیست.");
    const input = scope.querySelector("tamin-field-combo-box-static input");
    const id = digits(input?.value);
    if (!/^\d{1,20}$/.test(id)) throw new Error("ابتدا شماره مستمری را در فرم سامانه انتخاب کنید.");
    return id;
  }

  function staticField(scope, label) {
    const key = (value) => normalizeName(value).replace(/[:：\s\u200c\u200e\u200f]/g, "");
    for (const node of scope?.querySelectorAll("tamin-field-static-text") || []) {
      if ([node, node.parentElement].some((container) => key(container?.textContent) === key(label))) {
        return text(node.querySelector("input")?.value);
      }
    }
    return "";
  }

  function sourceSnapshot(documentNode, location) {
    if (!isWagePage(location)) throw new Error("صفحهٔ کسر اقساط تأمین اجتماعی باز نیست.");
    const pensionerId = selectedPension(documentNode);
    const identityScope = documentNode.querySelector("app-edict-view");
    const firstName = normalizeName(staticField(identityScope, "نام"));
    const lastName = normalizeName(staticField(identityScope, "نام خانوادگی"));
    if (!firstName || !lastName) {
      throw new Error(`خواندن فیلد «${!firstName ? "نام" : "نام خانوادگی"}» از بخش اطلاعات هویتی فرم امکان‌پذیر نشد.`);
    }
    const nationalCode = digits(staticField(identityScope, "کد ملی"));
    if (!/^\d{10}$/.test(nationalCode)) throw new Error("کد ملی ده‌رقمی در بخش اطلاعات هویتی فرم پیدا نشد.");
    const shownAmount = staticField(documentNode.querySelector("app-wage-assignment-edit"), "میزان اعتبار");
    if (!/^[0-9۰-۹٠-٩,٬،\s]+$/.test(shownAmount)) throw new Error("خواندن مبلغ «میزان اعتبار» از فرم امکان‌پذیر نشد؛ تا نمایش مبلغ صبر کنید.");
    const monthlyCapacityRials = creditAmount(digits(shownAmount));
    const identity = { nationalCode, fullName: `${firstName} ${lastName}`, mobile: "", birthDateJalali: "" };
    return { identity, pensionerId, monthlyCapacityRials };
  }

  async function fetchCustomerReport({ document, location }) {
    // Read only the populated native form, without APIs, network hooks or session state.
    const snapshot = sourceSnapshot(document, location);
    const { identity, pensionerId, monthlyCapacityRials } = snapshot;
    return {
      identity,
      creditReport: { provider: "beta", sourceSystem: "tamin", nationalCode: identity.nationalCode, pensionerId,
        monthlyCapacityRials, receivedDate: new Intl.DateTimeFormat("fa-IR-u-nu-latn", { timeZone: "Asia/Tehran", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()) }
    };
  }

  async function verifyCurrentReport(data, options) {
    const current = await fetchCustomerReport(options);
    if (current.identity.nationalCode !== data.identity.nationalCode || current.identity.fullName !== data.identity.fullName ||
        current.creditReport.pensionerId !== data.creditReport.pensionerId || current.creditReport.monthlyCapacityRials !== data.creditReport.monthlyCapacityRials ||
        current.creditReport.receivedDate !== data.creditReport.receivedDate) {
      throw new Error("اطلاعات مشتری یا توان قسط نسبت به پیش‌نمایش تغییر کرده است؛ پنجره را ببندید و دوباره واکشی کنید.");
    }
  }
  const api = { digits, creditAmount, isWagePage, selectedPension, staticField, sourceSnapshot, fetchCustomerReport, verifyCurrentReport };
  root.TaminCreditCore = api;
  if (typeof module === "object" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
