globalThis.DidarRelease = {
  "channel": "chromium",
  "downloadUrl": "https://github.com/mhfazaeli-hub/didar-extension-updates",
  "nativeHost": "ir.sarika.didar_updater",
  "teamChecklists": {
    "url": "https://raw.githubusercontent.com/mhfazaeli-hub/didar-extension-updates/main/templates/calls.json",
    "publicKey": "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAy1PBW6X8KliCrLZb/7/CKjfDhhxMyC8NRPKOEMuMyl+WzMJdAXnf4JmjSiqxPuGZ4BW7A3Tg6S9E3nGciN8nvhjwJAz0ivMQPTMoxNQEANw4oJVMn/ohxJisRDxo3fREHiHhl4r2kTYXSyZAP3UbesMDTz0s3ld4gGn8nb2xPqXn2BvFl3drdx4PqsnX8QRCBSSH/tkOqDefw/Ip/IguMirGMD4uNjss24dq0SvDTd7y64IdBg7mI8w7iX7UOv5JtpdDLqQ1dg73OHyCWlHDMJR32uYqW0+0mkKkXAoLBFWmpFjwXdDamR+nke7MoDWqcnEyYQYuJHAzKiFnsqeaVw4g3boibs/sPxMfJOGUlxALNoJqiupkV0JEaelRu4OiGJh9vzLOroc59OBo+qfPuV6L8uWE+Tyew1kIJk3g6VMIWc9AYMS0Xhi958eou89bO4OpJGpz3sp2AdpnjLd09OzxWGMvsPEIA2ia6Wpgz10FYYU4kFZS8ZI6n+W+2ZgrAgMBAAE=",
    "publishUrl": "https://didar-team-checklists.didar-quick-checklist-extension.workers.dev"
  },
  "diagnosticsUrl": "https://didar-extension-diagnostics.didar-quick-checklist-extension.workers.dev/events",
  "cloudApiUrl": "https://didar-extension-cloud-api.didar-quick-checklist-extension.workers.dev:8443",
  "cloudApiFallbackUrl": "https://didar-extension-cloud-api.didar-quick-checklist-extension.workers.dev"
};
