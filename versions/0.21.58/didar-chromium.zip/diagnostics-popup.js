(function initializeDiagnosticPopup() {
  "use strict";
  const api = globalThis.browser || globalThis.chrome;
  const button = document.getElementById("downloadDiagnostics");
  const status = document.getElementById("diagnosticStatus");
  const consent = document.getElementById("enableDiagnosticSending");
  const sendButton = document.getElementById("sendDiagnostics");
  if (typeof api.runtime.getBrowserInfo === "function") {
    api.permissions.getAll().then(value => {
      consent.hidden = value.data_collection?.includes("technicalAndInteraction") === true;
    }).catch(() => {});
    consent.addEventListener("click", async () => {
      const granted = await api.permissions.request({data_collection:["technicalAndInteraction"]});
      if (granted) {
        consent.hidden = true;
        await api.runtime.sendMessage({type:"DIDAR_DIAGNOSTICS_GET"});
        status.textContent = "ارسال گزارش‌های فنی فعال شد.";
      }
    });
  }
  sendButton.addEventListener("click", async () => {
    sendButton.disabled = true;
    status.textContent = "در حال ارسال گزارش‌های معطل‌مانده…";
    try {
      const result = await api.runtime.sendMessage({ type: "DIDAR_DIAGNOSTICS_GET" });
      if (!result?.ok) throw Error("ارسال گزارش فنی انجام نشد.");
      status.textContent = result.queue.length
        ? `${result.queue.length} رویداد در انتظار ارسال است. اتصال شبکه و مجوز ارسال گزارش را بررسی کنید.`
        : result.recent.length ? "ارسال گزارش‌های فنی ثبت‌شده تکمیل شد." : "هنوز رویداد فنی برای ارسال ثبت نشده است.";
    } catch (error) { status.textContent = error.message; }
    finally { sendButton.disabled = false; }
  });
  button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      const result = await api.runtime.sendMessage({
        type: "DIDAR_DIAGNOSTICS_GET",
      });
      if (!result?.ok) throw Error("دریافت گزارش فنی انجام نشد.");
      const url = URL.createObjectURL(
        new Blob(
          [
            JSON.stringify(
              { schemaVersion: 1, recent: result.recent },
              null,
              2,
            ),
          ],
          { type: "application/json" },
        ),
      );
      const link = document.createElement("a");
      link.href = url;
      link.download =
        "didar-diagnostics-" + new Date().toISOString().slice(0, 10) + ".json";
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      const last = result.recent.at(-1);
      status.textContent = last
        ? `آخرین شناسهٔ پیگیری ${last.id} — ${result.queue.length} مورد در انتظار ارسال`
        : "هنوز رویداد فنی ثبت نشده است.";
    } catch (error) {
      status.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });
})();
