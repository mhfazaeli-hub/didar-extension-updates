(function initializeTeamBackground(root) {
  "use strict";
  const api = root.browser || root.chrome;
  const Team = root.DidarTeamChecklists;
  if (!Team?.managed()) return;
  let state;
  let booting;
  let syncing;
  let lastError = "";
  let publisherCode = "";
  let publisherExpiresAt = 0;
  const canPublish = () => Boolean(publisherCode && Date.now() < publisherExpiresAt);
  async function restorePublisher() {
    if (!api.storage.session) return;
    const stored = await api.storage.session.get("teamPublisher");
    publisherCode = stored.teamPublisher?.code || "";
    publisherExpiresAt = stored.teamPublisher?.expiresAt || 0;
    if (!canPublish()) { publisherCode = ""; publisherExpiresAt = 0; await api.storage.session.remove("teamPublisher"); }
  }
  async function service(route, body, code = publisherCode) {
    const base = root.DidarRelease.teamChecklists.publishUrl;
    if (!base || !base.startsWith("https://")) throw Error("درگاه انتشار هنوز تنظیم نشده است.");
    const response = await fetch(base + route,{method:"POST",credentials:"omit",headers:{Authorization:"Bearer " + code,"Content-Type":"application/json"},body:JSON.stringify(body || {}),signal:AbortSignal.timeout(60000)});
    const result = await response.json();
    if (!response.ok || !result.ok) {
      if (response.status === 401) { publisherCode = ""; publisherExpiresAt = 0; await api.storage.session?.remove("teamPublisher"); }
      throw Error(result.error || "درگاه انتشار پاسخ معتبر نداد.");
    }
    return result;
  }
  async function commit(envelope, receivedAt) {
    const candidate = await Team.verify(envelope);
    if (state && candidate.version < state.version) throw Error("نسخهٔ قدیمی قالب تیم رد شد.");
    if (state && candidate.version === state.version && JSON.stringify(candidate) !== JSON.stringify(state)) throw Error("محتوای متفاوت برای نسخهٔ یکسان قالب رد شد.");
    const previous = state;
    state = candidate;
    try { await api.storage.local.set({didarTeamEnvelope:envelope, didarTeamReceivedAt:receivedAt, ...candidate.settings}); }
    catch (error) { state = previous; throw error; }
  }
  function boot() {
    if (!booting) booting = (async () => {
      const stored = await api.storage.local.get(["didarTeamEnvelope", "didarTeamReceivedAt"]);
      if (stored.didarTeamEnvelope) {
        try { await commit(stored.didarTeamEnvelope, stored.didarTeamReceivedAt); } catch (error) { lastError = error.message; }
      }
      if (!state) {
        const response = await fetch(api.runtime.getURL("team-checklists.json"));
        if (!response.ok) throw Error("قالب اولیهٔ تیم در دسترس نیست.");
        await commit(await response.json(), "");
      }
      return state;
    })().catch(error => { booting = null; throw error; });
    return booting;
  }
  function sync() {
    if (!syncing) syncing = (async () => {
      await boot();
      try {
        const response = await fetch(root.DidarRelease.teamChecklists.url + "?check=" + Date.now(), {credentials:"omit",cache:"no-store",signal:AbortSignal.timeout(15000)});
        if (!response.ok || Number(response.headers.get("content-length")) > 262144) throw Error("دریافت قالب تیم انجام نشد.");
        const body = await response.text();
        if (body.length > 262144) throw Error("فایل قالب تیم بیش از حد بزرگ است.");
        await commit(JSON.parse(body), new Date().toISOString());
        lastError = "";
      } catch (error) { lastError = error.message; }
      return state;
    })().finally(() => { syncing = null; });
    return syncing;
  }
  api.runtime.onMessage.addListener((message, sender, respond) => {
    if (!message?.type?.startsWith("DIDAR_TEAM_") || sender.id !== api.runtime.id) return false;
    const popup = sender.url === api.runtime.getURL("popup.html");
    (async () => {
      await restorePublisher();
      if (["DIDAR_TEAM_UNLOCK","DIDAR_TEAM_LOCK"].includes(message.type)) {
        if (!popup) throw Error("دسترسی ناشر فقط از تنظیمات مجاز است.");
        publisherCode = ""; publisherExpiresAt = 0;
        await api.storage.session?.remove("teamPublisher");
        if (message.type === "DIDAR_TEAM_UNLOCK") {
          if (typeof message.code !== "string" || message.code.length < 16 || message.code.length > 128) throw Error("رمز انتشار معتبر نیست.");
          await service("/authorize",{},message.code);
          publisherCode = message.code;
          publisherExpiresAt = Date.now() + 15 * 60 * 1000;
          await api.storage.session?.set({teamPublisher:{code:publisherCode,expiresAt:publisherExpiresAt}});
        }
        await boot();
        return {ok:true,state,manager:canPublish()};
      }
      if (message.type === "DIDAR_TEAM_PUBLISH") {
        if (!popup) throw Error("انتشار فقط از تنظیمات افزونه مجاز است.");
        await boot();
        if (!canPublish()) throw Error("برای انتشار، رمز ناشر را دوباره وارد کنید.");
        const result = await service("/publish",{settings:Team.settings(message.settings),expectedVersion:message.expectedVersion});
        await commit(result.envelope, new Date().toISOString());
        return {ok:true, state,manager:canPublish()};
      }
      if (message.type === "DIDAR_TEAM_SYNC" && !popup) throw Error("درخواست بروزرسانی مجاز نیست.");
      await (message.type === "DIDAR_TEAM_SYNC" ? sync() : boot());
      const stored = await api.storage.local.get("didarTeamReceivedAt");
      return {ok:true,state,receivedAt:stored.didarTeamReceivedAt,error:lastError,manager:canPublish()};
    })().then(respond).catch(error => respond({ok:false,error:error.message}));
    return true;
  });
  api.runtime.onStartup?.addListener(() => void sync().catch(() => {}));
  api.runtime.onInstalled?.addListener(() => void sync().catch(() => {}));
  void sync().catch(() => {});
})(globalThis);
