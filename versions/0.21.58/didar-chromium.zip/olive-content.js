(function initializeOliveTransfer() {
  "use strict";
  const chrome = globalThis.browser || globalThis.chrome;
  if (globalThis.__didarOliveContent) return;
  globalThis.__didarOliveContent = true;
  let busy = false;
  let launcher;
  let status;
  let diagnosticButton;
  let lastDiagnostic = null;
  const Core = globalThis.OliveCreditCore;
  function diagnosticFor(error) {
    const value = error?.diagnostic || {};
    const availability = {};
    for (const key of ["hasReport", "scoreAvailable", "rankAvailable", "historyRowFound", "identityMatches"]) {
      if (typeof value.availability?.[key] === "boolean") availability[key] = value.availability[key];
    }
    const stages = ["profile", "score", "history", "pdf"];
    const codes = ["HTTP_ERROR", "TIMEOUT", "REQUEST_FAILED", "PROFILE_UNAVAILABLE", "REPORT_UNAVAILABLE", "RESULT_INCOMPLETE", "HISTORY_UNAVAILABLE", "IDENTITY_MISMATCH", "CONTEXT_INVALIDATED"];
    let extensionVersion = "unknown";
    try { extensionVersion = chrome.runtime.getManifest?.().version || "unknown"; } catch {}
    return { schemaVersion: 1, source: "olive", extensionVersion,
      timestamp: new Date().toISOString(), stage: stages.includes(value.stage) ? value.stage : "client",
      code: codes.includes(value.code) ? value.code : "CLIENT_ERROR",
      ...(Number.isInteger(value.httpStatus) && value.httpStatus >= 100 && value.httpStatus <= 599 ? { httpStatus: value.httpStatus } : {}), availability };
  }
  function request() {
    return new Promise((resolve, reject) => {
      const marker = document.createElement("meta"); marker.dataset.didarOliveRequest = crypto.randomUUID();
      const timer = window.setTimeout(() => { marker.remove(); reject(new Error("واکشی زمان زیادی برد؛ صفحهٔ سامانه را تازه‌سازی کنید.")); }, 90000);
      marker.addEventListener("didar-olive:result", () => {
        window.clearTimeout(timer);
        try {
          const result = JSON.parse(marker.textContent);
          if (result.ok) resolve(result);
          else { const error = new Error(result.error); error.diagnostic = result.diagnostic; reject(error); }
        }
        catch (error) { reject(error); }
        finally { marker.remove(); }
      }, { once: true });
      document.documentElement.append(marker);
      marker.dispatchEvent(new Event("didar-olive:fetch", { bubbles: true }));
    });
  }
  async function parse(base64, identity, score) {
    const pages = await new Promise((resolve, reject) => {
      const frame = document.createElement("iframe"), id = crypto.randomUUID();
      frame.hidden = true; frame.setAttribute("aria-hidden", "true");
      frame.src = chrome.runtime.getURL("olive-pdf.html");
      const url = new URL(frame.src), origin = `${url.protocol}//${url.host}`;
      const clean = () => { window.clearTimeout(timeout); window.removeEventListener("message", receive); frame.remove(); };
      const timeout = window.setTimeout(() => { clean(); reject(new Error("خواندن PDF به‌موقع انجام نشد؛ دوباره تلاش کنید.")); }, 45000);
      const receive = (event) => {
        if (event.source !== frame.contentWindow || event.origin !== origin || typeof event.data !== "string") return;
        let result; try { result = JSON.parse(event.data); } catch { return; }
        if (result.type === "didar-olive-pdf-ready") {
          frame.contentWindow.postMessage(JSON.stringify({ type: "didar-olive-pdf", id, base64 }), origin);
        } else if (result.type === "didar-olive-pdf-result" && result.id === id) {
          clean(); result.ok ? resolve(result.pages) : reject(new Error(result.error));
        }
      };
      window.addEventListener("message", receive); document.documentElement.append(frame);
    });
    return Core.pdf(pages, identity, score);
  }
  async function transfer() {
    if (busy) return;
    busy = true; launcher.disabled = true; status.textContent = "در حال دریافت پروفایل و گزارش موجود...";
    lastDiagnostic = null; diagnosticButton.hidden = true;
    let stage="client";
    try {
      const settings = await chrome.storage.local.get({ etebaritoPreviewEnabled: true });
      if (!settings.etebaritoPreviewEnabled) throw new Error("گزینهٔ «انتقال اعتبارسنجی به دیدار» را در تنظیمات افزونه فعال کنید.");
      const result = await request();
      const identity = Core.profile(result.profile), score = Core.score(result.score);
      status.textContent = "در حال خواندن و تطبیق گزارش...";
      stage="parse";
      const report = await parse(result.base64, identity, score);
      stage="preview";
      await globalThis.DidarCreditPreview.openExternal({
        row: { shareReportId: `olive:${score.id}:${identity.nationalCode}`, customerNationalCode: identity.nationalCode,
          reportUniqCode: report.reportUniqCode, creditRatingScore: score.creditRatingScore, creditRank: score.creditRank,
          oliveReport: report }, identity: { ...identity, overdueContracts: report.overdueContracts }
      });
      status.textContent = "گزارش آماده است؛ فرم انتقال را بررسی کنید.";
    } catch (error) {
      if (/extension context invalidated|receiving end does not exist|could not establish connection/i.test(error?.message || "")) {
        error = globalThis.DidarCreditPreview?.recoverInvalidContext?.() || new Error("افزونه بروزرسانی شده است؛ صفحه الیو کردیت را تازه‌سازی کنید.");
        error.diagnostic = { stage: "client", code: "CONTEXT_INVALIDATED" };
      }
      status.textContent = error.message || "واکشی انجام نشد.";
      lastDiagnostic = diagnosticFor(error); diagnosticButton.hidden = false;
      void globalThis.DidarDiagnostics?.report({source:"olive",operation:"fetch",stage:error.diagnostic?.stage || stage,
        code:error.diagnostic?.code || (stage==="parse" ? "PDF_PARSE_FAILED" : globalThis.DidarDiagnostics.classify(error)),httpStatus:error.diagnostic?.httpStatus});
    }
    finally { busy = false; launcher.disabled = false; }
  }
  function mount() {
    if (!location.pathname.startsWith("/profile")) { document.getElementById("didar-olive-transfer")?.remove(); return; }
    if (!document.body) return;
    if (document.getElementById("didar-olive-transfer")) return;
    const panel = document.createElement("aside"); panel.id = "didar-olive-transfer";
    launcher = document.createElement("button"); launcher.type = "button"; launcher.textContent = "واکشی الیو کردیت برای دیدار";
    status = document.createElement("small"); status.setAttribute("role", "status");
    status.textContent = "انتقال گزارش موجود به دیدار";
    launcher.addEventListener("click", () => void transfer()); panel.append(launcher, status); document.body.append(panel);
    diagnosticButton = document.createElement("button"); diagnosticButton.type = "button";
    diagnosticButton.className = "didar-olive-diagnostic"; diagnosticButton.hidden = true;
    diagnosticButton.textContent = "دانلود جزئیات خطا برای بررسی";
    diagnosticButton.title = "فقط مرحله و وضعیت خطا؛ بدون نام، کد ملی، شماره همراه، گزارش یا اطلاعات ورود";
    diagnosticButton.addEventListener("click", () => {
      if (!lastDiagnostic) return;
      const url = URL.createObjectURL(new Blob([JSON.stringify(lastDiagnostic, null, 2)], { type: "application/json" }));
      const link = document.createElement("a"); link.href = url;
      link.download = `didar-olive-error-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
      link.hidden = true; panel.append(link); link.click(); link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
    panel.append(diagnosticButton);
  }
  const observer = new MutationObserver(mount);
  window.addEventListener("pagehide", () => observer.disconnect(), { once: true });
  function start() { if (!document.documentElement) return; observer.observe(document.documentElement, { childList: true, subtree: true }); mount(); }
  document.addEventListener("DOMContentLoaded", start, { once: true });
  if (document.documentElement) start();
})();
