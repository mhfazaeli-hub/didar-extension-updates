(function initializeDidarTodoExtension() {
  "use strict";
  const chrome = globalThis.DidarCloudExtensionAPI || globalThis.browser || globalThis.chrome;

  if (globalThis.__didarQuickChecklistContentLoaded) {
    if (typeof globalThis.__didarQuickChecklistRegisterMessageListener === "function") {
      globalThis.__didarQuickChecklistRegisterMessageListener();
    }
    return;
  }
  globalThis.__didarQuickChecklistContentLoaded = true;

  const Core = globalThis.DidarTodoCore;
  const CallChecklists = globalThis.DidarCallChecklists;
  const DEFAULT_SETTINGS = {
    enabled: true,
    confirmBeforeSave: false,
    autoPlanChecklist: true,
    autoCallChecklist: true,
    callChecklistColumns: 3,
    callChecklistTemplates: CallChecklists?.defaultTemplates() || {},
    autoAddPlanProduct: true,
    etebaritoPreviewEnabled: true,
    etebaritoKeepAliveEnabled: false,
    connectionMode: "automatic",
    manualToken: "",
    manualBizDomain: ""
  };
  const RESOLVE_EVENT = "didar-quick-checklist:resolve";
  const PLAN_ACTIVITY_CREATED_EVENT = "didar-quick-checklist:plan-activity-created";
  const PLAN_ACTIVITY_DELETED_EVENT = "didar-quick-checklist:plan-activity-deleted";
  const DEAL_PRODUCTS_UPDATED_EVENT = "didar-quick-checklist:deal-products-updated";
  const DEAL_PRODUCTS_SYNCED_EVENT = "didar-quick-checklist:deal-products-synced";
  const ACTIVITY_COMPLETED_EVENT = "didar-quick-checklist:activity-completed";
  const ACTIVITY_SAVED_EVENT = "didar-quick-checklist:activity-saved";
  const ACTIVITY_COMPLETION_SYNCED_EVENT = "didar-quick-checklist:activity-completion-synced";
  const ACTIVITY_CREATED_REFRESH_EVENT = "didar-quick-checklist:activity-created-refresh";
  const ACTIVITY_CREATED_REFRESHED_EVENT = "didar-quick-checklist:activity-created-refreshed";
  const NATIVE_QUICK_ACTIVITY_CREATE_EVENT = "didar-quick-checklist:native-quick-activity-create";
  const NATIVE_QUICK_ACTIVITY_STARTED_EVENT = "didar-quick-checklist:native-quick-activity-started";
  const NATIVE_ACTIVITY_DONE_ARM_EVENT = "didar-quick-checklist:native-activity-done-arm";
  const NATIVE_ACTIVITY_DONE_ARMED_EVENT = "didar-quick-checklist:native-activity-done-armed";
  const NATIVE_ACTIVITY_DONE_FINISHED_EVENT = "didar-quick-checklist:native-activity-done-finished";
  const DEAL_ADD_PERSON_SELECTED_EVENT = "didar-quick-checklist:deal-add-person-selected";
  const MANUAL_DEAL_ATTACH_EVENT = "didar-quick-checklist:manual-deal-attach";
  const MANUAL_DEAL_ATTACH_DONE_EVENT = "didar-quick-checklist:manual-deal-attach-done";
  const GLOBAL_SEARCH_RESULTS_EVENT = "didar-quick-checklist:global-search-results";
  const PIPELINE_ACTIVITY_FILTER_EVENT = "didar-quick-checklist:pipeline-activity-filter";
  const EMPTY_GUID = "00000000-0000-0000-0000-000000000000";
  const PRODUCT_ACTIVITY_MAP_KEY = "didar-quick-checklist:activity-product-map:v1";
  const SAVE_OUTBOX_KEY = "didarQuickChecklistSaveOutboxV1";
  const SAVE_OUTBOX_FALLBACK_KEY = "didar-quick-checklist:save-outbox:v1";
  const PRODUCT_DRAFTS_KEY = "didar-quick-checklist:product-drafts:v1";
  const ETEBARITO_STATUS_JOURNAL_KEY = "didar-quick-checklist:etebarito-status-journal:v1";
  const API_REQUEST_TIMEOUT = 20000;
  const ETEBARITO_STATUS_JOURNAL_MAX_AGE = 24 * 60 * 60 * 1000;
  const PLAN_TITLE_PREFIX = "شروع طرح";
  const PRODUCT_TITLE_PREFIX = "کالا کارت";
  const DELIVERY_TODO = "تحویل کالا کارت";
  const DELIVERY_PREREQUISITES = ["تشکیل پرونده", "ارجاع به بانک", "نوبت امضا"];
  const PLAN_TODO_LABELS = [...DELIVERY_PREREQUISITES, DELIVERY_TODO, "ناموفق شدن طرح"];
  const ETEBARITO_JOB_FIELD_KEY = "Field_996_4_23";
  const ETEBARITO_PLAN_TYPE_FIELD_KEY = "Field_8783_9_4";
  const ETEBARITO_CREDIT_RANK_FIELD_KEY = "Field_8783_4_49";
  const ETEBARITO_CUSTOMER_STATUS_FIELD_KEY = "Field_8783_4_12";
  const CREDIT_CUSTOMER_ROLE_FIELD_KEY = "Field_8783_4_50";
  const ETEBARITO_TARGET_PIPELINE = "پرونده اعتباری";
  const ETEBARITO_TARGET_STAGE = "اعتبار سنجی اولیه";
  const ETEBARITO_ACTIVITY_TITLE = "اعتباریتو";
  const BETA_ACTIVITY_TITLE = "اعتبارسنجی بتا";
  const processed = new WeakSet();
  const hitboxByInput = new WeakMap();
  const hitboxRecords = new Set();
  const activeActivitySaves = new Set();
  const activitySaveQueues = new Map();
  const completedNoteCleanups = new Map();
  const confirmedCompletedActivities = new Map();
  const recentlyVerifiedChecklists = new Map();
  const rememberedDealProductViews = new Map();
  const rememberedDealPlanActivities = new Map();
  const dealActivityBindingLoads = new Map();
  const dealActivityBindingAttempts = new Map();
  const productActivityMappings = new Map();
  const activeProductSaves = new Set();
  const activityResolutionAttempts = new WeakMap();
  const pendingCreatedActivityBindings = new Map();
  let durableOperationSequence = 0;
  const hydratingProductEditors = new WeakMap();
  const hydratedProductEditors = new WeakMap();
  let settings = { ...DEFAULT_SETTINGS };
  let callSettingsReady = false;
  let caseCallTypes = { status: "idle", items: [], error: "" };
  let caseCallTypesEpoch = 0;
  const activeCaseCalls = new Set();
  const knownCaseCallCreations = new Set();
  let caseCallNotice = "";
  let observerTimer = null;
  let hitboxFrame = null;
  let cachedIdentity = null;
  let cachedIdentityKey = "";
  let preferredAutomaticToken = "";
  let lastInteraction = "هنوز کلیکی دریافت نشده";
  let productCreationQueue = Promise.resolve();
  const productDealLoads = new Map();
  const productDealLoadGenerations = new Map();
  const productDealLoadFailures = new Map();
  let productSyncSequence = 0;
  let activitySyncSequence = 0;
  let persistenceRecoveryTimer = null;
  let persistenceRecoveryDealId = "";
  let persistenceRecoveryAt = 0;
  const fallbackOperationLocks = new Map();
  let planActivityTypesState = { status: "idle", items: [], error: "" };
  let pipelineActivityTypesState = { status: "idle", items: [], error: "" };
  let pipelineActivityFilterState = { status: "idle", dealCount: 0, error: "" };
  const selectedPipelineActivityTypes = new Set();
  let pipelineActivityFilterTimer = null;
  let pipelineActivityFilterSequence = 0;
  let pipelineActivityFilterPublished = false;
  let pipelineActivityFilterPortal = null;
  const activeQuickPlanCreations = new Set();
  const knownQuickPlanCreations = new Set();
  const activeEtebaritoTransfers = new Map();
  const activeEtebaritoUpdates = new Map();
  let selectedDealAddPersonState = null;
  let selectedDealAddPersonSequence = 0;
  let manualDealContactState = null;
  const manualDealContactDraft = { name: "", mobile: "" };
  let manualDealContactCloseTimer = null;
  const globalSearchProductLabels = new Map();
  const globalSearchProductLoads = new Map();
  let latestGlobalSearchDeals = [];
  const GLOBAL_SEARCH_PRODUCT_CACHE_MS = 30000;
  const planBoard = globalThis.DidarPlanBoard?.create({
    apiRequest,
    accountKey: () => localStorage.getItem("account") || "",
    userKey: async () => (await currentIdentity()).id,
    resolveProduct: resolveBoardProduct,
    saveChecklist: saveBoardChecklist,
    saveProduct: saveBoardProduct,
    createActivity: createBoardActivity,
    loadProductLabels: (deal) => Array.isArray(deal?.Items) && deal.Items.length
      ? productLabelsFromDeal(deal)
      : loadGlobalSearchProductLabels(Core.text(deal?.Id).toLowerCase())
  });

  async function createBoardActivity({ dealId, typeId, title }) {
    if (!settings.enabled || !Core.GUID_PATTERN.test(dealId) ||
        !Core.GUID_PATTERN.test(typeId) || !normalizedTitle(title).startsWith(`${PLAN_TITLE_PREFIX} `)) {
      throw new Error("مشخصات معامله یا نوع فعالیت معتبر نیست.");
    }
    const [deal, identity, history] = await Promise.all([
      apiRequest("deal/GetDealDetail", { body: { Id: dealId }, retry: true }),
      currentIdentity(),
      apiRequest("activity/GetDetailActivities", { body: { DealId: dealId }, retry: true })
    ]);
    if (Core.text(deal?.Id).toLowerCase() !== dealId || deal.IsDeleted === true) {
      throw new Error("معامله انتخاب‌شده در دیدار یافت نشد.");
    }
    const activityRows = (value) => [
      ...(Array.isArray(value?.Planned) ? value.Planned : []),
      ...(Array.isArray(value?.Done) ? value.Done : []),
      ...(Array.isArray(value?.Pinned) ? value.Pinned : [])
    ].filter((activity) => !activity.IsDeleted);
    const prior = activityRows(history);
    if (prior.some((activity) => Core.text(activity.ActivityTypeId).toLowerCase() === typeId &&
        !activity.IsDone)) {
      throw new Error("برای این معامله از همین نوع، فعالیت باز وجود دارد.");
    }
    const contactId = Core.text(deal.ContactId || deal.PersonId || deal.Contact?.Id || deal.Person?.Id);
    const now = new Date().toISOString();
    const note = `<ul class="todo-list">${PLAN_TODO_LABELS.map((label) =>
      `<li><label class="todo-list__label"><input type="checkbox" disabled="disabled">` +
      `<span class="todo-list__label__description">${label}</span></label></li>`).join("")}</ul>`;
    const saved = await apiRequest("activity/SaveActivity", {
      body: {
        Activity: {
          Id: EMPTY_GUID,
          ActivityGroupId: EMPTY_GUID,
          ActivityGroupType: "Default",
          ActivityTicketStatus: "NotAnswered",
          ActivityTypeId: typeId,
          CaseId: EMPTY_GUID,
          DealId: dealId,
          Title: title,
          Note: note,
          ResultNote: "",
          StartDate: now,
          DueDate: now,
          OriginalDueDate: now,
          NextOccurrence: now,
          DoneDate: now,
          FinishDate: now,
          RecurrenceEndDate: now,
          Duration: 5,
          DueDateType: "NoTime",
          FeedbackType: "Neutral",
          RecurrenceType: "OneTime",
          RecurrenceData: 0,
          IsDone: false,
          IsAttended: false,
          IsDeleted: false,
          IsKeepInTouch: false,
          IsPinned: false,
          IsPrivate: false,
          IsTicket: false,
          OwnerId: identity.id,
          CreatorId: identity.id,
          UpdaterId: identity.id,
          Contacts: Core.GUID_PATTERN.test(contactId) ? [{
            ActivityId: EMPTY_GUID,
            ContactId: contactId,
            Message: "",
            Status: "Accepted"
          }] : [],
          Users: [],
          Notifies: [],
          Attachments: [],
          Comments: [],
          Tags: []
        },
        NewAttachments: [],
        SetDone: false
      }
    });
    const before = new Set(prior.map((activity) => Core.text(activity.Id).toLowerCase()));
    const savedId = Core.text(saved?.Id || saved?.Activity?.Id).toLowerCase();
    for (const wait of [0, 180, 420, 850]) {
      if (wait) await delay(wait);
      if (Core.GUID_PATTERN.test(savedId)) {
        try {
          const activity = await apiRequest("activity/GetActivityById", {
            body: { Id: savedId }, retry: true
          });
          if (Core.text(activity?.Id).toLowerCase() === savedId &&
              Core.text(activity?.DealId).toLowerCase() === dealId &&
              Core.text(activity?.ActivityTypeId).toLowerCase() === typeId &&
              !activity.IsDeleted) {
            await ensurePlanProductForActivity(activity);
            return activity;
          }
        } catch {
          // The deal's activity list is the fallback source for confirmation.
        }
      }
      const latest = await apiRequest("activity/GetDetailActivities", {
        body: { DealId: dealId }, retry: true
      });
      const created = activityRows(latest).find((activity) =>
        Core.GUID_PATTERN.test(Core.text(activity.Id)) &&
        !before.has(Core.text(activity.Id).toLowerCase()) &&
        Core.text(activity.DealId).toLowerCase() === dealId &&
        Core.text(activity.ActivityTypeId).toLowerCase() === typeId &&
        normalizedTitle(activity.Title) === normalizedTitle(title));
      if (created) {
        await ensurePlanProductForActivity(created);
        return created;
      }
    }
    throw new Error("ذخیره ارسال شد، اما تأیید سرور دریافت نشد. پیش از تلاش دوباره معامله را بررسی کنید.");
  }

  function readCookie(name) {
    const prefix = `${name}=`;
    const part = document.cookie
      .split(";")
      .map((item) => item.trim())
      .find((item) => item.startsWith(prefix));
    return part ? decodeURIComponent(part.slice(prefix.length)) : "";
  }

  function didarConnectionError(message, code, endpoint = "") {
    const error = new Error(message);
    error.code = code;
    error.endpoint = endpoint;
    return error;
  }

  function errorResponse(error) {
    return {
      ok: false,
      error: error?.message || "عملیات دیدار انجام نشد.",
      code: Core.text(error?.code) || "DIDAR_REQUEST_FAILED",
      ...(Number.isInteger(error?.status) ? {httpStatus:error.status} : {}),
      endpoint: Core.text(error?.endpoint)
    };
  }

  function automaticCredentialCandidates() {
    const bizDomain = localStorage.getItem("account") || "";
    const currentTokens = [localStorage.getItem("losid"), readCookie("LocoAuthCookie")]
      .map((token) => Core.text(token))
      .filter((token, index, values) => token && values.indexOf(token) === index);
    if (preferredAutomaticToken && !currentTokens.includes(preferredAutomaticToken)) {
      preferredAutomaticToken = "";
      cachedIdentity = null;
      cachedIdentityKey = "";
    }
    const tokens = [
      preferredAutomaticToken,
      ...currentTokens
    ]
      .map((token) => Core.text(token))
      .filter((token, index, values) => token && values.indexOf(token) === index);
    return tokens.map((token) => ({ token, bizDomain }));
  }

  function automaticCredentials() {
    return automaticCredentialCandidates()[0] || {
      token: "",
      bizDomain: localStorage.getItem("account") || ""
    };
  }

  function credentialCandidates() {
    if (settings.connectionMode === "manual") {
      return [{
        token: Core.text(settings.manualToken),
        bizDomain: Core.text(settings.manualBizDomain)
      }];
    }
    return automaticCredentialCandidates();
  }

  function credentials() {
    if (globalThis.DidarCloudClient) return { token: "cloud", bizDomain: "cloud-credit" };
    return credentialCandidates()[0] || automaticCredentials();
  }

  function retryDelay(attempt) {
    return Math.min(2500, 250 * (2 ** Math.max(0, attempt - 1)));
  }

  function isTransientDidarServerMessage(message) {
    return /object reference not set to an instance of an object/i.test(Core.text(message));
  }

  async function apiRequest(path, options = {}) {
    if (globalThis.DidarCloudClient) return globalThis.DidarCloudClient.request(path, options);
    const candidates = credentialCandidates();
    const auth = candidates[0] || automaticCredentials();
    if (!auth.token) {
      throw didarConnectionError(
        "نشست فعال دیدار در این تب پیدا نشد. در همین مرورگر وارد دیدار شوید و صفحه دیدار را تازه‌سازی کنید.",
        "DIDAR_AUTH_REQUIRED"
      );
    }
    if (!options.ignoreAccount && !auth.bizDomain) {
      throw didarConnectionError(
        "حساب سازمانی دیدار در این تب مشخص نیست. یک صفحه داخل حساب دیدار را باز و تازه‌سازی کنید.",
        "DIDAR_ACCOUNT_REQUIRED"
      );
    }

    const maxAttempts = options.retry === true ? 3 : 1;
    let lastTransientError = null;
    for (const candidate of candidates) {
      const headers = {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: candidate.token,
        "X-Url": location.href
      };
      if (candidate.bizDomain) {
        headers["X-Bizdomain"] = candidate.bizDomain;
      }

      for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
        let response;
        const controller = new AbortController();
        const timeoutId = window.setTimeout(() => controller.abort(), API_REQUEST_TIMEOUT);
        try {
          response = await fetch(`/api/${path}`, {
            method: options.method || "POST",
            headers,
            credentials: "include",
            signal: controller.signal,
            body: options.body === undefined ? undefined : JSON.stringify(options.body)
          });
        } catch (error) {
          lastTransientError = error?.name === "AbortError"
            ? new Error("پاسخ دیدار بیش از حد طول کشید؛ نتیجه عملیات از سرور بررسی می‌شود.")
            : error;
          if (attempt < maxAttempts) {
            await delay(retryDelay(attempt));
            continue;
          }
          throw lastTransientError;
        } finally {
          window.clearTimeout(timeoutId);
        }
        if (response.status === 401) {
          break;
        }
        if (response.status === 403) {
          throw didarConnectionError(
            "کاربر وارد دیدار است اما مجوز خواندن این اطلاعات را ندارد. سطح دسترسی کاربر در دیدار بررسی شود.",
            "DIDAR_PERMISSION_DENIED"
          );
        }
        if ((response.status === 429 || response.status >= 500) && attempt < maxAttempts) {
          await delay(retryDelay(attempt));
          continue;
        }
        let payload;
        try {
          payload = await response.json();
        } catch {
          const error = new Error(`پاسخ نامعتبر از دیدار دریافت شد (${response.status}).`);
          error.status = response.status;
          throw error;
        }
        if (!response.ok || payload?.Error || payload?.Message) {
          const message = Core.errorMessage(payload, `خطای ${response.status} از دیدار`);
          const transientServerError = isTransientDidarServerMessage(message);
          if (attempt < maxAttempts && transientServerError) {
            await delay(retryDelay(attempt));
            continue;
          }
          const error = new Error(transientServerError
            ? "دیدار موقتاً پاسخ معتبری نداد. چند لحظه بعد دوباره تلاش کنید."
            : message);
          error.status = response.status;
          error.endpoint = path;
          if (transientServerError) error.code = "DIDAR_TRANSIENT_SERVER_ERROR";
          throw error;
        }
        if (settings.connectionMode === "automatic") {
          preferredAutomaticToken = candidate.token;
        }
        return Core.responseNode(payload);
      }
    }

    if (lastTransientError) {
      throw lastTransientError;
    }

    const isSessionEndpoint = path.toLowerCase() === "authentication/session";
    throw didarConnectionError(
      settings.connectionMode === "manual"
        ? `توکن اتصال دستی برای درخواست «${path}» پذیرفته نشد. اتصال را روی حالت خودکار بگذارید یا توکن دستی را اصلاح کنید.`
        : isSessionEndpoint
          ? "نشست دیدار این تب منقضی یا نامعتبر است. دوباره وارد دیدار شوید و صفحه دیدار را تازه‌سازی کنید."
          : `دیدار درخواست «${path}» را با پاسخ 401 رد کرد. نشست کاربر ممکن است معتبر باشد، اما نقش او به این بخش دسترسی ندارد.`,
      isSessionEndpoint ? "DIDAR_AUTH_REQUIRED" : "DIDAR_ENDPOINT_UNAUTHORIZED",
      path
    );
  }

  async function currentIdentity(force = false) {
    if (globalThis.DidarCloudClient) return globalThis.DidarCloudClient.identity();
    const auth = credentials();
    const key = `${auth.token}:${auth.bizDomain}`;
    if (!force && cachedIdentity && cachedIdentityKey === key) {
      return cachedIdentity;
    }
    const session = await apiRequest("Authentication/session", {
      method: "GET",
      ignoreAccount: true
    });
    if (!session?.IsLoggedIn || !Core.GUID_PATTERN.test(Core.text(session.Id))) {
      throw didarConnectionError(
        "کاربر واردشده در دیدار شناسایی نشد. از حساب خارج شوید و دوباره وارد شوید.",
        "DIDAR_AUTH_REQUIRED"
      );
    }
    cachedIdentity = {
      id: session.Id,
      displayName: Core.userDisplayName(session),
      username: Core.text(session.UserName),
      bizDomain: auth.bizDomain,
      connectionMode: settings.connectionMode
    };
    const activeAuth = credentials();
    cachedIdentityKey = `${activeAuth.token}:${activeAuth.bizDomain}`;
    return cachedIdentity;
  }

  async function readActivityUntil(activityId, predicate) {
    const waits = [0, 150, 350, 700, 1200, 2000, 3200];
    let latest = null;
    for (const wait of waits) {
      if (wait) {
        await delay(wait);
      }
      latest = await apiRequest("activity/GetActivityById", {
        body: { Id: activityId },
        retry: true
      });
      if (predicate(latest)) {
        return latest;
      }
    }
    return null;
  }

  function normalizedTitle(value) {
    return Core.text(value)
      .replace(/[\u200c\u200d\u200e\u200f]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function responseList(value) {
    if (Array.isArray(value)) {
      return value;
    }
    for (const key of ["List", "Products", "Items"]) {
      if (Array.isArray(value?.[key])) {
        return value[key];
      }
    }
    return [];
  }

  function productTitleForActivity(activityTitle) {
    const title = normalizedTitle(activityTitle);
    if (!title.startsWith(PLAN_TITLE_PREFIX)) {
      return "";
    }
    const suffix = normalizedTitle(title.slice(PLAN_TITLE_PREFIX.length));
    return suffix ? `${PRODUCT_TITLE_PREFIX} ${suffix}` : "";
  }

  function globalSearchProductLabel(productTitle) {
    const title = normalizedTitle(productTitle);
    if (!title.startsWith(PRODUCT_TITLE_PREFIX)) {
      return "";
    }
    return normalizedTitle(title.slice(PRODUCT_TITLE_PREFIX.length));
  }

  function unitPriceForProduct(product, currencyId, variantId) {
    const variants = Array.isArray(product?.Variants) ? product.Variants : [];
    const variant = variantId
      ? variants.find((item) => Core.text(item.Id) === Core.text(variantId))
      : null;
    const prices = variant?.VariantPrices || product?.ProductPrices || [];
    const price = prices.find((item) => Number(item.CurrencyId) === Number(currencyId));
    return price?.Price ?? product?.UnitPrice ?? 0;
  }

  function processedProductKey(creationId) {
    return `didar-quick-checklist:product:${Core.text(creationId).toLowerCase()}`;
  }

  function productActivityMapKey(dealId, activityId) {
    return `${Core.text(dealId).toLowerCase()}:${Core.text(activityId).toLowerCase()}`;
  }

  function productDraftKey(dealId, activityId) {
    return [
      Core.text(credentials().bizDomain).toLowerCase(),
      Core.text(dealId).toLowerCase(),
      Core.text(activityId).toLowerCase()
    ].join(":");
  }

  function readProductDraft(dealId, activityId) {
    try {
      const drafts = JSON.parse(sessionStorage.getItem(PRODUCT_DRAFTS_KEY) || "{}");
      return drafts[productDraftKey(dealId, activityId)] || null;
    } catch {
      return null;
    }
  }

  function writeProductDraft(fields) {
    const dealId = Core.text(fields?.dataset?.dealId).toLowerCase();
    const activityId = Core.text(fields?.dataset?.activityId).toLowerCase();
    if (!Core.GUID_PATTERN.test(dealId) || !Core.GUID_PATTERN.test(activityId)) {
      return;
    }
    try {
      const drafts = JSON.parse(sessionStorage.getItem(PRODUCT_DRAFTS_KEY) || "{}");
      drafts[productDraftKey(dealId, activityId)] = {
        description: fields.querySelector(".didar-plan-product-description")?.value || "",
        unitPrice: fields.querySelector(".didar-plan-product-unit-price")?.value || "",
        dealProductId: fields.dataset.dealProductId,
        baseDescription: fields.dataset.baseDescription,
        baseUnitPrice: fields.dataset.baseUnitPrice,
        updatedAt: Date.now()
      };
      sessionStorage.setItem(PRODUCT_DRAFTS_KEY, JSON.stringify(drafts));
    } catch {
      // The visible form still keeps the draft until navigation.
    }
  }

  function clearProductDraft(dealId, activityId) {
    try {
      const drafts = JSON.parse(sessionStorage.getItem(PRODUCT_DRAFTS_KEY) || "{}");
      delete drafts[productDraftKey(dealId, activityId)];
      sessionStorage.setItem(PRODUCT_DRAFTS_KEY, JSON.stringify(drafts));
    } catch {
      // A confirmed server save is not failed by unavailable session storage.
    }
  }

  function loadProductActivityMappings() {
    try {
      const stored = JSON.parse(localStorage.getItem(PRODUCT_ACTIVITY_MAP_KEY) || "{}");
      Object.entries(stored).forEach(([key, value]) => {
        if (value && typeof value === "object") {
          productActivityMappings.set(key, value);
        }
      });
    } catch {
      try {
        localStorage.removeItem(PRODUCT_ACTIVITY_MAP_KEY);
      } catch {
        // The in-memory map still works when site storage is unavailable.
      }
    }
  }

  function persistProductActivityMappings() {
    const entries = Array.from(productActivityMappings.entries());
    entries.slice(0, Math.max(0, entries.length - 1000)).forEach(([key]) => {
      productActivityMappings.delete(key);
    });
    try {
      localStorage.setItem(
        PRODUCT_ACTIVITY_MAP_KEY,
        JSON.stringify(Object.fromEntries(productActivityMappings.entries()))
      );
    } catch {
      // Saving the product itself must not fail because browser storage is full or blocked.
    }
  }

  function normalizeOutboxRecords(value) {
    const records = Array.isArray(value) ? value : [];
    return records.filter((record) =>
      record &&
      typeof record === "object" &&
      Core.text(record.id)
    );
  }

  async function readOutboxRecords() {
    let extensionRecords = [];
    try {
      if (chrome?.storage?.local?.get) {
        const stored = await chrome.storage.local.get({ [SAVE_OUTBOX_KEY]: [] });
        extensionRecords = normalizeOutboxRecords(stored?.[SAVE_OUTBOX_KEY]);
      }
    } catch {
      extensionRecords = [];
    }
    let fallbackRecords = [];
    try {
      fallbackRecords = normalizeOutboxRecords(
        JSON.parse(localStorage.getItem(SAVE_OUTBOX_FALLBACK_KEY) || "[]")
      );
    } catch {
      fallbackRecords = [];
    }
    const merged = new Map();
    [...extensionRecords, ...fallbackRecords].forEach((record) => {
      const previous = merged.get(record.id);
      if (!previous || Number(record.updatedAt || 0) >= Number(previous.updatedAt || 0)) {
        merged.set(record.id, record);
      }
    });
    return Array.from(merged.values());
  }

  async function writeOutboxRecords(records) {
    const normalized = normalizeOutboxRecords(records);
    let stored = false;
    try {
      localStorage.setItem(SAVE_OUTBOX_FALLBACK_KEY, JSON.stringify(normalized));
      stored = true;
    } catch {
      // Extension storage below can still provide the durable copy.
    }
    try {
      if (chrome?.storage?.local?.set) {
        await chrome.storage.local.set({ [SAVE_OUTBOX_KEY]: normalized });
        stored = true;
      }
    } catch {
      // The site-storage fallback may already contain the operation.
    }
    if (!stored) {
      throw new Error("ذخیره محلی درخواست انجام نشد؛ فضای ذخیره‌سازی مرورگر را بررسی کنید.");
    }
  }

  function withOperationLock(name, operation) {
    if (navigator?.locks?.request) {
      // Firefox calls the lock callback from the page realm. Returning the
      // content-script Promise directly raises Permission denied ... "then".
      // Keep values/errors private and let a page Promise hold only the lock.
      let value;
      let failure;
      let failed = false;
      const callback = () => {
        const bridge = new window.Promise((release) => {
          Promise.resolve().then(operation).then((result) => {
            value = result;
            release();
          }, (error) => {
            failure = error;
            failed = true;
            release();
          });
        });
        return bridge.wrappedJSObject || bridge;
      };
      const lockCallback = typeof exportFunction === "function" ? exportFunction(callback, window) : callback;
      const held = navigator.locks.request(`didar-quick-checklist:${name}`, lockCallback);
      return Promise.resolve(held).then(() => {
        if (failed) throw failure;
        return value;
      });
    }
    const previous = fallbackOperationLocks.get(name) || Promise.resolve();
    const queued = previous.then(operation);
    const settled = queued.catch(() => {});
    fallbackOperationLocks.set(name, settled);
    void settled.finally(() => {
      if (fallbackOperationLocks.get(name) === settled) {
        fallbackOperationLocks.delete(name);
      }
    });
    return queued;
  }

  function mutateOutbox(mutator) {
    return withOperationLock("outbox", async () => {
      const records = await readOutboxRecords();
      const next = await mutator(records);
      await writeOutboxRecords(next || records);
      return next || records;
    });
  }

  function prepareDurableOperation(operation) {
    if (Core.text(operation?.revision)) {
      return operation;
    }
    durableOperationSequence += 1;
    const queuedAt = Date.now();
    return {
      ...operation,
      accountKey: Core.text(credentials().bizDomain).toLowerCase(),
      revision: `${queuedAt}-${durableOperationSequence}-${Math.random().toString(36).slice(2, 10)}`,
      queuedAt
    };
  }

  async function putOutboxOperation(operation) {
    const prepared = prepareDurableOperation(operation);
    const now = Date.now();
    await mutateOutbox((records) => {
      const previous = records.find((record) => record.id === prepared.id);
      if (previous && Number(previous.queuedAt || 0) > Number(prepared.queuedAt || 0)) {
        return records;
      }
      return [
        ...records.filter((record) => record.id !== prepared.id),
        {
          ...previous,
          ...prepared,
          createdAt: previous?.createdAt || now,
          updatedAt: now,
          attempts: Number(previous?.attempts || 0),
          lastError: ""
        }
      ];
    });
    return prepared;
  }

  function removeOutboxOperation(operationId, revision = "") {
    return mutateOutbox((records) => records.filter((record) =>
      record.id !== operationId || (revision && record.revision !== revision)
    ));
  }

  function markOutboxOperationFailed(operationId, revision, error) {
    return mutateOutbox((records) => records.map((record) =>
      record.id === operationId && (!revision || record.revision === revision)
        ? {
          ...record,
          updatedAt: Date.now(),
          attempts: Number(record.attempts || 0) + 1,
          lastError: Core.text(error?.message || error)
        }
        : record
    ));
  }

  async function runDurableOperation(operation, task, options = {}) {
    const prepared = options.staged === true && Core.text(operation?.revision)
      ? operation
      : await putOutboxOperation(operation);
    return withOperationLock(prepared.lockName || `operation:${prepared.id}`, async () => {
      const pending = (await readOutboxRecords()).find((record) =>
        record.id === prepared.id && record.revision === prepared.revision
      );
      if (!pending) {
        return null;
      }
      try {
        const result = await task(pending);
        await removeOutboxOperation(prepared.id, prepared.revision);
        return result;
      } catch (error) {
        await markOutboxOperationFailed(prepared.id, prepared.revision, error);
        throw error;
      }
    });
  }

  function rememberActivityProduct(dealId, activityId, item, ordinal = 0) {
    if (!Core.GUID_PATTERN.test(Core.text(activityId)) || !item) {
      return;
    }
    const key = productActivityMapKey(dealId, activityId);
    productActivityMappings.delete(key);
    productActivityMappings.set(key, {
      dealProductId: Core.text(item.Id).toLowerCase(),
      productId: Core.text(item.ProductId || item.Id).toLowerCase(),
      variantId: Core.text(item.VariantId).toLowerCase(),
      productTitle: normalizedTitle(item.Title),
      ordinal: Math.max(0, Number(ordinal) || 0),
      updatedAt: new Date().toISOString()
    });
    persistProductActivityMappings();
  }

  function mappedProductItem(deal, mapping) {
    const items = Array.isArray(deal?.Items) ? deal.Items : [];
    const dealProductId = Core.text(mapping?.dealProductId).toLowerCase();
    if (dealProductId && dealProductId !== EMPTY_GUID) {
      const exact = items.find((item) => Core.text(item.Id).toLowerCase() === dealProductId);
      if (exact) {
        return exact;
      }
      const mappedVariantId = Core.text(mapping?.variantId).toLowerCase();
      if (!mappedVariantId) {
        return null;
      }
      const productId = Core.text(mapping?.productId).toLowerCase();
      const variantMatches = items.filter((item) =>
        Core.text(item.VariantId).toLowerCase() === mappedVariantId &&
        (!productId || Core.text(item.ProductId || item.Id).toLowerCase() === productId)
      );
      return variantMatches.length === 1 ? variantMatches[0] : null;
    }
    const matching = items.filter((item) => {
      const productId = Core.text(item.ProductId || item.Id).toLowerCase();
      return mapping?.productId
        ? productId === Core.text(mapping.productId).toLowerCase()
        : normalizedTitle(item.Title) === normalizedTitle(mapping?.productTitle);
    });
    return matching[Math.max(0, Number(mapping?.ordinal) || 0)] || null;
  }

  function syncOpenDealView(deal, options = {}) {
    productSyncSequence += 1;
    const requestId = `${Date.now()}-${productSyncSequence}`;
    return new Promise((resolve) => {
      let settled = false;
      const marker = document.createElement("meta");
      marker.hidden = true;
      marker.dataset.didarProductSyncRequest = requestId;
      marker.textContent = JSON.stringify({
        requestId,
        dealId: deal.Id,
        items: Core.cloneJson(deal.Items || []),
        adjustment: deal.Adjustment,
        estimatedPrice: deal.EstimatedPrice,
        requireProductEditor: Boolean(options.requireProductEditor),
        waitForView: options.waitForView !== false
      });
      const finish = (synced) => {
        if (settled) {
          return;
        }
        settled = true;
        marker.removeEventListener(DEAL_PRODUCTS_SYNCED_EVENT, handleSynced);
        window.clearTimeout(timeoutId);
        marker.remove();
        resolve(Boolean(synced));
      };
      const handleSynced = () => {
        finish(marker.dataset.didarProductSyncResult === "true");
      };
      marker.addEventListener(DEAL_PRODUCTS_SYNCED_EVENT, handleSynced);
      const timeoutId = window.setTimeout(() => finish(false), options.waitForView === false ? 0 : 3200);
      document.documentElement.appendChild(marker);
      marker.dispatchEvent(new Event(DEAL_PRODUCTS_UPDATED_EVENT, { bubbles: true }));
    });
  }

  function delay(milliseconds) {
    return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
  }

  async function waitForElement(find, timeout = 1800, interval = 40) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const element = find();
      if (element) {
        return element;
      }
      await delay(interval);
    }
    return null;
  }

  function normalizedUiText(value) {
    return normalizedTitle(value)
      .replace(/[يى]/g, "\u06cc")
      .replace(/ك/g, "\u06a9")
      .replace(/[أإ]/g, "\u0627");
  }

  function findProductAction() {
    const host = document.querySelector("lc-deal-details") || document;
    return Array.from(host.querySelectorAll("span, a, button"))
      .filter((element) => !element.closest("add-product"))
      .map((element) => ({ element, text: normalizedUiText(element.textContent) }))
      .filter(({ text }) => text.includes("\u0645\u062d\u0635\u0648\u0644") && (text.includes("\u0627\u0641\u0632\u0648\u062f\u0646") || text.includes("\u0648\u06cc\u0631\u0627\u06cc\u0634")))
      .sort((left, right) => left.text.length - right.text.length)[0]?.element || null;
  }

  function currentDealId() {
    return Core.text(location.pathname.match(/\/deal\/([0-9a-f-]{36})/i)?.[1]).toLowerCase();
  }

  function currentCaseId() {
    return Core.text(location.pathname.match(/\/case\/([0-9a-f-]{36})/i)?.[1]).toLowerCase();
  }

  async function createCompletedCaseCall(type, caseId) {
    const [identity, card, history] = await Promise.all([
      currentIdentity(true), apiRequest("case/GetCaseDetail", { body: { Id: caseId }, retry: true }),
      apiRequest("activity/GetDetailActivities", { body: { CaseId: caseId }, retry: true })
    ]);
    if (Core.text(card?.Id).toLowerCase() !== caseId || card.IsDeleted === true || currentCaseId() !== caseId) {
      throw new Error("کارت انتخاب‌شده تغییر کرده یا در دسترس نیست.");
    }
    const list = (value) => [...(value?.Done || []), ...(value?.Planned || []), ...(value?.Pinned || [])];
    const before = new Set(list(history).map((item) => Core.text(item.Id).toLowerCase()));
    const template = CallChecklists.templateForKey(type.key, settings.callChecklistTemplates);
    const resultNote = CallChecklists.ensure("", template);
    const now = new Date().toISOString();
    const contacts = [...new Set([card.PersonId, card.Person?.Id, card.CompanyId, card.Company?.Id]
      .map((id) => Core.text(id).toLowerCase()).filter((id) => Core.GUID_PATTERN.test(id) && id !== EMPTY_GUID))];
    const dealId = Core.text(card.DealId || card.Deal?.Id).toLowerCase();
    const activity = {
      Id: EMPTY_GUID, ActivityGroupId: EMPTY_GUID, ActivityGroupType: "Default", ActivityTicketStatus: "NotAnswered",
      ActivityTypeId: type.id, CaseId: caseId, DealId: Core.GUID_PATTERN.test(dealId) ? dealId : EMPTY_GUID,
      Title: type.title, Note: "", ResultNote: resultNote, IsDone: true, IsDeleted: false,
      OwnerId: identity.id, CreatorId: identity.id, UpdaterId: identity.id,
      StartDate: now, DueDate: now, OriginalDueDate: now, DoneDate: now, FinishDate: now,
      RecurrenceEndDate: now, DueDateType: "Default", DoneDateType: "Default", Duration: type.duration || 5,
      RecurrenceType: "OneTime", RecurrenceData: 0, RecurrenceCount: 1, FeedbackType: "Neutral",
      IsAttended: false, IsKeepInTouch: false, IsPinned: false, IsPrivate: false, IsTicket: false,
      Contacts: contacts.map((contactId) => ({ ActivityId: EMPTY_GUID, ContactId: contactId, Message: "", Status: "Accepted" })),
      Users: [], Notifies: [], Attachments: [], Comments: [], Tags: []
    };
    let saved;
    let saveError;
    // Never resend a write after a timeout; first look for its confirmed result.
    try { saved = await apiRequest("activity/SaveActivity", { body: { Activity: activity, NewAttachments: [], SetDone: true } }); }
    catch (error) { saveError = error; }
    const savedId = Core.text(saved?.Id || saved?.Activity?.Id).toLowerCase();
    const matches = (item) => Core.GUID_PATTERN.test(Core.text(item?.Id)) && !item.IsDeleted && item.IsDone === true &&
      Core.text(item.CaseId).toLowerCase() === caseId && Core.text(item.ActivityTypeId).toLowerCase() === type.id &&
      Core.text(item.OwnerId).toLowerCase() === Core.text(identity.id).toLowerCase() &&
      normalizedTitle(item.Title) === type.title && checklistMatches(item.ResultNote || "", resultNote);
    for (const pause of [0, 200, 500, 900]) {
      if (pause) await delay(pause);
      try {
        if (Core.GUID_PATTERN.test(savedId) && savedId !== EMPTY_GUID) {
          const verified = await apiRequest("activity/GetActivityById", { body: { Id: savedId }, retry: true });
          if (matches(verified)) return verified;
        } else {
          const latest = await apiRequest("activity/GetDetailActivities", { body: { CaseId: caseId }, retry: true });
          const candidates = list(latest).filter((item) => !before.has(Core.text(item.Id).toLowerCase()) && matches(item));
          if (candidates.length === 1) return candidates[0];
        }
      } catch { /* A read can be retried; a write cannot. */ }
    }
    throw new Error(saveError?.message || "ثبت تماس از سرور تأیید نشد؛ پیش از تلاش دوباره تاریخچهٔ کارت را بررسی کنید.");
  }

  async function runCaseCallShortcut(type) {
    const caseId = currentCaseId();
    const key = `${caseId}:${type.id}`;
    if (!Core.GUID_PATTERN.test(caseId) || activeCaseCalls.has(key)) return;
    activeCaseCalls.add(key); caseCallNotice = "در حال ثبت تماس تکمیل‌شده...";
    renderCaseCallShortcuts();
    try {
      const activity = await createCompletedCaseCall(type, caseId);
      knownCaseCallCreations.add(key);
      const success = `«${type.title}» تکمیل‌شده ثبت شد.`;
      if (currentCaseId() === caseId) {
        caseCallNotice = success;
        const marker = document.createElement("meta");
        marker.dataset.didarCaseCallCreated = JSON.stringify({ caseId, activity });
        document.documentElement.append(marker);
        marker.dispatchEvent(new Event("didar-quick-checklist:case-call-created", { bubbles: true }));
        marker.remove();
      }
      toast(success, "success");
    } catch (error) {
      const message = error?.message || "ثبت تماس انجام نشد.";
      if (currentCaseId() === caseId) caseCallNotice = message;
      toast(message, "error");
    } finally { activeCaseCalls.delete(key); renderCaseCallShortcuts(); }
  }

  function renderCaseCallShortcuts() {
    const caseId = currentCaseId();
    const host = document.querySelector("lc-activity-add-inline");
    let section = document.querySelector(".didar-case-call-actions");
    if (!settings.enabled || document.readyState === "loading" || !caseId || !host || !CallChecklists) {
      section?.remove(); return;
    }
    if (!section) {
      section = document.createElement("section"); section.className = "didar-case-call-actions";
    }
    if (host.nextElementSibling !== section) host.after(section);
    if (section.dataset.caseId !== caseId) { section.dataset.caseId = caseId; caseCallNotice = ""; }
    const signature = JSON.stringify([caseId, caseCallTypes, [...activeCaseCalls], [...knownCaseCallCreations], caseCallNotice]);
    if (section.dataset.signature === signature) return;
    section.dataset.signature = signature;
    section.replaceChildren();
    const header = document.createElement("div"); header.className = "didar-plan-quick-actions__header";
    const caption = document.createElement("strong"); caption.textContent = "ایجاد سریع تماس"; header.append(caption);
    const items = document.createElement("div"); items.className = "didar-plan-quick-actions__items";
    section.append(header, items);
    for (const definition of CallChecklists.DEFINITIONS) {
      const matches = caseCallTypes.items.filter((item) => item.key === definition.key);
      const type = matches.length === 1 ? matches[0] : null;
      const key = `${caseId}:${type?.id}`;
      const busy = activeCaseCalls.has(key);
      const created = knownCaseCallCreations.has(key);
      const button = document.createElement("button"); button.type = "button";
      button.className = "didar-plan-quick-action";
      button.classList.toggle("is-created", created);
      button.dataset.status = busy ? "busy" : created ? "created" : "available";
      button.setAttribute("aria-pressed", created ? "true" : "false");
      button.setAttribute("aria-busy", busy ? "true" : "false");
      const icon = document.createElement("span"); icon.className = "didar-plan-quick-action__icon";
      icon.setAttribute("aria-hidden", "true"); icon.textContent = busy ? "…" : created ? "✓" : "+";
      const label = document.createElement("span"); label.className = "didar-plan-quick-action__label";
      label.textContent = definition.key === "beforePurchase" ? "قبل خرید" : "بعد خرید";
      button.append(icon, label);
      button.disabled = !type || busy;
      button.title = type ? `ثبت تکمیل‌شدهٔ ${type.title} برای همین کارت` : "نوع فعالیت فعال و یکتا در دیدار پیدا نشد";
      button.addEventListener("click", () => { if (type) void runCaseCallShortcut(type); });
      items.append(button);
    }
    const status = document.createElement("span"); status.className = "didar-plan-quick-actions__status";
    status.setAttribute("role", "status");
    status.textContent = caseCallNotice || caseCallTypes.error ||
      (caseCallTypes.status === "loading" ? "در حال دریافت فعالیت‌ها..." :
        !CallChecklists.DEFINITIONS.every((definition) => caseCallTypes.items.filter((item) => item.key === definition.key).length === 1)
          ? "نوع فعالیت تماس قبل و بعد خرید باید در دیدار فعال و یکتا باشد." : "ثبت به‌صورت تکمیل‌شده");
    header.append(status);
    if (caseCallTypes.status === "error") {
      const retry = document.createElement("button"); retry.type = "button"; retry.textContent = "تلاش دوباره";
      retry.addEventListener("click", () => { caseCallTypes = { status: "idle", items: [], error: "" }; renderCaseCallShortcuts(); });
      section.append(retry);
    }
    if (caseCallTypes.status === "idle") {
      const epoch = caseCallTypesEpoch;
      caseCallTypes = { status: "loading", items: [], error: "" };
      void apiRequest("activity/GetActivityType", { body: {} }).then((value) => {
        if (epoch !== caseCallTypesEpoch) return;
        const items = responseList(value).filter((item) => item.IsDisabled !== true && item.ShowInAddTask !== false)
          .map((item) => ({ id: Core.text(item.Id).toLowerCase(), title: normalizedTitle(item.Title),
            duration: Math.max(0, Number(item.Duration) || 0), key: CallChecklists.templateForTitle(item.Title)?.key }))
          .filter((item) => item.key && Core.GUID_PATTERN.test(item.id) && item.id !== EMPTY_GUID);
        caseCallTypes = { status: "loaded", items, error: "" };
      }).catch((error) => { if (epoch === caseCallTypesEpoch) caseCallTypes = { status: "error", items: [], error: error.message }; })
        .finally(renderCaseCallShortcuts);
    }
  }

  function planActivityLabel(title) {
    const normalized = normalizedTitle(title);
    if (!normalized.startsWith(PLAN_TITLE_PREFIX)) {
      return "";
    }
    return normalizedTitle(normalized.slice(PLAN_TITLE_PREFIX.length));
  }

  function existingPlanActivityTitles() {
    const titles = new Set();
    document.querySelectorAll("lc-deal-details h2").forEach((heading) => {
      if (heading.closest(".didar-plan-quick-actions, lc-activity-detail")) {
        return;
      }
      const title = normalizedTitle(heading.textContent);
      if (title.startsWith(PLAN_TITLE_PREFIX)) {
        titles.add(title);
      }
    });
    return titles;
  }

  function sortedPlanActivityTypes(value) {
    const enabledTypes = responseList(value)
      .filter((item) => item?.IsDisabled !== true && item?.ShowInAddTask !== false)
      .map((item) => ({
        id: Core.text(item?.Id).toLowerCase(),
        title: normalizedTitle(item?.Title),
        label: planActivityLabel(item?.Title),
        duration: Math.max(0, Number(item?.Duration) || 0),
        index: Number.isFinite(Number(item?.Index)) ? Number(item.Index) : Number.MAX_SAFE_INTEGER
      }))
      .filter((item) => Core.GUID_PATTERN.test(item.id))
      .sort((left, right) => left.index - right.index || left.label.localeCompare(right.label, "fa"));
    return enabledTypes
      .map((item, nativePosition) => ({ ...item, nativePosition }))
      .filter((item) => item.label);
  }

  function loadPlanActivityTypes(force = false) {
    if (!settings.enabled || document.readyState === "loading" || !currentDealId()) {
      return;
    }
    if (!force && ["loading", "loaded", "error"].includes(planActivityTypesState.status)) {
      return;
    }
    planActivityTypesState = { status: "loading", items: [], error: "" };
    renderPlanActivityQuickActions();
    void apiRequest("activity/GetActivityType", { body: {} })
      .then((result) => {
        planActivityTypesState = {
          status: "loaded",
          items: sortedPlanActivityTypes(result),
          error: ""
        };
      })
      .catch((error) => {
        planActivityTypesState = {
          status: "error",
          items: [],
          error: error?.message || "دریافت فهرست فعالیت‌ها انجام نشد."
        };
      })
      .finally(() => renderPlanActivityQuickActions());
  }

  function isPipelinePage() {
    return !currentDealId() && /^\/deal(?:;|\/?$)/i.test(location.pathname);
  }

  function sortedPipelineActivityTypes(value) {
    return responseList(value)
      .map((item) => ({
        id: Core.text(item?.Id).toLowerCase(),
        title: normalizedTitle(item?.Title),
        disabled: item?.IsDisabled === true,
        index: Number.isFinite(Number(item?.Index)) ? Number(item.Index) : Number.MAX_SAFE_INTEGER
      }))
      .filter((item) => Core.GUID_PATTERN.test(item.id) && item.id !== EMPTY_GUID && item.title)
      .sort((left, right) =>
        Number(left.disabled) - Number(right.disabled) ||
        left.index - right.index ||
        left.title.localeCompare(right.title, "fa")
      );
  }

  function loadPipelineActivityTypes(force = false) {
    if (!settings.enabled || document.readyState === "loading" || !isPipelinePage()) {
      return;
    }
    if (!force && ["loading", "loaded"].includes(pipelineActivityTypesState.status)) {
      return;
    }
    pipelineActivityTypesState = { status: "loading", items: [], error: "" };
    renderPipelineActivityFilter();
    void apiRequest("activity/GetActivityType", { body: {} })
      .then((result) => {
        pipelineActivityTypesState = {
          status: "loaded",
          items: sortedPipelineActivityTypes(result),
          error: ""
        };
      })
      .catch((error) => {
        pipelineActivityTypesState = {
          status: "error",
          items: [],
          error: error?.message || "دریافت فهرست فعالیت‌های دیدار انجام نشد."
        };
      })
      .finally(() => renderPipelineActivityFilter());
  }

  function pipelineRefreshButton() {
    const matchesRefreshLabel = (value) => {
      const compact = normalizedUiText(value).replace(/\s+/g, "");
      return compact.includes("بروزرسانیسریعصفحه") || compact.includes("بهروزرسانیسریعصفحه");
    };
    const candidates = Array.from(document.querySelectorAll(
      "button, a, [role='button'], [tabindex], .btn, .pointer, [class*='refresh' i], lc-button, span"
    ));
    const walker = document.createTreeWalker(
      document.body || document.documentElement,
      NodeFilter.SHOW_TEXT
    );
    let textNode = walker.nextNode();
    while (textNode) {
      if (matchesRefreshLabel(textNode.nodeValue)) {
        candidates.push(textNode.parentElement);
      }
      textNode = walker.nextNode();
    }
    const label = Array.from(new Set(candidates.filter(Boolean)))
      .filter((element) => !element.closest(".didar-pipeline-activity-filter"))
      .filter((element) => matchesRefreshLabel(element.textContent))
      .sort((left, right) =>
        normalizedUiText(left.textContent).length - normalizedUiText(right.textContent).length
      )[0];
    if (!label) {
      return null;
    }
    const interactive = label.closest(
      "button, a, [role='button'], [tabindex], .btn, .pointer, [class*='refresh' i], lc-button"
    );
    if (interactive && matchesRefreshLabel(interactive.textContent)) {
      return interactive;
    }

    // Didar sometimes renders the label in a plain span inside an unnamed host.
    // One parent level reaches that host without accidentally selecting the toolbar.
    const labelText = normalizedUiText(label.textContent).replace(/\s+/g, "");
    const parent = label.parentElement;
    if (parent && parent !== document.body && /^(SPAN|STRONG|B|I|SMALL)$/.test(label.tagName)) {
      const parentText = normalizedUiText(parent.textContent).replace(/\s+/g, "");
      if (parentText === labelText && parent.children.length <= 4) {
        return parent;
      }
    }
    return label;
  }

  function publishPipelineActivityFilter(
    dealIds,
    active = selectedPipelineActivityTypes.size > 0
  ) {
    const marker = document.createElement("meta");
    marker.hidden = true;
    marker.dataset.didarPipelineActivityFilter = "true";
    marker.textContent = JSON.stringify({
      active,
      dealIds: Array.from(dealIds || [])
    });
    document.documentElement.appendChild(marker);
    marker.dispatchEvent(new Event(PIPELINE_ACTIVITY_FILTER_EVENT, { bubbles: true }));
    marker.remove();
    pipelineActivityFilterPublished = active;
  }

  async function fetchPipelineActivityDealIds(activityTypeIds) {
    const pageSize = 100;
    const maximumRows = 20000;
    const dealIds = new Set();
    let offset = 0;
    let total = Number.POSITIVE_INFINITY;
    while (offset < total && offset < maximumRows) {
      const response = await apiRequest("activity/search", {
        body: {
          FromDate: "1800-01-01T00:00:00.000Z",
          ToDate: "9999-12-28T20:30:00.000Z",
          SortType: 1,
          From: offset,
          Limit: pageSize,
          ActivityTypeIds: activityTypeIds,
          IsDeleted: false
        }
      });
      const rows = responseList(response);
      rows.forEach((activity) => {
        const dealId = Core.text(activity?.DealId || activity?.Deal?.Id).toLowerCase();
        if (Core.GUID_PATTERN.test(dealId) && dealId !== EMPTY_GUID) {
          dealIds.add(dealId);
        }
      });
      total = Number(response?.Total ?? response?.TotalCount ?? rows.length);
      offset += rows.length;
      if (!rows.length || rows.length < pageSize) {
        break;
      }
    }
    if (Number.isFinite(total) && total > maximumRows) {
      throw new Error("تعداد فعالیت‌های منطبق بیش از حد مجاز است؛ فعالیت‌های کمتری انتخاب کنید.");
    }
    return dealIds;
  }

  function refreshPipelineAfterActivityFilter() {
    const refresh = pipelineRefreshButton();
    if (!refresh) {
      throw new Error("دکمه بروزرسانی کاریز پیدا نشد.");
    }
    refresh.click();
  }

  async function applyPipelineActivityFilter() {
    pipelineActivityFilterSequence += 1;
    const sequence = pipelineActivityFilterSequence;
    const activityTypeIds = Array.from(selectedPipelineActivityTypes);
    pipelineActivityFilterState = { status: "loading", dealCount: 0, error: "" };
    renderPipelineActivityFilter();
    try {
      const dealIds = activityTypeIds.length
        ? await fetchPipelineActivityDealIds(activityTypeIds)
        : new Set();
      if (sequence !== pipelineActivityFilterSequence) {
        return;
      }
      publishPipelineActivityFilter(dealIds);
      refreshPipelineAfterActivityFilter();
      pipelineActivityFilterState = {
        status: "loaded",
        dealCount: dealIds.size,
        error: ""
      };
    } catch (error) {
      if (sequence !== pipelineActivityFilterSequence) {
        return;
      }
      publishPipelineActivityFilter(new Set(), false);
      try {
        refreshPipelineAfterActivityFilter();
      } catch {
        // The visible error below is enough when Didar has not mounted its refresh action.
      }
      pipelineActivityFilterState = {
        status: "error",
        dealCount: 0,
        error: error?.message || "فیلتر فعالیت‌ها اعمال نشد."
      };
    }
    renderPipelineActivityFilter();
  }

  function schedulePipelineActivityFilter() {
    window.clearTimeout(pipelineActivityFilterTimer);
    pipelineActivityFilterTimer = window.setTimeout(() => void applyPipelineActivityFilter(), 180);
  }

  function pipelineActivityPopover(section) {
    return section?.querySelector(".didar-pipeline-activity-filter__popover") ||
      pipelineActivityFilterPortal;
  }

  function positionPipelineActivityPopover(section) {
    const popover = pipelineActivityPopover(section);
    const trigger = section?.querySelector(".didar-pipeline-activity-filter__trigger");
    if (!popover || popover.hidden || !trigger) {
      return;
    }
    const rect = trigger.getBoundingClientRect();
    const viewportWidth = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
    const width = Math.min(Math.max(rect.width, 320), Math.max(220, viewportWidth - 16));
    const left = Math.min(
      Math.max(8, rect.right - width),
      Math.max(8, viewportWidth - width - 8)
    );
    popover.style.width = `${width}px`;
    popover.style.left = `${left}px`;
    popover.style.top = `${Math.max(8, rect.bottom + 7)}px`;
  }

  function closePipelineActivityPopover(section) {
    const popover = pipelineActivityPopover(section);
    const trigger = section?.querySelector(".didar-pipeline-activity-filter__trigger");
    if (!popover) {
      return;
    }
    popover.hidden = true;
    popover.classList.remove("is-portaled");
    popover.removeAttribute("style");
    if (section?.isConnected) {
      section.appendChild(popover);
    }
    trigger?.setAttribute("aria-expanded", "false");
  }

  function openPipelineActivityPopover(section) {
    const popover = pipelineActivityPopover(section);
    const trigger = section?.querySelector(".didar-pipeline-activity-filter__trigger");
    if (!popover || !trigger || !document.body) {
      return;
    }
    pipelineActivityFilterPortal = popover;
    document.body.appendChild(popover);
    popover.classList.add("is-portaled");
    popover.hidden = false;
    trigger.setAttribute("aria-expanded", "true");
    positionPipelineActivityPopover(section);
    popover.querySelector("input[type='search']")?.focus();
  }

  function pipelineActivityFilterSection() {
    const refresh = pipelineRefreshButton();
    if (!refresh?.parentElement) {
      return null;
    }
    let section = document.querySelector(".didar-pipeline-activity-filter");
    if (!section) {
      section = document.createElement("section");
      section.className = "didar-pipeline-activity-filter";
      section.setAttribute("dir", "rtl");
      section.innerHTML =
        '<button class="didar-pipeline-activity-filter__trigger" type="button" aria-expanded="false">' +
          '<span class="didar-pipeline-activity-filter__trigger-label">فیلتر فعالیت‌ها</span>' +
          '<span class="didar-pipeline-activity-filter__count" hidden></span>' +
          '<span class="didar-pipeline-activity-filter__chevron" aria-hidden="true">⌄</span>' +
        '</button>' +
        '<div class="didar-pipeline-activity-filter__popover" hidden>' +
          '<label class="didar-pipeline-activity-filter__search">' +
            '<span aria-hidden="true">⌕</span>' +
            '<input type="search" placeholder="جستجوی فعالیت" autocomplete="off">' +
          '</label>' +
          '<div class="didar-pipeline-activity-filter__options" role="listbox" aria-multiselectable="true"></div>' +
          '<div class="didar-pipeline-activity-filter__footer">' +
            '<span class="didar-pipeline-activity-filter__status" role="status"></span>' +
            '<button class="didar-pipeline-activity-filter__clear" type="button">پاک کردن</button>' +
          '</div>' +
        '</div>';
      const trigger = section.querySelector(".didar-pipeline-activity-filter__trigger");
      const popover = section.querySelector(".didar-pipeline-activity-filter__popover");
      const search = popover.querySelector("input[type='search']");
      pipelineActivityFilterPortal = popover;
      trigger.addEventListener("click", () => {
        if (popover.hidden) {
          openPipelineActivityPopover(section);
        } else {
          closePipelineActivityPopover(section);
        }
      });
      search.addEventListener("input", () => renderPipelineActivityFilterOptions(section));
      popover.querySelector(".didar-pipeline-activity-filter__clear").addEventListener("click", () => {
        selectedPipelineActivityTypes.clear();
        renderPipelineActivityFilter();
        schedulePipelineActivityFilter();
      });
      refresh.parentElement.insertBefore(section, refresh);
    } else if (section.parentElement !== refresh.parentElement) {
      refresh.parentElement.insertBefore(section, refresh);
    }
    return section;
  }

  function renderPipelineActivityFilterOptions(section) {
    const popover = pipelineActivityPopover(section);
    const host = popover?.querySelector(".didar-pipeline-activity-filter__options");
    if (!host) {
      return;
    }
    const query = normalizedTitle(popover.querySelector("input[type='search']")?.value).toLowerCase();
    const items = pipelineActivityTypesState.items.filter((item) =>
      !query || item.title.toLowerCase().includes(query)
    );
    const signature = JSON.stringify([
      query,
      items.map((item) => [item.id, item.title, item.disabled]),
      Array.from(selectedPipelineActivityTypes).sort()
    ]);
    if (host.dataset.renderSignature === signature) {
      return;
    }
    host.dataset.renderSignature = signature;
    host.replaceChildren();
    items.forEach((item) => {
      const label = document.createElement("label");
      label.className = "didar-pipeline-activity-filter__option";
      label.classList.toggle("is-legacy", item.disabled);
      const input = document.createElement("input");
      input.type = "checkbox";
      input.value = item.id;
      input.checked = selectedPipelineActivityTypes.has(item.id);
      input.addEventListener("change", () => {
        if (input.checked) {
          selectedPipelineActivityTypes.add(item.id);
        } else {
          selectedPipelineActivityTypes.delete(item.id);
        }
        renderPipelineActivityFilter();
        schedulePipelineActivityFilter();
      });
      const text = document.createElement("span");
      text.textContent = item.title;
      label.append(input, text);
      host.appendChild(label);
    });
    if (!items.length) {
      const empty = document.createElement("p");
      empty.className = "didar-pipeline-activity-filter__empty";
      empty.textContent = "فعالیتی پیدا نشد";
      host.appendChild(empty);
    }
  }

  function renderPipelineActivityFilter() {
    const section = pipelineActivityFilterSection();
    if (!section) {
      return;
    }
    const selectedCount = selectedPipelineActivityTypes.size;
    const count = section.querySelector(".didar-pipeline-activity-filter__count");
    const status = pipelineActivityPopover(section)?.querySelector(
      ".didar-pipeline-activity-filter__status"
    );
    if (!count || !status) {
      return;
    }
    section.dataset.state = pipelineActivityFilterState.status;
    section.classList.toggle("has-selection", selectedCount > 0);
    count.hidden = selectedCount === 0;
    count.textContent = localizedNumber(selectedCount);
    if (pipelineActivityTypesState.status === "loading") {
      status.textContent = "در حال دریافت فعالیت‌ها...";
    } else if (pipelineActivityTypesState.status === "error") {
      status.textContent = pipelineActivityTypesState.error;
    } else if (pipelineActivityFilterState.status === "loading") {
      status.textContent = "در حال اعمال فیلتر...";
    } else if (pipelineActivityFilterState.status === "error") {
      status.textContent = pipelineActivityFilterState.error;
    } else if (selectedCount) {
      status.textContent = "فیلتر اعمال شد";
    } else {
      status.textContent = "";
    }
    renderPipelineActivityFilterOptions(section);
  }

  function enhancePipelineActivityFilter() {
    if (!settings.enabled || document.readyState === "loading" || !isPipelinePage()) {
      document.querySelectorAll(".didar-pipeline-activity-filter").forEach((section) => {
        closePipelineActivityPopover(section);
        section.remove();
      });
      pipelineActivityFilterPortal?.remove();
      pipelineActivityFilterPortal = null;
      if (pipelineActivityFilterPublished) {
        selectedPipelineActivityTypes.clear();
        publishPipelineActivityFilter(new Set());
      }
      return;
    }
    renderPipelineActivityFilter();
    loadPipelineActivityTypes();
  }

  function requestCreatedActivityRefresh(dealId, activity) {
    activitySyncSequence += 1;
    const requestId = `created-${Date.now()}-${activitySyncSequence}`;
    const marker = document.createElement("meta");
    marker.hidden = true;
    marker.dataset.didarActivityCreatedRefreshRequest = requestId;
    marker.textContent = JSON.stringify({ requestId, dealId, activity });
    document.documentElement.appendChild(marker);
    return new Promise((resolve) => {
      const timeoutId = window.setTimeout(() => {
        marker.remove();
        resolve(false);
      }, 1400);
      marker.addEventListener(
        ACTIVITY_CREATED_REFRESHED_EVENT,
        () => {
          window.clearTimeout(timeoutId);
          const refreshed = marker.dataset.didarActivityCreatedRefreshResult === "true";
          marker.remove();
          resolve(refreshed);
        },
        { once: true }
      );
      marker.dispatchEvent(new Event(ACTIVITY_CREATED_REFRESH_EVENT, { bubbles: true }));
    });
  }

  function plannedActivityHost() {
    const hosts = Array.from(
      document.querySelectorAll("lc-deal-details lc-activity-list-brief")
    );
    return hosts.find((host) => host.querySelector(".activity-planned-list")) || hosts[0] || null;
  }

  function completedActivityHost() {
    const plannedHost = plannedActivityHost();
    const hosts = Array.from(
      document.querySelectorAll("lc-deal-details lc-activity-list-brief")
    ).filter((host) => host !== plannedHost && !host.closest("lc-activity-detail"));
    return hosts.find((host) => host.querySelector(".activity-main-list")) || hosts.at(-1) || null;
  }

  function waitForNativePlanActivityCreated(dealId, title, timeout = 15000) {
    let cancel = () => {};
    const promise = new Promise((resolve, reject) => {
      let settled = false;
      const finish = (value) => {
        if (settled) {
          return;
        }
        settled = true;
        window.clearTimeout(timeoutId);
        document.removeEventListener(PLAN_ACTIVITY_CREATED_EVENT, handleCreated);
        resolve(value);
      };
      const timeoutId = window.setTimeout(() => {
        settled = true;
        document.removeEventListener(PLAN_ACTIVITY_CREATED_EVENT, handleCreated);
        reject(new Error("دیدار ایجاد فعالیت را در زمان مورد انتظار تأیید نکرد."));
      }, timeout);
      const handleCreated = (event) => {
        const detail = event.detail || {};
        if (
          Core.text(detail.dealId).toLowerCase() !== dealId ||
          normalizedTitle(detail.title) !== normalizedTitle(title)
        ) {
          return;
        }
        finish(detail);
      };
      cancel = () => finish(null);
      document.addEventListener(PLAN_ACTIVITY_CREATED_EVENT, handleCreated);
    });
    return { promise, cancel };
  }

  function startNativeQuickActivity(type, dealId) {
    activitySyncSequence += 1;
    const requestId = `quick-native-${Date.now()}-${activitySyncSequence}`;
    const marker = document.createElement("meta");
    marker.hidden = true;
    marker.dataset.didarNativeQuickActivityRequest = requestId;
    marker.textContent = JSON.stringify({
      requestId,
      dealId,
      activityTypeId: type.id,
      title: type.title
    });
    document.documentElement.appendChild(marker);
    return new Promise((resolve) => {
      const finish = (started) => {
        window.clearTimeout(timeoutId);
        marker.remove();
        resolve(Boolean(started));
      };
      const timeoutId = window.setTimeout(() => finish(false), 3800);
      marker.addEventListener(
        NATIVE_QUICK_ACTIVITY_STARTED_EVENT,
        () => finish(marker.dataset.didarNativeQuickActivityResult === "true"),
        { once: true }
      );
      marker.dispatchEvent(new Event(NATIVE_QUICK_ACTIVITY_CREATE_EVENT, { bubbles: true }));
    });
  }

  function nativeAddActivityLaunchers() {
    const dealDetails = document.querySelector("lc-deal-details");
    const searchRoot = dealDetails || document;
    const candidates = [];
    const seen = new Set();
    const addCandidate = (element) => {
      if (
        !element ||
        seen.has(element) ||
        typeof element.click !== "function" ||
        element.closest(".didar-plan-quick-actions") ||
        element.closest("lc-activity-add, lc-activity-detail") ||
        element.matches(":disabled, [aria-disabled='true']")
      ) {
        return;
      }
      seen.add(element);
      candidates.push(element);
    };

    // The deal page uses the inline activity tab, while the activities page uses a popup button.
    [
      searchRoot.querySelector("lc-activity-add-inline [tab-name='activity']"),
      searchRoot.querySelector("#tour-add-activity-button"),
      searchRoot.querySelector("[lc-popup='lc-activity-add']"),
      document.querySelector("#tour-add-activity-button"),
      document.querySelector("[lc-popup='lc-activity-add']")
    ].forEach(addCandidate);

    const clickableSelector =
      "button, a, [role='button'], [tab-name], [lc-popup], [lc-popup-click], .btn, .pointer";
    Array.from(searchRoot.querySelectorAll(clickableSelector)).forEach((element) => {
      const label = normalizedTitle(element.textContent);
      if (label === "افزودن فعالیت جدید" || label === "افزودن فعالیت") {
        addCandidate(element);
      }
    });
    return candidates;
  }

  function setNativeInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value"
    )?.set;
    if (setter) {
      setter.call(input, value);
    } else {
      input.value = value;
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function nativeActivityTypeControl(popup, type) {
    const labeledControl = Array.from(
      popup.querySelectorAll("li[title], li[didartooltip], [role='option'][title]")
    ).find((element) => {
      const label = element.getAttribute("title") || element.getAttribute("didartooltip");
      return normalizedTitle(label) === normalizedTitle(type.title);
    });
    if (labeledControl) {
      return labeledControl;
    }

    const iconControls = Array.from(popup.querySelectorAll(".activity-icons-list li"));
    return Number.isInteger(type.nativePosition)
      ? iconControls[type.nativePosition] || null
      : null;
  }

  function nativeActivitySaveControl(popup) {
    const buttons = Array.from(popup.querySelectorAll("button"));
    return buttons.find(
      (button) =>
        normalizedTitle(button.textContent) === "ذخیره" &&
        !button.disabled &&
        button.getAttribute("aria-disabled") !== "true"
    ) || null;
  }

  async function submitNativeQuickActivityForm(popup, type) {
    const typeControl = await waitForElement(
      () => nativeActivityTypeControl(popup, type),
      4500
    );
    if (!typeControl) {
      return false;
    }
    typeControl.click();

    const titleInput = await waitForElement(() => {
      const inputs = Array.from(popup.querySelectorAll("input[type='text']"));
      return inputs.find((input) => normalizedTitle(input.value) === normalizedTitle(type.title)) ||
        inputs.find((input) => input.required || input.classList.contains("form-control")) ||
        inputs[0] ||
        null;
    }, 1800);
    if (titleInput && normalizedTitle(titleInput.value) !== normalizedTitle(type.title)) {
      setNativeInputValue(titleInput, type.title);
    }

    const saveButton = await waitForElement(
      () => nativeActivitySaveControl(popup),
      2400
    );
    if (!saveButton) {
      return false;
    }
    saveButton.click();
    return true;
  }

  function nativeActivityFormForLauncher(launcher, previousForms) {
    const inlineHost = launcher.closest("lc-activity-add-inline");
    if (inlineHost) {
      const inlineForms = Array.from(inlineHost.querySelectorAll("lc-activity-add"));
      if (inlineForms.length) {
        return inlineForms.at(-1);
      }
    }
    const forms = Array.from(document.querySelectorAll("lc-activity-add"));
    return forms.find((form) => !previousForms.has(form)) || null;
  }

  async function openNativeQuickActivity(type, dealId) {
    const launchers = nativeAddActivityLaunchers();
    if (!launchers.length) {
      throw new Error("دکمه اصلی افزودن فعالیت دیدار در این صفحه پیدا نشد.");
    }
    let popup = null;
    let hiddenInlineHost = null;
    try {
      for (const launcher of launchers) {
        const inlineHost = launcher.closest("lc-activity-add-inline");
        if (hiddenInlineHost && hiddenInlineHost !== inlineHost) {
          hiddenInlineHost.classList.remove("didar-native-quick-activity-running");
        }
        hiddenInlineHost = inlineHost;
        hiddenInlineHost?.classList.add("didar-native-quick-activity-running");

        const previousForms = new Set(document.querySelectorAll("lc-activity-add"));
        launcher.click();
        popup = await waitForElement(
          () => nativeActivityFormForLauncher(launcher, previousForms),
          2400
        );
        if (popup) {
          break;
        }
      }
      if (!popup) {
        throw new Error("فرم اصلی ایجاد فعالیت دیدار باز نشد.");
      }
      const created = waitForNativePlanActivityCreated(dealId, type.title);
      const startedFromForm = await submitNativeQuickActivityForm(popup, type);
      const startedFromController = startedFromForm
        ? false
        : await startNativeQuickActivity(type, dealId);
      if (!startedFromForm && !startedFromController) {
        created.cancel();
        throw new Error(
          "فرم دیدار باز شد اما ذخیره خودکار آماده نشد؛ فرم برای ادامه دستی باز مانده است."
        );
      }
      return await created.promise;
    } finally {
      hiddenInlineHost?.classList.remove("didar-native-quick-activity-running");
    }
  }

  async function createQuickPlanActivity(type) {
    const dealId = currentDealId();
    const operationKey = `${dealId}:${type.id}`;
    if (!Core.GUID_PATTERN.test(dealId) || activeQuickPlanCreations.has(operationKey)) {
      return;
    }
    activeQuickPlanCreations.add(operationKey);
    renderPlanActivityQuickActions();
    try {
      const created = await openNativeQuickActivity(type, dealId);
      const activityId = Core.text(created?.activityId).toLowerCase();
      knownQuickPlanCreations.add(operationKey);
      if (!Core.GUID_PATTERN.test(activityId)) {
        throw new Error("دیدار فعالیت را ایجاد کرد اما شناسه معتبر برنگرداند.");
      }
      lastInteraction = `فعالیت «${type.label}» با میانبر ساخته شد`;
      toast(`فعالیت «${type.label}» ایجاد شد`, "success");
    } catch (error) {
      lastInteraction = `خطای ساخت سریع فعالیت: ${error?.message || "عملیات انجام نشد"}`;
      toast(error?.message || "ایجاد فعالیت انجام نشد.", "error");
    } finally {
      activeQuickPlanCreations.delete(operationKey);
      renderPlanActivityQuickActions();
    }
  }

  function quickActionSection() {
    const details = document.querySelector("lc-deal-details");
    const activityList = details?.querySelector("lc-activity-list-brief");
    if (!details || !activityList) {
      return null;
    }
    let section = details.querySelector(".didar-plan-quick-actions");
    if (!section) {
      section = document.createElement("section");
      section.className = "didar-plan-quick-actions";
      section.setAttribute("dir", "rtl");
      section.innerHTML =
        '<div class="didar-plan-quick-actions__header">' +
          '<strong>ایجاد سریع فعالیت</strong>' +
          '<span class="didar-plan-quick-actions__status" role="status"></span>' +
        '</div>' +
        '<div class="didar-plan-quick-actions__items"></div>';
      activityList.before(section);
    }
    return section;
  }

  function renderPlanActivityQuickActions() {
    const section = quickActionSection();
    if (!section) {
      return;
    }
    const status = section.querySelector(".didar-plan-quick-actions__status");
    const itemsHost = section.querySelector(".didar-plan-quick-actions__items");
    const state = planActivityTypesState;
    const dealId = currentDealId();
    const existingTitles = existingPlanActivityTitles();
    const renderSignature = JSON.stringify([
      state.status,
      state.error,
      state.items.map((item) => [item.id, item.label, item.index]),
      state.items.map((item) => {
        const key = `${dealId}:${item.id}`;
        return [
          activeQuickPlanCreations.has(key),
          knownQuickPlanCreations.has(key) || existingTitles.has(item.title)
        ];
      })
    ]);
    if (section.dataset.renderSignature === renderSignature) {
      return;
    }
    section.dataset.renderSignature = renderSignature;
    section.dataset.state = state.status;
    itemsHost.replaceChildren();

    if (state.status === "idle" || state.status === "loading") {
      status.textContent = "در حال دریافت طرح‌ها...";
      for (let index = 0; index < 4; index += 1) {
        const placeholder = document.createElement("span");
        placeholder.className = "didar-plan-quick-action-skeleton";
        itemsHost.appendChild(placeholder);
      }
      return;
    }
    if (state.status === "error") {
      status.textContent = state.error;
      const retry = document.createElement("button");
      retry.type = "button";
      retry.className = "didar-plan-quick-actions__retry";
      retry.title = "تلاش دوباره";
      retry.setAttribute("aria-label", "دریافت دوباره فعالیت‌های طرح");
      retry.textContent = "↻";
      retry.addEventListener("click", () => {
        planActivityTypesState = { status: "idle", items: [], error: "" };
        loadPlanActivityTypes(true);
      });
      itemsHost.appendChild(retry);
      return;
    }
    if (!state.items.length) {
      status.textContent = "فعالیت فعالی با عنوان «شروع طرح» تعریف نشده است.";
      return;
    }

    status.textContent = "";
    state.items.forEach((type) => {
      const button = document.createElement("button");
      const operationKey = `${dealId}:${type.id}`;
      const busy = activeQuickPlanCreations.has(operationKey);
      const created = knownQuickPlanCreations.has(operationKey) || existingTitles.has(type.title);
      button.type = "button";
      button.className = "didar-plan-quick-action";
      button.classList.toggle("is-created", created);
      button.dataset.activityTypeId = type.id;
      button.dataset.status = busy ? "busy" : created ? "created" : "available";
      button.disabled = busy;
      button.title = created
        ? `فعالیت ${type.title} قبلاً ایجاد شده است؛ برای ایجاد دوباره کلیک کنید`
        : `ایجاد فعالیت ${type.title}`;
      button.setAttribute("aria-label", button.title);
      button.setAttribute("aria-pressed", created ? "true" : "false");
      const icon = document.createElement("span");
      icon.className = "didar-plan-quick-action__icon";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = busy ? "…" : created ? "✓" : "+";
      const label = document.createElement("span");
      label.className = "didar-plan-quick-action__label";
      label.textContent = type.label;
      button.append(icon, label);
      button.addEventListener("click", () => void createQuickPlanActivity(type));
      itemsHost.appendChild(button);
    });
  }

  function enhancePlanActivityQuickActions() {
    if (!settings.enabled || document.readyState === "loading" || !currentDealId()) {
      document.querySelectorAll(".didar-plan-quick-actions").forEach((section) => section.remove());
      return;
    }
    if (!quickActionSection()) {
      return;
    }
    renderPlanActivityQuickActions();
    loadPlanActivityTypes();
  }

  function localizedNumber(value) {
    return String(Math.max(0, Number(value) || 0)).replace(
      /\d/g,
      (digit) => "\u06f0\u06f1\u06f2\u06f3\u06f4\u06f5\u06f6\u06f7\u06f8\u06f9"[Number(digit)]
    );
  }

  function updateProductSummary(deal) {
    const dealId = Core.text(deal?.Id).toLowerCase();
    if (!Core.GUID_PATTERN.test(dealId) || dealId !== currentDealId()) {
      return false;
    }
    const count = Array.isArray(deal?.Items) ? deal.Items.length : 0;
    const action = findProductAction();
    if (!action) {
      return false;
    }
    const targetText = count
      ? `${localizedNumber(count)} \u0645\u062d\u0635\u0648\u0644 (\u0648\u06cc\u0631\u0627\u06cc\u0634)`
      : "+ \u0627\u0641\u0632\u0648\u062f\u0646 \u0645\u062d\u0635\u0648\u0644";
    if (Core.text(action.textContent) !== targetText) {
      action.textContent = targetText;
    }
    action.dataset.didarProductCount = String(count);
    return true;
  }

  function rememberDealProductView(deal) {
    const dealId = Core.text(deal?.Id).toLowerCase();
    if (!Core.GUID_PATTERN.test(dealId) || !Array.isArray(deal?.Items)) {
      return false;
    }
    rememberedDealProductViews.set(dealId, Core.cloneJson(deal));
    return updateProductSummary(deal);
  }

  function dealProductSignature(deal) {
    return JSON.stringify((deal?.Items || []).map((item) => [
      item.Id,
      item.ProductId,
      item.Title,
      item.Description,
      item.UnitPrice,
      item.Quantity
    ]));
  }

  function formatProductMoney(value) {
    const number = Number(String(value ?? 0).replace(/,/g, ""));
    return Number.isFinite(number) ? new Intl.NumberFormat("fa-IR").format(number) : Core.text(value);
  }

  function renderProductEditorPreview(editor, deal) {
    const items = Array.isArray(deal?.Items) ? deal.Items : [];
    const signature = JSON.stringify(items.map((item) => [
      item.Id,
      item.ProductId,
      item.Title,
      item.Description,
      item.UnitPrice,
      item.Quantity
    ]));
    let preview = editor.querySelector(":scope > .didar-live-product-preview");
    if (!items.length) {
      preview?.remove();
      return;
    }
    if (preview?.dataset.signature === signature) {
      return;
    }
    preview?.remove();
    preview = document.createElement("section");
    preview.className = "didar-live-product-preview";
    preview.dataset.signature = signature;
    preview.setAttribute("dir", "rtl");

    const heading = document.createElement("div");
    heading.className = "didar-live-product-preview__heading";
    heading.textContent = `محصولات ثبت‌شده در معامله (${localizedNumber(items.length)})`;
    preview.appendChild(heading);

    const table = document.createElement("table");
    table.innerHTML = "<thead><tr><th>محصول</th><th>توضیحات</th><th>مبلغ واحد</th><th>تعداد</th><th>عملیات</th></tr></thead>";
    const body = document.createElement("tbody");
    items.forEach((item) => {
      const row = document.createElement("tr");
      row.dataset.dealProductId = Core.text(item.Id).toLowerCase();
      row.dataset.baseDescription = Core.text(item.Description);
      row.dataset.baseUnitPrice = normalizeUnitPriceInput(item.UnitPrice ?? 0);

      const titleCell = document.createElement("td");
      titleCell.textContent = Core.text(item.Title) || "-";

      const descriptionCell = document.createElement("td");
      const descriptionInput = document.createElement("input");
      descriptionInput.type = "text";
      descriptionInput.className = "didar-live-product-description";
      descriptionInput.value = formatLongNumbersInDescription(item.Description);
      descriptionInput.setAttribute("aria-label", `توضیحات ${Core.text(item.Title) || "محصول"}`);
      descriptionInput.addEventListener("input", () => formatDescriptionWhileTyping(descriptionInput));
      descriptionCell.appendChild(descriptionInput);

      const priceCell = document.createElement("td");
      const priceInput = document.createElement("input");
      priceInput.type = "text";
      priceInput.inputMode = "decimal";
      priceInput.className = "didar-live-product-unit-price";
      priceInput.value = formatUnitPriceForDisplay(item.UnitPrice ?? 0);
      priceInput.setAttribute("aria-label", `مبلغ واحد ${Core.text(item.Title) || "محصول"}`);
      priceInput.addEventListener("input", () => formatUnitPriceWhileTyping(priceInput));
      priceCell.appendChild(priceInput);

      const quantityCell = document.createElement("td");
      quantityCell.textContent = Core.text(item.Quantity || 1);

      const actionCell = document.createElement("td");
      const saveButton = document.createElement("button");
      saveButton.type = "button";
      saveButton.className = "didar-live-product-save";
      saveButton.textContent = "ذخیره";
      saveButton.disabled = !Core.GUID_PATTERN.test(row.dataset.dealProductId);
      saveButton.addEventListener("click", () => {
        void saveProductEditorRow(editor, row, deal.Id);
      });
      const status = document.createElement("span");
      status.className = "didar-live-product-status";
      status.setAttribute("role", "status");
      actionCell.append(saveButton, status);

      row.append(titleCell, descriptionCell, priceCell, quantityCell, actionCell);
      body.appendChild(row);
    });
    table.appendChild(body);
    preview.appendChild(table);
    editor.prepend(preview);
  }

  async function saveProductEditorRow(editor, row, requestedDealId) {
    const dealId = Core.text(requestedDealId).toLowerCase();
    const dealProductId = Core.text(row.dataset.dealProductId).toLowerCase();
    const operationKey = `${dealId}:${dealProductId}`;
    const descriptionInput = row.querySelector(".didar-live-product-description");
    const priceInput = row.querySelector(".didar-live-product-unit-price");
    const saveButton = row.querySelector(".didar-live-product-save");
    const status = row.querySelector(".didar-live-product-status");
    if (
      !settings.enabled ||
      !settings.autoAddPlanProduct ||
      currentDealId() !== dealId ||
      !Core.GUID_PATTERN.test(dealProductId) ||
      activeProductSaves.has(operationKey)
    ) {
      return;
    }

    let unitPrice;
    try {
      unitPrice = normalizeUnitPriceInput(priceInput.value);
    } catch (error) {
      status.textContent = error.message;
      row.classList.add("has-error");
      return;
    }
    const description = Core.text(descriptionInput.value);
    const operation = prepareDurableOperation({
      id: `product-fields:${dealId}:${dealProductId}`,
      type: "plan-product-fields",
      lockName: `deal-products:${dealId}`,
      dealId,
      dealProductId,
      description,
      unitPrice,
      baseDescription: Core.text(row.dataset.baseDescription),
      baseUnitPrice: normalizeUnitPriceInput(row.dataset.baseUnitPrice || 0)
    });
    activeProductSaves.add(operationKey);
    row.classList.remove("has-error", "is-saved");
    row.classList.add("is-saving");
    descriptionInput.disabled = true;
    priceInput.disabled = true;
    saveButton.disabled = true;
    status.textContent = "در حال ذخیره...";

    try {
      await putOutboxOperation(operation);
      const confirmed = await runDurableOperation(
        operation,
        persistProductFieldsIntent,
        { staged: true }
      );
      if (!confirmed?.item) {
        throw new Error("این ذخیره با درخواست جدیدتری جایگزین شد یا تأیید نشد.");
      }
      rememberDealProductView(confirmed.deal);
      void syncOpenDealView(confirmed.deal, { requireProductEditor: true, waitForView: false });
      renderProductEditorPreview(editor, confirmed.deal);
      toast(`اطلاعات محصول «${Core.text(confirmed.item.Title)}» ذخیره شد`, "success");
    } catch (error) {
      row.classList.add("has-error");
      status.textContent = error?.message || "ذخیره محصول انجام نشد.";
      toast(status.textContent, "error");
    } finally {
      activeProductSaves.delete(operationKey);
      row.classList.remove("is-saving");
      if (row.isConnected) {
        descriptionInput.disabled = false;
        priceInput.disabled = false;
        saveButton.disabled = false;
      }
    }
  }

  async function ensureCurrentDealProductView(force = false, requestedDealId = currentDealId()) {
    const dealId = Core.text(requestedDealId).toLowerCase();
    if (!Core.GUID_PATTERN.test(dealId)) {
      return null;
    }
    if (!force && rememberedDealProductViews.has(dealId)) {
      return rememberedDealProductViews.get(dealId);
    }
    if (!force && productDealLoads.has(dealId)) {
      return productDealLoads.get(dealId);
    }
    const auth = credentials();
    if (!auth.token || (!auth.bizDomain && !force)) {
      return null;
    }
    if (!force && Date.now() - (productDealLoadFailures.get(dealId) || 0) < 15000) {
      return null;
    }
    const generation = Number(productDealLoadGenerations.get(dealId) || 0) + 1;
    productDealLoadGenerations.set(dealId, generation);
    const load = apiRequest("deal/GetDealDetail", {
      body: { Id: dealId },
      retry: true
    })
      .then((deal) => {
        productDealLoadFailures.delete(dealId);
        if (productDealLoadGenerations.get(dealId) === generation) {
          rememberDealProductView(deal);
        }
        return deal;
      })
      .catch((error) => {
        productDealLoadFailures.set(dealId, Date.now());
        throw error;
      })
      .finally(() => {
        if (productDealLoads.get(dealId) === load) {
          productDealLoads.delete(dealId);
        }
      });
    productDealLoads.set(dealId, load);
    return load;
  }

  function syncRememberedProductView() {
    const deal = rememberedDealProductViews.get(currentDealId());
    if (!deal) {
      return false;
    }
    const summaryUpdated = updateProductSummary(deal);
    document.querySelectorAll("add-product").forEach((editor) => {
      renderProductEditorPreview(editor, deal);
      const signature = dealProductSignature(deal);
      if (
        hydratedProductEditors.get(editor) === signature ||
        hydratingProductEditors.get(editor) === signature
      ) {
        return;
      }
      hydratingProductEditors.set(editor, signature);
      void syncOpenDealView(deal, { requireProductEditor: true }).then((synced) => {
        if (hydratingProductEditors.get(editor) === signature) {
          hydratingProductEditors.delete(editor);
        }
        if (synced) {
          hydratedProductEditors.set(editor, signature);
        }
      });
    });
    return summaryUpdated;
  }

  async function verifyAddedProduct(dealId, selectedId, activityId, previousIds, expectedCount) {
    const waits = [0, 180, 400, 800, 1400, 2400, 3800];
    let latestDeal = null;
    for (const wait of waits) {
      if (wait) {
        await delay(wait);
      }
      latestDeal = await apiRequest("deal/GetDealDetail", {
        body: { Id: dealId },
        retry: true
      });
      const matching = (latestDeal?.Items || []).filter(
        (item) => Core.text(item.ProductId).toLowerCase() === selectedId
      );
      const ownedItems = matching.filter(
        (item) => Core.text(item.VariantId).toLowerCase() === activityId
      );
      const newItems = matching.filter((item) => {
        const id = Core.text(item.Id).toLowerCase();
        return id && id !== EMPTY_GUID && !previousIds.has(id);
      });
      const createdItem = ownedItems.length > 1
        ? null
        : (ownedItems[0] || (newItems.length === 1 ? newItems[0] : null));
      if (matching.length >= expectedCount && createdItem) {
        return latestDeal;
      }
    }
    return null;
  }

  function planActivitiesFromDetail(value) {
    const activities = [
      ...(Array.isArray(value?.Planned) ? value.Planned : []),
      ...(Array.isArray(value?.Done) ? value.Done : []),
      ...(Array.isArray(value?.Pinned) ? value.Pinned : [])
    ];
    const unique = new Map();
    activities.forEach((activity) => {
      const id = Core.text(activity?.Id).toLowerCase();
      if (
        Core.GUID_PATTERN.test(id) &&
        activity?.IsDeleted !== true &&
        productTitleForActivity(activity?.Title)
      ) {
        unique.set(id, activity);
      }
    });
    return Array.from(unique.values()).sort((left, right) => {
      const leftTime = Date.parse(left.RegisterDate || left.DueDate || left.LastUpdateTime || 0) || 0;
      const rightTime = Date.parse(right.RegisterDate || right.DueDate || right.LastUpdateTime || 0) || 0;
      return leftTime - rightTime || Core.text(left.Id).localeCompare(Core.text(right.Id));
    });
  }

  async function planActivitiesForDeal(dealId, expectedActivityId = "") {
    const waits = expectedActivityId ? [0, 200, 500, 1000, 1800, 3000] : [0];
    let activities = [];
    for (const wait of waits) {
      if (wait) {
        await delay(wait);
      }
      const detail = await apiRequest("activity/GetDetailActivities", {
        body: { DealId: dealId },
        retry: true
      });
      activities = planActivitiesFromDetail(detail).filter((activity) => {
        const activityDealId = Core.text(activity.DealId).toLowerCase();
        return !Core.GUID_PATTERN.test(activityDealId) || activityDealId === dealId.toLowerCase();
      });
      rememberedDealPlanActivities.set(dealId.toLowerCase(), activities);
      bindPlanActivityCardsFromServer(dealId.toLowerCase(), true);
      if (!expectedActivityId || activities.some(
        (activity) => Core.text(activity.Id).toLowerCase() === expectedActivityId
      )) {
        break;
      }
    }
    return activities;
  }

  function mapExistingProductsToActivities(deal, activities) {
    const groups = new Map();
    activities.forEach((activity) => {
      const productTitle = productTitleForActivity(activity.Title);
      if (!groups.has(productTitle)) {
        groups.set(productTitle, []);
      }
      groups.get(productTitle).push(activity);
    });

    groups.forEach((titleActivities, productTitle) => {
      const matchingItems = (deal.Items || []).filter(
        (item) => normalizedTitle(item.Title) === productTitle
      );
      const used = new Set();
      const assignments = new Map();
      titleActivities.forEach((activity) => {
        const activityId = Core.text(activity.Id).toLowerCase();
        const mapping = productActivityMappings.get(productActivityMapKey(deal.Id, activityId));
        const item = mappedProductItem(deal, mapping);
        if (item && matchingItems.includes(item) && !used.has(item)) {
          assignments.set(activityId, item);
          used.add(item);
        }
      });
      titleActivities.forEach((activity) => {
        const activityId = Core.text(activity.Id).toLowerCase();
        if (assignments.has(activityId)) {
          return;
        }
        const item = matchingItems.find((candidate) =>
          !used.has(candidate) && Core.text(candidate.VariantId).toLowerCase() === activityId
        );
        if (item) {
          assignments.set(activityId, item);
          used.add(item);
        }
      });
      const unresolvedActivities = titleActivities.filter(
        (activity) => !assignments.has(Core.text(activity.Id).toLowerCase())
      );
      const unclaimedItems = matchingItems.filter((candidate) => !used.has(candidate));
      if (unresolvedActivities.length === 1 && unclaimedItems.length === 1) {
        const activityId = Core.text(unresolvedActivities[0].Id).toLowerCase();
        assignments.set(activityId, unclaimedItems[0]);
        used.add(unclaimedItems[0]);
      }
      titleActivities.forEach((activity, ordinal) => {
        const activityId = Core.text(activity.Id).toLowerCase();
        const item = assignments.get(activityId);
        if (item) {
          rememberActivityProduct(deal.Id, activityId, item, ordinal);
        } else {
          productActivityMappings.delete(productActivityMapKey(deal.Id, activityId));
        }
      });
      persistProductActivityMappings();
    });
  }

  async function addProductRowForActivity(activity, deal) {
    const activityId = Core.text(activity?.Id).toLowerCase();
    const dealId = Core.text(deal?.Id).toLowerCase();
    const expectedTitle = productTitleForActivity(activity?.Title);
    if (!Core.GUID_PATTERN.test(activityId) || !Core.GUID_PATTERN.test(dealId) || !expectedTitle) {
      throw new Error("اطلاعات فعالیت برای افزودن محصول کامل نیست.");
    }
    const searchResult = await apiRequest("product/search", {
      body: { Criteria: { Keywords: expectedTitle }, Count: 300 },
      retry: true
    });
    const exactMatches = responseList(searchResult).filter(
      (item) => normalizedTitle(item?.Title) === expectedTitle && item?.IsActive !== false
    );
    if (exactMatches.length !== 1) {
      throw new Error(
        exactMatches.length
          ? `بیش از یک محصول با عنوان دقیق «${expectedTitle}» پیدا شد.`
          : `محصول دقیق «${expectedTitle}» در فهرست محصولات پیدا نشد.`
      );
    }
    const selected = exactMatches[0];
    const [freshDeal, productResult] = await Promise.all([
      apiRequest("deal/GetDealDetail", { body: { Id: dealId }, retry: true }),
      apiRequest("product/getProductByIds", { body: { Ids: [selected.Id] }, retry: true })
    ]);
    const product = responseList(productResult).find(
      (item) => Core.text(item.Id).toLowerCase() === Core.text(selected.Id).toLowerCase()
    );
    if (!freshDeal || !product) {
      throw new Error(`اطلاعات محصول «${expectedTitle}» از سرور دریافت نشد.`);
    }
    const concurrentItem = (freshDeal.Items || []).find(
      (item) => Core.text(item.VariantId).toLowerCase() === activityId
    );
    if (concurrentItem) {
      rememberActivityProduct(dealId, activityId, concurrentItem);
      return { deal: freshDeal, item: concurrentItem, title: expectedTitle };
    }
    const existingItems = Array.isArray(freshDeal.Items) ? Core.cloneJson(freshDeal.Items) : [];
    const taxPercent = existingItems.find((item) => item?.TaxPercent != null)?.TaxPercent ?? 0;
    const selectedId = Core.text(selected.Id).toLowerCase();
    const existingMatchingItems = existingItems.filter(
      (item) => Core.text(item.ProductId).toLowerCase() === selectedId
    );
    const existingIds = new Set(existingMatchingItems.map(
      (item) => Core.text(item.Id).toLowerCase()
    ).filter((id) => id && id !== EMPTY_GUID));
    const newItem = {
      ...Core.cloneJson(selected),
      Title: selected.Title,
      ProductId: selected.Id,
      ProductCode: selected.Code,
      UnitPrice: unitPriceForProduct(product, freshDeal.CurrencyId, selected.VariantId),
      Discount: 0,
      TaxPercent: taxPercent,
      DiscountPercent: 0,
      Quantity: 1,
      DiscountType: "Amount",
      VariantId: activityId,
      Id: EMPTY_GUID
    };
    await apiRequest("DealProduct/Update", {
      body: {
        DealId: dealId,
        DealProducts: [...existingItems, newItem],
        Adjustment: Core.text(freshDeal.Adjustment || 0)
      }
    });
    const verifiedDeal = await verifyAddedProduct(
      dealId,
      selectedId,
      activityId,
      existingIds,
      existingMatchingItems.length + 1
    );
    if (!verifiedDeal) {
      throw new Error(`سرور افزودن یک ردیف «${expectedTitle}» را تأیید نکرد.`);
    }
    const verifiedMatchingItems = (verifiedDeal.Items || []).filter(
      (item) => Core.text(item.ProductId).toLowerCase() === selectedId
    );
    const ownedItems = verifiedMatchingItems.filter(
      (item) => Core.text(item.VariantId).toLowerCase() === activityId
    );
    const newItems = verifiedMatchingItems.filter((item) => {
      const id = Core.text(item.Id).toLowerCase();
      return id && id !== EMPTY_GUID && !existingIds.has(id);
    });
    const createdItem = ownedItems.length > 1
      ? null
      : (ownedItems[0] || (newItems.length === 1 ? newItems[0] : null));
    if (!createdItem) {
      throw new Error(`اتصال قطعی محصول تازه «${expectedTitle}» به فعالیت تأیید نشد.`);
    }
    rememberActivityProduct(dealId, activityId, createdItem, existingMatchingItems.length);
    return { deal: verifiedDeal, item: createdItem, title: expectedTitle };
  }

  async function reconcileDealPlanProducts(dealId, expectedActivityId = "") {
    if (!settings.enabled || !settings.autoAddPlanProduct || !Core.GUID_PATTERN.test(dealId)) {
      return null;
    }
    const activities = await planActivitiesForDeal(dealId, expectedActivityId);
    const targets = expectedActivityId
      ? activities.filter((activity) => Core.text(activity.Id).toLowerCase() === expectedActivityId)
      : activities;
    if (expectedActivityId && !targets.length) {
      throw new Error("فعالیت جدید هنوز در فهرست سرور دیده نشد؛ ساخت محصول دوباره بررسی می‌شود.");
    }
    let deal = await ensureCurrentDealProductView(true, dealId);
    if (!deal) {
      throw new Error("محصولات معامله از سرور دریافت نشد.");
    }
    mapExistingProductsToActivities(deal, activities);
    for (const activity of targets) {
      const activityId = Core.text(activity.Id).toLowerCase();
      const mapping = productActivityMappings.get(productActivityMapKey(deal.Id, activityId));
      if (mappedProductItem(deal, mapping)) {
        continue;
      }
      const created = await addProductRowForActivity(activity, deal);
      deal = created.deal;
      mapExistingProductsToActivities(deal, activities);
    }
    const summarySynced = rememberDealProductView(deal);
    enhancePlanProductFields();
    const directlySynced = await syncOpenDealView(deal);
    return {
      deal,
      activities,
      viewSynced: directlySynced || summarySynced || syncRememberedProductView()
    };
  }

  async function addProductForCreatedPlanActivity(detail) {
    const activityId = Core.text(detail?.activityId).toLowerCase();
    const dealId = Core.text(detail?.dealId).toLowerCase();
    if (!Core.GUID_PATTERN.test(activityId) || !Core.GUID_PATTERN.test(dealId)) {
      throw new Error("دیدار شناسه معتبر فعالیت جدید را برنگرداند.");
    }
    const result = await reconcileDealPlanProducts(dealId, activityId);
    const mapping = productActivityMappings.get(productActivityMapKey(dealId, activityId));
    if (!mappedProductItem(result?.deal, mapping)) {
      throw new Error(`محصول متناظر «${productTitleForActivity(detail?.title)}» تأیید نشد.`);
    }
    lastInteraction = `فعالیت و محصول متناظر روی سرور تأیید شدند: ${normalizedTitle(detail?.title)}`;
    if (detail.notify !== false) {
      toast("فعالیت و محصول متناظر روی سرور ذخیره شدند", "success");
    }
  }

  async function ensurePlanProductForActivity(activity) {
    const activityId = Core.text(activity?.activityId || activity?.Id).toLowerCase();
    const dealId = Core.text(activity?.dealId || activity?.DealId).toLowerCase();
    const title = normalizedTitle(activity?.title || activity?.Title);
    if (!settings.enabled || !settings.autoAddPlanProduct ||
        !Core.GUID_PATTERN.test(activityId) || !Core.GUID_PATTERN.test(dealId) ||
        !productTitleForActivity(title) || activity?.IsDeleted === true) return;
    const detail = { activityId, dealId, title, notify: activity.notify };
    if (activity.bindCreatedCard !== false) scheduleCreatedActivityCardBinding(detail);
    const operation = prepareDurableOperation({
      id: `product:${dealId}:${activityId}`,
      type: "plan-product",
      lockName: `deal-products:${dealId}`,
      activityId,
      dealId,
      title,
      notify: detail.notify
    });
    let staged = false;
    try {
      await putOutboxOperation(operation);
      staged = true;
      await queueProductOperation(() => runDurableOperation(
        operation,
        (pending) => addProductForCreatedPlanActivity(pending),
        { staged: true }
      ));
    } catch (error) {
      lastInteraction = `خطای افزودن محصول: ${error?.message || "عملیات انجام نشد"}`;
      if (detail.notify !== false) {
        toast(`فعالیت ثبت شده است؛ محصول ذخیره نشد: ${error?.message || "خطای دیدار"}${
          staged ? " — برای تلاش مجدد نگه داشته شد." : ""
        }`, "error");
      }
    }
  }

  function handlePlanActivityCreated(event) {
    void ensurePlanProductForActivity(event.detail);
  }

  async function verifyRemovedProduct(dealId, dealProductId, expectedCount) {
    const waits = [0, 120, 300, 650, 1100, 1700];
    let latest = null;
    for (const wait of waits) {
      if (wait) {
        await delay(wait);
      }
      latest = await ensureCurrentDealProductView(true, dealId);
      const items = Array.isArray(latest?.Items) ? latest.Items : [];
      const exactStillExists = dealProductId && dealProductId !== EMPTY_GUID
        ? items.some((item) => Core.text(item.Id).toLowerCase() === dealProductId)
        : items.length > expectedCount;
      if (!exactStillExists && items.length <= expectedCount) {
        return latest;
      }
    }
    return null;
  }

  async function persistProductDeletionIntent(operation) {
    const activityId = Core.text(operation?.activityId).toLowerCase();
    const dealId = Core.text(operation?.dealId).toLowerCase();
    const productTitle = Core.text(operation?.productTitle);
    if (
      !Core.GUID_PATTERN.test(activityId) ||
      !Core.GUID_PATTERN.test(dealId)
    ) {
      throw new Error("شناسه فعالیت یا معامله برای حذف محصول معتبر نیست.");
    }

    const mappingKey = productActivityMapKey(dealId, activityId);
    const mapping = productActivityMappings.get(mappingKey);
    if (!mapping && !productTitle) {
      return;
    }
    const deal = await ensureCurrentDealProductView(true, dealId);
    if (!deal || !Array.isArray(deal.Items)) {
      throw new Error("محصولات معامله برای حذف محصول متناظر دریافت نشد.");
    }

    const mappedDealProductId = Core.text(mapping?.dealProductId).toLowerCase();
    let item = Core.GUID_PATTERN.test(mappedDealProductId)
      ? deal.Items.find(
        (candidate) => Core.text(candidate.Id).toLowerCase() === mappedDealProductId
      )
      : null;
    const ownedItems = deal.Items.filter(
      (candidate) => Core.text(candidate.VariantId).toLowerCase() === activityId
    );
    if (ownedItems.length > 1) {
      throw new Error("چند محصول با شناسه همین فعالیت وجود دارد؛ حذف خودکار متوقف شد.");
    }
    if (!item) {
      item = ownedItems[0] || null;
    } else if (ownedItems.length === 1 && ownedItems[0] !== item) {
      throw new Error("اتصال ذخیره‌شده محصول با شناسه فعالیت همخوان نیست؛ حذف متوقف شد.");
    }
    if (!item) {
      productActivityMappings.delete(mappingKey);
      persistProductActivityMappings();
      return { deal, deleted: false };
    }

    const itemIndex = deal.Items.indexOf(item);
    const dealProductId = Core.text(item.Id).toLowerCase();
    const updatedItems = Core.cloneJson(deal.Items);
    updatedItems.splice(itemIndex, 1);
    await apiRequest("DealProduct/Update", {
      body: {
        DealId: dealId,
        DealProducts: updatedItems,
        Adjustment: Core.text(deal.Adjustment || 0)
      }
    });
    const verifiedDeal = await verifyRemovedProduct(
      dealId,
      dealProductId,
      updatedItems.length
    );
    if (!verifiedDeal) {
      throw new Error("سرور حذف محصول متناظر را تأیید نکرد.");
    }

    productActivityMappings.delete(mappingKey);
    persistProductActivityMappings();
    const summarySynced = rememberDealProductView(verifiedDeal);
    const directlySynced = await syncOpenDealView(verifiedDeal);
    const viewSynced = directlySynced || summarySynced || syncRememberedProductView();
    enhancePlanProductFields();
    const removedTitle = normalizedTitle(item.Title) || productTitle;
    lastInteraction = `محصول متناظر فعالیت حذف شد: ${removedTitle}`;
    toast(
      viewSynced
        ? `محصول «${removedTitle}» همراه فعالیت حذف شد`
        : `محصول «${removedTitle}» حذف شد؛ نمایش صفحه با تأخیر همگام می‌شود`,
      viewSynced ? "success" : "error"
    );
    return { deal: verifiedDeal, deleted: true };
  }

  function handlePlanActivityDeleted(event) {
    if (!settings.autoAddPlanProduct) {
      return;
    }
    const detail = event.detail || {};
    const activityId = Core.text(detail.activityId).toLowerCase();
    const dealId = Core.text(detail.dealId || currentDealId()).toLowerCase();
    if (!Core.GUID_PATTERN.test(activityId) || !Core.GUID_PATTERN.test(dealId)) {
      return;
    }
    const operation = prepareDurableOperation({
      id: `product-delete:${dealId}:${activityId}`,
      type: "plan-product-delete",
      lockName: `deal-products:${dealId}`,
      activityId,
      dealId,
      productTitle: productTitleForActivity(detail.title)
    });
    void putOutboxOperation(operation)
      .then(() => queueProductOperation(() => runDurableOperation(
        operation,
        persistProductDeletionIntent,
        { staged: true }
      )))
      .catch((error) => {
        lastInteraction = `خطای حذف محصول متناظر: ${error?.message || "عملیات انجام نشد"}`;
        toast(error?.message || "حذف محصول متناظر فعالیت انجام نشد.", "error");
      });
  }

  function queueProductOperation(operation) {
    const queued = productCreationQueue.then(operation);
    productCreationQueue = queued.catch(() => {});
    return queued;
  }

  function visibleRows(todoList) {
    return Array.from(todoList.querySelectorAll(":scope > li")).map((item) => {
      const checkbox = item.querySelector('input[type="checkbox"]');
      const description = item.querySelector(".todo-list__label__description");
      return {
        label: Core.normalizeLabel(description?.textContent || item.textContent),
        checked: Boolean(checkbox?.checked)
      };
    });
  }

  function contextValues(element) {
    const values = [];
    for (const key of Object.getOwnPropertyNames(element)) {
      if (key.startsWith("__ngContext__")) {
        values.push(element[key]);
      }
    }
    return values;
  }

  function collectActivityCandidates(value, rows, changedIndex, expectedTitle = "", maxDepth = 7) {
    const queue = [{ value, depth: 0 }];
    const visited = new WeakSet();
    const candidates = [];
    let inspected = 0;

    while (queue.length && inspected < 1800) {
      const current = queue.shift();
      const node = current.value;
      if (!node || (typeof node !== "object" && typeof node !== "function")) {
        continue;
      }
      if (visited.has(node)) {
        continue;
      }
      visited.add(node);
      inspected += 1;

      if (
        Core.isActivity(node) &&
        node.IsDeleted !== true &&
        (!Core.GUID_PATTERN.test(Core.text(node.DealId)) ||
          Core.text(node.DealId).toLowerCase() === currentDealId()) &&
        (!expectedTitle || normalizedTitle(node.Title) === expectedTitle) &&
        Core.rowsMatchActivity(node, rows, changedIndex)
      ) {
        candidates.push({ id: Core.text(node.Id).toLowerCase(), depth: current.depth });
        continue;
      }
      if (current.depth >= maxDepth || node instanceof Node) {
        continue;
      }

      const nextValues = [];
      if (node.$implicit) {
        nextValues.push(node.$implicit);
      }
      if (Array.isArray(node)) {
        nextValues.push(...node);
      } else {
        for (const key of Object.keys(node)) {
          if (key === "parent" || key === "__proto__") {
            continue;
          }
          try {
            nextValues.push(node[key]);
          } catch {
            // Some Angular getters can throw while a view is being destroyed.
          }
        }
      }
      nextValues.forEach((next) => queue.push({ value: next, depth: current.depth + 1 }));
    }
    return candidates;
  }

  function resolveActivityId(input, changedIndex) {
    const todoList = input.closest("ul.todo-list");
    const stableId = Core.text(todoList.dataset.didarStableActivityId).toLowerCase();
    if (Core.GUID_PATTERN.test(stableId)) {
      return stableId;
    }
    const mappedId = Core.text(todoList.dataset.didarActivityId).toLowerCase();
    if (Core.GUID_PATTERN.test(mappedId)) {
      todoList.dataset.didarStableActivityId = mappedId;
      return mappedId;
    }
    todoList.dataset.didarTodoChangedIndex = String(changedIndex);
    todoList.dispatchEvent(new Event(RESOLVE_EVENT, { bubbles: true }));
    const bridgedId = Core.text(todoList.dataset.didarActivityId).toLowerCase();
    const resolution = Core.text(todoList.dataset.didarActivityResolution);
    todoList.removeAttribute("data-didar-todo-changed-index");
    if (Core.GUID_PATTERN.test(bridgedId)) {
      todoList.dataset.didarStableActivityId = bridgedId;
      return bridgedId;
    }
    if (resolution === "ambiguous") {
      throw new Error("چند فعالیت مشابه پیدا شد؛ برای جلوگیری از تغییر اشتباه ذخیره انجام نشد.");
    }

    const rows = visibleRows(todoList);
    const expectedTitle = normalizedTitle(
      todoList.closest(".activity-item, article")?.querySelector("h2")?.textContent
    );
    const scored = [];
    let element = input;
    let ancestorDistance = 0;

    while (element && ancestorDistance < 14) {
      for (const context of contextValues(element)) {
        collectActivityCandidates(context, rows, changedIndex, expectedTitle).forEach((candidate) => {
          scored.push({
            id: candidate.id,
            score: ancestorDistance * 20 + candidate.depth
          });
        });
      }
      element = element.parentElement;
      ancestorDistance += 1;
    }

    const bestById = new Map();
    scored.forEach((candidate) => {
      const prior = bestById.get(candidate.id);
      if (prior === undefined || candidate.score < prior) {
        bestById.set(candidate.id, candidate.score);
      }
    });
    const ranked = Array.from(bestById, ([id, score]) => ({ id, score })).sort(
      (left, right) => left.score - right.score
    );
    if (!ranked.length) {
      throw new Error("شناسه این فعالیت از صفحه قابل تشخیص نیست. صفحه را تازه‌سازی کنید.");
    }
    if (ranked.length > 1 && ranked[0].score === ranked[1].score) {
      throw new Error("چند فعالیت مشابه پیدا شد؛ برای جلوگیری از تغییر اشتباه ذخیره انجام نشد.");
    }
    todoList.dataset.didarStableActivityId = ranked[0].id;
    return ranked[0].id;
  }

  function toast(message, type = "success") {
    if (type === "error") void globalThis.DidarDiagnostics?.report({source:"didar",operation:"activity",error:message});
    document.querySelectorAll(".didar-todo-toast").forEach((item) => item.remove());
    const element = document.createElement("div");
    element.className = `didar-todo-toast didar-todo-toast--${type}`;
    element.setAttribute("role", type === "error" ? "alert" : "status");
    element.textContent = message;
    document.body.appendChild(element);
    requestAnimationFrame(() => element.classList.add("is-visible"));
    window.setTimeout(() => {
      element.classList.remove("is-visible");
      window.setTimeout(() => element.remove(), 180);
    }, type === "error" ? 6500 : 3500);
  }

  function markBusy(input, busy) {
    input.closest("li")?.classList.toggle("didar-todo-busy", busy);
    const hitbox = hitboxByInput.get(input);
    if (hitbox) {
      hitbox.disabled = busy;
      hitbox.classList.toggle("is-busy", busy);
    }
  }

  function setCheckboxState(input, checked) {
    input.checked = Boolean(checked);
    input.toggleAttribute("checked", Boolean(checked));
  }

  async function completeActivityThroughDidarUi(input, activityId, resultNote) {
    activitySyncSequence += 1;
    const requestId = `native-${Date.now()}-${activitySyncSequence}`;
    const marker = document.createElement("meta");
    marker.hidden = true;
    marker.dataset.didarNativeActivityDoneRequest = requestId;
    marker.textContent = JSON.stringify({ requestId, activityId, resultNote });
    document.documentElement.appendChild(marker);
    let detailPopup = null;

    try {
      const armed = new Promise((resolve) => {
        const timeoutId = window.setTimeout(() => resolve(false), 700);
        marker.addEventListener(
          NATIVE_ACTIVITY_DONE_ARMED_EVENT,
          () => {
            window.clearTimeout(timeoutId);
            resolve(marker.dataset.didarNativeActivityDoneArmed === "true");
          },
          { once: true }
        );
      });
      marker.dispatchEvent(new Event(NATIVE_ACTIVITY_DONE_ARM_EVENT, { bubbles: true }));
      if (!(await armed)) {
        return false;
      }

      const activityCard = input.closest(".activity-item, article");
      const title = activityCard?.querySelector("h2");
      const nativeDoneTarget = title?.parentElement;
      if (!nativeDoneTarget) {
        return false;
      }
      nativeDoneTarget.click();
      detailPopup = await waitForElement(() => {
        const popups = Array.from(document.querySelectorAll("lc-activity-detail"));
        return popups.at(-1) || null;
      }, 2600);
      if (!detailPopup) {
        return false;
      }
      const primaryButton = await waitForElement(() => {
        const buttons = Array.from(
          detailPopup.querySelectorAll("button.activity-detail-modal__primary")
        );
        const button = buttons.at(-1);
        return button && !button.disabled ? button : null;
      }, 3200);
      if (!primaryButton) {
        return false;
      }

      const completed = new Promise((resolve) => {
        const timeoutId = window.setTimeout(() => resolve(false), 9400);
        marker.addEventListener(
          NATIVE_ACTIVITY_DONE_FINISHED_EVENT,
          () => {
            window.clearTimeout(timeoutId);
            resolve(marker.dataset.didarNativeActivityDoneResult === "true");
          },
          { once: true }
        );
      });
      primaryButton.click();
      return await completed;
    } finally {
      if (marker.dataset.didarNativeActivityDoneResult !== "true") {
        detailPopup?.querySelector("[lc-popup-close]")?.click();
      }
      marker.remove();
    }
  }

  function syncCompletedActivityView(activity) {
    activitySyncSequence += 1;
    const requestId = `${Date.now()}-${activitySyncSequence}`;
    return new Promise((resolve) => {
      let settled = false;
      const marker = document.createElement("meta");
      marker.hidden = true;
      marker.dataset.didarActivityCompletionRequest = requestId;
      const dealId = Core.text(
        activity?.DealId || location.pathname.match(/\/deal\/([0-9a-f-]{36})/i)?.[1]
      );
      marker.textContent = JSON.stringify({
        requestId,
        dealId,
        activity: Core.cloneJson(activity)
      });
      const finish = (synced) => {
        if (settled) {
          return;
        }
        settled = true;
        window.clearTimeout(timeoutId);
        marker.removeEventListener(ACTIVITY_COMPLETION_SYNCED_EVENT, handleSynced);
        marker.remove();
        resolve(Boolean(synced));
      };
      const handleSynced = () => {
        finish(marker.dataset.didarActivityCompletionResult === "true");
      };
      marker.addEventListener(ACTIVITY_COMPLETION_SYNCED_EVENT, handleSynced);
      const timeoutId = window.setTimeout(() => finish(false), 1200);
      document.documentElement.appendChild(marker);
      marker.dispatchEvent(new Event(ACTIVITY_COMPLETED_EVENT, { bubbles: true }));
    });
  }

  function removeStaleCompletedChecklistFromDom(activity) {
    const activityId = Core.text(activity?.Id).toLowerCase();
    const expectedRows = Core.parseTodoRows(activity?.ResultNote);
    if (!Core.GUID_PATTERN.test(activityId) || !expectedRows.length) {
      return false;
    }
    let changed = false;
    const expectedLabels = expectedRows.map((row) => row.label);
    document.querySelectorAll(".activity-item, article").forEach((card) => {
      const lists = Array.from(card.querySelectorAll("ul.todo-list"));
      if (!lists.length) {
        return;
      }
      if (lists.length === 1 && card.closest("lc-activity-list-brief") !== completedActivityHost()) {
        return;
      }
      const belongsToActivity = lists.some((list) =>
        [list.dataset.didarStableActivityId, list.dataset.didarActivityId]
          .map((value) => Core.text(value).toLowerCase())
          .includes(activityId)
      );
      if (!belongsToActivity) {
        return;
      }
      const candidates = lists.filter((list) => {
        const rows = visibleRows(list);
        return rows.length === expectedLabels.length &&
          rows.every((row, index) => row.label === expectedLabels[index]);
      });
      if (!candidates.length || (lists.length > 1 && candidates.length < 2)) {
        return;
      }
      // Didar places ResultNote after Note. A later native render may keep only
      // one stale checklist, so apply the verified state to that list as well.
      const currentList = candidates.at(-1);
      currentList.querySelectorAll(':scope > li input[type="checkbox"]').forEach((input, index) => {
        if (expectedRows[index]) {
          changed ||= input.checked !== expectedRows[index].checked;
          setCheckboxState(input, expectedRows[index].checked);
        }
      });
      candidates.forEach((list) => {
        if (list !== currentList) {
          list.remove();
          changed = true;
        }
      });
    });
    return changed;
  }

  function rememberCompletedActivity(activity) {
    const activityId = Core.text(activity?.Id).toLowerCase();
    if (!Core.GUID_PATTERN.test(activityId) || activity?.IsDone !== true) {
      return;
    }
    confirmedCompletedActivities.delete(activityId);
    confirmedCompletedActivities.set(activityId, Core.cloneJson(activity));
    while (confirmedCompletedActivities.size > 100) {
      confirmedCompletedActivities.delete(confirmedCompletedActivities.keys().next().value);
    }
  }

  function bindCompletedActivityCard(activity) {
    const activityId = Core.text(activity?.Id).toLowerCase();
    const title = normalizedTitle(activity?.Title);
    const expectedRows = Core.parseTodoRows(activity?.ResultNote);
    if (!Core.GUID_PATTERN.test(activityId) || !title || !expectedRows.length) {
      return null;
    }
    const candidates = Array.from(document.querySelectorAll(".activity-item, article"))
      .filter((card) => !card.closest("lc-activity-detail"))
      .filter((card) => !card.classList.contains("didar-completed-activity-fallback"))
      .filter((card) => normalizedTitle(card.querySelector("h2")?.textContent) === title)
      .filter((card) => {
        const ids = Array.from(card.querySelectorAll("ul.todo-list"))
          .flatMap((list) => [list.dataset.didarStableActivityId, list.dataset.didarActivityId])
          .map((value) => Core.text(value).toLowerCase())
          .filter((value) => Core.GUID_PATTERN.test(value));
        return !ids.length || ids.every((id) => id === activityId);
      })
      .filter((card) => Array.from(card.querySelectorAll("ul.todo-list")).some((list) => {
        const rows = visibleRows(list);
        return rows.length === expectedRows.length && rows.every((row, index) =>
          row.label === expectedRows[index].label && row.checked === expectedRows[index].checked
        );
      }));
    const historyHost = completedActivityHost();
    const historyCards = candidates.filter(
      (candidate) => candidate.closest("lc-activity-list-brief") === historyHost
    );
    const historyCard = historyCards.length === 1 ? historyCards[0] : null;
    const alreadyBound = candidates.find((card) =>
      Array.from(card.querySelectorAll("ul.todo-list")).some((list) =>
        [list.dataset.didarStableActivityId, list.dataset.didarActivityId]
          .map((value) => Core.text(value).toLowerCase())
          .includes(activityId)
      )
    );
    // A late Angular history render can reuse a title that is already present in
    // another list. Prefer the actual history host so the fresh card receives
    // the verified id before duplicate-note cleanup and product reattachment.
    const card = historyCard || alreadyBound || (candidates.length === 1 ? candidates[0] : null);
    card?.querySelectorAll("ul.todo-list").forEach((list) => {
      list.dataset.didarActivityId = activityId;
      list.dataset.didarStableActivityId = activityId;
      list.dataset.didarActivityResolution = "server-confirmed-completed";
    });
    return card || null;
  }

  function scheduleCompletedChecklistDomSync(activity) {
    rememberCompletedActivity(activity);
    [0, 80, 240, 600, 1400, 3000, 6000].forEach((wait) => {
      window.setTimeout(() => {
        bindCompletedActivityCard(activity);
        removeStaleCompletedChecklistFromDom(activity);
        enhancePlanProductFields();
      }, wait);
    });
  }

  function plannedActivityCards(activityId, preferredInput = null) {
    const normalizedId = Core.text(activityId).toLowerCase();
    const plannedHost = plannedActivityHost();
    if (!Core.GUID_PATTERN.test(normalizedId)) {
      return [];
    }
    const cards = new Set();
    const preferredCard = preferredInput?.closest?.(".activity-item, article");
    if (preferredCard?.closest("lc-activity-list-brief") === plannedHost) {
      cards.add(preferredCard);
    }
    plannedHost?.querySelectorAll("ul.todo-list").forEach((list) => {
      const ids = [list.dataset.didarActivityId, list.dataset.didarStableActivityId]
        .map((value) => Core.text(value).toLowerCase());
      if (ids.includes(normalizedId)) {
        const card = list.closest(".activity-item, article");
        if (card) {
          cards.add(card);
        }
      }
    });
    plannedHost
      ?.querySelectorAll(`[data-activity-id="${normalizedId}"]`)
      .forEach((element) => {
        const card = element.matches(".activity-item, article")
          ? element
          : element.closest(".activity-item, article");
        if (card) {
          cards.add(card);
        }
      });
    return Array.from(cards);
  }

  function nativeCompletedActivityCardExists(activityId) {
    const host = completedActivityHost();
    if (!host) {
      return false;
    }
    return Array.from(
      host.querySelectorAll(
        "ul.todo-list[data-didar-activity-id], ul.todo-list[data-didar-stable-activity-id]"
      )
    ).some((list) => {
      if (list.closest(".didar-completed-activity-fallback")) {
        return false;
      }
      return [list.dataset.didarActivityId, list.dataset.didarStableActivityId]
        .map((value) => Core.text(value).toLowerCase())
        .includes(activityId);
    });
  }

  function reconcileCompletedActivityFallback(activityId) {
    const normalizedId = Core.text(activityId).toLowerCase();
    if (!Core.GUID_PATTERN.test(normalizedId) || !nativeCompletedActivityCardExists(normalizedId)) {
      return false;
    }
    document
      .querySelectorAll(`.didar-completed-activity-fallback[data-activity-id="${normalizedId}"]`)
      .forEach((card) => card.remove());
    return true;
  }

  function renderCompletedActivityFallback(activity) {
    const activityId = Core.text(activity?.Id).toLowerCase();
    const host = completedActivityHost();
    if (!host || !Core.GUID_PATTERN.test(activityId) || nativeCompletedActivityCardExists(activityId)) {
      return false;
    }
    const existing = host.querySelector(
      `.didar-completed-activity-fallback[data-activity-id="${activityId}"]`
    );
    if (existing) {
      return true;
    }

    const card = document.createElement("article");
    card.className = "activity-item didar-completed-activity-fallback";
    card.dataset.activityId = activityId;
    card.setAttribute("dir", "rtl");

    const header = document.createElement("div");
    header.className = "didar-completed-activity-fallback__header";
    const state = document.createElement("span");
    state.className = "didar-completed-activity-fallback__state";
    state.textContent = "✓";
    state.setAttribute("aria-hidden", "true");
    const title = document.createElement("h2");
    title.textContent = normalizedTitle(activity.Title);
    const meta = document.createElement("span");
    meta.className = "didar-completed-activity-fallback__meta";
    meta.textContent = "همین حالا تکمیل شد";
    header.append(state, title, meta);

    const note = document.createElement("div");
    note.className = "didar-completed-activity-fallback__note ck-content";
    note.innerHTML = Core.text(activity.ResultNote || activity.Note);
    note.querySelectorAll("ul.todo-list").forEach((list) => {
      list.dataset.didarActivityId = activityId;
      list.dataset.didarStableActivityId = activityId;
      list.dataset.didarActivityResolution = "server-confirmed-completed";
    });
    card.append(header, note);

    const target = host.querySelector(".activity-main-list") || host;
    target.prepend(card);
    scheduleScan();
    return true;
  }

  function refreshNativeActivityHistory() {
    const details = document.querySelector("lc-deal-details");
    if (!details) {
      return false;
    }
    const labels = Array.from(
      details.querySelectorAll("button, a, [role='tab'], li, span")
    ).filter((element) => element.children.length === 0);
    const allTab = labels.find((element) => {
      if (Core.normalizeLabel(element.textContent) !== "همه") {
        return false;
      }
      let container = element.parentElement;
      for (let depth = 0; container && depth < 4; depth += 1) {
        const text = Core.normalizeLabel(container.textContent);
        if (text.includes("فعالیت ها") && text.includes("یادداشت ها")) {
          return true;
        }
        container = container.parentElement;
      }
      return false;
    });
    const target = allTab?.closest("button, a, [role='tab'], li") || allTab;
    if (!target || typeof target.click !== "function") {
      return false;
    }
    target.click();
    return true;
  }

  function reconcileCompletedActivityDom(activity, preferredInput = null) {
    const activityId = Core.text(activity?.Id).toLowerCase();
    if (!Core.GUID_PATTERN.test(activityId) || activity?.IsDone !== true) {
      return false;
    }
    const cards = plannedActivityCards(activityId, preferredInput);
    cards.forEach((card) => {
      const host = card.closest("lc-activity-list-brief");
      card.remove();
      if (host && !host.querySelector(".didar-created-activity-fallback")) {
        host.classList.remove("didar-has-created-activity-fallback");
      }
    });
    if (cards.length) {
      scheduleScan();
    }
    return cards.length > 0;
  }

  function scheduleCompletedActivityReconciliation(activity, preferredInput = null) {
    rememberCompletedActivity(activity);
    bindCompletedActivityCard(activity);
    const rendered = renderCompletedActivityFallback(activity);
    const removed = reconcileCompletedActivityDom(activity, preferredInput);
    window.setTimeout(refreshNativeActivityHistory, 120);
    [250, 700, 1600, 3200, 6000].forEach((wait) => {
      window.setTimeout(() => {
        bindCompletedActivityCard(activity);
        removeStaleCompletedChecklistFromDom(activity);
        renderCompletedActivityFallback(activity);
        reconcileCompletedActivityDom(activity);
        reconcileCompletedActivityFallback(activity.Id);
        enhancePlanProductFields();
      }, wait);
    });
    return rendered || removed;
  }

  async function cleanupCompletedDuplicateNoteUnlocked(activityId) {
    if (activeActivitySaves.has(activityId)) {
      return;
    }
    activeActivitySaves.add(activityId);
    try {
      const activity = await apiRequest("activity/GetActivityById", {
        body: { Id: activityId }
      });
      if (
        activity?.IsDone !== true ||
        activity?.IsDeleted ||
        !activity?.CanEdit ||
        !normalizedTitle(activity?.Title).startsWith(PLAN_TITLE_PREFIX) ||
        !Core.text(activity?.Note)
      ) {
        return;
      }
      let resultNote = activity.ResultNote;
      if (!Core.parseTodoRows(resultNote).length && Core.parseTodoRows(activity.Note).length) {
        const resultDocument = new DOMParser().parseFromString(Core.text(resultNote), "text/html");
        const source = new DOMParser().parseFromString(activity.Note, "text/html");
        source.querySelectorAll("ul.todo-list").forEach((list) =>
          resultDocument.body.appendChild(list.cloneNode(true)));
        resultNote = resultDocument.body.innerHTML;
      }
      const cleanedNote = Core.removeMatchingTodoLists(activity.Note, resultNote);
      if (cleanedNote === Core.text(activity.Note)) {
        return;
      }
      await apiRequest("activity/SaveActivity", {
        body: Core.buildSavePayload({ ...activity, ResultNote: resultNote }, "Note", cleanedNote, false)
      });
      const verified = await readActivityUntil(
        activityId,
        (value) =>
          value?.IsDone === true &&
          checklistMatches(value?.ResultNote, resultNote) &&
          !Core.hasMatchingTodoList(value?.Note, value?.ResultNote)
      );
      if (!verified) {
        throw new Error("سرور حذف چک‌لیست تکراری از Note را تأیید نکرد.");
      }
      if (Core.hasMatchingTodoList(verified?.Note, verified?.ResultNote)) {
        throw new Error("سرور حذف چک‌لیست تکراری از Note را تأیید نکرد.");
      }
      await syncCompletedActivityView(verified);
      rememberCompletedActivity(verified);
      scheduleCompletedChecklistDomSync(verified);
      lastInteraction = `چک‌لیست تکراری Note حذف شد: ${activity.Title}`;
      toast("چک‌لیست تکراری حذف شد و متن‌های دیگر Note حفظ شدند", "success");
    } finally {
      activeActivitySaves.delete(activityId);
    }
  }

  function cleanupCompletedDuplicateNote(activityId) {
    return withOperationLock(
      `activity:${activityId}`,
      () => cleanupCompletedDuplicateNoteUnlocked(activityId)
    );
  }

  function scheduleCompletedDuplicateCleanup() {
    if (!settings.autoPlanChecklist || document.readyState === "loading") {
      return;
    }
    document.querySelectorAll(".activity-item, article").forEach((card) => {
      const lists = Array.from(card.querySelectorAll("ul.todo-list"));
      if (!lists.length ||
          !normalizedTitle(card.querySelector("h2")?.textContent).startsWith(PLAN_TITLE_PREFIX)) {
        return;
      }
      const activityId = activityIdForCard(card);
      const signature = JSON.stringify(lists.map((list) => visibleRows(list)));
      const cleanupKey = `${activityId}:${signature}`;
      if (!activityId || completedNoteCleanups.has(cleanupKey) ||
          activeActivitySaves.has(activityId) || activitySaveQueues.has(activityId)) {
        return;
      }
      const cleanup = cleanupCompletedDuplicateNote(activityId).catch((error) => {
        lastInteraction = `خطای حذف Note تکراری: ${error?.message || "عملیات انجام نشد"}`;
        toast(error?.message || "حذف Note تکراری انجام نشد.", "error");
      });
      completedNoteCleanups.set(cleanupKey, cleanup);
    });
  }

  function autoCompletionState(activity, updatedNote, targetChecked) {
    if (
      activity?.IsDone !== false ||
      !targetChecked ||
      !Core.normalizeLabel(activity.Title).startsWith(PLAN_TITLE_PREFIX)
    ) {
      return { shouldComplete: false, missing: [] };
    }
    const states = new Map(
      Core.parseTodoRows(updatedNote).map((row) => [Core.normalizeLabel(row.label), row.checked])
    );
    if (states.get("ناموفق شدن طرح") === true) {
      return { shouldComplete: true, missing: [] };
    }
    if (states.get(DELIVERY_TODO) !== true) {
      return { shouldComplete: false, missing: [] };
    }
    const missing = DELIVERY_PREREQUISITES.filter((label) => states.get(label) !== true);
    return { shouldComplete: missing.length === 0, missing };
  }

  async function saveCheckboxChange(input, requestedChecked = input.checked) {
    const dealId = currentDealId();
    const caseId = Core.text(location.pathname.match(/\/case\/([0-9a-f-]{36})/i)?.[1]).toLowerCase();
    markBusy(input, true);
    setCheckboxState(input, !requestedChecked);
    let activityId;
    try {
      const list = input.closest("ul.todo-list");
      const index = Array.from(list?.querySelectorAll(":scope > li") || []).indexOf(input.closest("li"));
      try {
        activityId = resolveActivityId(input, index);
      } catch {
        await loadPlanActivityBindings(dealId, true);
        if (currentDealId() !== dealId || !input.isConnected) {
          throw new Error("صفحه فعالیت تغییر کرد؛ این کلیک ذخیره نشد.");
        }
        activityId = resolveActivityId(input, index);
      }
    } catch (error) {
      setCheckboxState(input, !requestedChecked);
      markBusy(input, false);
      toast(error.message, "error");
      return;
    }
    const list = input.closest("ul.todo-list");
    const item = input.closest("li");
    const index = Array.from(list?.querySelectorAll(":scope > li") || []).indexOf(item);
    const description = item?.querySelector(".todo-list__label__description");
    const label = Core.normalizeLabel(description?.textContent || item?.textContent);
    if (!list || index < 0 || !label) {
      markBusy(input, false);
      toast("ساختار این چک‌لیست قابل شناسایی نیست.", "error");
      return;
    }
    if (settings.confirmBeforeSave) {
      const action = requestedChecked ? "تیک‌زدن" : "برداشتن تیک";
      if (!window.confirm(`${action} «${label}» ذخیره شود؟`)) {
        markBusy(input, false);
        return;
      }
    }
    const durableOperation = prepareDurableOperation({
      id: `activity:${activityId}:${index}`,
      type: "activity-checkbox",
      lockName: `activity:${activityId}`,
      activityId,
      dealId,
      caseId,
      index,
      label,
      targetChecked: Boolean(requestedChecked)
    });
    try {
      await putOutboxOperation(durableOperation);
    } catch (error) {
      markBusy(input, false);
      toast(error?.message || "درخواست ذخیره در صف پایدار ثبت نشد.", "error");
      return;
    }
    const previous = activitySaveQueues.get(activityId) || Promise.all(
      Array.from(completedNoteCleanups.entries())
        .filter(([key]) => key.startsWith(`${activityId}:`))
        .map(([, operation]) => operation)
    );
    const operation = previous.then(() => performCheckboxChange(
      input,
      requestedChecked,
      activityId,
      dealId,
      durableOperation
    ));
    activitySaveQueues.set(activityId, operation);
    return operation.finally(() => {
      markBusy(input, false);
      if (activitySaveQueues.get(activityId) === operation) {
        activitySaveQueues.delete(activityId);
      }
    });
  }

  function checklistMatches(note, expectedNote) {
    const rows = Core.parseTodoRows(note);
    const expected = Core.parseTodoRows(expectedNote);
    return rows.length === expected.length && rows.every((row, index) =>
      row.label === expected[index].label && row.checked === expected[index].checked
    );
  }

  async function persistChecklistIntent(intent) {
    const activityId = Core.text(intent?.activityId).toLowerCase();
    const index = Number(intent?.index);
    const label = Core.normalizeLabel(intent?.label);
    const targetChecked = Boolean(intent?.targetChecked);
    const identity = await currentIdentity(true);
    let lastError = null;

    for (let attempt = 1; attempt <= 3; attempt += 1) {
      try {
        const activity = await apiRequest("activity/GetActivityById", {
          body: { Id: activityId },
          retry: true
        });
        if (!activity || Core.text(activity.Id).toLowerCase() !== activityId) {
          throw new Error("فعالیت انتخاب‌شده از سرور دریافت نشد.");
        }
        if (Core.GUID_PATTERN.test(Core.text(intent.caseId))) {
          if (Core.text(activity.CaseId).toLowerCase() !== Core.text(intent.caseId).toLowerCase()) {
            throw new Error("این فعالیت متعلق به کارت انتخاب‌شده نیست؛ ذخیره انجام نشد.");
          }
        } else if (Core.GUID_PATTERN.test(Core.text(activity.DealId)) &&
            Core.text(activity.DealId).toLowerCase() !== Core.text(intent.dealId).toLowerCase()) {
          throw new Error("این فعالیت متعلق به معامله انتخاب‌شده نیست؛ ذخیره انجام نشد.");
        }
        if (activity.IsDeleted || !activity.CanEdit) {
          throw new Error("این کاربر اجازه ویرایش فعالیت را ندارد.");
        }
        const todoField = Core.todoField(activity);
        const serverNote = Core.todoNote(activity);
        const serverRows = Core.parseTodoRows(serverNote);
        if (serverRows[index]?.label !== label) {
          throw new Error("ساختار چک‌لیست سرور با فعالیت نمایش‌داده‌شده یکسان نیست.");
        }
        if (intent.completionOnly && (!serverRows[index].checked ||
            !autoCompletionState(activity, serverNote, true).shouldComplete)) {
          return { activity, identity, completion: { shouldComplete: false, missing: [] }, alreadySynchronized: true };
        }
        const alreadySynchronized = serverRows[index].checked === targetChecked;
        const updatedNote = alreadySynchronized
          ? serverNote
          : Core.patchTodo(serverNote, index, label, targetChecked);
        const completion = autoCompletionState(activity, updatedNote, targetChecked);
        if (completion.shouldComplete && !activity.CanDone) {
          throw new Error("این کاربر اجازه تکمیل فعالیت را ندارد.");
        }

        if (completion.shouldComplete) {
          const completedActivity = {
            ...activity,
            IsDone: true,
            Note: Core.removeMatchingTodoLists(activity.Note, updatedNote)
          };
          const completedResultNote = Core.replaceMatchingTodoLists(
            activity.ResultNote,
            updatedNote
          );
          await apiRequest("activity/SaveActivity", {
            body: Core.buildSavePayload(
              completedActivity,
              "ResultNote",
              completedResultNote,
              true
            ),
            retry: true
          });
        } else if (!alreadySynchronized) {
          await apiRequest("activity/SaveActivity", {
            body: Core.buildSavePayload(activity, todoField, updatedNote, false),
            retry: true
          });
        }

        const verified = await readActivityUntil(activityId, (value) => {
          if (!value) {
            return false;
          }
          const rows = Core.parseTodoRows(Core.todoNote(value));
          const checkboxSaved = rows[index]?.label === label && rows[index]?.checked === targetChecked;
          const completionSaved = !completion.shouldComplete || (
            value.IsDone === true &&
            checklistMatches(value.ResultNote, updatedNote) &&
            !Core.hasMatchingTodoList(value.Note, updatedNote)
          );
          return checkboxSaved && completionSaved;
        });
        const verifiedRows = Core.parseTodoRows(Core.todoNote(verified));
        if (verifiedRows[index]?.label !== label || verifiedRows[index]?.checked !== targetChecked) {
          throw new Error("سرور وضعیت جدید چک‌باکس را تأیید نکرد.");
        }
        if (completion.shouldComplete && verified.IsDone !== true) {
          throw new Error("سرور تکمیل فعالیت را تأیید نکرد.");
        }
        return { activity: verified, identity, completion, alreadySynchronized };
      } catch (error) {
        lastError = error;
        if (
          error?.code === "DIDAR_PERMISSION_DENIED" ||
          error?.code === "DIDAR_AUTH_REQUIRED" ||
          attempt === 3
        ) {
          break;
        }
        await delay(retryDelay(attempt));
      }
    }
    throw lastError || new Error("ذخیره چک‌لیست انجام نشد.");
  }

  async function saveBoardChecklist(intent) {
    const activityId = Core.text(intent.activityId).toLowerCase();
    const dealId = Core.text(intent.dealId).toLowerCase();
    if (!settings.enabled || !Core.GUID_PATTERN.test(activityId) || !Core.GUID_PATTERN.test(dealId)) {
      throw new Error("شناسه فعالیت یا معامله برای ذخیره معتبر نیست.");
    }
    const operation = prepareDurableOperation({
      id: `activity:${activityId}:${intent.index}`,
      type: "activity-checkbox",
      lockName: `activity:${activityId}`,
      activityId,
      dealId,
      index: intent.index,
      label: intent.label,
      targetChecked: intent.targetChecked
    });
    await putOutboxOperation(operation);
    const previous = activitySaveQueues.get(activityId) || Promise.resolve();
    const queued = previous.then(() => runDurableOperation(
      operation,
      persistChecklistIntent,
      { staged: true }
    ));
    activitySaveQueues.set(activityId, queued);
    activeActivitySaves.add(activityId);
    try {
      const result = await queued;
      const activity = result?.activity || await apiRequest("activity/GetActivityById", {
        body: { Id: activityId }, retry: true
      });
      const row = Core.parseTodoRows(Core.todoNote(activity))[intent.index];
      if (row?.label !== Core.normalizeLabel(intent.label) ||
          row?.checked !== Boolean(intent.targetChecked)) {
        throw new Error("ذخیره چک‌باکس در سرور تأیید نشد.");
      }
      publishVerifiedActivity(activity, dealId);
      return activity;
    } finally {
      activeActivitySaves.delete(activityId);
      if (activitySaveQueues.get(activityId) === queued) activitySaveQueues.delete(activityId);
    }
  }

  async function performCheckboxChange(
    input,
    requestedChecked,
    resolvedActivityId,
    requestedDealId,
    durableOperation
  ) {
    const todoList = input.closest("ul.todo-list");
    const item = input.closest("li");
    const items = Array.from(todoList?.querySelectorAll(":scope > li") || []);
    const index = items.indexOf(item);
    const description = item?.querySelector(".todo-list__label__description");
    const label = Core.normalizeLabel(description?.textContent || item?.textContent);
    const targetChecked = Boolean(requestedChecked);
    const previousChecked = !targetChecked;

    setCheckboxState(input, previousChecked);
    if (!todoList || index < 0 || !label) {
      toast("ساختار این چک‌لیست قابل شناسایی نیست.", "error");
      return;
    }
    let activityId;
    try {
      activityId = resolvedActivityId || resolveActivityId(input, index);
    } catch (error) {
      toast(error.message, "error");
      return;
    }
    const dealId = requestedDealId || currentDealId();
    if (!durableOperation || durableOperation.activityId !== activityId ||
        durableOperation.index !== index || durableOperation.label !== label) {
      throw new Error("هویت درخواست ذخیره چک‌لیست تغییر کرده است.");
    }

    activeActivitySaves.add(activityId);
    markBusy(input, true);
    try {
      const result = await runDurableOperation(
        durableOperation,
        persistChecklistIntent,
        { staged: true }
      );
      if (!result) {
        return;
      }
      const { activity, identity, completion, alreadySynchronized } = result;
      publishVerifiedActivity(activity, dealId);
      setCheckboxState(input, targetChecked);
      input.dataset.didarTodoLastUpdate = Core.text(activity.LastUpdateTime);
      if (completion.shouldComplete) {
        const modelSynchronized = await syncCompletedActivityView(activity);
        scheduleCompletedChecklistDomSync(activity);
        if (!modelSynchronized) {
          scheduleCompletedActivityReconciliation(activity, input);
        }
        lastInteraction = `فعالیت تکمیل شد: ${label}`;
        toast(`تیک ذخیره و فعالیت توسط ${identity.displayName} تکمیل شد`, "success");
      } else if (completion.missing.length) {
        lastInteraction = `ذخیره شد؛ فعالیت باز ماند: ${completion.missing.join("، ")}`;
        toast(`تیک ذخیره شد؛ پیش‌نیازهای تکمیل نشده: ${completion.missing.join("، ")}`);
      } else {
        lastInteraction = alreadySynchronized ? `همگام با سرور: ${label}` : `ذخیره موفق: ${label}`;
        toast(alreadySynchronized ? "وضعیت نمایش با سرور همگام شد" : `ذخیره شد توسط ${identity.displayName}`);
      }
    } catch (error) {
      setCheckboxState(input, previousChecked);
      lastInteraction = `خطا: ${error?.message || "ذخیره انجام نشد"}`;
      toast("ذخیره تأیید نشد؛ عملیات برای تلاش مجدد نگه داشته شد.", "error");
    } finally {
      activeActivitySaves.delete(activityId);
      markBusy(input, false);
    }
  }

  function positionHitboxes() {
    hitboxFrame = null;
    hitboxRecords.forEach((record) => {
      const { input, hitbox } = record;
      if (!input.isConnected) {
        hitbox.remove();
        hitboxRecords.delete(record);
        return;
      }
      if (!settings.enabled) {
        hitbox.hidden = true;
        return;
      }

      const inputRect = input.getBoundingClientRect();
      let left = inputRect.left;
      let top = inputRect.top;
      let width = inputRect.width;
      let height = inputRect.height;
      if (width < 8 || height < 8) {
        const label = input.closest("label");
        const description = input.closest("li")?.querySelector(".todo-list__label__description");
        const labelRect = label?.getBoundingClientRect();
        const textRect = description?.getBoundingClientRect();
        const direction = label ? window.getComputedStyle(label).direction : "rtl";
        width = 18;
        height = 18;
        if (textRect) {
          left = direction === "rtl" ? textRect.right + 5 : textRect.left - width - 5;
          top = textRect.top + (textRect.height - height) / 2;
        } else if (labelRect) {
          left = direction === "rtl" ? labelRect.right + 5 : labelRect.left - width - 5;
          top = labelRect.top + (labelRect.height - height) / 2;
        }
      }

      const visible =
        width >= 8 &&
        height >= 8 &&
        top + height > 0 &&
        left + width > 0 &&
        top < window.innerHeight &&
        left < window.innerWidth;
      hitbox.hidden = !visible;
      if (!visible) {
        return;
      }
      hitbox.style.left = `${left}px`;
      hitbox.style.top = `${top}px`;
      hitbox.style.width = `${width}px`;
      hitbox.style.height = `${height}px`;
    });
  }

  function scheduleHitboxPosition() {
    if (hitboxFrame === null) {
      hitboxFrame = window.requestAnimationFrame(positionHitboxes);
    }
  }

  function ensureHitbox(input) {
    if (hitboxByInput.has(input)) {
      scheduleHitboxPosition();
      return;
    }
    const hitbox = document.createElement("button");
    hitbox.type = "button";
    hitbox.className = "didar-todo-hitbox";
    hitbox.title = "تغییر و ذخیره این چک‌باکس";
    hitbox.setAttribute("aria-label", "تغییر و ذخیره این چک‌باکس");
    hitbox.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (!settings.enabled || input.closest("li")?.classList.contains("didar-todo-busy")) {
        return;
      }
      const description = input.closest("li")?.querySelector(".todo-list__label__description");
      const label = Core.normalizeLabel(description?.textContent || input.closest("li")?.textContent);
      const targetChecked = !input.checked;
      lastInteraction = `کلیک دریافت شد: ${label || "چک‌باکس"}`;
      void saveCheckboxChange(input, targetChecked);
    });
    document.body.appendChild(hitbox);
    hitboxByInput.set(input, hitbox);
    hitboxRecords.add({ input, hitbox });
    scheduleHitboxPosition();
  }

  function enhanceCheckbox(input) {
    if (input.closest('[contenteditable="true"], .ck-editor__editable')) {
      return;
    }
    if (processed.has(input)) {
      ensureHitbox(input);
      return;
    }
    processed.add(input);
    input.classList.add("didar-todo-checkbox");
    input.title = "ذخیره مستقیم در دیدار";
    ensureHitbox(input);
  }

  function handleChecklistClick(event) {
    if (!settings.enabled || !(event.target instanceof Element)) {
      return;
    }
    if (event.target.closest(".didar-todo-hitbox")) {
      return;
    }
    const input = event.target.closest("input.didar-todo-checkbox");
    if (!input) {
      const label = event.target.closest("label");
      if (label?.querySelector("input.didar-todo-checkbox")) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
      return;
    }
    const todoList = input?.closest("ul.todo-list");
    if (!todoList || event.button !== 0) {
      return;
    }

    // Checkbox pre-activation has already applied the requested value here.
    // Cancelling the click keeps Didar's read-only handler out of the way.
    const targetChecked = input.checked;
    const previousChecked = !targetChecked;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (input.closest("li")?.classList.contains("didar-todo-busy")) {
      return;
    }
    const description = input.closest("li")?.querySelector(".todo-list__label__description");
    const label = Core.normalizeLabel(description?.textContent || input.closest("li")?.textContent);
    lastInteraction = `کلیک دریافت شد: ${label || "چک‌باکس"}`;
    queueMicrotask(() => {
      if (input.isConnected) {
        setCheckboxState(input, previousChecked);
      }
    });
    void saveCheckboxChange(input, targetChecked);
  }

  function preserveStableMappings() {
    document.querySelectorAll("ul.todo-list").forEach((todoList) => {
      const mappedId = Core.text(todoList.dataset.didarActivityId);
      if (Core.GUID_PATTERN.test(mappedId)) {
        todoList.dataset.didarStableActivityId = mappedId;
      }
    });
  }

  function bindPlanActivityCardsFromServer(dealId, freshSnapshot = false) {
    if (dealId !== currentDealId()) {
      return;
    }
    const activities = rememberedDealPlanActivities.get(dealId);
    if (!activities) {
      return;
    }
    const cards = Array.from(document.querySelectorAll("lc-deal-details .activity-item, lc-deal-details article"))
      .filter((card) => !card.closest("lc-activity-detail"))
      .filter((card) => !card.parentElement?.closest(".activity-item, article"));
    cards.forEach((card) => {
      const title = normalizedTitle(card.querySelector("h2")?.textContent);
      const lists = Array.from(card.querySelectorAll("ul.todo-list"));
      const matching = activities.filter((activity) => normalizedTitle(activity.Title) === title);
      const knownIds = lists.flatMap((list) =>
        [list.dataset.didarStableActivityId, list.dataset.didarActivityId]
      ).map((value) => Core.text(value).toLowerCase());
      let activity = matching.find((value) => knownIds.includes(Core.text(value.Id).toLowerCase()));
      // A title alone is safe only when both the server and the visible list contain one record.
      if (!activity && !knownIds.some((id) => Core.GUID_PATTERN.test(id)) &&
          (freshSnapshot || !lists.some((list) =>
        list.dataset.didarActivityResolution === "ambiguous"
      )) && matching.length === 1 && cards.filter((item) =>
        normalizedTitle(item.querySelector("h2")?.textContent) === title
      ).length === 1) {
        activity = matching[0];
      }
      if (!activity) {
        return;
      }
      const rows = Core.parseTodoRows(Core.todoNote(activity));
      lists.forEach((list) => {
        const visible = visibleRows(list);
        if (!visible.length || visible.length !== rows.length ||
            !visible.every((row, index) => row.label === rows[index].label)) {
          return;
        }
        const id = Core.text(activity.Id).toLowerCase();
        if (list.dataset.didarActivityId !== id) {
          list.dataset.didarActivityId = id;
        }
        if (list.dataset.didarStableActivityId !== id) {
          list.dataset.didarStableActivityId = id;
        }
        list.dataset.didarActivityResolution = "resolved-server-record";
      });
    });
  }

  function loadPlanActivityBindings(dealId, force = false) {
    if (!Core.GUID_PATTERN.test(dealId) || document.readyState === "loading" ||
        !document.querySelector("lc-deal-details")) {
      return Promise.resolve();
    }
    const pending = dealActivityBindingLoads.get(dealId);
    if (pending) {
      return pending;
    }
    if (!force && Date.now() - (dealActivityBindingAttempts.get(dealId) || 0) < 5000) {
      return Promise.resolve();
    }
    dealActivityBindingAttempts.set(dealId, Date.now());
    const operation = planActivitiesForDeal(dealId).then(() => {
      enhancePlanProductFields();
    }).finally(() => {
      dealActivityBindingLoads.delete(dealId);
    });
    dealActivityBindingLoads.set(dealId, operation);
    return operation;
  }

  function publishVerifiedActivity(activity, dealId) {
    const activities = rememberedDealPlanActivities.get(dealId);
    const id = Core.text(activity.Id).toLowerCase();
    if (activities) {
      const index = activities.findIndex((value) => Core.text(value.Id).toLowerCase() === id);
      if (index >= 0) {
        activities[index] = activity;
      }
    }
    if (dealId !== currentDealId()) {
      return;
    }
    if (activity.IsDone === true) {
      recentlyVerifiedChecklists.delete(id);
    } else {
      recentlyVerifiedChecklists.set(id, { activity, dealId, expiresAt: Date.now() + 15000 });
    }
    syncRecentlyVerifiedChecklists();
    const marker = document.createElement("meta");
    marker.dataset.didarActivitySaveRequest = JSON.stringify({ dealId, activity });
    document.documentElement.appendChild(marker);
    marker.dispatchEvent(new Event(ACTIVITY_SAVED_EVENT, { bubbles: true }));
    marker.remove();
  }

  function syncRecentlyVerifiedChecklists() {
    recentlyVerifiedChecklists.forEach((record, id) => {
      if (Date.now() > record.expiresAt) {
        recentlyVerifiedChecklists.delete(id);
        return;
      }
      if (record.dealId !== currentDealId()) {
        return;
      }
      const rows = Core.parseTodoRows(Core.todoNote(record.activity));
      document.querySelectorAll("ul.todo-list").forEach((list) => {
        if (![list.dataset.didarStableActivityId, list.dataset.didarActivityId]
          .some((value) => Core.text(value).toLowerCase() === id)) {
          return;
        }
        const visible = visibleRows(list);
        if (visible.length !== rows.length || !visible.every((row, index) => row.label === rows[index].label)) {
          return;
        }
        list.querySelectorAll(':scope > li input[type="checkbox"]').forEach((input, index) => {
          if (!input.closest("li")?.classList.contains("didar-todo-busy") &&
              input.checked !== rows[index].checked) {
            setCheckboxState(input, rows[index].checked);
          }
        });
      });
    });
  }

  function activityIdForCard(card) {
    const lists = Array.from(card.querySelectorAll("ul.todo-list"));
    const knownId = lists
      .flatMap((list) => [list.dataset.didarStableActivityId, list.dataset.didarActivityId])
      .map((value) => Core.text(value))
      .find((value) => Core.GUID_PATTERN.test(value));
    if (knownId) {
      return knownId;
    }
    if (!lists.length || Date.now() - (activityResolutionAttempts.get(card) || 0) < 500) {
      return "";
    }
    activityResolutionAttempts.set(card, Date.now());
    for (const todoList of [...lists].reverse()) {
      todoList.dataset.didarTodoChangedIndex = "0";
      todoList.dispatchEvent(new Event(RESOLVE_EVENT, { bubbles: true }));
      todoList.removeAttribute("data-didar-todo-changed-index");
      const resolvedId = Core.text(todoList.dataset.didarActivityId);
      if (Core.GUID_PATTERN.test(resolvedId)) {
        lists.forEach((list) => {
          list.dataset.didarStableActivityId = resolvedId;
        });
        return resolvedId;
      }
    }
    return "";
  }

  function matchingUnresolvedPlanActivityCard(activityId, title) {
    const normalizedActivityTitle = normalizedTitle(title);
    const matchingCards = Array.from(document.querySelectorAll(".activity-item, article"))
      .filter((card) => !card.closest("lc-activity-detail"))
      .filter((card) => !card.parentElement?.closest(".activity-item, article"))
      .filter(
        (card) => normalizedTitle(card.querySelector("h2")?.textContent) === normalizedActivityTitle
      );
    const alreadyBound = matchingCards.find((card) =>
      Array.from(card.querySelectorAll("ul.todo-list")).some((list) =>
        [list.dataset.didarStableActivityId, list.dataset.didarActivityId]
          .map((value) => Core.text(value).toLowerCase())
          .includes(activityId)
      )
    );
    if (alreadyBound) {
      return alreadyBound;
    }
    const unresolved = matchingCards.filter((card) => {
      const plannedHost = plannedActivityHost();
      if (plannedHost && card.closest("lc-activity-list-brief") !== plannedHost) {
        return false;
      }
      const list = card.querySelector("ul.todo-list");
      if (!list) {
        return false;
      }
      return ![list.dataset.didarStableActivityId, list.dataset.didarActivityId]
        .map((value) => Core.text(value))
        .some((value) => Core.GUID_PATTERN.test(value));
    });
    return unresolved.length === 1 ? unresolved[0] : null;
  }

  function scheduleCreatedActivityCardBinding(detail) {
    const activityId = Core.text(detail?.activityId).toLowerCase();
    const dealId = Core.text(detail?.dealId).toLowerCase();
    const title = normalizedTitle(detail?.title);
    if (
      !Core.GUID_PATTERN.test(activityId) ||
      !Core.GUID_PATTERN.test(dealId) ||
      !title.startsWith(PLAN_TITLE_PREFIX)
    ) {
      return;
    }

    const previous = pendingCreatedActivityBindings.get(activityId);
    if (previous) {
      window.clearTimeout(previous.timerId);
    }
    const binding = {
      activityId,
      dealId,
      title,
      deadline: Date.now() + 8000,
      timerId: null
    };
    pendingCreatedActivityBindings.set(activityId, binding);

    const attempt = () => {
      if (pendingCreatedActivityBindings.get(activityId) !== binding) {
        return;
      }
      if (currentDealId() !== dealId) {
        pendingCreatedActivityBindings.delete(activityId);
        return;
      }
      const card = matchingUnresolvedPlanActivityCard(activityId, title);
      const todoList = card?.querySelector("ul.todo-list");
      if (todoList) {
        todoList.dataset.didarActivityId = activityId;
        todoList.dataset.didarStableActivityId = activityId;
        todoList.dataset.didarActivityResolution = "resolved-created-event";
        activityResolutionAttempts.delete(card);
        pendingCreatedActivityBindings.delete(activityId);
        enhancePlanProductFields();
        return;
      }
      if (Date.now() >= binding.deadline) {
        pendingCreatedActivityBindings.delete(activityId);
        return;
      }
      binding.timerId = window.setTimeout(attempt, 160);
    };
    attempt();
  }

  function formatUnitPriceForDisplay(value) {
    const normalized = Core.text(value)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/[\s,٬،]/g, "");
    const match = normalized.match(/^(\d*)(?:\.(\d*))?$/);
    if (!match) {
      return normalized;
    }
    const whole = match[1] || "0";
    const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return match[2] === undefined ? grouped : `${grouped}.${match[2]}`;
  }

  function formatUnitPriceWhileTyping(input) {
    const caret = input.selectionStart ?? input.value.length;
    const significantBeforeCaret = input.value
      .slice(0, caret)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/[^\d.]/g, "").length;
    const formatted = formatUnitPriceForDisplay(input.value);
    input.value = formatted;
    if (document.activeElement !== input) {
      return;
    }
    if (!significantBeforeCaret) {
      input.setSelectionRange(0, 0);
      return;
    }
    let nextCaret = formatted.length;
    let seenSignificant = 0;
    for (let index = 0; index < formatted.length; index += 1) {
      if (/[\d.]/.test(formatted[index])) {
        seenSignificant += 1;
      }
      if (seenSignificant >= significantBeforeCaret) {
        nextCaret = index + 1;
        break;
      }
    }
    input.setSelectionRange(nextCaret, nextCaret);
  }

  function formatLongNumbersInDescription(value) {
    return String(value == null ? "" : value).replace(
      /[0-9٠-٩۰-۹]+(?:[,٬][0-9٠-٩۰-۹]+)*/g,
      (token) => {
        const digits = token.replace(/[,٬]/g, "");
        if (digits.length <= 3) {
          return digits;
        }
        const firstGroupLength = digits.length % 3 || 3;
        const groups = [digits.slice(0, firstGroupLength)];
        for (let index = firstGroupLength; index < digits.length; index += 3) {
          groups.push(digits.slice(index, index + 3));
        }
        return groups.join(",");
      }
    );
  }

  function formatDescriptionWhileTyping(input) {
    const original = input.value;
    const caret = input.selectionStart ?? original.length;
    const nextCaret = formatLongNumbersInDescription(original.slice(0, caret)).length;
    input.value = formatLongNumbersInDescription(original);
    if (document.activeElement === input) {
      const boundedCaret = Math.min(nextCaret, input.value.length);
      input.setSelectionRange(boundedCaret, boundedCaret);
    }
  }

  function normalizeUnitPriceInput(value) {
    const normalized = Core.text(value)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/[\s,٬،]/g, "");
    if (!normalized) {
      return "0";
    }
    if (!/^\d+(?:\.\d+)?$/.test(normalized)) {
      throw new Error("مبلغ واحد باید فقط عدد باشد.");
    }
    const [wholePart, fractionPart = ""] = normalized.split(".");
    const whole = wholePart.replace(/^0+(?=\d)/, "") || "0";
    const fraction = fractionPart.replace(/0+$/, "");
    return fraction ? `${whole}.${fraction}` : whole;
  }

  function activityProductMapping(deal, activityId, productTitle) {
    const key = productActivityMapKey(deal.Id, activityId);
    const stored = productActivityMappings.get(key);
    const storedItem = mappedProductItem(deal, stored);
    if (storedItem) {
      return { key, mapping: stored, item: storedItem };
    }
    const ownedItem = (deal.Items || []).find(
      (item) => Core.text(item.VariantId).toLowerCase() === activityId.toLowerCase()
    );
    if (ownedItem) {
      const siblings = (deal.Items || []).filter(
        (item) => Core.text(item.ProductId).toLowerCase() === Core.text(ownedItem.ProductId).toLowerCase()
      );
      rememberActivityProduct(deal.Id, activityId, ownedItem, siblings.indexOf(ownedItem));
      return {
        key,
        mapping: productActivityMappings.get(key),
        item: ownedItem
      };
    }
    const matches = (deal.Items || []).filter(
      (item) => normalizedTitle(item.Title) === normalizedTitle(productTitle)
    );
    const singleMatchId = Core.text(matches[0]?.Id).toLowerCase();
    const claimedByAnotherActivity = singleMatchId && Array.from(productActivityMappings.entries())
      .some(([mappingKey, mapping]) =>
        mappingKey.startsWith(`${Core.text(deal.Id).toLowerCase()}:`) &&
        mappingKey !== key &&
        Core.text(mapping?.dealProductId).toLowerCase() === singleMatchId
      );
    if (matches.length === 1 && !claimedByAnotherActivity) {
      rememberActivityProduct(deal.Id, activityId, matches[0], 0);
      return {
        key,
        mapping: productActivityMappings.get(key),
        item: matches[0]
      };
    }
    return { key, mapping: stored || null, item: null, ambiguous: matches.length > 1 };
  }

  function resolveBoardProduct(deal, activity, allActivities) {
    const activityId = Core.text(activity?.Id).toLowerCase();
    const dealId = Core.text(deal?.Id).toLowerCase();
    const productTitle = productTitleForActivity(activity?.Title);
    const key = productActivityMapKey(dealId, activityId);
    if (!Core.GUID_PATTERN.test(activityId) || !Core.GUID_PATTERN.test(dealId) || !productTitle) {
      return { item: null, mappingKey: key };
    }
    const matching = (deal.Items || []).filter(
      (item) => normalizedTitle(item.Title) === normalizedTitle(productTitle)
    );
    const claimedByOther = (item) => Array.from(productActivityMappings.entries()).some(
      ([mappingKey, mapping]) => mappingKey.startsWith(`${dealId}:`) && mappingKey !== key &&
        Core.text(mapping.dealProductId).toLowerCase() === Core.text(item.Id).toLowerCase()
    );
    const storedId = Core.text(productActivityMappings.get(key)?.dealProductId).toLowerCase();
    const storedItem = matching.find((item) => Core.text(item.Id).toLowerCase() === storedId);
    if (storedItem && !claimedByOther(storedItem)) {
      return { item: storedItem, mappingKey: key };
    }
    const owned = matching.filter(
      (item) => Core.text(item.VariantId).toLowerCase() === activityId && !claimedByOther(item)
    );
    if (owned.length === 1) {
      rememberActivityProduct(dealId, activityId, owned[0]);
      return { item: owned[0], mappingKey: key };
    }
    const siblings = (allActivities || []).filter(
      (item) => !item.IsDeleted && normalizedTitle(item.Title) === normalizedTitle(activity.Title)
    );
    if (siblings.length === 1 && Core.text(siblings[0].Id).toLowerCase() === activityId &&
        matching.length === 1 && !claimedByOther(matching[0])) {
      rememberActivityProduct(dealId, activityId, matching[0]);
      return { item: matching[0], mappingKey: key };
    }
    return { item: null, mappingKey: key, ambiguous: matching.length > 0 };
  }

  async function saveBoardProduct(intent) {
    const dealId = Core.text(intent.dealId).toLowerCase();
    const activityId = Core.text(intent.activityId).toLowerCase();
    const expectedItemId = Core.text(intent.itemId).toLowerCase();
    if (!settings.enabled || ![dealId, activityId, expectedItemId].every(
      (value) => Core.GUID_PATTERN.test(value)
    )) {
      throw new Error("شناسه فعالیت یا محصول برای ذخیره معتبر نیست.");
    }
    const [activity, deal, detail] = await Promise.all([
      apiRequest("activity/GetActivityById", { body: { Id: activityId }, retry: true }),
      apiRequest("deal/GetDealDetail", { body: { Id: dealId }, retry: true }),
      apiRequest("activity/GetDetailActivities", { body: { DealId: dealId }, retry: true })
    ]);
    if (Core.text(activity?.Id).toLowerCase() !== activityId ||
        Core.text(activity?.DealId).toLowerCase() !== dealId ||
        Core.text(deal?.Id).toLowerCase() !== dealId || activity?.IsDeleted || deal?.CanEdit === false) {
      throw new Error("فعالیت یا معامله دیگر قابل ویرایش نیست.");
    }
    const resolved = resolveBoardProduct(deal, activity, planActivitiesFromDetail(detail));
    if (Core.text(resolved.item?.Id).toLowerCase() !== expectedItemId) {
      throw new Error("اتصال فعالیت و محصول در سرور تغییر کرده است؛ چیزی ذخیره نشد.");
    }
    const operation = prepareDurableOperation({
      id: `product-fields:${dealId}:${activityId}`,
      type: "plan-product-fields",
      lockName: `deal-products:${dealId}`,
      dealId,
      activityId,
      mappingKey: resolved.mappingKey,
      dealProductId: expectedItemId,
      productTitle: productTitleForActivity(activity.Title),
      description: Core.text(intent.description),
      unitPrice: normalizeUnitPriceInput(intent.unitPrice),
      baseDescription: Core.text(intent.baseDescription),
      baseUnitPrice: normalizeUnitPriceInput(intent.baseUnitPrice ?? 0)
    });
    if (activeProductSaves.has(resolved.mappingKey)) {
      throw new Error("ذخیره دیگری برای این محصول در حال انجام است.");
    }
    activeProductSaves.add(resolved.mappingKey);
    try {
      await putOutboxOperation(operation);
      const verified = await runDurableOperation(
        operation,
        persistProductFieldsIntent,
        { staged: true }
      );
      if (!verified?.item) {
        throw new Error("ذخیره محصول در سرور تأیید نشد؛ فهرست را تازه‌سازی کنید.");
      }
      rememberActivityProduct(dealId, activityId, verified.item);
      if (currentDealId() === dealId) {
        rememberDealProductView(verified.deal);
        syncRememberedProductView();
      }
      return verified;
    } finally {
      activeProductSaves.delete(resolved.mappingKey);
    }
  }

  function createPlanProductFields() {
    const fields = document.createElement("div");
    fields.className = "didar-plan-product-fields";
    fields.setAttribute("dir", "rtl");
    fields.innerHTML = `
      <label class="didar-plan-product-field didar-plan-product-field--description">
        <span>توضیحات محصول</span>
        <input type="text" class="didar-plan-product-description" autocomplete="off">
      </label>
      <label class="didar-plan-product-field didar-plan-product-field--price">
        <span>مبلغ واحد</span>
        <input type="text" inputmode="decimal" class="didar-plan-product-unit-price" autocomplete="off">
      </label>
      <button type="button" class="didar-plan-product-save">ذخیره محصول</button>
      <span class="didar-plan-product-status" role="status"></span>
    `;
    fields.querySelectorAll("input").forEach((input) => {
      input.addEventListener("input", () => {
        if (input.classList.contains("didar-plan-product-unit-price")) {
          formatUnitPriceWhileTyping(input);
        } else if (input.classList.contains("didar-plan-product-description")) {
          formatDescriptionWhileTyping(input);
        }
        input.dataset.dirty = "true";
        fields.classList.remove("is-saved", "has-error");
        const status = fields.querySelector(".didar-plan-product-status");
        if (status) {
          status.textContent = "تغییرات ذخیره نشده";
        }
        writeProductDraft(fields);
      });
      input.addEventListener("click", (event) => event.stopPropagation());
    });
    fields.addEventListener("click", (event) => event.stopPropagation());
    fields.querySelector(".didar-plan-product-save").addEventListener("click", () => {
      void saveActivityProductFields(fields);
    });
    return fields;
  }

  function renderPlanProductFields(card, deal, activityId, productTitle) {
    let fields = card.querySelector(":scope > .didar-plan-product-fields");
    if (!fields) {
      fields = createPlanProductFields();
      card.appendChild(fields);
    }
    const resolved = activityProductMapping(deal, activityId, productTitle);
    fields.dataset.mappingKey = resolved.key;
    fields.dataset.dealId = Core.text(deal.Id).toLowerCase();
    fields.dataset.activityId = activityId;
    fields.dataset.productTitle = productTitle;
    fields.hidden = false;
    const description = fields.querySelector(".didar-plan-product-description");
    const unitPrice = fields.querySelector(".didar-plan-product-unit-price");
    const save = fields.querySelector(".didar-plan-product-save");
    const status = fields.querySelector(".didar-plan-product-status");
    const item = resolved.item;
    const isSaving = fields.classList.contains("is-saving");
    const shouldDisable = !item || isSaving;
    if (item && description.dataset.dirty !== "true" && unitPrice.dataset.dirty !== "true") {
      fields.dataset.dealProductId = Core.text(item.Id).toLowerCase();
      fields.dataset.baseDescription = Core.text(item.Description);
      fields.dataset.baseUnitPrice = normalizeUnitPriceInput(item.UnitPrice ?? 0);
    }
    const draft = item && fields.dataset.draftRestored !== "true"
      ? readProductDraft(deal.Id, activityId)
      : null;
    if (draft) {
      description.value = Core.text(draft.description);
      unitPrice.value = formatUnitPriceForDisplay(draft.unitPrice);
      description.dataset.dirty = "true";
      unitPrice.dataset.dirty = "true";
      fields.dataset.draftRestored = "true";
      if (draft.dealProductId && draft.dealProductId === fields.dataset.dealProductId &&
          Object.hasOwn(draft, "baseDescription") && Object.hasOwn(draft, "baseUnitPrice")) {
        fields.dataset.baseDescription = Core.text(draft.baseDescription);
        fields.dataset.baseUnitPrice = normalizeUnitPriceInput(draft.baseUnitPrice);
      }
      fields.classList.remove("is-saved", "has-error");
      status.textContent = "پیش‌نویس ذخیره‌نشده بازیابی شد";
    }

    [description, unitPrice].forEach((input) => {
      if (input.disabled !== shouldDisable) {
        input.disabled = shouldDisable;
      }
    });
    if (save.disabled !== shouldDisable) {
      save.disabled = shouldDisable;
    }
    if (item) {
      if (description.dataset.dirty !== "true" && unitPrice.dataset.dirty !== "true") {
        fields.dataset.dealProductId = Core.text(item.Id).toLowerCase();
        fields.dataset.baseDescription = Core.text(item.Description);
        fields.dataset.baseUnitPrice = normalizeUnitPriceInput(item.UnitPrice ?? 0);
      }
      if (description.dataset.dirty !== "true" && document.activeElement !== description) {
        description.value = formatLongNumbersInDescription(item.Description);
      }
      if (unitPrice.dataset.dirty !== "true" && document.activeElement !== unitPrice) {
        unitPrice.value = formatUnitPriceForDisplay(item.UnitPrice ?? 0);
      }
      if (!isSaving && !fields.classList.contains("is-saved") &&
          !fields.classList.contains("has-error")) {
        if (status.textContent) {
          status.textContent = "";
        }
      }
    } else {
      const message = resolved.ambiguous
        ? "برای فعالیت‌های هم‌نام قدیمی، اتصال دقیق محصول مشخص نیست."
        : "محصول متناظر هنوز در معامله پیدا نشد.";
      if (status.textContent !== message) {
        status.textContent = message;
      }
    }
  }

  async function verifyUpdatedProduct(
    dealId,
    mapping,
    description,
    unitPrice,
    dealProductId = ""
  ) {
    const waits = [0, 180, 400, 800, 1400, 2400, 3800];
    let latest = null;
    for (const wait of waits) {
      if (wait) {
        await delay(wait);
      }
      latest = await ensureCurrentDealProductView(true, dealId);
      const exactId = Core.text(dealProductId).toLowerCase();
      const item = Core.GUID_PATTERN.test(exactId)
        ? (latest?.Items || []).find(
          (candidate) => Core.text(candidate.Id).toLowerCase() === exactId
        )
        : mappedProductItem(latest, mapping);
      if (
        item &&
        Core.text(item.Description) === description &&
        normalizeUnitPriceInput(item.UnitPrice) === unitPrice
      ) {
        return { deal: latest, item };
      }
    }
    return { deal: latest, item: null };
  }

  async function persistProductFieldsIntent(operation) {
    const dealId = Core.text(operation?.dealId).toLowerCase();
    const mappingKey = Core.text(operation?.mappingKey);
    const mapping = productActivityMappings.get(mappingKey);
    const dealProductId = Core.text(operation?.dealProductId).toLowerCase();
    const hasBaseline = Object.hasOwn(operation, "baseDescription") &&
      Object.hasOwn(operation, "baseUnitPrice");
    const baseline = {
      Description: Core.text(operation.baseDescription),
      UnitPrice: normalizeUnitPriceInput(operation.baseUnitPrice ?? 0)
    };
    const desired = {
      Description: Core.text(operation.description),
      UnitPrice: normalizeUnitPriceInput(operation.unitPrice)
    };
    // Merge each field independently: an untouched field belongs to the latest
    // server version, while an already-applied field is safe to resume on retry.
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const deal = await ensureCurrentDealProductView(true, dealId);
      if (Core.text(deal?.Id).toLowerCase() !== dealId) {
        throw new Error("محصولات معامله مقصد از سرور دریافت نشد.");
      }
      const item = Core.GUID_PATTERN.test(dealProductId)
        ? (deal.Items || []).find((candidate) => Core.text(candidate.Id).toLowerCase() === dealProductId)
        : mappedProductItem(deal, mapping);
      if (!item) {
        throw new Error("ردیف دقیق محصول متناظر پیدا نشد؛ چیزی تغییر نکرد.");
      }
      const current = {
        Description: Core.text(item.Description),
        UnitPrice: normalizeUnitPriceInput(item.UnitPrice ?? 0)
      };
      const merged = {};
      for (const field of ["Description", "UnitPrice"]) {
        if (hasBaseline && desired[field] === baseline[field]) {
          merged[field] = current[field];
        } else if (!hasBaseline || current[field] === baseline[field] || current[field] === desired[field]) {
          merged[field] = desired[field];
        } else {
          const error = new Error("محصول بعد از شروع ویرایش تغییر کرده است؛ مقادیر فعلی سرور را بررسی کنید و سپس دوباره ذخیره بزنید.");
          error.productConflict = true;
          error.currentProduct = Core.cloneJson(item);
          throw error;
        }
      }
      if (current.Description !== merged.Description || current.UnitPrice !== merged.UnitPrice) {
        const updatedItems = Core.cloneJson(deal.Items);
        updatedItems[deal.Items.indexOf(item)] = { ...item, ...merged };
        await apiRequest("DealProduct/Update", {
          body: { DealId: deal.Id, DealProducts: updatedItems, Adjustment: Core.text(deal.Adjustment || 0) }
        });
      }
      const confirmed = await verifyUpdatedProduct(
        deal.Id, mapping, merged.Description, merged.UnitPrice, dealProductId
      );
      if (!confirmed.item) continue;
      if (currentDealId() === dealId) {
        rememberDealProductView(confirmed.deal);
        void syncOpenDealView(confirmed.deal, { waitForView: false });
      }
      await delay(1200);
      const stable = await verifyUpdatedProduct(
        deal.Id, mapping, merged.Description, merged.UnitPrice, dealProductId
      );
      if (stable.item) return stable;
      // A stale native save may restore the baseline. Read fresh and merge again;
      // never retry the old complete list or overwrite a third-party field edit.
    }
    throw new Error("سرور ذخیره پایدار توضیحات و مبلغ را تأیید نکرد؛ درخواست برای تلاش مجدد نگه داشته شد.");
  }

  async function saveActivityProductFields(fields) {
    const mappingKey = Core.text(fields.dataset.mappingKey);
    const activityId = Core.text(fields.dataset.activityId);
    const productTitle = Core.text(fields.dataset.productTitle);
    const dealId = Core.text(fields.dataset.dealId).toLowerCase();
    const dealProductId = Core.text(fields.dataset.dealProductId).toLowerCase();
    if (
      !settings.enabled ||
      !settings.autoAddPlanProduct ||
      !Core.GUID_PATTERN.test(dealId) ||
      currentDealId() !== dealId ||
      !mappingKey ||
      !Core.GUID_PATTERN.test(dealProductId) ||
      activeProductSaves.has(mappingKey)
    ) {
      return;
    }
    const descriptionInput = fields.querySelector(".didar-plan-product-description");
    const priceInput = fields.querySelector(".didar-plan-product-unit-price");
    const button = fields.querySelector(".didar-plan-product-save");
    const status = fields.querySelector(".didar-plan-product-status");
    let unitPrice;
    try {
      unitPrice = normalizeUnitPriceInput(priceInput.value);
    } catch (error) {
      status.textContent = error.message;
      fields.classList.add("has-error");
      return;
    }

    activeProductSaves.add(mappingKey);
    fields.classList.remove("has-error", "is-saved");
    fields.classList.add("is-saving");
    button.disabled = true;
    descriptionInput.disabled = true;
    priceInput.disabled = true;
    status.textContent = "در حال ذخیره...";
    try {
      const operation = prepareDurableOperation({
        id: `product-fields:${dealId}:${activityId}`,
        type: "plan-product-fields",
        lockName: `deal-products:${dealId}`,
        dealId,
        activityId,
        mappingKey,
        dealProductId,
        productTitle,
        description: Core.text(descriptionInput.value).trim(),
        unitPrice,
        baseDescription: Core.text(fields.dataset.baseDescription),
        baseUnitPrice: normalizeUnitPriceInput(fields.dataset.baseUnitPrice || 0)
      });
      await putOutboxOperation(operation);
      const verified = await runDurableOperation(
        operation,
        persistProductFieldsIntent,
        { staged: true }
      );
      if (!verified?.item) {
        throw new Error("این ذخیره با درخواست جدیدتری جایگزین شد یا تأیید نشد.");
      }
      const matching = verified.deal.Items.filter(
        (candidate) => Core.text(candidate.ProductId).toLowerCase() === Core.text(verified.item.ProductId).toLowerCase()
      );
      rememberActivityProduct(
        verified.deal.Id,
        activityId,
        verified.item,
        Math.max(0, matching.indexOf(verified.item))
      );
      descriptionInput.dataset.dirty = "false";
      priceInput.dataset.dirty = "false";
      fields.dataset.baseDescription = Core.text(verified.item.Description);
      fields.dataset.baseUnitPrice = normalizeUnitPriceInput(verified.item.UnitPrice ?? 0);
      clearProductDraft(dealId, activityId);
      rememberDealProductView(verified.deal);
      syncRememberedProductView();
      fields.classList.add("is-saved");
      status.textContent = `«${productTitle}» ذخیره شد.`;
      toast(`اطلاعات محصول «${productTitle}» ذخیره شد`, "success");
    } catch (error) {
      fields.classList.add("has-error");
      status.textContent = error?.message || "ذخیره تأیید نشد؛ برای تلاش مجدد نگه داشته شد.";
      if (error?.productConflict && error.currentProduct) {
        fields.dataset.baseDescription = Core.text(error.currentProduct.Description);
        fields.dataset.baseUnitPrice = normalizeUnitPriceInput(error.currentProduct.UnitPrice ?? 0);
        status.textContent += ` مبلغ فعلی: ${formatUnitPriceForDisplay(error.currentProduct.UnitPrice ?? 0)}؛ توضیحات فعلی: ${Core.text(error.currentProduct.Description) || "خالی"}`;
        writeProductDraft(fields);
      }
      toast(status.textContent, "error");
    } finally {
      activeProductSaves.delete(mappingKey);
      fields.classList.remove("is-saving");
      const card = fields.closest(".activity-item, article");
      const rememberedDeal = rememberedDealProductViews.get(dealId);
      if (card && rememberedDeal) {
        renderPlanProductFields(card, rememberedDeal, activityId, productTitle);
      } else {
        button.disabled = false;
        descriptionInput.disabled = false;
        priceInput.disabled = false;
      }
    }
  }

  function enhancePlanProductFields() {
    if (!settings.enabled || !settings.autoAddPlanProduct) {
      document.querySelectorAll(".didar-plan-product-fields").forEach((fields) => {
        fields.hidden = true;
      });
      document.querySelectorAll(".didar-plan-quick-actions").forEach((section) => {
        section.remove();
      });
      return;
    }
    if (document.readyState === "loading" || !document.querySelector("lc-deal-details")) {
      return;
    }
    bindPlanActivityCardsFromServer(currentDealId());
    const planCards = Array.from(document.querySelectorAll(".activity-item, article"))
      .filter((card) => !card.closest("lc-activity-detail"))
      .filter((card) => !card.parentElement?.closest(".activity-item, article"))
      .map((card) => ({
        card,
        productTitle: productTitleForActivity(card.querySelector("h2")?.textContent)
      }))
      .filter(({ productTitle }) => Boolean(productTitle));
    const deal = rememberedDealProductViews.get(currentDealId());
    if (!deal) {
      if (
        !planCards.length && !document.querySelector("add-product")
      ) {
        return;
      }
      void ensureCurrentDealProductView()
        .then((loadedDeal) => {
          if (loadedDeal) {
            enhancePlanProductFields();
          }
        })
        .catch(() => {});
      return;
    }
    planCards.forEach(({ card, productTitle }) => {
      const activityId = activityIdForCard(card);
      if (Core.GUID_PATTERN.test(activityId)) {
        renderPlanProductFields(card, deal, activityId, productTitle);
      } else {
        void loadPlanActivityBindings(currentDealId()).catch(() => {});
      }
    });
  }

  function handleProductEditorIntent(event) {
    if (!settings.enabled || !settings.autoAddPlanProduct || !(event.target instanceof Element)) {
      return;
    }
    const action = event.target.closest("span, a, button");
    if (!action || action.closest("add-product, .didar-plan-product-fields")) {
      return;
    }
    const actionText = normalizedUiText(action.textContent);
    if (
      !actionText.includes("محصول") ||
      (!actionText.includes("افزودن") && !actionText.includes("ویرایش"))
    ) {
      return;
    }
    const dealId = currentDealId();
    if (!Core.GUID_PATTERN.test(dealId)) {
      return;
    }
    void ensureCurrentDealProductView(true, dealId)
      .then((deal) => {
        if (deal && currentDealId() === dealId) {
          rememberDealProductView(deal);
          syncRememberedProductView();
          scheduleScan();
        }
      })
      .catch(() => {});
  }

  function exactUiTextElement(root, expected, selectors = "button, a, span, div") {
    return Array.from(root.querySelectorAll(selectors)).find(
      (element) => normalizedUiText(element.textContent) === expected
    ) || null;
  }

  function activeDealAddRoot() {
    const nativeModals = Array.from(document.querySelectorAll("lc-deal-add"));
    const nativeModal = nativeModals.reverse().find((modal) =>
      modal.isConnected &&
      !modal.hidden &&
      modal.getAttribute("aria-hidden") !== "true" &&
      exactUiTextElement(modal, "ذخیره معامله")
    );
    if (nativeModal) {
      return nativeModal;
    }
    const selectedNotices = Array.from(document.querySelectorAll("div, p, section, aside"))
      .filter((element) => {
        const text = normalizedUiText(element.textContent);
        return text.includes("این خریدار") && text.includes("در دیدار");
      })
      .sort((left, right) => left.textContent.length - right.textContent.length);
    for (const notice of selectedNotices) {
      let candidate = notice.parentElement;
      while (candidate && candidate !== document.body) {
        const text = normalizedUiText(candidate.textContent);
        if (
          exactUiTextElement(candidate, "اطلاعات خریدار") &&
          (text.includes("عنوان معامله") ||
            exactUiTextElement(candidate, "ذخیره معامله", "button"))
        ) {
          return candidate;
        }
        candidate = candidate.parentElement;
      }
    }

    const buyerTabs = Array.from(document.querySelectorAll("button, a, span, div"))
      .filter((element) => normalizedUiText(element.textContent) === "اطلاعات خریدار");
    for (const buyerTab of buyerTabs.reverse()) {
      let candidate = buyerTab.parentElement;
      while (candidate && candidate !== document.body) {
        if (
          normalizedUiText(candidate.textContent).includes("افزودن معامله") &&
          exactUiTextElement(candidate, "ذخیره معامله")
        ) {
          return candidate;
        }
        candidate = candidate.parentElement;
      }
    }

    const saveControls = Array.from(
      document.querySelectorAll("button, a, span, div, input[type='submit']")
    ).filter((control) => {
      const text = control instanceof HTMLInputElement
        ? control.value
        : control.textContent;
      return normalizedUiText(text) === "ذخیره معامله";
    });
    for (const saveControl of saveControls.reverse()) {
      let candidate = saveControl.parentElement;
      while (candidate && candidate !== document.body) {
        if (normalizedUiText(candidate.textContent).includes("افزودن معامله")) {
          return candidate;
        }
        candidate = candidate.parentElement;
      }
    }
    return null;
  }

  function dealAddBuyerTabsAnchor(panel) {
    const buyerTab = exactUiTextElement(panel, "اطلاعات خریدار");
    if (!buyerTab) {
      return null;
    }
    let candidate = buyerTab.parentElement;
    while (candidate && candidate !== panel) {
      if (exactUiTextElement(candidate, "افزودن محصول")) {
        if (candidate.querySelector("input, textarea, select")) {
          let tabGroup = buyerTab;
          while (tabGroup.parentElement && tabGroup.parentElement !== candidate) {
            tabGroup = tabGroup.parentElement;
          }
          return tabGroup;
        }
        return candidate;
      }
      candidate = candidate.parentElement;
    }
    return buyerTab.parentElement;
  }

  function manualDealContactInput(root) {
    const nativeInputs = Array.from(root.querySelectorAll("lc-selector input"));
    return nativeInputs.find((input) =>
      normalizedUiText(input.closest("label")?.textContent || input.parentElement?.parentElement?.textContent)
        .includes("نام خانوادگی")
    ) || nativeInputs[0] || null;
  }

  function manualDealContactName(contact) {
    return normalizedTitle([contact?.FirstName, contact?.LastName].filter(Boolean).join(" ")) ||
      normalizedTitle(contact?.DisplayName || contact?.Name);
  }

  function manualDealContactIdentity(value) {
    const fullName = normalizedTitle(value);
    const match = fullName.match(/(?:^|\s)([0-9۰-۹٠-٩]{10})$/);
    return {
      name: match ? normalizedTitle(fullName.slice(0, match.index)) : fullName,
      nationalCode: match ? normalizeLookupDigits(match[1]) : ""
    };
  }

  function manualDealContactMatches(contact, state) {
    const code = manualDealContactIdentity(state.name).nationalCode;
    const phone = normalizeIranianMobile(state.mobile);
    const contactCode = normalizeLookupDigits(contact?.NationalCode);
    const contactPhone = normalizeIranianMobile(contact?.MobilePhone);
    return Boolean(
      (code && (contactCode === code || normalizeLookupDigits(contact?.LastName).endsWith(code))) ||
      (phone && contactPhone === phone)
    );
  }

  function manualDealContactStatus(state, message, kind = "info") {
    state.message = message;
    state.messageKind = kind;
    const panel = state.root.querySelector(".didar-manual-contact");
    const status = panel?.querySelector(".didar-manual-contact__status");
    if (status) {
      status.textContent = message;
      status.dataset.kind = kind;
    }
  }

  function manualDealContactResults(state) {
    const panel = state.root.querySelector(".didar-manual-contact");
    const list = panel?.querySelector(".didar-manual-contact__results");
    if (!list) {
      return;
    }
    list.replaceChildren();
    state.results.forEach((contact) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "didar-manual-contact__result";
      button.dataset.contactId = Core.text(contact.Id);
      const name = document.createElement("strong");
      name.textContent = manualDealContactName(contact) || "مخاطب بدون نام";
      const details = document.createElement("small");
      details.textContent = [contact.NationalCode && `کد ملی ${contact.NationalCode}`,
        contact.MobilePhone && `همراه ${contact.MobilePhone}`].filter(Boolean).join(" · ");
      button.append(name, details);
      button.addEventListener("click", () => {
        state.selected = contact;
        manualDealContactStatus(state, "مخاطب انتخاب شد؛ معاملات او در ادامه نمایش داده می‌شود.");
        beginSelectedPersonDealLoad(Core.text(contact.Id).toLowerCase(), state.root);
        void attachManualDealContact(state, contact);
      });
      list.appendChild(button);
    });
  }

  async function searchManualDealContacts(state) {
    const { name, nationalCode } = manualDealContactIdentity(state.name);
    const term = normalizedTitle(nationalCode || state.mobile || name);
    if (term.length < 2) {
      manualDealContactStatus(state, "نام، کد ملی یا شماره همراه را برای جست‌وجو وارد کنید.", "error");
      return;
    }
    const requestId = ++state.searchSequence;
    manualDealContactStatus(state, "در حال جست‌وجوی مخاطبان دیدار...");
    try {
      const response = await apiRequest("contact/search", {
        body: { Criteria: { Keywords: term }, From: 0, Limit: 30 }
      });
      if (state.searchSequence !== requestId || !state.root.isConnected) {
        return;
      }
      state.results = responseList(response)
        .filter((contact) => Core.GUID_PATTERN.test(Core.text(contact?.Id)))
        .slice(0, 30);
      state.searched = true;
      manualDealContactResults(state);
      manualDealContactStatus(state, state.results.length
        ? `${state.results.length} مخاطب پیدا شد. مخاطب درست را انتخاب کنید.`
        : "مخاطبی پیدا نشد. در صورت اطمینان، مخاطب جدید را بسازید.");
    } catch (error) {
      if (state.searchSequence === requestId) {
        manualDealContactStatus(state, error?.message || "جست‌وجوی مخاطب انجام نشد.", "error");
      }
    }
  }

  function manualDealNativeChoices(root, input) {
    const scope = input.closest("lc-selector") || input.parentElement;
    const selectors = "li, [role='option'], .search-res-list > *, .selector-item";
    return Array.from((scope || root).querySelectorAll(selectors))
      .filter((item) => {
        const label = normalizedUiText(item.textContent);
        return label && item.getClientRects().length &&
          !/ایجاد (شخص|مخاطب)|افزودن (شخص|مخاطب)/.test(label);
      });
  }

  function normalizedManualContactText(value) {
    return normalizedUiText(Core.text(value)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit))));
  }

  function attachManualDealContactById(contactId, root) {
    return new Promise((resolve) => {
      const marker = document.createElement("meta");
      marker.hidden = true;
      marker.dataset.didarManualDealAttachRequest = contactId;
      if (root?.matches?.("lc-deal-add")) {
        root.dataset.didarManualDealAttachTarget = contactId;
      }
      let settled = false;
      let timer = null;
      const finish = (result) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        marker.remove();
        if (root?.dataset?.didarManualDealAttachTarget === contactId) {
          delete root.dataset.didarManualDealAttachTarget;
        }
        resolve(result);
      };
      marker.addEventListener(MANUAL_DEAL_ATTACH_DONE_EVENT, () => {
        finish({
          handled: true,
          ok: marker.dataset.didarManualDealAttachResult === "true",
          method: marker.dataset.didarManualDealAttachMethod || "",
          name: marker.dataset.didarManualDealAttachName || "",
          title: marker.dataset.didarManualDealAttachTitle || ""
        });
      }, { once: true });
      document.documentElement.appendChild(marker);
      marker.dispatchEvent(new Event(MANUAL_DEAL_ATTACH_EVENT, { bubbles: true }));
      if (marker.dataset.didarManualDealAttachStarted !== "true") {
        finish({ handled: false, ok: false, method: "bridge-unavailable" });
      } else if (!settled) {
        timer = window.setTimeout(() => {
          finish({ handled: true, ok: false, method: "bridge-timeout" });
        }, 12000);
      }
    });
  }

  async function attachManualDealContact(state, contact) {
    const contactId = Core.text(contact?.Id).toLowerCase();
    let bridgeFailure = "";
    if (Core.GUID_PATTERN.test(contactId)) {
      const native = await attachManualDealContactById(contactId, state.root);
      if (state.root !== activeDealAddRoot() || state.selected !== contact) {
        return;
      }
      if (native.ok) {
        manualDealContactStatus(state,
          `مخاطب «${native.name || manualDealContactName(contact)}» به فرم معامله وصل شد. عنوان و اطلاعات خریدار را بررسی کنید.`,
          "success");
        return;
      }
      bridgeFailure = native.method || "bridge-unavailable";
      manualDealContactStatus(state,
        `در حال انتخاب مخاطب از فیلد دیدار... (${bridgeFailure})`);
    }
    const input = manualDealContactInput(state.root);
    if (!input) {
      manualDealContactStatus(state, "فیلد انتخاب خریدار در فرم دیدار پیدا نشد. معاملات مخاطب نمایش داده شدند.", "error");
      return;
    }
    const name = manualDealContactName(contact);
    const phone = normalizeIranianMobile(contact.MobilePhone);
    const lookup = phone || name;
    if (!lookup) {
      manualDealContactStatus(state, "مخاطب نام یا شماره همراه قابل جست‌وجو در فرم دیدار ندارد.", "error");
      return;
    }
    input.focus();
    setNativeInputValue(input, lookup);
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: lookup.slice(-1) }));
    for (let attempt = 0; attempt < 50; attempt += 1) {
      await delay(200);
      if (state.root !== activeDealAddRoot() || state.selected !== contact) {
        return;
      }
      if (attempt > 0 && attempt % 8 === 0) {
        input.focus();
        setNativeInputValue(input, lookup);
        input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: lookup.slice(-1) }));
      }
      const candidates = manualDealNativeChoices(state.root, input);
      const named = candidates.filter((item) => normalizedManualContactText(item.textContent)
        .includes(normalizedManualContactText(name)));
      const exactPhone = phone
        ? candidates.filter((item) => normalizeLookupDigits(item.textContent).includes(phone))
        : [];
      const unique = exactPhone.length === 1 ? exactPhone[0] : named.length === 1 ? named[0] : null;
      if (unique) {
        state.attaching = true;
        try {
          unique.click();
          for (let settle = 0; settle < 10; settle += 1) {
            await delay(200);
            if (state.root !== activeDealAddRoot() || state.selected !== contact) {
              return;
            }
            if (dealAddHasSelectedPerson(state.root)) {
              manualDealContactStatus(state,
                "مخاطب به فرم معامله وصل شد. عنوان معامله و اطلاعات خریدار را بررسی کنید.", "success");
              return;
            }
          }
          manualDealContactStatus(state,
            "گزینه خریدار انتخاب شد، اما اتصال آن در فرم دیدار تأیید نشد. پیش از ذخیره، اطلاعات خریدار را بررسی کنید.",
            "error");
        } finally {
          state.attaching = false;
        }
        return;
      }
    }
    manualDealContactStatus(state,
      `مخاطب ثبت شد، اما هنوز در جست‌وجوی فیلد دیدار دیده نمی‌شود. کمی بعد روی نتیجه مخاطب در باکس افزونه بزنید تا اتصال دوباره انجام شود. (${bridgeFailure})`, "error");
  }

  async function createManualDealContact(state) {
    const { name, nationalCode } = manualDealContactIdentity(state.name);
    const mobile = normalizeIranianMobile(state.mobile);
    if (name.length < 3 || (!nationalCode && !mobile) ||
      (nationalCode && !/^\d{10}$/.test(nationalCode)) ||
      (state.mobile && !mobile)) {
      manualDealContactStatus(state, "نام کامل و کد ملی ده‌رقمی یا شماره همراه معتبر را وارد کنید.", "error");
      return;
    }
    if (!state.searched) {
      window.clearTimeout(state.searchTimer);
      await searchManualDealContacts(state);
      if (!state.searched) {
        return;
      }
    }
    if (state.saving || state.createdId) {
      return;
    }
    state.saving = true;
    manualDealContactStatus(state, "در حال بررسی دوباره مخاطبان دیدار...");
    try {
      const lookup = nationalCode || mobile;
      const rows = await fetchAllSearchResults("contact/search", { Keywords: lookup });
      const duplicates = rows.filter((contact) => manualDealContactMatches(contact, { name: state.name, mobile }));
      if (duplicates.length) {
        state.results = duplicates;
        manualDealContactResults(state);
        manualDealContactStatus(state, "مخاطب با همین کد ملی یا شماره همراه وجود دارد. همان را انتخاب کنید.", "error");
        return;
      }
      const identity = await currentIdentity();
      const result = await apiRequest("contact/save", { body: { Contact: {
        FirstName: "",
        LastName: nationalCode ? `${name} ${nationalCode}` : name,
        NationalCode: nationalCode,
        MobilePhone: mobile,
        Type: "Person",
        LeadType: "General",
        ContactType: "Prospect",
        CompanyId: EMPTY_GUID,
        OwnerId: identity.id,
        VisibilityType: "All",
        Fields: {}
      } } });
      const contactId = entityIdFromSaveResult(result);
      if (!Core.GUID_PATTERN.test(contactId)) {
        throw new Error("مخاطب ذخیره شد، اما شناسه آن دریافت نشد. پیش از تلاش دوباره جست‌وجو کنید.");
      }
      const contact = { Id: contactId, LastName: nationalCode ? `${name} ${nationalCode}` : name,
        NationalCode: nationalCode, MobilePhone: mobile };
      state.results = [contact];
      state.selected = contact;
      state.createdId = contactId;
      state.searched = false;
      manualDealContactResults(state);
      beginSelectedPersonDealLoad(contactId.toLowerCase(), state.root);
      manualDealContactStatus(state, "مخاطب جدید ثبت شد؛ در حال اتصال به فرم معامله...");
      await attachManualDealContact(state, contact);
    } catch (error) {
      manualDealContactStatus(state, error?.message || "ساخت مخاطب انجام نشد.", "error");
    } finally {
      state.saving = false;
    }
  }

  function mountManualDealContact() {
    if (!settings.enabled) {
      document.querySelectorAll(".didar-manual-contact").forEach((panel) => panel.remove());
      manualDealContactState = null;
      return;
    }
    const root = activeDealAddRoot();
    if (!root) {
      if (document.visibilityState === "visible" && !manualDealContactCloseTimer) {
        manualDealContactCloseTimer = window.setTimeout(() => {
          manualDealContactCloseTimer = null;
          if (!activeDealAddRoot() && document.visibilityState === "visible") {
            manualDealContactState = null;
            manualDealContactDraft.name = "";
            manualDealContactDraft.mobile = "";
          }
        }, 800);
      }
      return;
    }
    window.clearTimeout(manualDealContactCloseTimer);
    manualDealContactCloseTimer = null;
    const anchor = dealAddBuyerTabsAnchor(root);
    if (manualDealContactState?.root === root && root.querySelector(".didar-manual-contact")) {
      return;
    }
    root.querySelectorAll(".didar-manual-contact").forEach((panel) => panel.remove());
    const state = { root, ...manualDealContactDraft, results: [],
      selected: null, searched: false, saving: false, attaching: false,
      createdId: "", searchSequence: 0, searchTimer: null };
    manualDealContactState = state;
    const panel = document.createElement("section");
    panel.className = "didar-manual-contact";
    panel.dir = "rtl";
    panel.innerHTML = `<strong>جست‌وجو یا ثبت مخاطب معامله</strong>
      <div class="didar-manual-contact__fields">
        <label>نام و نام خانوادگی (کد ملی در انتها)<input data-field="name" autocomplete="off" placeholder="نام کامل مشتری و کد ملی"></label>
        <label>شماره همراه<input data-field="mobile" inputmode="tel" autocomplete="off" placeholder="09xxxxxxxxx"></label>
      </div>
      <div class="didar-manual-contact__actions">
        <button type="button" data-action="search">جست‌وجو در مخاطبان</button>
        <button type="button" data-action="create">ساخت مخاطب جدید</button>
      </div>
      <p class="didar-manual-contact__status" role="status">با نوشتن نام یا شماره همراه، مخاطبان دیدار جست‌وجو می‌شوند.</p>
      <div class="didar-manual-contact__results"></div>`;
    panel.querySelectorAll("input[data-field]").forEach((input) => {
      input.value = state[input.dataset.field];
      input.addEventListener("input", () => {
        state[input.dataset.field] = input.value;
        manualDealContactDraft[input.dataset.field] = input.value;
        state.searchSequence += 1;
        state.searched = false;
        state.createdId = "";
        state.selected = null;
        state.results = [];
        manualDealContactResults(state);
        window.clearTimeout(state.searchTimer);
        const { name, nationalCode } = manualDealContactIdentity(state.name);
        if (normalizedTitle(nationalCode || state.mobile || name).length < 2) {
          manualDealContactStatus(state, "نام یا شماره همراه را وارد کنید؛ کد ملی را می‌توانید در انتهای نام بنویسید.");
          return;
        }
        manualDealContactStatus(state, "در حال آماده‌سازی جست‌وجو...");
        state.searchTimer = window.setTimeout(() => {
          state.searchTimer = null;
          void searchManualDealContacts(state);
        }, 350);
      });
      input.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          window.clearTimeout(state.searchTimer);
          void searchManualDealContacts(state);
        }
      });
    });
    panel.querySelector('[data-action="search"]').addEventListener("click", () => {
      window.clearTimeout(state.searchTimer);
      void searchManualDealContacts(state);
    });
    panel.querySelector('[data-action="create"]').addEventListener("click", () => {
      void createManualDealContact(state);
    });
    if (anchor) {
      anchor.insertAdjacentElement("afterend", panel);
    } else {
      panel.classList.add("didar-manual-contact--fallback");
      root.appendChild(panel);
    }
  }

  function selectedPersonDealStatus(value) {
    const status = normalizedUiText(value).toLowerCase();
    if (status === "won" || status === "1" || status.includes("موفق")) {
      return { key: "won", label: "موفق" };
    }
    if (status === "lost" || status === "2" || status.includes("ناموفق")) {
      return { key: "lost", label: "ناموفق" };
    }
    if (
      status === "pending" ||
      status === "0" ||
      status.includes("جاری") ||
      status.includes("باز")
    ) {
      return { key: "pending", label: "جاری" };
    }
    return { key: "closed", label: "بسته" };
  }

  function selectedPersonDealRows(personId, rows) {
    const normalizedPersonId = Core.text(personId).toLowerCase();
    const unique = new Map();
    responseList(rows).forEach((deal) => {
      const id = Core.text(deal?.Id).toLowerCase();
      const relatedId = Core.text(
        deal?.ContactId || deal?.PersonId || deal?.Contact?.Id || deal?.Person?.Id
      ).toLowerCase();
      if (
        !Core.GUID_PATTERN.test(id) ||
        deal?.IsDeleted ||
        (relatedId && relatedId !== normalizedPersonId)
      ) {
        return;
      }
      const status = selectedPersonDealStatus(deal?.Status);
      unique.set(id, {
        id,
        title: normalizedTitle(deal?.Title) || `معامله ${Core.text(deal?.Code)}`.trim(),
        code: Core.text(deal?.Code),
        pipeline: normalizedTitle(deal?.PipelineTitle || deal?.Pipeline?.Title),
        stage: normalizedTitle(
          deal?.PipelineStageTitle || deal?.StageTitle || deal?.PipelineStage?.Title
        ),
        registerTime: Core.text(deal?.RegisterTime),
        status
      });
    });
    const rank = { pending: 0, won: 1, lost: 2, closed: 3 };
    return Array.from(unique.values()).sort((left, right) => {
      const statusDifference = rank[left.status.key] - rank[right.status.key];
      if (statusDifference) {
        return statusDifference;
      }
      return right.registerTime.localeCompare(left.registerTime);
    });
  }

  async function loadSelectedPersonDeals(personId) {
    const rows = await fetchAllSearchResults("deal/search", {
      ContactIds: [personId]
    });
    return selectedPersonDealRows(personId, rows);
  }

  function dealAddHasSelectedPerson(root) {
    const text = normalizedUiText(root?.textContent);
    return Boolean(
      text.includes("این خریدار") &&
      text.includes("در دیدار") &&
      (text.includes("ثبت شده است") || text.includes("شناخته شده است"))
    );
  }

  function dealAddSelectedMobile(root) {
    const mobiles = Array.from(root?.querySelectorAll("input") || [])
      .map((input) => normalizeIranianMobile(input.value))
      .filter(Boolean);
    return mobiles[0] || "";
  }

  async function resolveDealAddPersonByMobile(mobile) {
    const response = await apiRequest("search/search", {
      body: { Keyword: mobile, Types: ["contact"] }
    });
    const matches = responseList(response)
      .filter((contact) => Core.GUID_PATTERN.test(Core.text(contact?.Id)))
      .map((contact) => ({
        contact,
        phones: [contact?.MobilePhone, contact?.WorkPhone, contact?.OtherPhones]
          .map(normalizeIranianMobile)
          .filter(Boolean)
      }));
    const exact = matches.filter((item) => item.phones.includes(mobile));
    const selected = exact.length === 1
      ? exact[0].contact
      : matches.length === 1
        ? matches[0].contact
        : null;
    return Core.text(selected?.Id).toLowerCase();
  }

  function beginSelectedPersonDealLoad(personId, root = activeDealAddRoot()) {
    selectedDealAddPersonSequence += 1;
    const requestId = selectedDealAddPersonSequence;
    selectedDealAddPersonState = {
      personId,
      requestId,
      root,
      status: "loading",
      deals: [],
      error: ""
    };
    renderSelectedPersonDeals();
    void loadSelectedPersonDeals(personId)
      .then((deals) => {
        if (selectedDealAddPersonState?.requestId !== requestId) {
          return;
        }
        selectedDealAddPersonState.status = "ready";
        selectedDealAddPersonState.deals = deals;
        renderSelectedPersonDeals();
      })
      .catch((error) => {
        if (selectedDealAddPersonState?.requestId !== requestId) {
          return;
        }
        selectedDealAddPersonState.status = "error";
        selectedDealAddPersonState.error = error?.message || "دریافت معاملات مشتری انجام نشد.";
        renderSelectedPersonDeals();
      });
  }

  function resolveSelectedDealAddPersonFromForm() {
    if (!settings.enabled || selectedDealAddPersonState) {
      return;
    }
    const root = activeDealAddRoot();
    if (!root || !dealAddHasSelectedPerson(root)) {
      return;
    }
    const mobile = dealAddSelectedMobile(root);
    selectedDealAddPersonSequence += 1;
    const requestId = selectedDealAddPersonSequence;
    selectedDealAddPersonState = {
      personId: "",
      requestId,
      root,
      status: "resolving",
      deals: [],
      error: ""
    };
    renderSelectedPersonDeals();
    if (!mobile) {
      selectedDealAddPersonState.status = "error";
      selectedDealAddPersonState.error = "شناسه مشتری دریافت نشد و شماره همراه معتبری برای بازیابی آن وجود ندارد.";
      renderSelectedPersonDeals();
      return;
    }
    void resolveDealAddPersonByMobile(mobile)
      .then((personId) => {
        if (selectedDealAddPersonState?.requestId !== requestId) {
          return;
        }
        if (!Core.GUID_PATTERN.test(personId)) {
          selectedDealAddPersonState.status = "error";
          selectedDealAddPersonState.error = "مخاطب انتخاب‌شده برای نمایش معاملات به‌صورت یکتا شناسایی نشد.";
          renderSelectedPersonDeals();
          return;
        }
        beginSelectedPersonDealLoad(personId, root);
      })
      .catch((error) => {
        if (selectedDealAddPersonState?.requestId !== requestId) {
          return;
        }
        selectedDealAddPersonState.status = "error";
        selectedDealAddPersonState.error = error?.message || "شناسایی مخاطب انتخاب‌شده انجام نشد.";
        renderSelectedPersonDeals();
      });
  }

  function selectedPersonDealCard(deal) {
    const link = document.createElement("a");
    link.className = `didar-contact-deal-card is-${deal.status.key}`;
    link.href = `https://app.didar.me/deal/${deal.id}`;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.dataset.dealId = deal.id;

    const title = document.createElement("strong");
    title.className = "didar-contact-deal-card__title";
    title.textContent = deal.title || "معامله بدون عنوان";
    const badge = document.createElement("span");
    badge.className = "didar-contact-deal-card__status";
    badge.textContent = deal.status.label;
    link.append(title, badge);

    const metaParts = [deal.pipeline, deal.stage, deal.code ? `کد ${deal.code}` : ""].filter(Boolean);
    if (metaParts.length) {
      const meta = document.createElement("span");
      meta.className = "didar-contact-deal-card__meta";
      meta.textContent = metaParts.join(" · ");
      link.appendChild(meta);
    }
    return link;
  }

  function selectedPersonDealsRenderSignature(state) {
    return JSON.stringify([
      state.status,
      state.error,
      state.deals.map((deal) => [
        deal.id,
        deal.title,
        deal.code,
        deal.pipeline,
        deal.stage,
        deal.status.key,
        deal.status.label
      ])
    ]);
  }

  function handleContactDealCardClick(event) {
    const card = event.target instanceof Element
      ? event.target.closest("a.didar-contact-deal-card")
      : null;
    const dealId = Core.text(card?.dataset.dealId).toLowerCase();
    if (!card || !Core.GUID_PATTERN.test(dealId)) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    void chrome.runtime.sendMessage({
      type: "DIDAR_OPEN_DEAL_TAB",
      url: `https://app.didar.me/deal/${dealId}`
    }).then((response) => {
      if (!response?.ok) {
        showToast(response?.error || "بازکردن معامله در تب جدید انجام نشد.", "error");
      }
    }).catch(() => {
      showToast("بازکردن معامله در تب جدید انجام نشد.", "error");
    });
  }

  function renderSelectedPersonDeals() {
    const existingSections = Array.from(
      document.querySelectorAll(".didar-contact-deals")
    );
    if (!settings.enabled || !selectedDealAddPersonState) {
      existingSections.forEach((section) => section.remove());
      return;
    }
    if (
      selectedDealAddPersonState.root &&
      !selectedDealAddPersonState.root.isConnected
    ) {
      selectedDealAddPersonState = null;
      existingSections.forEach((section) => section.remove());
      return;
    }

    const root = activeDealAddRoot();
    if (!root) {
      return;
    }
    if (selectedDealAddPersonState.root && selectedDealAddPersonState.root !== root) {
      selectedDealAddPersonState = null;
      existingSections.forEach((section) => section.remove());
      return;
    }
    selectedDealAddPersonState.root = root;
    const anchor = dealAddBuyerTabsAnchor(root);
    const picker = root.querySelector(".didar-manual-contact");
    const fallbackPicker = picker?.classList.contains("didar-manual-contact--fallback");
    const panel = fallbackPicker ? picker : picker?.parentElement || anchor?.parentElement || null;
    if (!panel || (!anchor && !picker)) {
      return;
    }

    existingSections.forEach((section) => {
      if (!panel.contains(section)) {
        section.remove();
      }
    });
    let section = panel.querySelector(".didar-contact-deals");
    if (!section) {
      section = document.createElement("section");
      section.className = "didar-contact-deals";
    }
    const insertAfter = fallbackPicker
      ? picker.querySelector(".didar-manual-contact__results") || picker.lastElementChild
      : picker || anchor;
    if (insertAfter.nextElementSibling !== section) {
      insertAfter.insertAdjacentElement("afterend", section);
    }
    const renderSignature = selectedPersonDealsRenderSignature(selectedDealAddPersonState);
    section.dataset.state = selectedDealAddPersonState.status;
    if (section.dataset.renderSignature === renderSignature) {
      return;
    }
    section.dataset.renderSignature = renderSignature;
    section.replaceChildren();

    const header = document.createElement("div");
    header.className = "didar-contact-deals__header";
    const heading = document.createElement("strong");
    heading.textContent = "معاملات این مشتری";
    header.appendChild(heading);
    if (selectedDealAddPersonState.status === "ready") {
      const count = document.createElement("span");
      count.textContent = `${selectedDealAddPersonState.deals.length} معامله`;
      header.appendChild(count);
    }
    section.appendChild(header);

    if (["resolving", "loading"].includes(selectedDealAddPersonState.status)) {
      const status = document.createElement("p");
      status.className = "didar-contact-deals__message";
      status.textContent = selectedDealAddPersonState.status === "resolving"
        ? "در حال شناسایی مشتری..."
        : "در حال دریافت معاملات...";
      section.appendChild(status);
      return;
    }
    if (selectedDealAddPersonState.status === "error") {
      const status = document.createElement("p");
      status.className = "didar-contact-deals__message";
      status.textContent = selectedDealAddPersonState.error;
      section.appendChild(status);
      return;
    }
    if (!selectedDealAddPersonState.deals.length) {
      const status = document.createElement("p");
      status.className = "didar-contact-deals__message";
      status.textContent = "معامله‌ای برای این مشتری پیدا نشد.";
      section.appendChild(status);
      return;
    }
    const list = document.createElement("div");
    list.className = "didar-contact-deals__list";
    selectedDealAddPersonState.deals.forEach((deal) => {
      list.appendChild(selectedPersonDealCard(deal));
    });
    section.appendChild(list);
  }

  function handleDealAddPersonSelected(event) {
    const marker = event.target?.matches?.("meta[data-didar-deal-add-person-id]")
      ? event.target
      : null;
    const personId = Core.text(
      event.detail?.personId || marker?.dataset.didarDealAddPersonId
    ).toLowerCase();
    marker?.remove();
    if (!Core.GUID_PATTERN.test(personId)) {
      return;
    }
    if (
      selectedDealAddPersonState?.personId === personId &&
      ["loading", "ready"].includes(selectedDealAddPersonState.status)
    ) {
      renderSelectedPersonDeals();
      return;
    }
    beginSelectedPersonDealLoad(personId);
  }

  function consumeDealAddPersonMarkers() {
    document
      .querySelectorAll("meta[data-didar-deal-add-person-id]")
      .forEach((marker) => {
        const createdAt = Number(marker.dataset.didarDealAddPersonTime || 0);
        const personId = Core.text(marker.dataset.didarDealAddPersonId).toLowerCase();
        marker.remove();
        if (
          Core.GUID_PATTERN.test(personId) &&
          createdAt > 0 &&
          Date.now() - createdAt < 15000
        ) {
          handleDealAddPersonSelected({ detail: { personId }, target: marker });
        }
      });
  }

  function handleDealAddPersonRemovalIntent(event) {
    const root = selectedDealAddPersonState?.root;
    if (!root || !(event.target instanceof Element) || !root.contains(event.target)) {
      return;
    }
    if (event.target.closest(".didar-manual-contact")) {
      return;
    }
    if (manualDealContactState?.root === root && manualDealContactState.attaching) {
      return;
    }
    window.setTimeout(() => {
      const rootText = normalizedUiText(root.textContent);
      const stillHasSelectedPerson =
        rootText.includes("این خریدار") &&
        rootText.includes("در دیدار") &&
        (rootText.includes("ثبت شده است") || rootText.includes("شناخته شده است"));
      if (
        selectedDealAddPersonState?.root !== root ||
        !root.isConnected ||
        stillHasSelectedPerson
      ) {
        return;
      }
      selectedDealAddPersonState = null;
      root.querySelectorAll(".didar-contact-deals").forEach((section) => section.remove());
    }, 120);
  }

  function productLabelsFromDeal(deal) {
    const labels = new Set();
    (Array.isArray(deal?.Items) ? deal.Items : []).forEach((item) => {
      const label = globalSearchProductLabel(
        item?.Title || item?.ProductTitle || item?.Product?.Title
      );
      if (label) {
        labels.add(label);
      }
    });
    return Array.from(labels);
  }

  function readGlobalSearchResultsMarker(marker) {
    if (!marker?.matches?.("meta[data-didar-global-search-results]")) {
      return false;
    }
    let detail;
    try {
      detail = JSON.parse(marker.textContent || "{}");
    } catch {
      return false;
    }
    latestGlobalSearchDeals = (Array.isArray(detail?.deals) ? detail.deals : [])
      .map((deal) => ({
        id: Core.text(deal?.id).toLowerCase(),
        title: Core.normalizeLabel(deal?.title)
      }))
      .filter((deal) => Core.GUID_PATTERN.test(deal.id));
    return true;
  }

  function consumeGlobalSearchResultsMarkers() {
    document
      .querySelectorAll("meta[data-didar-global-search-results]")
      .forEach((marker) => readGlobalSearchResultsMarker(marker));
  }

  function bindGlobalSearchDealRowsFromResults() {
    if (!latestGlobalSearchDeals.length) {
      return;
    }
    const used = new Set();
    const rows = Array.from(
      document.querySelectorAll("lc-global-search .search-res-list li")
    ).filter((row) => row.querySelector(".icon-srch.Deal"));
    rows.forEach((row, rowIndex) => {
      const title = Core.normalizeLabel(row.querySelector("h1")?.textContent);
      let resultIndex = latestGlobalSearchDeals.findIndex(
        (deal, index) => !used.has(index) && deal.title === title
      );
      if (resultIndex < 0 && rows.length === latestGlobalSearchDeals.length) {
        resultIndex = rowIndex;
      }
      const deal = latestGlobalSearchDeals[resultIndex];
      if (!deal || used.has(resultIndex)) {
        row.removeAttribute("data-didar-search-deal-id");
        row.removeAttribute("data-didar-search-deal-source");
        return;
      }
      used.add(resultIndex);
      row.dataset.didarSearchDealId = deal.id;
      row.dataset.didarSearchDealSource = "response";
    });
  }

  function renderGlobalSearchProductLabels(dealId, labels) {
    document
      .querySelectorAll(`lc-global-search .search-res-list li[data-didar-search-deal-id="${dealId}"]`)
      .forEach((row) => {
        row.classList.add("didar-search-deal-result");
        let host = row.querySelector(":scope > .didar-search-deal-products");
        const signature = JSON.stringify(labels);
        if (!labels.length) {
          host?.remove();
          return;
        }
        if (!host) {
          host = document.createElement("span");
          host.className = "didar-search-deal-products";
          host.setAttribute("aria-label", "محصولات طرح این معامله");
          row.appendChild(host);
        }
        host.dataset.dealId = dealId;
        if (host.dataset.renderSignature === signature) {
          return;
        }
        host.dataset.renderSignature = signature;
        host.replaceChildren();
        labels.forEach((label) => {
          const chip = document.createElement("span");
          chip.className = "didar-search-deal-product";
          chip.textContent = label;
          host.appendChild(chip);
        });
      });
  }

  function loadGlobalSearchProductLabels(dealId) {
    const cached = globalSearchProductLabels.get(dealId);
    if (cached && cached.expiresAt > Date.now()) {
      return Promise.resolve(cached.labels);
    }
    if (globalSearchProductLoads.has(dealId)) {
      return globalSearchProductLoads.get(dealId);
    }
    const load = apiRequest("deal/GetDealDetail", { body: { Id: dealId } })
      .then((deal) => {
        if (Core.text(deal?.Id).toLowerCase() !== dealId) {
          throw new Error("جزئیات محصول با معامله انتخاب‌شده همخوانی ندارد.");
        }
        const labels = productLabelsFromDeal(deal);
        globalSearchProductLabels.set(dealId, {
          labels,
          expiresAt: Date.now() + GLOBAL_SEARCH_PRODUCT_CACHE_MS
        });
        return labels;
      })
      .finally(() => globalSearchProductLoads.delete(dealId));
    globalSearchProductLoads.set(dealId, load);
    return load;
  }

  function enhanceGlobalSearchProductLabels() {
    const rows = Array.from(
      document.querySelectorAll("lc-global-search .search-res-list li")
    );
    rows.forEach((row) => {
      const dealId = Core.text(row.dataset.didarSearchDealId).toLowerCase();
      if (!settings.enabled || !Core.GUID_PATTERN.test(dealId)) {
        row.classList.remove("didar-search-deal-result");
        row.querySelector(":scope > .didar-search-deal-products")?.remove();
        return;
      }
      const existingHost = row.querySelector(":scope > .didar-search-deal-products");
      if (existingHost?.dataset.dealId && existingHost.dataset.dealId !== dealId) {
        existingHost.remove();
      }
      row.classList.add("didar-search-deal-result");
      const cached = globalSearchProductLabels.get(dealId);
      if (cached && cached.expiresAt > Date.now()) {
        renderGlobalSearchProductLabels(dealId, cached.labels);
        return;
      }
      void loadGlobalSearchProductLabels(dealId)
        .then((labels) => renderGlobalSearchProductLabels(dealId, labels))
        .catch(() => {
          // Didar's native search remains usable when product details are unavailable.
        });
    });
  }

  async function recoverPlanActivityCompletions(dealId) {
    if (!settings.enabled || document.readyState === "loading" ||
        !Core.GUID_PATTERN.test(dealId) || currentDealId() !== dealId) return;
    const activities = await planActivitiesForDeal(dealId);
    for (const activity of activities) {
      if (!autoCompletionState(activity, Core.todoNote(activity), true).shouldComplete) continue;
      const rows = Core.parseTodoRows(Core.todoNote(activity));
      const index = rows.findIndex(row => row.checked && row.label === "ناموفق شدن طرح");
      const terminalIndex = index >= 0 ? index : rows.findIndex(row => row.label === DELIVERY_TODO);
      const activityId = Core.text(activity.Id).toLowerCase();
      if (activeActivitySaves.has(activityId)) continue;
      try {
        const operation = prepareDurableOperation({
          id: `activity-completion:${activityId}`,
          type: "activity-checkbox",
          lockName: `activity:${activityId}`,
          activityId, dealId, index: terminalIndex, label: rows[terminalIndex].label,
          targetChecked: true, completionOnly: true
        });
        await putOutboxOperation(operation);
        const result = await runDurableOperation(operation, persistChecklistIntent, { staged: true });
        if (result?.activity) publishVerifiedActivity(result.activity, dealId);
        if (result?.activity?.IsDone === true) scheduleCompletedActivityReconciliation(result.activity);
      } catch (error) {
        lastInteraction = `تکمیل فعالیت بررسی شد: ${error?.message || "ذخیره تأیید نشد"}`;
      }
    }
  }

  async function recoverMissingPlanProducts(dealId) {
    if (!settings.enabled || !settings.autoAddPlanProduct ||
        !Core.GUID_PATTERN.test(dealId) || currentDealId() !== dealId) return;
    await withOperationLock(`plan-product-discovery:${dealId}`, async () => {
      const activities = await planActivitiesForDeal(dealId);
      if (!activities.length) return;
      const deal = await ensureCurrentDealProductView(true, dealId);
      if (Core.text(deal?.Id).toLowerCase() !== dealId) return;
      mapExistingProductsToActivities(deal, activities);
      const pending = await readOutboxRecords();
      const ownedIds = new Set(activities.map((activity) => mappedProductItem(deal,
        productActivityMappings.get(productActivityMapKey(dealId, Core.text(activity.Id).toLowerCase()))
      )?.Id).filter(Boolean));
      for (const activity of activities) {
        const activityId = Core.text(activity.Id).toLowerCase();
        if (mappedProductItem(deal, productActivityMappings.get(productActivityMapKey(dealId, activityId)))) continue;
        if (pending.some((record) => record.id === `product:${dealId}:${activityId}`)) continue;
        // A historical same-title row with unknown ownership is not evidence of
        // absence. Leave it for review instead of adding a duplicate card.
        const unclaimed = (deal.Items || []).some((item) => !ownedIds.has(item.Id) &&
          normalizedTitle(item.Title) === productTitleForActivity(activity.Title));
        if (unclaimed) continue;
        await ensurePlanProductForActivity({ ...activity, notify: false, bindCreatedCard: false });
      }
    });
  }

  async function recoverCurrentDealPersistence(dealId) {
    const accountKey = Core.text(credentials().bizDomain).toLowerCase();
    const records = (await readOutboxRecords()).filter(
      (record) => Core.text(record.dealId).toLowerCase() === dealId &&
        (!record.accountKey || Core.text(record.accountKey).toLowerCase() === accountKey)
    );
    for (const record of records.filter((item) => item.type === "activity-checkbox")) {
      try {
        const result = await runDurableOperation(record, persistChecklistIntent, { staged: true });
        if (result?.activity) {
          publishVerifiedActivity(result.activity, dealId);
        }
        if (result?.activity?.IsDone === true) {
          scheduleCompletedActivityReconciliation(result.activity);
        }
      } catch (error) {
        lastInteraction = `بازیابی ذخیره فعالیت ناموفق بود: ${error?.message || "خطای دیدار"}`;
      }
    }

    await queueProductOperation(async () => {
      const handlers = {
        "plan-product": settings.autoAddPlanProduct ? addProductForCreatedPlanActivity : null,
        "plan-product-delete": persistProductDeletionIntent,
        "plan-product-fields": persistProductFieldsIntent
      };
      for (const type of Object.keys(handlers)) {
        if (!handlers[type]) continue;
        for (const record of records.filter((item) => item.type === type)) {
          try {
            await runDurableOperation(record, handlers[type], { staged: true });
          } catch (error) {
            lastInteraction = `بازیابی ${record.id} ناموفق بود: ${error?.message || "خطای دیدار"}`;
          }
        }
      }
    });
  }

  async function recoverPendingPersistence(preferredDealId = "") {
    const accountKey = Core.text(credentials().bizDomain).toLowerCase();
    const records = (await readOutboxRecords()).filter((record) =>
      !record.accountKey || Core.text(record.accountKey).toLowerCase() === accountKey
    );
    const dealIds = Array.from(new Set(records.map(
      (record) => Core.text(record.dealId).toLowerCase()
    ).filter((dealId) => Core.GUID_PATTERN.test(dealId))));
    const preferred = Core.text(preferredDealId).toLowerCase();
    // Case activities can also reference a deal. Their validation uses CaseId,
    // and a case-only intent has no deal group through which to be recovered.
    for (const record of records.filter((item) => item.type === "activity-checkbox" &&
      Core.GUID_PATTERN.test(Core.text(item.caseId)) && !Core.GUID_PATTERN.test(Core.text(item.dealId)))) {
      try {
        const result = await runDurableOperation(record, persistChecklistIntent, { staged: true });
        if (result?.activity) publishVerifiedActivity(result.activity, "");
      } catch (error) {
        lastInteraction = `بازیابی ذخیره فعالیت کارت ناموفق بود: ${error?.message || "خطای دیدار"}`;
      }
    }
    dealIds.sort((left, right) => Number(right === preferred) - Number(left === preferred));
    for (const dealId of dealIds) {
      try {
        await recoverCurrentDealPersistence(dealId);
      } catch (error) {
        lastInteraction = `بازیابی معامله ${dealId} ناموفق بود: ${error?.message || "خطای دیدار"}`;
      }
    }
    if (settings.enabled && Core.GUID_PATTERN.test(preferred)) {
      await recoverPlanActivityCompletions(preferred);
    }
    if (settings.enabled && settings.autoAddPlanProduct && Core.GUID_PATTERN.test(preferred)) {
      await recoverMissingPlanProducts(preferred);
    }
  }

  function scheduleCurrentDealPersistenceRecovery(force = false) {
    const dealId = currentDealId();
    if (!settings.enabled || !credentials().token) {
      return;
    }
    const now = Date.now();
    if (
      !force &&
      persistenceRecoveryDealId === dealId &&
      now - persistenceRecoveryAt < 60000
    ) {
      return;
    }
    persistenceRecoveryDealId = dealId;
    persistenceRecoveryAt = now;
    window.clearTimeout(persistenceRecoveryTimer);
    persistenceRecoveryTimer = window.setTimeout(() => {
      void recoverPendingPersistence(dealId).catch((error) => {
        lastInteraction = `بازیابی عملیات ذخیره کامل نشد: ${error?.message || "خطای دیدار"}`;
      });
    }, 700);
  }

  function layoutCallChecklists() {
    if (!CallChecklists) return;
    document.querySelectorAll("ul.todo-list").forEach((list) => {
      const editor = list.closest("lc-activity-add, lc-activity-add-inline");
      const card = list.closest(".activity-item, article");
      const title = card?.querySelector("h2")?.textContent || "";
      const template = CallChecklists.templateForKey(list.dataset.didarCallTemplate || editor?.dataset.didarCallTemplate) ||
        CallChecklists.templateForTitle(title);
      const active = settings.enabled && Boolean(template);
      list.classList.toggle("didar-call-checklist", active);
      if (active) list.style.setProperty("--didar-call-columns", String(CallChecklists.columns(settings.callChecklistColumns)));
      else list.style.removeProperty("--didar-call-columns");
    });
  }

  function scan() {
    layoutCallChecklists();
    renderCaseCallShortcuts();
    mountManualDealContact();
    planBoard?.mount(settings.enabled && document.readyState !== "loading");
    consumeGlobalSearchResultsMarkers();
    bindGlobalSearchDealRowsFromResults();
    consumeDealAddPersonMarkers();
    resolveSelectedDealAddPersonFromForm();
    preserveStableMappings();
    if (settings.enabled) {
      // Schedule server cleanup before removing its duplicate checklist evidence from the DOM.
      scheduleCompletedDuplicateCleanup();
    }
    confirmedCompletedActivities.forEach((activity) => {
      bindCompletedActivityCard(activity);
      removeStaleCompletedChecklistFromDom(activity);
    });
    document.querySelectorAll(".didar-completed-activity-fallback[data-activity-id]")
      .forEach((card) => reconcileCompletedActivityFallback(card.dataset.activityId));
    syncRememberedProductView();
    enhancePipelineActivityFilter();
    enhanceGlobalSearchProductLabels();
    if (!settings.enabled) {
      hitboxRecords.forEach(({ hitbox }) => {
        hitbox.hidden = true;
      });
      document.querySelectorAll(".didar-plan-product-fields").forEach((fields) => {
        fields.hidden = true;
      });
      return;
    }
    document
      .querySelectorAll('ul.todo-list input[type="checkbox"]')
      .forEach(enhanceCheckbox);
    enhancePlanActivityQuickActions();
    enhancePlanProductFields();
    syncRecentlyVerifiedChecklists();
    renderSelectedPersonDeals();
    scheduleCurrentDealPersistenceRecovery();
    scheduleHitboxPosition();
  }

  function scheduleScan() {
    const dealModal = globalThis.document?.querySelector?.("lc-deal-add");
    if (settings.enabled && dealModal && !dealModal.querySelector(".didar-manual-contact")) {
      mountManualDealContact();
    }
    window.clearTimeout(observerTimer);
    observerTimer = window.setTimeout(scan, 80);
  }

  function normalizeLookupDigits(value) {
    return Core.text(value)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/\D/g, "");
  }

  function normalizeIranianMobile(value) {
    let digits = normalizeLookupDigits(value);
    if (digits.startsWith("0098")) {
      digits = digits.slice(4);
    } else if (digits.startsWith("98")) {
      digits = digits.slice(2);
    }
    if (digits.startsWith("9") && digits.length === 10) {
      digits = `0${digits}`;
    }
    return /^09\d{9}$/.test(digits) ? digits : "";
  }

  function nationalCodesInValue(value) {
    const normalized = Core.text(value)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)));
    return (normalized.match(/\d+/g) || []).filter((candidate) => /^\d{10}$/.test(candidate));
  }

  function jalaliBirthDateToIso(value) {
    const parts = normalizeLookupDigits(value).match(/^(\d{4})(\d{2})(\d{2})$/);
    if (!parts) {
      return "";
    }
    let jy = Number(parts[1]);
    const jm = Number(parts[2]);
    const jd = Number(parts[3]);
    const maxDay = jm <= 6 ? 31 : jm <= 11 ? 30 : 30;
    if (jy < 1200 || jy > 1600 || jm < 1 || jm > 12 || jd < 1 || jd > maxDay) {
      return "";
    }

    jy += 1595;
    let days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) +
      Math.floor(((jy % 33) + 3) / 4) + jd +
      (jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    let gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      gy += 100 * Math.floor((days - 1) / 36524);
      days = (days - 1) % 36524;
      if (days >= 365) {
        days += 1;
      }
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      gy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    let gd = days + 1;
    const leap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
    const monthDays = [0, 31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 1;
    while (gm <= 12 && gd > monthDays[gm]) {
      gd -= monthDays[gm];
      gm += 1;
    }
    return `${gy}-${String(gm).padStart(2, "0")}-${String(gd).padStart(2, "0")}T00:00:00Z`;
  }

  function recursiveValues(value) {
    if (Array.isArray(value)) {
      return value.flatMap(recursiveValues);
    }
    if (value && typeof value === "object") {
      return Object.values(value).flatMap(recursiveValues);
    }
    return [value];
  }

  async function fetchAllSearchResults(path, criteria = {}) {
    const pageSize = 100;
    const rows = [];
    let offset = 0;
    let total = Number.POSITIVE_INFINITY;
    for (let page = 0; page < 100 && offset < total; page += 1) {
      const response = await apiRequest(path, {
        body: { Criteria: criteria, From: offset, Limit: pageSize }
      });
      if (!Array.isArray(response) && !["List", "Products", "Items"].some((key) => Array.isArray(response?.[key]))) {
        throw didarConnectionError("پاسخ جست‌وجوی دیدار قابل بررسی نیست؛ نبود مشتری تأیید نشد.", "DIDAR_SEARCH_RESPONSE_INVALID", path);
      }
      const pageRows = responseList(response);
      rows.push(...pageRows);
      total = Number(response?.TotalCount ?? response?.Total ?? Number.POSITIVE_INFINITY);
      if (!pageRows.length || pageRows.length < pageSize) {
        break;
      }
      offset += pageSize;
    }
    return rows;
  }

  function creditIntegrationProvider(value) {
    const provider = Core.text(value?.provider || value);
    return ["beta", "olive"].includes(provider) ? provider : "etebarito";
  }

  function creditIntegrationActivityTitle(value) {
    const provider = creditIntegrationProvider(value);
    return provider === "olive" ? "الیو کردیت" : provider === "beta" ? BETA_ACTIVITY_TITLE : ETEBARITO_ACTIVITY_TITLE;
  }

  function creditIntegrationLabel(value) {
    const provider = creditIntegrationProvider(value);
    return provider === "olive" ? "الیو کردیت" : provider === "beta" ? "بتا" : "اعتباریتو";
  }

  async function etebaritoDidarConfig(provider = "etebarito") {
    const activityTitle = creditIntegrationActivityTitle(provider);
    const identity = await currentIdentity(true);
    const [customFieldsResult, pipelinesResult, sourcesResult, activityTypesResult] = await Promise.allSettled([
      apiRequest("customfield/GetCustomfieldList", { body: {} }),
      apiRequest("pipeline/list/0", { body: {} }),
      apiRequest("source/GetList", { body: {} }),
      apiRequest("activity/GetActivityType", { body: {} })
    ]);
    const requiredConfigPart = (result, title) => {
      if (result.status === "fulfilled") {
        return result.value;
      }
      const error = result.reason instanceof Error
        ? result.reason
        : new Error(`دریافت ${title} از دیدار انجام نشد.`);
      error.message = `دریافت ${title} انجام نشد: ${error.message}`;
      throw error;
    };
    const customFieldsResponse = requiredConfigPart(customFieldsResult, "فیلدهای سفارشی");
    const pipelinesResponse = requiredConfigPart(pipelinesResult, "کاریزهای دیدار");
    const activityTypesResponse = requiredConfigPart(activityTypesResult, "انواع فعالیت دیدار");
    const sourcesResponse = sourcesResult.status === "fulfilled" ? sourcesResult.value : null;
    const warnings = sourcesResult.status === "rejected"
      ? [`گزینه‌های نحوه آشنایی برای این نقش قابل دریافت نیست: ${sourcesResult.reason?.message || "خطای نامشخص"}`]
      : [];
    const customFields = Array.isArray(customFieldsResponse)
      ? customFieldsResponse
      : Object.values(customFieldsResponse || {});
    const fieldByKey = (key) => customFields.find(
      (item) => Core.text(item?.Key) === key && !item?.IsDeleted
    );
    const optionTitles = (field) => (field?.Options || [])
      .map((item) => typeof item === "string" ? item : Core.text(item?.Title || item?.Value))
      .map(normalizedTitle)
      .filter(Boolean);
    const jobField = fieldByKey(ETEBARITO_JOB_FIELD_KEY);
    const planTypeField = fieldByKey(ETEBARITO_PLAN_TYPE_FIELD_KEY);
    const creditRankField = fieldByKey(ETEBARITO_CREDIT_RANK_FIELD_KEY);
    const customerStatusField = fieldByKey(ETEBARITO_CUSTOMER_STATUS_FIELD_KEY);
    const customerRoleField = fieldByKey(CREDIT_CUSTOMER_ROLE_FIELD_KEY);
    const customerRoleOptions = optionTitles(customerRoleField);
    if (!customerRoleField || !["خریدار", "ضامن"].every((role) => customerRoleOptions.includes(role))) {
      throw new Error("فیلد معاملهٔ «نقش مشتری» با گزینه‌های خریدار و ضامن در دیدار پیدا نشد.");
    }
    const pipeline = responseList(pipelinesResponse).find(
      (item) => normalizedTitle(item?.Title) === ETEBARITO_TARGET_PIPELINE
    );
    const stage = (pipeline?.Stages || []).find(
      (item) => normalizedTitle(item?.Title) === ETEBARITO_TARGET_STAGE
    );
    const creditActivityType = responseList(activityTypesResponse).find(
      (item) => !item?.IsDisabled && normalizedTitle(item?.Title) === activityTitle
    );
    const sourceOptions = responseList(sourcesResponse)
      .map((item) => ({ id: Core.text(item?.Id), title: normalizedTitle(item?.Title) }))
      .filter((item) => item.id && item.title)
      .sort((left, right) => left.title.localeCompare(right.title, "fa"));
    if (!jobField || !planTypeField || !creditRankField || !customerStatusField || !pipeline || !stage || !creditActivityType) {
      throw new Error(`فیلدهای اتصال، مقصد پرونده اعتباری / اعتبار سنجی اولیه یا فعالیت «${activityTitle}» در دیدار پیدا نشد.`);
    }
    return {
      ok: true,
      identity,
      jobFieldKey: jobField.Key,
      jobOptions: optionTitles(jobField),
      planTypeFieldKey: planTypeField.Key,
      planTypeOptions: optionTitles(planTypeField),
      creditRankFieldKey: creditRankField.Key,
      creditRankOptions: optionTitles(creditRankField),
      customerStatusFieldKey: customerStatusField.Key,
      customerStatusOptions: optionTitles(customerStatusField),
      customerRoleFieldKey: customerRoleField.Key,
      customerRoleOptions,
      customerRoleDefault: "خریدار",
      sourceOptions,
      sourceOptionsAvailable: sourcesResult.status === "fulfilled",
      warnings,
      pipelineId: pipeline.Id,
      pipelineTitle: pipeline.Title,
      stageId: stage.Id,
      stageTitle: stage.Title,
      creditActivityTypeId: creditActivityType.Id,
      creditActivityTitle: creditActivityType.Title,
      creditActivityDuration: Number(creditActivityType.Duration) || 5,
      provider: creditIntegrationProvider(provider),
      writeEnabled: true
    };
  }

  async function etebaritoContactMatches(nationalCode) {
    const allContacts = await fetchAllSearchResults("contact/search", { Keywords: nationalCode });
    const matched = (contacts) => contacts
      .filter((contact) => !contact?.IsDeleted && Core.GUID_PATTERN.test(Core.text(contact?.Id)))
      .map((contact) => {
        const nationalCodes = new Set([
          ...[contact?.NationalCode, contact?.NationalID]
            .map(normalizeLookupDigits)
            .filter((value) => /^\d{10}$/.test(value)),
          ...recursiveValues([
            contact?.LastName,
            contact?.DisplayName,
            contact?.FirstName
          ]).flatMap(nationalCodesInValue)
        ]);
        return {
          contact,
          matchedByNationalCode: nationalCodes.has(nationalCode)
        };
      })
      .filter((item) => item.matchedByNationalCode);
    let matches = matched(allContacts);
    let globalCandidates = 0;
    if (!matches.length) {
      const response = await apiRequest("search/search", { body: { Keyword: nationalCode, Types: ["contact"] } });
      if (!Array.isArray(response) && !Array.isArray(response?.List)) {
        throw didarConnectionError("پاسخ جست‌وجوی سراسری دیدار معتبر نیست؛ نبود مشتری تأیید نشد.", "DIDAR_SEARCH_RESPONSE_INVALID", "search/search");
      }
      const candidates = responseList(response).filter((contact) => !contact?.IsDeleted && Core.GUID_PATTERN.test(Core.text(contact?.Id)));
      globalCandidates = candidates.length;
      // Global search can return abbreviated contacts. Verify their fresh identity
      // before reusing one, even when their result label contains the national code.
      const details = await Promise.all(candidates.map(async (contact) => {
        const response = await apiRequest("contact/GetContactDetail", { body: { Id: contact.Id }, retry: true });
        const detail = response?.Contact || response;
        if (Core.text(detail?.Id).toLowerCase() !== Core.text(contact.Id).toLowerCase()) {
          throw didarConnectionError("هویت نتیجهٔ جست‌وجوی دیدار قابل تأیید نیست.", "DIDAR_SEARCH_IDENTITY_MISMATCH");
        }
        return detail;
      }));
      matches = matched(details);
    }
    const unique = new Map(matches.map((item) => [Core.text(item.contact.Id).toLowerCase(), item]));
    return { matches: [...unique.values()], lookupDiagnostics: { directCandidates: allContacts.length, globalCandidates, matches: unique.size } };
  }

  async function etebaritoNationalCodeMatches(nationalCode) {
    const { matches: contactMatches, lookupDiagnostics } = await etebaritoContactMatches(nationalCode);

    const contactIds = new Set(contactMatches.map((item) => Core.text(item.contact.Id).toLowerCase()).filter(Boolean));
    const conflict = contactIds.size > 1;

    let deals = [];
    if (contactIds.size) {
      const allDeals = await fetchAllSearchResults("deal/search", {
        ContactIds: Array.from(contactIds)
      });
      deals = allDeals
        .filter((deal) => {
          const relatedId = Core.text(
            deal.ContactId || deal.PersonId || deal.Contact?.Id || deal.Person?.Id
          );
          return contactIds.has(relatedId.toLowerCase()) && !deal.IsDeleted;
        })
        .map((deal) => ({
          id: deal.Id,
          contactId: Core.text(
            deal.ContactId || deal.PersonId || deal.Contact?.Id || deal.Person?.Id
          ),
          title: deal.Title,
          code: deal.Code,
          status: Core.text(deal.Status),
          pipelineId: deal.PipelineId,
          url: `https://app.didar.me/deal/${deal.Id}`
        }));
    }

    const openDeals = deals.filter((deal) => deal.status === "Pending");

    const result = {
      conflict,
      lookupDiagnostics,
      contacts: contactMatches.map((item) => ({
        id: item.contact.Id,
        displayName: item.contact.DisplayName,
        mobilePhone: normalizeIranianMobile(item.contact.MobilePhone),
        workPhone: normalizeIranianMobile(item.contact.WorkPhone),
        matchedByNationalCode: item.matchedByNationalCode
      })),
      deals,
      openDeals
    };
    Object.defineProperty(result, "matchedContactRecords", {
      value: contactMatches.map((item) => item.contact),
      enumerable: false
    });
    return result;
  }

  function selectedCreditMatches(matches, payload) {
    const contactId = Core.text(payload?.approvedContactId).toLowerCase();
    if (!contactId) return matches;
    const contact = matches.contacts.find((item) => Core.text(item.id).toLowerCase() === contactId);
    if (!contact || (matches.contacts.length > 1 && payload.confirmContactSelection !== true)) {
      return { ...matches, conflict: true };
    }
    const deals = matches.deals.filter((deal) => Core.text(deal.contactId).toLowerCase() === contactId);
    const selected = { ...matches, conflict: false, contacts: [contact], deals,
      openDeals: deals.filter((deal) => deal.status === "Pending") };
    Object.defineProperty(selected, "matchedContactRecords", {
      value: (matches.matchedContactRecords || []).filter((item) => Core.text(item.Id).toLowerCase() === contactId),
      enumerable: false
    });
    return selected;
  }

  async function verifiedCreditContact(contactId, nationalCode) {
    const response = await apiRequest("contact/GetContactDetail", { body: { Id: contactId }, retry: true });
    const detail = response?.Contact || response;
    const codes = [detail?.NationalCode, detail?.NationalID].map(normalizeLookupDigits).filter((code) => /^\d{10}$/.test(code));
    const nameCodes = recursiveValues([detail?.FirstName, detail?.LastName, detail?.DisplayName]).flatMap(nationalCodesInValue);
    if (Core.text(detail?.Id).toLowerCase() !== contactId.toLowerCase() || detail?.IsDeleted ||
        codes.some((code) => code !== nationalCode) || !(codes.includes(nationalCode) || nameCodes.includes(nationalCode))) {
      throw new Error("مشخصات مخاطب انتخابی با کد ملی گزارش تطبیق ندارد؛ مقصد را دوباره انتخاب کنید.");
    }
    return detail;
  }

  function contactHasMobile(contact, mobile) {
    return recursiveValues([contact?.MobilePhone, contact?.WorkPhone, contact?.OtherPhones])
      .some((value) => [value, ...Core.text(value).split(/[,;،|\n/-]/)]
        .some((phone) => normalizeIranianMobile(phone) === mobile));
  }

  async function etebaritoMobileMatches(payload) {
    const mobile = normalizeIranianMobile(payload?.mobile);
    if (!mobile) throw new Error("شماره همراه معتبر یازده‌رقمی وارد کنید.");
    const contactsById = new Map();
    for (const keywords of [mobile, `98${mobile.slice(1)}`]) {
      const candidates = await fetchAllSearchResults("contact/search", { Keywords: keywords });
      for (const contact of candidates) {
        const id = Core.text(contact?.Id);
        if (!contact?.IsDeleted && Core.GUID_PATTERN.test(id) && contactHasMobile(contact, mobile)) {
          contactsById.set(id.toLowerCase(), contact);
        }
      }
    }
    const contacts = [];
    for (const contact of contactsById.values()) {
      const response = await apiRequest("contact/GetContactDetail", { body: { Id: contact.Id }, retry: true });
      const detail = response?.Contact || response;
      if (Core.text(detail?.Id).toLowerCase() !== Core.text(contact.Id).toLowerCase() ||
          detail?.IsDeleted || !contactHasMobile(detail, mobile)) continue;
      contacts.push({
        id: detail.Id,
        displayName: normalizedTitle([detail.FirstName, detail.LastName].filter(Boolean).join(" ") || detail.DisplayName),
        nationalCode: normalizeLookupDigits(detail.NationalCode || detail.NationalID),
        mobilePhone: normalizeIranianMobile(detail.MobilePhone),
        workPhone: normalizeIranianMobile(detail.WorkPhone),
        url: `https://app.didar.me/contact/${detail.Id}`
      });
    }
    const contactIds = new Set(contacts.map((contact) => Core.text(contact.id).toLowerCase()));
    const rows = contacts.length ? await fetchAllSearchResults("deal/search", { ContactIds: contacts.map((contact) => contact.id) }) : [];
    const deals = rows.filter((deal) => !deal?.IsDeleted && Core.GUID_PATTERN.test(Core.text(deal?.Id)) &&
      contactIds.has(Core.text(deal.ContactId || deal.PersonId || deal.Contact?.Id || deal.Person?.Id).toLowerCase()))
      .map((deal) => ({
        id: deal.Id,
        contactId: deal.ContactId || deal.PersonId || deal.Contact?.Id || deal.Person?.Id,
        title: deal.Title,
        code: deal.Code,
        status: Core.text(deal.Status),
        url: `https://app.didar.me/deal/${deal.Id}`
      }));
    return { ok: true, mobile, contacts, deals };
  }

  async function etebaritoAppendMobileReport(payload) {
    if (payload?.confirmReportOnly !== true) throw new Error("ثبت گزارش نیازمند تأیید کارشناس است.");
    const mobile = normalizeIranianMobile(payload.mobile);
    const contactId = Core.text(payload.approvedContactId).toLowerCase();
    const selectedDealId = Core.text(payload.approvedDealId).toLowerCase();
    const subjectCode = normalizeLookupDigits(payload.reportSubject?.nationalCode);
    const provider = creditIntegrationProvider(payload);
    if (!mobile || !Core.GUID_PATTERN.test(contactId) || !/^\d{10}$/.test(subjectCode) ||
        (provider !== "beta" && !normalizeLookupDigits(payload.creditReport?.reportUniqCode)) ||
        (!Core.GUID_PATTERN.test(selectedDealId) && payload.createDeal !== true)) {
      throw new Error("شماره همراه، مخاطب انتخاب‌شده یا شناسه گزارش معتبر نیست.");
    }
    const config = await etebaritoDidarConfig(provider);
    const report = normalizedCreditReport({ creditReport: { ...payload.creditReport, provider }, provider }, config);
    return withOperationLock(`mobile-report:${Core.text(credentials().bizDomain)}:${contactId}`, async () => {
      // Phone ownership and deal membership are read again after confirmation.
      const matches = await etebaritoMobileMatches({ mobile });
      const contact = matches.contacts.find((item) => Core.text(item.id).toLowerCase() === contactId);
      if (!contact) throw new Error("این شماره دیگر به مخاطب انتخاب‌شده متصل نیست؛ دوباره بررسی کنید.");
      const contactDeals = matches.deals.filter((deal) => Core.text(deal.contactId).toLowerCase() === contactId);
      let deal = null;
      if (selectedDealId) {
        deal = contactDeals.find((item) => Core.text(item.id).toLowerCase() === selectedDealId);
        if (!deal) throw new Error("معامله انتخاب‌شده به این مخاطب تعلق ندارد؛ گزارشی ثبت نشد.");
        const detail = await etebaritoDealDetail(selectedDealId, true);
        if (Core.text(detail?.Id).toLowerCase() !== selectedDealId || detail?.IsDeleted ||
            Core.text(detail.ContactId || detail.PersonId || detail.Contact?.Id || detail.Person?.Id).toLowerCase() !== contactId) {
          throw new Error("ارتباط معامله و مخاطب تغییر کرده است؛ دوباره بررسی کنید.");
        }
      } else {
        const approvedIds = payload.approvedExistingDealIds;
        if (!Array.isArray(approvedIds) || approvedIds.length > 500 ||
            approvedIds.some((id) => !Core.GUID_PATTERN.test(Core.text(id))) ||
            new Set(approvedIds.map((id) => Core.text(id).toLowerCase())).size !== approvedIds.length ||
            contactDeals.length !== approvedIds.length ||
            contactDeals.some((item) => !approvedIds.some((id) => Core.text(id).toLowerCase() === Core.text(item.id).toLowerCase()))) {
          throw new Error("معاملات این مخاطب تغییر کرده‌اند؛ مقصد را دوباره انتخاب کنید.");
        }
        const fields = selectedFieldValues(payload, config);
        const sourceId = Core.text(payload.preparedDealSourceId);
        if (sourceId && !(config.sourceOptions || []).some(source => source.id === sourceId)) {
          throw new Error("نحوه آشنایی انتخاب‌شده معتبر نیست؛ دوباره بررسی کنید.");
        }
        const displayName = normalizedTitle(contact.displayName);
        const destinationCode = normalizeLookupDigits(contact.nationalCode);
        const title = /^\d{10}$/.test(destinationCode) && !nationalCodesInValue(displayName).includes(destinationCode)
          ? `${displayName} ${destinationCode}` : displayName;
        const created = await apiRequest("deal/save", { body: { Deal: {
          Title: `معامله ${title}`, ContactId: contact.id, PersonId: contact.id,
          CompanyId: EMPTY_GUID, PipelineId: config.pipelineId, PipelineStageId: config.stageId,
          OwnerId: config.identity.id, Status: "Pending", VisibilityType: "All", Fields: fields,
          ...(sourceId ? { SourceId: sourceId } : {})
        } } });
        const id = entityIdFromSaveResult(created);
        if (!Core.GUID_PATTERN.test(id)) throw new Error("دیدار شناسهٔ معاملهٔ جدید را تأیید نکرد؛ مقصد را بررسی کنید.");
        deal = { id, contactId: contact.id, title: `معامله ${title}`, status: "Pending", url: `https://app.didar.me/deal/${id}` };
      }
      let activity;
      try {
        activity = await createCreditReportActivity({
        dealId: deal.id,
        contactId,
        identity: config.identity,
        activityTypeId: config.creditActivityTypeId,
        activityDuration: config.creditActivityDuration,
        report,
        previousRank: "",
        isUpdate: false,
        reportOnly: true,
        reportSubject: { nationalCode: subjectCode, fullName: normalizedTitle(payload.reportSubject?.fullName).slice(0, 160) }
        });
      } catch (error) {
        if (!selectedDealId) return { ok: false, partial: true, contact, deal,
          error: `معامله ساخته شد، اما گزارش ثبت نشد. ${error.message}` };
        throw error;
      }
      return { ok: true, reportOnly: true, activityCreated: activity.created, activityUpdated: Boolean(activity.updated), activitySkipped: activity.duplicate, contact, deal };
    });
  }

  function isoDateToJalali(value) {
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) {
      return "";
    }
    try {
      const parts = new Intl.DateTimeFormat("fa-IR-u-ca-persian-nu-latn", {
        timeZone: "UTC",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
      }).formatToParts(date);
      const part = (type) => parts.find((item) => item.type === type)?.value || "";
      const year = normalizeLookupDigits(part("year"));
      const month = normalizeLookupDigits(part("month")).padStart(2, "0");
      const day = normalizeLookupDigits(part("day")).padStart(2, "0");
      return year && month && day ? `${year}/${month}/${day}` : "";
    } catch {
      return "";
    }
  }

  function normalizedMultiFieldValue(value) {
    if (Array.isArray(value)) {
      return value.map(normalizedTitle).filter(Boolean);
    }
    const single = normalizedTitle(value);
    return single ? [single] : [];
  }

  async function enrichedEtebaritoMatches(matches, config) {
    const contactDetails = await Promise.allSettled(
      matches.contacts.map((contact) => apiRequest("contact/GetContactDetail", {
        body: { Id: contact.id }
      }))
    );
    const contacts = matches.contacts.map((contact, index) => {
      const detailResult = contactDetails[index]?.status === "fulfilled"
        ? contactDetails[index].value
        : null;
      const candidate = detailResult?.Contact || detailResult;
      const detail = Core.text(candidate?.Id) === Core.text(contact.id) ? candidate : null;
      const fields = dealFieldValues(detail?.Fields);
      const fullName = normalizedTitle(
        [detail?.FirstName, detail?.LastName].filter(Boolean).join(" ") || detail?.DisplayName
      );
      return {
        ...contact,
        fullName,
        firstName: normalizedTitle(detail?.FirstName),
        lastName: normalizedTitle(detail?.LastName),
        nationalCode: normalizeLookupDigits(detail?.NationalCode || detail?.NationalID),
        mobilePhone: normalizeIranianMobile(detail?.MobilePhone) || contact.mobilePhone,
        workPhone: normalizeIranianMobile(detail?.WorkPhone) || contact.workPhone,
        birthDateJalali: isoDateToJalali(detail?.BirthDate),
        job: normalizedTitle(fields[config.jobFieldKey]),
        url: `https://app.didar.me/contact/${contact.id}`,
        ownerName: normalizedTitle(detail?.Owner?.DisplayName || detail?.Owner?.Title)
      };
    });

    const dealDetails = await Promise.allSettled(
      matches.deals.map((deal) => etebaritoDealDetail(deal.id, true))
    );
    const deals = matches.deals.map((deal, index) => {
      const detail = dealDetails[index]?.status === "fulfilled" ? dealDetails[index].value : {};
      const fields = dealFieldValues(detail?.Fields);
      return {
        ...deal,
        sourceId: Core.text(detail?.SourceId || detail?.Source?.Id),
        changeToWonTime: Core.text(detail?.ChangeToWonTime),
        changeToLossTime: Core.text(detail?.ChangeToLossTime),
        rank: normalizedTitle(fields[config.creditRankFieldKey]),
        customerStatus: normalizedTitle(fields[config.customerStatusFieldKey]),
        customerRole: normalizedTitle(fields[config.customerRoleFieldKey]),
        planTypes: normalizedMultiFieldValue(fields[config.planTypeFieldKey]),
        amount: Core.text(detail?.Price ?? detail?.Value ?? detail?.TotalPrice),
        ownerName: normalizedTitle(detail?.Owner?.DisplayName || detail?.Owner?.Title),
        products: (Array.isArray(detail?.Items) ? detail.Items : []).map((item) =>
          normalizedTitle(item.Title || item.Product?.Title || item.ProductTitle)).filter(Boolean)
      };
    });
    return {
      ...matches,
      contacts,
      deals,
      openDeals: deals.filter((deal) => deal.status === "Pending")
    };
  }

  async function syncEtebaritoContactProfile(contact, sourceFields, config, options = {}) {
    const integrationLabel = creditIntegrationLabel(config?.provider);
    const contactId = Core.text(contact?.Id);
    const detailResult = await apiRequest("contact/GetContactDetail", {
      body: { Id: contactId }
    });
    const detail = detailResult?.Contact || detailResult;
    if (Core.text(detail?.Id) !== contactId) {
      throw new Error("جزئیات کامل مخاطب برای بروزرسانی دریافت نشد.");
    }
    const nationalCode = normalizeLookupDigits(sourceFields?.nationalCode);
    const fullName = normalizedTitle(sourceFields?.fullName)
      .replace(new RegExp(`\\s*${nationalCode}$`), "")
      .trim();
    const expectedName = [fullName, nationalCode].filter(Boolean).join(" ");
    const birthDateJalali = Core.text(sourceFields?.birthDateJalali);
    const birthDate = birthDateJalali ? jalaliBirthDateToIso(birthDateJalali) : "";
    const job = normalizedTitle(sourceFields?.job);
    const primary = normalizeIranianMobile(detail.MobilePhone);
    const secondary = normalizeIranianMobile(detail.WorkPhone);
    const mobile = options.preserveExistingMobile && (primary || secondary)
      ? (primary || secondary)
      : normalizeIranianMobile(sourceFields?.mobile);
    const updatedContact = { Id: contactId };
    for (const key of [
      "CompanyId",
      "Type",
      "LeadType",
      "ContactType",
      "VisibilityType",
      "OwnerId",
      "FirstName",
      "LastName",
      "CustomerCode",
      "NationalCode",
      "MobilePhone",
      "WorkPhone",
      "Email",
      "BirthDate",
      "BirthDateisValid",
      "Fields"
    ]) {
      if (detail[key] !== undefined && detail[key] !== null) {
        updatedContact[key] = detail[key];
      }
    }
    const addedFields = [];
    let phoneField = "";
    let phoneAlreadyPresent = false;
    let phoneWarning = "";
    if (mobile) {
      if (options.replaceMobile && mobile !== primary) {
        const owners = await etebaritoMobileMatches({ mobile });
        if (owners.contacts.some((item) => Core.text(item.id).toLowerCase() !== contactId.toLowerCase())) {
          throw new Error("Duplicate contacts is not allowed؛ این شماره همراه به مخاطب دیگری متصل است.");
        }
        updatedContact.MobilePhone = mobile;
        phoneField = "MobilePhone";
        addedFields.push("شماره همراه");
      } else if (mobile === primary || mobile === secondary) {
        phoneAlreadyPresent = true;
      } else {
        phoneField = primary ? (secondary ? "" : "WorkPhone") : "MobilePhone";
        if (phoneField) {
          updatedContact[phoneField] = mobile;
          addedFields.push("شماره همراه");
        } else {
          phoneWarning = `هر دو جایگاه شماره مخاطب در دیدار از قبل پر هستند؛ شماره ${integrationLabel} جایگزین نشد.`;
        }
      }
    }
    const currentName = normalizedTitle([detail.FirstName, detail.LastName].filter(Boolean).join(" "));
    const shouldCorrectName = options.correctName && fullName && expectedName !== currentName;
    if (shouldCorrectName || (fullName && !currentName)) {
      updatedContact.FirstName = "";
      updatedContact.LastName = options.correctName ? expectedName : fullName;
      addedFields.push("نام و نام خانوادگی");
    }
    if (/^\d{10}$/.test(nationalCode) && !normalizeLookupDigits(detail.NationalCode || detail.NationalID)) {
      updatedContact.NationalCode = nationalCode;
      addedFields.push("کد ملی");
    }
    const correctOliveBirthDate = (config?.provider === "olive" || options.replaceBirthDate) && birthDate &&
      Core.text(detail.BirthDate).slice(0, 10) !== birthDate.slice(0, 10);
    if (birthDate && (!Core.text(detail.BirthDate) || correctOliveBirthDate)) {
      updatedContact.BirthDate = birthDate;
      updatedContact.BirthDateisValid = true;
      addedFields.push("تاریخ تولد");
    }
    if (job && (config.jobOptions || []).includes(job)) {
      const fields = dealFieldValues(detail.Fields);
      if (!normalizedTitle(fields[config.jobFieldKey]) || (options.forceJob && normalizedTitle(fields[config.jobFieldKey]) !== job)) {
        fields[config.jobFieldKey] = job;
        updatedContact.Fields = fields;
        addedFields.push("شغل");
      }
    }
    if (!addedFields.length) {
      return {
        profileUpdated: false,
        profileFieldsAdded: [],
        nameCorrected: false,
        phoneAdded: false,
        phoneAlreadyPresent,
        phoneField,
        phoneWarning
      };
    }
    await apiRequest("contact/save", { body: { Contact: updatedContact } });
    const verifiedResult = await apiRequest("contact/GetContactDetail", {
      body: { Id: contactId }
    });
    const verified = verifiedResult?.Contact || verifiedResult;
    if (phoneField && normalizeIranianMobile(verified?.[phoneField]) !== mobile) {
      throw new Error(`دیدار افزودن شماره همراه ${integrationLabel} را تأیید نکرد.`);
    }
    if (shouldCorrectName && normalizedTitle([verified?.FirstName, verified?.LastName].filter(Boolean).join(" ")) !== expectedName) {
      throw new Error("دیدار اصلاح نام مخاطب را تأیید نکرد.");
    }
    if (birthDate && addedFields.includes("تاریخ تولد") && (!Core.text(verified?.BirthDate) ||
        (correctOliveBirthDate && Core.text(verified?.BirthDate).slice(0, 10) !== birthDate.slice(0, 10)))) {
      throw new Error(`دیدار افزودن تاریخ تولد ${integrationLabel} را تأیید نکرد.`);
    }
    if (options.forceJob && normalizedTitle(dealFieldValues(verified?.Fields)[config.jobFieldKey]) !== job) {
      throw new Error("دیدار ثبت شغل انتخاب‌شده را تأیید نکرد.");
    }
    if (
      addedFields.includes("کد ملی") &&
      normalizeLookupDigits(verified?.NationalCode || verified?.NationalID) !== nationalCode
    ) {
      throw new Error(`دیدار افزودن کد ملی ${integrationLabel} را تأیید نکرد.`);
    }
    return {
      profileUpdated: true,
      profileFieldsAdded: addedFields,
      nameCorrected: Boolean(shouldCorrectName),
      phoneAdded: Boolean(phoneField),
      phoneAlreadyPresent,
      phoneField,
      phoneWarning
    };
  }

  async function etebaritoDidarLookup(payload) {
    await currentIdentity(true);
    const nationalCode = normalizeLookupDigits(payload?.nationalCode);
    if (!/^\d{10}$/.test(nationalCode)) {
      throw new Error("کد ملی ده‌رقمی برای بررسی معتبر نیست.");
    }
    const [config, matches] = await Promise.all([
      etebaritoDidarConfig(creditIntegrationProvider(payload)),
      etebaritoNationalCodeMatches(nationalCode)
    ]);
    return {
      ok: true,
      writeEnabled: true,
      ...(await enrichedEtebaritoMatches(matches, config))
    };
  }

  function entityIdFromSaveResult(value) {
    const candidates = [
      value?.Id,
      value?.Contact?.Id,
      value?.Deal?.Id,
      value?.Response?.Id,
      typeof value === "string" ? value : ""
    ];
    return candidates.map(Core.text).find((item) => Core.GUID_PATTERN.test(item)) || "";
  }

  function selectedCustomerRole(payload, config, defaultRole = "") {
    const role = normalizedTitle(payload?.preparedDealFields?.[config.customerRoleFieldKey]) || defaultRole;
    if (role && !(config.customerRoleOptions || []).includes(role)) {
      throw new Error("نقش مشتری معتبر نیست؛ خریدار یا ضامن را انتخاب کنید.");
    }
    return role;
  }

  function selectedFieldValues(payload, config) {
    const prepared = payload?.preparedDealFields || {};
    const planTypes = Array.isArray(prepared[config.planTypeFieldKey])
      ? prepared[config.planTypeFieldKey].map(normalizedTitle).filter(Boolean)
      : [];
    const rank = normalizedTitle(prepared[config.creditRankFieldKey]);
    const customerStatus = normalizedTitle(prepared[config.customerStatusFieldKey]);
    const validPlanTypes = new Set(config.planTypeOptions || []);
    if (planTypes.some((item) => !validPlanTypes.has(item))) {
      throw new Error("یکی از نوع طرح‌های انتخاب‌شده معتبر نیست.");
    }
    if (rank && !(config.creditRankOptions || []).includes(rank)) {
      throw new Error("رتبه اعتباری معتبر انتخاب نشده است.");
    }
    if (customerStatus && !(config.customerStatusOptions || []).includes(customerStatus)) {
      throw new Error("وضعیت مشتری جدید/قدیم معتبر انتخاب نشده است.");
    }
    const fields = {};
    if (planTypes.length) {
      fields[config.planTypeFieldKey] = planTypes;
    }
    if (rank) {
      fields[config.creditRankFieldKey] = rank;
    }
    if (customerStatus) {
      fields[config.customerStatusFieldKey] = customerStatus;
    }
    const customerRole = selectedCustomerRole(payload, config, config.customerRoleDefault);
    if (customerRole) fields[config.customerRoleFieldKey] = customerRole;
    return fields;
  }

  function safeHtml(value) {
    return Core.text(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function normalizedCreditReport(payload, config) {
    const source = payload?.creditReport || {};
    const provider = creditIntegrationProvider(source.provider || payload?.provider || config?.provider);
    const prepared = payload?.preparedDealFields || {};
    const rank = normalizedTitle(
      prepared[config.creditRankFieldKey] || source.creditRank
    );
    if (rank && !(config.creditRankOptions || []).includes(rank)) {
      throw new Error("رتبه اعتباری گزارش با گزینه‌های فعلی دیدار تطابق ندارد.");
    }
    const contracts = (Array.isArray(source.overdueContracts) ? source.overdueContracts : [])
      .slice(0, 100)
      .map((item) => ({
        role: normalizedTitle(item?.role),
        contractType: normalizedTitle(item?.contractType).slice(0, 120),
        lender: normalizedTitle(item?.lender).slice(0, 160),
        amount: normalizeLookupDigits(item?.amount)
      }))
      .filter((item) =>
        ["متقاضی", "ضامن"].includes(item.role) &&
        item.contractType &&
        item.lender &&
        /^\d+$/.test(item.amount) &&
        !/^0+$/.test(item.amount)
      );
    const report = {
      provider,
      reportUniqCode: normalizeLookupDigits(source.reportUniqCode).slice(0, 40),
      creditScore: normalizedTitle(source.creditScore).slice(0, 40),
      rank,
      contracts
    };
    if (provider === "olive") {
      if (!/^\d{20}$/.test(report.reportUniqCode) || !/^\d{1,3}$/.test(report.creditScore) || Number(report.creditScore) > 900) throw new Error("گزارش الیو کردیت کامل و معتبر نیست.");
      report.sourceSystem = "olive";
      report.reportDate = normalizedTitle(source.reportDate).slice(0, 40);
      report.overdueStatus = ["clear", "present", "unknown", "not_provided"].includes(source.overdueStatus) ? source.overdueStatus : "unknown";
      report.judgments = (Array.isArray(source.judgments) ? source.judgments : []).slice(0, 10).map((item) => ({
        title: normalizedTitle(item.title), count: normalizeLookupDigits(item.count), amount: normalizeLookupDigits(item.amount)
      })).filter((item) => ["حکم اجرا شده", "حکم اجرا نشده", "حکم اعسار"].includes(item.title) && /^\d{1,30}$/.test(item.count) && /^\d{1,30}$/.test(item.amount));
      report.checks = (Array.isArray(source.checks) ? source.checks : []).slice(0, 10).map((item) => ({
        label: normalizedTitle(item.label).slice(0, 80), status: ["pass", "fail"].includes(item.status) ? item.status : "unknown",
        ...(item.detail ? { detail: normalizedTitle(item.detail).slice(0, 600) } : {})
      }));
    }
    if (provider === "beta") {
      if (source.sourceSystem === "tamin") {
        const amount = Core.text(source.monthlyCapacityRials);
        const pensionerId = normalizeLookupDigits(source.pensionerId);
        const nationalCode = normalizeLookupDigits(source.nationalCode);
        const receivedDate = normalizedTitle(source.receivedDate);
        if (!/^\d{1,30}$/.test(amount) || !/^\d{1,20}$/.test(pensionerId) ||
            !/^\d{10}$/.test(nationalCode) || !/^1[34]\d{2}\/\d{2}\/\d{2}$/.test(receivedDate)) {
          throw new Error("اطلاعات توان قسط تأمین اجتماعی معتبر و کامل نیست.");
        }
        return { provider: "beta", sourceSystem: "tamin", monthlyCapacityRials: amount.replace(/^0+(?=\d)/, ""),
          pensionerId, nationalCode, receivedDate, reportUniqCode: "", creditScore: "", rank: "", contracts: [] };
      }
      report.reportUniqCode = "";
      report.creditScore = "";
      report.rank = "";
      report.contracts = [];
      report.inquiryDate = normalizedTitle(source.inquiryDate).slice(0, 40);
      report.validUntil = normalizedTitle(source.validUntil).slice(0, 20);
      report.eligibility = normalizedTitle(source.eligibility).slice(0, 80);
      report.monthlyCapacityRials = normalizeLookupDigits(source.monthlyCapacityRials).slice(0, 30);
      report.overdueCount = Math.max(0, Number(source.overdueCount) || 0);
      report.overdueHeadline = normalizedTitle(source.overdueHeadline).slice(0, 240);
      report.overdueSummary = normalizedTitle(source.overdueSummary).slice(0, 240);
      report.commitmentStatuses = (Array.isArray(source.commitmentStatuses) ? source.commitmentStatuses : [])
        .slice(0, 20)
        .map((item) => ({
          label: normalizedTitle(item?.label).slice(0, 80),
          status: normalizedTitle(item?.status).slice(0, 120),
          result: ["pass", "fail"].includes(item?.result) ? item.result : "unknown"
        }))
        .filter((item) => item.label);
      report.purchases = {
        golrang: Boolean(source.purchases?.golrang),
        samin: Boolean(source.purchases?.samin)
      };
    }
    return report;
  }

  function groupedContractsHtml(contracts) {
    const sections = [];
    for (const role of ["متقاضی", "ضامن"]) {
      const rows = contracts.filter((item) => item.role === role);
      if (!rows.length) {
        continue;
      }
      const items = rows.map((item) =>
        `<li>❌️ <strong>نوع قرارداد:</strong> ${safeHtml(item.contractType)} | ` +
        `<strong>اعتباردهنده:</strong> ${safeHtml(item.lender)} | ` +
        `<strong>مبلغ:</strong> ${safeHtml(item.amount.replace(/\B(?=(\d{3})+(?!\d))/g, ","))} ریال</li>`
      ).join("");
      sections.push(`<p><strong>نقش ${role}</strong></p><ul>${items}</ul>`);
    }
    return sections.join("");
  }

  function creditStatusIsPositive(value, fallback = null) {
    const text = normalizedTitle(value);
    if (!text) {
      return fallback;
    }
    if (/(غیر\s*مشمول|عدم\s*مشمول|مشمول(?:\s*طرح)?\s*نیست|ناموفق|رد\s*شده|فوت\s*شده|مسدود|برگشت\s*خورده|معوق)/.test(text)) {
      return false;
    }
    if (/(مشمول|تأیید|تایید|بررسی\s*شده|عادی|فعال|سالم|ندارد|بدون)/.test(text)) {
      return true;
    }
    return fallback;
  }

  function creditStatusIcon(isPositive) {
    return isPositive === true ? "✅️" : isPositive === false ? "❌️" : "❔";
  }

  function betaCommitmentRowsHtml(report) {
    if (!report.commitmentStatuses.length) {
      return "<p>جزئیات وضعیت تعهدات در صفحه نتیجه ثبت نشده است.</p>";
    }
    const rows = report.commitmentStatuses.map((item) => {
      const label = normalizedTitle(item.label);
      const status = normalizedTitle(item.status) || "ثبت نشده";
      if (/موارد\s*بررسی/.test(label)) {
        const reviewedItems = status
          .split(/[،,]/)
          .map((value) => normalizedTitle(value))
          .filter(Boolean)
          .map((value) => `${creditStatusIcon(null)} ${safeHtml(value)}`)
          .join("، ");
        return `<li><strong>${safeHtml(label)}:</strong> ${reviewedItems || safeHtml(status)}</li>`;
      }
      const isPositive = item.result === "pass" ? true : item.result === "fail" ? false :
        creditStatusIsPositive(status);
      return `<li><strong>${safeHtml(label)}:</strong> ${creditStatusIcon(isPositive)} ${safeHtml(status)}</li>`;
    });
    return `<ul>${rows.join("")}</ul>`;
  }

  function creditReportNoteHtml(report, options = {}) {
    if (report.provider === "olive") {
      const debt = report.overdueStatus === "clear" ? "✅ در گزارش مورد سررسیدشدهٔ پرداخت‌نشده ثبت نشده است."
        : report.overdueStatus === "present" ? "❌ بدهی سررسیدشدهٔ پرداخت‌نشده در گزارش وجود دارد."
          : report.overdueStatus === "not_provided" ? "گزارش با اطلاعات محدود سوابق تسهیلاتی تهیه شده و جدول مبالغ سررسیدشده را ارائه نکرده است؛ این وضعیت به معنی نداشتن بدهی نیست."
          : "وضعیت بدهی سررسیدشده از گزارش به‌طور قطعی خوانده نشد؛ PDF بررسی شود.";
      return `<p><strong>گزارش اعتبارسنجی الیو کردیت</strong></p>` +
        `<p><strong>منبع:</strong> Olive Credit</p><p><strong>شناسه یکتای گزارش:</strong> ${safeHtml(report.reportUniqCode)}</p>` +
        `<p><strong>تاریخ گزارش:</strong> ${safeHtml(report.reportDate || "ثبت نشده")}</p>` +
        `<p><strong>امتیاز اعتباری:</strong> ${safeHtml(report.creditScore)} | <strong>رتبه اعتباری:</strong> ${safeHtml(report.rank)}</p>` +
        `<p><strong>وضعیت بدهی‌های سررسیدشده:</strong> ${safeHtml(debt)}</p>${groupedContractsHtml(report.contracts)}` +
        (report.checks || []).map((item) => `<p>${item.status === "pass" ? "✅" : item.status === "fail" ? "❌" : "؟"} ${safeHtml(item.label)}: ${item.status === "pass" ? "فاقد سابقهٔ منفی در گزارش" : item.status === "fail" ? "سابقهٔ منفی در گزارش" : "قابل تشخیص نبود؛ نیازمند بررسی"}</p>${item.detail ? `<p>${safeHtml(item.detail)}</p>` : ""}`).join("") +
        (report.judgments || []).map((item) => `<p><strong>${safeHtml(item.title)}:</strong> تعداد ${safeHtml(item.count)} — مبلغ کل طبق گزارش: ${safeHtml(item.amount.replace(/\B(?=(\d{3})+(?!\d))/g, ","))}</p>`).join("");
    }
    if (report.sourceSystem === "tamin") {
      const amount = BigInt(report.monthlyCapacityRials);
      const money = (value) => value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      return [
        "<p><strong>گزارش اعتبارسنجی بتا</strong></p>",
        "<p><strong>منبع:</strong> سامانه خدمات غیرحضوری تأمین اجتماعی — کسر اقساط</p>",
        `<p><strong>تاریخ دریافت:</strong> ${safeHtml(report.receivedDate)}</p>`,
        `<p><strong>توان قسط:</strong> ${money(amount / 10n)} تومان</p>`
      ].join("");
    }
    if (creditIntegrationProvider(report) === "beta") {
      const capacityRials = normalizeLookupDigits(report.monthlyCapacityRials);
      const capacityTomans = capacityRials
        ? (BigInt(capacityRials) / 10n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        : "ثبت نشده";
      const eligibilityIsPositive = creditStatusIsPositive(report.eligibility);
      const overdueIsClear = Number(report.overdueCount) === 0 && (
        /ندار/.test(normalizedTitle(report.overdueHeadline)) ||
        /عادی/.test(normalizedTitle(report.overdueSummary))
      );
      const overdueStatus = report.overdueHeadline || report.overdueSummary || "وضعیت قسط سررسیدشده مشخص نیست";
      const commitmentRows = betaCommitmentRowsHtml(report);
      return [
        "<p><strong>گزارش اعتبارسنجی بتا</strong></p>",
        `<p><strong>تاریخ استعلام:</strong> ${safeHtml(report.inquiryDate || "ثبت نشده")}</p>`,
        `<p><strong>تاریخ اعتبار:</strong> ${safeHtml(report.validUntil || "ثبت نشده")}</p>`,
        "<p><br></p>",
        `<p><strong>وضعیت طرح:</strong> ${creditStatusIcon(eligibilityIsPositive)} ${safeHtml(report.eligibility || "ثبت نشده")}</p>`,
        "<p><br></p>",
        `<p><strong>توان پرداخت قسط ماهیانه طرح الماس رفاه:</strong> ${safeHtml(capacityTomans)} تومان</p>`,
        "<p><br></p>",
        "<p><strong>وضعیت تعهدات</strong></p>",
        commitmentRows,
        "<p><br></p>",
        "<p><strong>اقساط معوق</strong></p>",
        `<p><strong>تعداد:</strong> ${safeHtml(String(report.overdueCount))} قسط معوق</p>`,
        `<p>${creditStatusIcon(overdueIsClear)} ${safeHtml(overdueStatus)}</p>`,
        "<p><br></p>",
        "<p><strong>سوابق خرید موردنیاز</strong></p>",
        `<p>${creditStatusIcon(!report.purchases.golrang)} مشتری خرید گلرنگ ${report.purchases.golrang ? "دارد" : "ندارد"}.</p>`,
        `<p>${creditStatusIcon(!report.purchases.samin)} مشتری خرید ثمین ${report.purchases.samin ? "دارد" : "ندارد"}.</p>`,
        "<p><br></p>",
        "<p>این گزارش به‌صورت خودکار توسط افزونه و با تأیید کارشناس در فعالیت اعتبارسنجی بتا ثبت شده است.</p>"
      ].join("");
    }
    const previousRank = normalizedTitle(options.previousRank);
    const rankText = report.rank || "ثبت نشده";
    const scoreText = report.creditScore || "ثبت نشده";
    const reportCodeText = report.reportUniqCode || "ثبت نشده";
    const rankHistory = options.isUpdate
      ? `<p><strong>رتبه قبلی:</strong> ${safeHtml(previousRank || "ثبت نشده")} | ` +
        `<strong>رتبه جدید:</strong> ${safeHtml(rankText)}</p>`
      : `<p><strong>رتبه اعتباری:</strong> ${safeHtml(rankText)}</p>`;
    const contractText = report.contracts.length
      ? `<p><strong>وضعیت بدهی‌های سررسیدشده:</strong></p>` +
        `<p>❌️ موارد سررسیدشده پرداخت‌نشده در گزارش ثبت شده است.</p>${groupedContractsHtml(report.contracts)}`
      : options.isUpdate
        ? "<p><strong>وضعیت بدهی‌های سررسیدشده:</strong></p><p>✅️ در گزارش جدید مورد پرداخت‌نشده‌ای در خلاصه قراردادهای متقاضی یا ضامن ثبت نشده است؛ موارد قبلی رفع شده‌اند.</p>"
        : "<p><strong>وضعیت بدهی‌های سررسیدشده:</strong></p><p>✅️ مورد پرداخت‌نشده‌ای در خلاصه قراردادهای متقاضی یا ضامن ثبت نشده است.</p>";
    return [
      "<p><strong>گزارش اعتبارسنجی اعتباریتو</strong></p>",
      `<p><strong>شناسه یکتای گزارش:</strong> ${safeHtml(reportCodeText)}</p>`,
      rankHistory,
      `<p><strong>امتیاز اعتباری:</strong> ${safeHtml(scoreText)}</p>`,
      "<p><br></p>",
      contractText,
      "<p><br></p>",
      "<p>این گزارش به‌صورت خودکار توسط افزونه و با تأیید کارشناس در فعالیت اعتباریتو ثبت شده است.</p>"
    ].join("");
  }

  function comparableCreditNoteHtml(value) {
    return Core.text(value)
      .replace(/<!--\s*didar-(?:etebarito|beta)-credit-v[12]:[a-f0-9]+\s*-->/gi, "")
      .replace(/<p><strong>شناسه یکتای گزارش:<\/strong>[\s\S]*?<\/p>/i, "")
      .replace(
        /<p><strong>رتبه قبلی:<\/strong>[\s\S]*?<strong>رتبه جدید:<\/strong>\s*([\s\S]*?)<\/p>/i,
        "<p><strong>رتبه اعتباری:</strong>$1</p>"
      )
      .replace(
        /<p><strong>وضعیت بدهی‌های سررسیدشده:<\/strong><\/p>\s*<p>[\s\S]*?<\/p>/i,
        "<p>NO_OVERDUE</p>"
      )
      .replace(
        /<p><strong>وضعیت بدهی‌های سررسیدشده:<\/strong>[\s\S]*?<\/p>/i,
        "<p>NO_OVERDUE</p>"
      )
      .replace(/\s+/g, " ")
      .trim();
  }

  function creditNoteHash(value) {
    const source = comparableCreditNoteHtml(value);
    let hash = 2166136261;
    for (let index = 0; index < source.length; index += 1) {
      hash ^= source.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).padStart(8, "0");
  }

  function creditReportIdentityHash(report, noteBody) {
    if (report.sourceSystem === "tamin") {
      return creditNoteHash(`tamin:${report.nationalCode}:${report.pensionerId}:${report.receivedDate}:${report.monthlyCapacityRials}`);
    }
    if (creditIntegrationProvider(report) === "beta") {
      return creditNoteHash(`beta:${noteBody}`);
    }
    const reportCode = normalizeLookupDigits(report?.reportUniqCode);
    return creditNoteHash(reportCode ? `report:${reportCode}` : `snapshot:${noteBody}`);
  }

  function creditReportCodeFromNote(value) {
    const match = Core.text(value).match(
      /<p><strong>شناسه یکتای گزارش:<\/strong>\s*([^<]+)<\/p>/i
    );
    return normalizeLookupDigits(match?.[1]);
  }

  function betaInquiryDateFromNote(value) {
    const match = Core.text(value).match(/<strong>تاریخ استعلام:<\/strong>\s*([^<]+)<\/p>/i);
    return normalizedTitle(match?.[1]);
  }

  async function reviseBetaCreditActivity(activity, dealId, inquiryDate, resultNote) {
    const activityId = Core.text(activity?.Id);
    if (!Core.GUID_PATTERN.test(activityId)) {
      throw new Error("شناسه فعالیت قبلی اعتبارسنجی بتا معتبر نیست.");
    }
    const detail = await apiRequest("activity/GetActivityById", {
      body: { Id: activityId }, retry: true
    });
    if (Core.text(detail?.Id) !== activityId || Core.text(detail?.DealId) !== dealId ||
        detail?.IsDeleted || detail?.CanEdit === false ||
        betaInquiryDateFromNote(detail?.ResultNote) !== inquiryDate) {
      throw new Error("فعالیت قبلی این استعلام در دیدار قابل ویرایش مطمئن نیست؛ گزارشی تکراری ساخته نشد.");
    }
    await apiRequest("activity/SaveActivity", {
      body: {
        Activity: { ...detail, ResultNote: resultNote },
        NewAttachments: [],
        SetDone: Boolean(detail.IsDone)
      }
    });
    for (const wait of [0, 180, 420, 850, 1500]) {
      if (wait) await delay(wait);
      const verified = await apiRequest("activity/GetActivityById", {
        body: { Id: activityId }, retry: true
      });
      if (Core.text(verified?.Id) === activityId &&
          comparableCreditNoteHtml(verified?.ResultNote) === comparableCreditNoteHtml(resultNote)) {
        return;
      }
    }
    throw new Error("اصلاح گزارش قبلی اعتبارسنجی بتا در دیدار تأیید نشد؛ گزارشی تکراری ساخته نشد.");
  }

  async function creditReportActivities(dealId, activityTypeId, report, contactId = "") {
    const activityTitle = creditIntegrationActivityTitle(report);
    const reportHeading = `گزارش اعتبارسنجی ${creditIntegrationLabel(report)}`;
    const response = await apiRequest("activity/GetDetailActivities", {
      body: dealId === EMPTY_GUID ? { ContactId: contactId } : { DealId: dealId },
      retry: true
    });
    const activities = [
      ...(Array.isArray(response?.Planned) ? response.Planned : []),
      ...(Array.isArray(response?.Done) ? response.Done : []),
      ...(Array.isArray(response?.Pinned) ? response.Pinned : [])
    ];
    const reports = activities
      .filter((activity) =>
        !activity?.IsDeleted &&
        (dealId === EMPTY_GUID
          ? Core.text(activity.ContactId).toLowerCase() === Core.text(contactId).toLowerCase() ||
            (activity.Contacts || []).some((contact) => Core.text(contact.ContactId).toLowerCase() === Core.text(contactId).toLowerCase())
          : !activity?.DealId || Core.text(activity.DealId).toLowerCase() === dealId.toLowerCase()) &&
        (
          Core.text(activity?.ActivityTypeId) === activityTypeId ||
          normalizedTitle(activity?.Title) === activityTitle
        ) &&
        Core.text(activity?.ResultNote).includes(reportHeading)
      )
      .sort((left, right) => {
        const leftTime = Date.parse(left.RegisterTime || left.DoneDate || left.LastUpdateTime || 0) || 0;
        const rightTime = Date.parse(right.RegisterTime || right.DoneDate || right.LastUpdateTime || 0) || 0;
        return rightTime - leftTime;
      });
    return reports;
  }

  async function clearDuplicatedCreditActivityNote(activity) {
    const activityId = Core.text(activity?.Id);
    const resultNote = Core.text(activity?.ResultNote);
    if (!Core.GUID_PATTERN.test(activityId) || !resultNote) {
      return false;
    }
    try {
      const detail = await apiRequest("activity/GetActivityById", {
        body: { Id: activityId },
        retry: true
      });
      const detailNote = Core.text(detail?.Note);
      const detailResultNote = Core.text(detail?.ResultNote);
      if (
        Core.text(detail?.Id) !== activityId ||
        !detailNote ||
        !detailResultNote ||
        comparableCreditNoteHtml(detailNote) !== comparableCreditNoteHtml(detailResultNote)
      ) {
        return false;
      }
      await apiRequest("activity/SaveActivity", {
        body: {
          Activity: { ...detail, Note: "" },
          NewAttachments: [],
          SetDone: Boolean(detail.IsDone)
        }
      });
      return true;
    } catch (_error) {
      return false;
    }
  }

  async function createCreditReportActivity({
    dealId,
    contactId,
    identity,
    activityTypeId,
    activityDuration,
    report,
    previousRank,
    isUpdate,
    checkDuplicate = true,
    reportOnly = false,
    reportSubject = null
  }) {
    const provider = creditIntegrationProvider(report);
    const activityTitle = creditIntegrationActivityTitle(provider);
    const integrationLabel = creditIntegrationLabel(provider);
    if ((!Core.GUID_PATTERN.test(dealId) && !(reportOnly && dealId === EMPTY_GUID)) || !Core.GUID_PATTERN.test(contactId)) {
      throw new Error(`شناسه معامله یا مخاطب برای ثبت فعالیت ${integrationLabel} معتبر نیست.`);
    }
    if (!Core.GUID_PATTERN.test(activityTypeId)) {
      throw new Error(`نوع فعالیت «${activityTitle}» در دیدار معتبر نیست.`);
    }
    const now = new Date().toISOString();
    const subjectHtml = reportOnly && reportSubject
      ? `<p><strong>صاحب گزارش ${safeHtml(integrationLabel)}:</strong> ${safeHtml(reportSubject.fullName)} — کد ملی ${safeHtml(reportSubject.nationalCode)}</p>` +
        "<p>این گزارش با انتخاب و تأیید کارشناس به مخاطب موجودِ صاحب شماره همراه متصل شده است؛ اطلاعات مخاطب و معامله تغییر داده نشده‌اند.</p>"
      : "";
    const noteBody = subjectHtml + creditReportNoteHtml(report, { previousRank, isUpdate });
    const reportIdentityHash = creditReportIdentityHash(report, noteBody);
    const markerPrefix = provider === "olive" ? "didar-olive-credit-v1" : provider === "beta" ? "didar-beta-credit-v2" : "didar-etebarito-credit-v2";
    const resultNote = `<!-- ${markerPrefix}:${reportIdentityHash} -->${noteBody}`;
    if (checkDuplicate) {
      const previousActivities = await creditReportActivities(dealId, activityTypeId, report, contactId);
      let repaired = false;
      if (!reportOnly && report.sourceSystem !== "tamin") {
        for (const previousActivity of previousActivities) {
          repaired = (await clearDuplicatedCreditActivityNote(previousActivity)) || repaired;
        }
      }
      const reportCode = provider === "beta" ? "" : normalizeLookupDigits(report.reportUniqCode);
      const marker = `${markerPrefix}:${reportIdentityHash}`;
      if (provider === "olive" && (report.overdueStatus === "not_provided" || report.judgments?.length || report.checks?.some((item) => item.detail) || report.contracts?.length)) {
        // Replace only an exact, extension-generated legacy report; retain any expert-written text.
        const plainOliveNote = (value) => Core.text(value).replace(/^<!--\s*didar-olive-credit-v1:[a-f0-9]+\s*-->\s*/i, "").replace(/\s+/g, " ").trim();
        const legacyChecks = (report.checks || []).reduce((variants, item) => {
          const statuses = item.label === "چک برگشتی" && item.detail ? [item.status, "pass", "unknown"]
            : item.label === "محکومیت مالی" ? [item.status, "unknown"] : [item.status];
          return variants.flatMap((checks) => [...new Set(statuses)].map((status) => [...checks, { label: item.label, status }]));
        }, [[]]);
        const legacyBodies = [report.overdueStatus, "unknown"].flatMap((overdueStatus) =>
          [report.contracts, []].flatMap((contracts) => [report.judgments, []].flatMap((judgments) =>
            legacyChecks.map((checks) => plainOliveNote(subjectHtml + creditReportNoteHtml({
              ...report, overdueStatus, contracts, judgments, checks
            }, { previousRank, isUpdate }))))));
        const legacyMatches = previousActivities.filter((activity) => Core.text(activity.ResultNote).includes("didar-olive-credit-v1:") &&
          creditReportCodeFromNote(activity.ResultNote) === reportCode && legacyBodies.includes(plainOliveNote(activity.ResultNote)) &&
          plainOliveNote(activity.ResultNote) !== plainOliveNote(resultNote));
        if (legacyMatches.length > 1) throw new Error("چند نسخهٔ قبلی از این گزارش الیو پیدا شد؛ اصلاح خودکار متوقف شد.");
        if (legacyMatches.length === 1) {
          const previous = legacyMatches[0];
          const detail = await apiRequest("activity/GetActivityById", { body: { Id: previous.Id }, retry: true });
          if (Core.text(detail?.Id) !== Core.text(previous.Id) || Core.text(detail?.DealId) !== dealId ||
              Core.text(detail?.ActivityTypeId) !== activityTypeId || !detail?.IsDone || detail?.IsDeleted || detail?.CanEdit === false ||
              !(detail.Contacts || []).some((item) => Core.text(item.ContactId) === contactId) ||
              plainOliveNote(detail.ResultNote) !== plainOliveNote(previous.ResultNote)) {
            throw new Error("نسخهٔ قبلی گزارش الیو برای اصلاح مطمئن قابل تأیید نیست؛ فعالیت تکراری ساخته نشد.");
          }
          await apiRequest("activity/SaveActivity", { body: { Activity: { ...detail, ResultNote: resultNote }, NewAttachments: [], SetDone: true } });
          const verified = await apiRequest("activity/GetActivityById", { body: { Id: previous.Id }, retry: true });
          if (plainOliveNote(verified?.ResultNote) !== plainOliveNote(resultNote)) throw new Error("اصلاح متن گزارش قبلی الیو از دیدار تأیید نشد.");
          return { created: false, updated: true, duplicate: false, repaired: true, resultNote };
        }
      }
      const duplicate = previousActivities.some((activity) => {
        const previousResult = Core.text(activity?.ResultNote);
        if (previousResult.includes(marker)) {
          return true;
        }
        if (reportCode) {
          return creditReportCodeFromNote(previousResult) === reportCode;
        }
        return comparableCreditNoteHtml(previousResult) === comparableCreditNoteHtml(resultNote);
      });
      if (duplicate) {
        return { created: false, duplicate: true, repaired, resultNote };
      }
      if (provider === "beta" && report.sourceSystem !== "tamin") {
        const inquiryDate = normalizedTitle(report.inquiryDate);
        const sameInquiry = inquiryDate ? previousActivities.filter((activity) =>
          betaInquiryDateFromNote(activity?.ResultNote) === inquiryDate) : [];
        if (sameInquiry.length > 1) {
          throw new Error("چند فعالیت بتا با تاریخ استعلام یکسان پیدا شد؛ اصلاح خودکار برای جلوگیری از تغییر رکورد اشتباه متوقف شد.");
        }
        if (sameInquiry.length === 1) {
          await reviseBetaCreditActivity(sameInquiry[0], dealId, inquiryDate, resultNote);
          return { created: false, updated: true, duplicate: false, repaired: true, resultNote };
        }
      }
    }
    const saved = await apiRequest("activity/SaveActivity", {
      body: {
        Activity: {
          Id: EMPTY_GUID,
          ActivityGroupId: EMPTY_GUID,
          ActivityGroupType: "Default",
          ActivityTicketStatus: "NotAnswered",
          ActivityTypeId: activityTypeId,
          CaseId: EMPTY_GUID,
          DealId: dealId,
          Title: activityTitle,
          Note: "",
          ResultNote: resultNote,
          DueDate: now,
          OriginalDueDate: now,
          NextOccurrence: now,
          DoneDate: now,
          FinishDate: now,
          RecurrenceEndDate: now,
          Duration: Number(activityDuration) || 5,
          DueDateType: "NoTime",
          FeedbackType: "Neutral",
          RecurrenceType: "OneTime",
          RecurrenceData: 0,
          IsDone: true,
          IsAttended: false,
          IsDeleted: false,
          IsKeepInTouch: false,
          IsPinned: false,
          IsPrivate: false,
          IsTicket: false,
          OwnerId: identity.id,
          CreatorId: identity.id,
          UpdaterId: identity.id,
          Contacts: [{
            ActivityId: EMPTY_GUID,
            ContactId: contactId,
            Message: "",
            Status: "Accepted"
          }],
          Users: [],
          Notifies: [],
          Attachments: [],
          Comments: [],
          Tags: []
        },
        NewAttachments: [],
        SetDone: true
      }
    });
    if (reportOnly || report.sourceSystem === "tamin") {
      const savedId = entityIdFromSaveResult(saved);
      const isConfirmed = (activity) => !activity?.IsDeleted && activity?.IsDone === true &&
        Core.text(activity.DealId || EMPTY_GUID).toLowerCase() === dealId.toLowerCase() &&
        (activity.Contacts || []).some((contact) => Core.text(contact.ContactId).toLowerCase() === contactId.toLowerCase()) &&
        Core.text(activity.ActivityTypeId).toLowerCase() === activityTypeId.toLowerCase() &&
        Core.text(activity.ResultNote).includes(`${markerPrefix}:${reportIdentityHash}`);
      for (const wait of [0, 180, 420, 850, 1500]) {
        if (wait) await delay(wait);
        if (Core.GUID_PATTERN.test(savedId)) {
          try {
            const detail = await apiRequest("activity/GetActivityById", { body: { Id: savedId }, retry: true });
            if (isConfirmed(detail)) return { created: true, duplicate: false, repaired: false, resultNote };
          } catch (_error) {
            // Read a fresh destination list when the detail endpoint is temporarily unavailable.
          }
        }
        try {
          const candidates = await creditReportActivities(dealId, activityTypeId, report, contactId);
          if (candidates.some(isConfirmed)) return { created: true, duplicate: false, repaired: false, resultNote };
        } catch (_error) {
          // Keep the bounded verification attempts; do not submit another save.
        }
      }
      throw new Error("ذخیره ارسال شد، اما ثبت فعالیت از سرور تأیید نشد؛ پیش از تلاش دوباره مقصد را بررسی کنید.");
    }
    return { created: true, duplicate: false, repaired: false, resultNote };
  }

  function dealFieldValues(value) {
    if (value && typeof value === "object" && !Array.isArray(value)) {
      return { ...value };
    }
    if (Array.isArray(value)) {
      return Object.fromEntries(value
        .map((item) => [Core.text(item?.Key), item?.Value])
        .filter(([key]) => key));
    }
    return {};
  }

  async function etebaritoDealDetail(dealId, retry = false) {
    return apiRequest("deal/GetDealDetail_v2", {
      body: { Id: dealId },
      retry
    });
  }

  function editableDealPayload(deal, fields, status) {
    return {
      ...(deal && typeof deal === "object" ? deal : {}),
      Id: Core.text(deal?.Id),
      Status: Core.text(status || deal?.Status),
      Fields: { ...fields }
    };
  }

  async function waitForDealValues(dealId, fieldKey, expectedValue, expectedTitle = "", expectedFields = {}, expectedSourceId = null) {
    const waits = [0, 180, 420, 850, 1500, 2600];
    let latestDeal = null;
    for (const wait of waits) {
      if (wait) {
        await delay(wait);
      }
      latestDeal = await etebaritoDealDetail(dealId, true);
      const actualFields = dealFieldValues(latestDeal?.Fields);
      const actualValue = normalizedTitle(actualFields[fieldKey]);
      const fieldsMatch = Object.entries(expectedFields).every(([key, value]) => Array.isArray(value)
        ? JSON.stringify(normalizedMultiFieldValue(actualFields[key]).sort()) === JSON.stringify([...value].sort())
        : normalizedTitle(actualFields[key]) === value);
      const sourceMatch = expectedSourceId === null ||
        Core.text(latestDeal?.SourceId || latestDeal?.Source?.Id).replace(EMPTY_GUID, "") === expectedSourceId.replace(EMPTY_GUID, "");
      if (actualValue === expectedValue && fieldsMatch && sourceMatch && (!expectedTitle || normalizedTitle(latestDeal?.Title) === expectedTitle)) {
        return latestDeal;
      }
    }
    return null;
  }

  function sameDealTimestamp(left, right) {
    const leftTime = Date.parse(Core.text(left));
    const rightTime = Date.parse(Core.text(right));
    return Number.isFinite(leftTime) && Number.isFinite(rightTime) && leftTime === rightTime;
  }

  function closedDealSnapshot(deal) {
    const status = Core.text(deal?.Status);
    if (!["Won", "Lost"].includes(status)) {
      return null;
    }
    const timeField = status === "Won" ? "ChangeToWonTime" : "ChangeToLossTime";
    const closeTime = Core.text(deal?.[timeField]);
    if (!Number.isFinite(Date.parse(closeTime))) {
      throw new Error("زمان بسته‌شدن اصلی معامله از دیدار دریافت نشد؛ برای حفظ تاریخچه بروزرسانی انجام نشد.");
    }
    return {
      status,
      timeField,
      closeTime,
      lostReasonId: Core.text(deal?.LostReasonId) || EMPTY_GUID,
      lostReasonNote: Core.text(deal?.LostReasonNote),
      lostReasonOther: Core.text(deal?.LostReasonOther)
    };
  }

  function readEtebaritoStatusJournal() {
    try {
      const stored = JSON.parse(localStorage.getItem(ETEBARITO_STATUS_JOURNAL_KEY) || "{}");
      const now = Date.now();
      const account = Core.text(localStorage.getItem("account"));
      return Object.fromEntries(Object.entries(stored).filter(([dealId, entry]) =>
        Core.GUID_PATTERN.test(dealId) &&
        entry &&
        ["Won", "Lost"].includes(Core.text(entry.status)) &&
        Number.isFinite(Date.parse(Core.text(entry.closeTime))) &&
        now - Number(entry.createdAt || 0) < ETEBARITO_STATUS_JOURNAL_MAX_AGE &&
        (!Core.text(entry.account) || Core.text(entry.account) === account)
      ));
    } catch {
      return {};
    }
  }

  function rememberEtebaritoStatusSnapshot(dealId, snapshot) {
    const records = readEtebaritoStatusJournal();
    records[dealId] = {
      ...snapshot,
      dealId,
      account: Core.text(localStorage.getItem("account")),
      createdAt: Date.now()
    };
    try {
      localStorage.setItem(ETEBARITO_STATUS_JOURNAL_KEY, JSON.stringify(records));
      const verified = readEtebaritoStatusJournal()[dealId];
      if (!verified || verified.status !== snapshot.status || verified.closeTime !== snapshot.closeTime) {
        throw new Error("snapshot verification failed");
      }
    } catch {
      throw new Error("وضعیت و زمان بسته‌شدن معامله در حافظه بازیابی ذخیره نشد؛ هیچ تغییری انجام نشد.");
    }
  }

  function forgetEtebaritoStatusSnapshot(dealId) {
    try {
      const records = readEtebaritoStatusJournal();
      delete records[dealId];
      localStorage.setItem(ETEBARITO_STATUS_JOURNAL_KEY, JSON.stringify(records));
    } catch {
      // A stale entry is harmless: the next update verifies server state before using it.
    }
  }

  async function waitForDealStatus(dealId, expectedStatus) {
    const waits = [0, 180, 420, 850, 1500, 2600];
    let latestDeal = null;
    for (const wait of waits) {
      if (wait) {
        await delay(wait);
      }
      latestDeal = await etebaritoDealDetail(dealId, true);
      if (Core.text(latestDeal?.Status) === expectedStatus) {
        return latestDeal;
      }
    }
    return null;
  }

  async function reopenClosedDealForUpdate(dealId) {
    await apiRequest("deal/SetStatus", {
      body: {
        Id: dealId,
        Status: "Pending",
        LostReasonId: EMPTY_GUID,
        LostReasonNote: "",
        LostReasonOther: ""
      }
    });
    const reopenedDeal = await waitForDealStatus(dealId, "Pending");
    if (!reopenedDeal) {
      throw new Error("دیدار بازگشت موقت معامله بسته به وضعیت جاری را تأیید نکرد.");
    }
    return reopenedDeal;
  }

  async function restoreClosedDealSnapshot(dealId, snapshot) {
    let latestDeal = await etebaritoDealDetail(dealId, true);
    if (Core.text(latestDeal?.Status) !== snapshot.status) {
      await apiRequest("deal/SetStatus", {
        body: {
          Id: dealId,
          Status: snapshot.status,
          LostReasonId: snapshot.status === "Lost" ? snapshot.lostReasonId : EMPTY_GUID,
          LostReasonNote: snapshot.status === "Lost" ? snapshot.lostReasonNote : "",
          LostReasonOther: snapshot.status === "Lost" ? snapshot.lostReasonOther : ""
        }
      });
      latestDeal = await waitForDealStatus(dealId, snapshot.status);
      if (!latestDeal) {
        throw new Error(`وضعیت قبلی معامله (${snapshot.status}) بازیابی نشد.`);
      }
    }
    if (!sameDealTimestamp(latestDeal?.[snapshot.timeField], snapshot.closeTime)) {
      const endpoint = snapshot.status === "Won" ? "deal/ChangeWonTime" : "deal/ChangeLossTime";
      await apiRequest(endpoint, {
        body: {
          Id: dealId,
          [snapshot.timeField]: snapshot.closeTime
        }
      });
    }
    const verifiedDeal = await etebaritoDealDetail(dealId, true);
    if (
      Core.text(verifiedDeal?.Status) !== snapshot.status ||
      !sameDealTimestamp(verifiedDeal?.[snapshot.timeField], snapshot.closeTime)
    ) {
      throw new Error("وضعیت یا زمان بسته‌شدن قبلی معامله به‌طور کامل بازیابی نشد.");
    }
    return verifiedDeal;
  }

  async function recoverEtebaritoStatusSnapshot(dealId, deal) {
    const snapshot = readEtebaritoStatusJournal()[dealId];
    if (!snapshot) {
      return deal;
    }
    const currentStatus = Core.text(deal?.Status);
    if (
      currentStatus === snapshot.status &&
      sameDealTimestamp(deal?.[snapshot.timeField], snapshot.closeTime)
    ) {
      forgetEtebaritoStatusSnapshot(dealId);
      return deal;
    }
    if (currentStatus !== "Pending") {
      throw new Error("یک وضعیت بازیابی‌نشده برای این معامله وجود دارد، اما وضعیت فعلی سرور تغییر کرده است؛ بروزرسانی برای جلوگیری از بازنویسی متوقف شد.");
    }
    const restoredDeal = await restoreClosedDealSnapshot(dealId, snapshot);
    forgetEtebaritoStatusSnapshot(dealId);
    return restoredDeal;
  }

  function prepareTaminPayload(payload, config) {
    if (payload?.integrationSource !== "tamin") return payload;
    const jobKey = (value) => normalizedTitle(value).replace(/أ/g, "ا").replace(/ي/g, "ی").replace(/ك/g, "ک").replace(/\u200c/g, " ");
    const job = (config.jobOptions || []).find((option) => jobKey(option) === jobKey("بازنشسته تأمین اجتماعی"));
    if (!job || !config.jobFieldKey) throw new Error("گزینهٔ شغلی بازنشسته تأمین اجتماعی در دیدار موجود نیست؛ هیچ اطلاعاتی ثبت نشد.");
    const report = normalizedCreditReport(payload, config);
    if (report.sourceSystem !== "tamin" || report.nationalCode !== normalizeLookupDigits(payload.nationalCode)) {
      throw new Error("کد ملی گزارش تأمین اجتماعی با مشتری انتخاب‌شده مطابقت ندارد.");
    }
    return {
      ...payload,
      preparedContactFields: { ...payload.preparedContactFields, job },
      sourceContactFields: { ...payload.sourceContactFields, job },
      preparedDealFields: { ...payload.preparedDealFields, [config.creditRankFieldKey]: "" }
    };
  }

  function taminCreditPayload(payload) {
    return { ...payload, provider: "beta", integrationSource: "tamin",
      creditReport: { ...payload?.creditReport, provider: "beta", sourceSystem: "tamin", creditRank: "", creditScore: "" },
      preparedDealFields: { ...payload?.preparedDealFields } };
  }

  async function performEtebaritoTransfer(payload) {
    const identity = await currentIdentity(true);
    const provider = creditIntegrationProvider(payload);
    const integrationLabel = creditIntegrationLabel(provider);
    const config = await etebaritoDidarConfig(provider);
    payload = prepareTaminPayload(payload, config);
    if (
      normalizedTitle(config.pipelineTitle) !== ETEBARITO_TARGET_PIPELINE ||
      normalizedTitle(config.stageTitle) !== ETEBARITO_TARGET_STAGE
    ) {
      throw new Error("مقصد ثبت دقیقاً پرونده اعتباری / اعتبار سنجی اولیه نیست؛ عملیات متوقف شد.");
    }

    const nationalCode = normalizeLookupDigits(payload?.nationalCode);
    const fullName = normalizedTitle(payload?.fullName)
      .replace(new RegExp(`\\s*${nationalCode}$`), "")
      .trim();
    const rawMobile = Core.text(payload?.preparedContactFields?.mobile);
    const mobile = normalizeIranianMobile(rawMobile);
    const approvedContactId = Core.text(payload?.approvedContactId).toLowerCase();
    const job = normalizedTitle(payload?.preparedContactFields?.job);
    const birthDateJalali = Core.text(payload?.preparedContactFields?.birthDateJalali);
    const birthDate = birthDateJalali ? jalaliBirthDateToIso(birthDateJalali) : "";
    const sourceId = Core.text(payload?.preparedDealSourceId);
    const source = sourceId
      ? (config.sourceOptions || []).find((item) => item.id === sourceId)
      : null;
    const fields = selectedFieldValues(payload, config);

    if (!/^\d{10}$/.test(nationalCode)) {
      throw new Error("کد ملی ده‌رقمی معتبر نیست.");
    }
    if ((!approvedContactId && !mobile) || (rawMobile && !mobile)) {
      throw new Error("شماره همراه معتبر یازده‌رقمی برای ثبت مخاطب جدید الزامی است.");
    }
    if (approvedContactId && (!Core.GUID_PATTERN.test(approvedContactId) || approvedContactId === EMPTY_GUID)) {
      throw new Error("شناسه مخاطب تأییدشده معتبر نیست؛ دوباره بررسی کنید.");
    }
    if (job && !(config.jobOptions || []).includes(job)) {
      throw new Error("شغل انتخاب‌شده با گزینه‌های فعلی دیدار تطابق ندارد.");
    }
    if (birthDateJalali && !birthDate) {
      throw new Error("تاریخ تولد شمسی قابل تبدیل نیست.");
    }
    if (sourceId && !source) {
      throw new Error("نحوه آشنایی انتخاب‌شده با گزینه‌های فعلی دیدار تطابق ندارد.");
    }

    // This second lookup is intentionally immediately before the first write.
    const duplicateCheck = selectedCreditMatches(await etebaritoNationalCodeMatches(nationalCode), payload);
    const contactReused = Boolean(approvedContactId);
    const matchingContact = duplicateCheck.contacts.length === 1 &&
      Core.text(duplicateCheck.contacts[0].id).toLowerCase() === approvedContactId;
    const approvedExistingDealIds = Array.isArray(payload.approvedExistingDealIds)
      ? payload.approvedExistingDealIds.map((id) => Core.text(id).toLowerCase()) : [];
    const explicitNewDeal = payload.confirmNewDeal === true && contactReused;
    if (explicitNewDeal && (!Array.isArray(payload.approvedExistingDealIds) || approvedExistingDealIds.length > 500 ||
        approvedExistingDealIds.some((id) => !Core.GUID_PATTERN.test(id)) ||
        new Set(approvedExistingDealIds).size !== approvedExistingDealIds.length)) {
      throw new Error("فهرست معاملات قبلی برای ایجاد معاملهٔ جدید تأیید نشده است؛ بررسی مجدد را بزنید.");
    }
    const approvedDealsUnchanged = (matches) => explicitNewDeal
      ? matches.deals.length === approvedExistingDealIds.length && matches.deals.every((deal) => approvedExistingDealIds.includes(Core.text(deal.id).toLowerCase()))
      : matches.deals.length === 0;
    if (duplicateCheck.conflict || !approvedDealsUnchanged(duplicateCheck) ||
        (contactReused ? !matchingContact : duplicateCheck.contacts.length > 0)) {
      return {
        ok: false,
        blocked: true,
        error: contactReused
          ? "تطبیق مخاطب تغییر کرده یا معامله‌ای برای او پیدا شد؛ دوباره بررسی و معامله موردنظر را انتخاب کنید."
          : "در بررسی نهایی، مخاطب یا معامله مرتبط با این کد ملی پیدا شد؛ هیچ رکوردی ساخته نشد.",
        ...duplicateCheck
      };
    }

    const contactFields = job ? { [config.jobFieldKey]: job } : {};
    let contactDisplayName = [fullName, nationalCode].filter(Boolean).join(" ");
    const contact = {
      FirstName: "",
      LastName: contactDisplayName,
      MobilePhone: mobile,
      NationalCode: nationalCode,
      Type: "Person",
      LeadType: "General",
      ContactType: "Prospect",
      CompanyId: EMPTY_GUID,
      OwnerId: identity.id,
      VisibilityType: "All",
      Fields: contactFields
    };
    if (birthDate) {
      contact.BirthDate = birthDate;
      contact.BirthDateisValid = true;
    }

    // Validate the report before saving either a profile or a deal.
    const report = normalizedCreditReport(payload, config);
    let profileSync = {};
    let contactId = approvedContactId;
    if (contactReused) {
      const detail = await verifiedCreditContact(contactId, nationalCode);
      const nameCanBeCorrected = (["etebarito", "olive"].includes(provider) || payload.replaceContactFields === true) &&
        normalizeLookupDigits(payload.sourceContactFields?.nationalCode) === nationalCode &&
        /^[آ-یء][آ-یء\s]{3,60}$/.test(fullName) && fullName.split(" ").length >= 2 &&
        !/(اطلاعات|شماره|تلفن|نشانی|آدرس|توضیحات|مطابق|پست\s*الکترونیکی|ایمیل|گزارش|اعتبار|نام پدر)/.test(fullName);
      profileSync = await syncEtebaritoContactProfile(detail,
        { ...payload.preparedContactFields, nationalCode, fullName: ["etebarito", "olive"].includes(provider) && !nameCanBeCorrected ? "" : fullName }, config,
        { preserveExistingMobile: provider !== "olive" && payload.replaceContactFields !== true,
          replaceMobile: provider === "olive" || payload.replaceContactFields === true, correctName: nameCanBeCorrected,
          replaceBirthDate: payload.replaceContactFields === true,
          forceJob: payload.integrationSource === "tamin" || (provider === "olive" || payload.replaceContactFields === true) && Boolean(job) });
      const savedProfile = await apiRequest("contact/GetContactDetail", { body: { Id: contactId }, retry: true });
      const savedContact = savedProfile?.Contact || savedProfile;
      if (Core.text(savedContact?.Id).toLowerCase() !== contactId || savedContact?.IsDeleted) {
        throw new Error("مخاطب موجود پس از بررسی قابل بازیابی نیست؛ معامله ساخته نشد.");
      }
      const savedName = normalizedTitle([savedContact.FirstName, savedContact.LastName].filter(Boolean).join(" ") || savedContact.DisplayName || fullName)
        .replace(new RegExp(`\\s*${nationalCode}$`), "").trim();
      contactDisplayName = [savedName, nationalCode].filter(Boolean).join(" ");
      // Profile completion may take time; recheck deals immediately before creating one.
      const latest = selectedCreditMatches(await etebaritoNationalCodeMatches(nationalCode), payload);
      if (latest.conflict || latest.contacts.length !== 1 ||
          Core.text(latest.contacts[0].id).toLowerCase() !== contactId || !approvedDealsUnchanged(latest)) {
        return { ok: false, blocked: true, contactReused: true,
          error: "در بررسی مجدد، مخاطب تغییر کرد یا معامله‌ای پیدا شد؛ معامله جدید ساخته نشد.",
          ...latest, contact: { id: contactId, url: `https://app.didar.me/contact/${contactId}`, displayName: contactDisplayName }, ...profileSync };
      }
    } else {
      const contactResult = await apiRequest("contact/save", { body: { Contact: contact } });
      contactId = entityIdFromSaveResult(contactResult);
      if (!contactId) {
        const afterSave = await etebaritoNationalCodeMatches(nationalCode);
        contactId = afterSave.contacts.length === 1 ? Core.text(afterSave.contacts[0].id) : "";
      }
    }
    if (!Core.GUID_PATTERN.test(contactId)) {
      throw new Error("دیدار ذخیره مخاطب را تأیید کرد، اما شناسه مخاطب قابل بازیابی نبود؛ معامله ساخته نشد.");
    }

    const contactUrl = `https://app.didar.me/contact/${contactId}`;
    const deal = {
      Title: `معامله ${contactDisplayName}`,
      ContactId: contactId,
      PersonId: contactId,
      CompanyId: EMPTY_GUID,
      PipelineId: config.pipelineId,
      PipelineStageId: config.stageId,
      OwnerId: identity.id,
      Status: "Pending",
      VisibilityType: "All",
      Fields: fields
    };
    if (source) {
      deal.SourceId = source.id;
    }

    try {
      const dealResult = await apiRequest("deal/save", { body: { Deal: deal } });
      const dealId = entityIdFromSaveResult(dealResult);
      if (!Core.GUID_PATTERN.test(dealId)) {
        throw new Error("پاسخ دیدار شناسه معامله را برنگرداند.");
      }
      const dealRecord = {
        id: dealId,
        url: `https://app.didar.me/deal/${dealId}`,
        title: deal.Title
      };
      try {
        const activity = await createCreditReportActivity({
          dealId,
          contactId,
          identity,
          activityTypeId: config.creditActivityTypeId,
          activityDuration: config.creditActivityDuration,
          report,
          previousRank: "",
          isUpdate: false,
          checkDuplicate: false
        });
      } catch (error) {
        return {
          ok: false,
          partial: true,
          contactReused,
          ...profileSync,
          error: `معامله ساخته شد، اما فعالیت ${integrationLabel} ثبت نشد: ${error.message}`,
          contact: { id: contactId, url: contactUrl, displayName: contactDisplayName },
          deal: dealRecord
        };
      }
      return {
        ok: true,
        created: true,
        contactReused,
        ...profileSync,
        activityCreated: true,
        noteCreated: true,
        pipelineTitle: config.pipelineTitle,
        stageTitle: config.stageTitle,
        contact: { id: contactId, url: contactUrl, displayName: contactDisplayName },
        deal: dealRecord
      };
    } catch (error) {
      return {
        ok: false,
        partial: true,
        contactReused,
        ...profileSync,
        error: `${contactReused ? "مخاطب موجود تأیید شد" : "مخاطب ساخته شد"}، اما معامله ساخته نشد: ${error.message}`,
        contact: { id: contactId, url: contactUrl, displayName: contactDisplayName }
      };
    }
  }

  function etebaritoDidarTransfer(payload) {
    const nationalCode = normalizeLookupDigits(payload?.nationalCode);
    const operationKey = `${payload?.integrationSource === "tamin" ? "tamin" : creditIntegrationProvider(payload)}:${nationalCode}:${Core.text(payload?.approvedContactId) || "new"}`;
    if (activeEtebaritoTransfers.has(operationKey)) {
      return activeEtebaritoTransfers.get(operationKey);
    }
    const operation = withOperationLock(`credit-transfer:${nationalCode}`, () => performEtebaritoTransfer(payload))
      .finally(() => activeEtebaritoTransfers.delete(operationKey));
    activeEtebaritoTransfers.set(operationKey, operation);
    return operation;
  }

  async function performEtebaritoUpdate(payload) {
    const identity = await currentIdentity(true);
    const provider = creditIntegrationProvider(payload);
    const integrationLabel = creditIntegrationLabel(provider);
    const config = await etebaritoDidarConfig(provider);
    payload = prepareTaminPayload(payload, config);
    const nationalCode = normalizeLookupDigits(payload?.nationalCode);
    const approvedDealId = Core.text(payload?.approvedDealId);
    const customerRole = selectedCustomerRole(payload, config);
    const preparedFields = selectedFieldValues(payload, config);
    const replaceFields = payload.replaceContactFields === true;
    const sourceId = Core.text(payload.preparedDealSourceId);
    if (sourceId && !(config.sourceOptions || []).some((item) => item.id === sourceId)) {
      throw new Error("نحوه آشنایی انتخاب‌شده با گزینه‌های فعلی دیدار تطابق ندارد.");
    }
    if (replaceFields) {
      const rawMobile = Core.text(payload.preparedContactFields?.mobile);
      const birthDate = Core.text(payload.preparedContactFields?.birthDateJalali);
      const job = normalizedTitle(payload.preparedContactFields?.job);
      if (rawMobile && !normalizeIranianMobile(rawMobile)) throw new Error("شماره همراه معتبر یازده‌رقمی وارد کنید.");
      if (birthDate && !jalaliBirthDateToIso(birthDate)) throw new Error("تاریخ تولد شمسی معتبر نیست.");
      if (job && !(config.jobOptions || []).includes(job)) throw new Error("شغل انتخاب‌شده معتبر نیست.");
    }
    if (!/^\d{10}$/.test(nationalCode)) {
      throw new Error("کد ملی ده‌رقمی معتبر نیست.");
    }
    if (!Core.GUID_PATTERN.test(approvedDealId)) {
      throw new Error("شناسه معامله تأییدشده برای بروزرسانی معتبر نیست.");
    }
    const sourceNationalCode = normalizeLookupDigits(payload?.sourceContactFields?.nationalCode);
    const selectedNameInput = Object.prototype.hasOwnProperty.call(payload || {}, "fullName")
      ? payload.fullName
      : payload?.sourceContactFields?.fullName;
    const rawSelectedName = normalizedTitle(selectedNameInput)
      .replace(new RegExp(`\\s*${nationalCode}$`), "")
      .trim();
    const selectedName = (["etebarito", "olive"].includes(provider) || replaceFields) && sourceNationalCode === nationalCode &&
      /^[آ-یء][آ-یء\s]{3,60}$/.test(rawSelectedName) &&
      rawSelectedName.split(" ").length >= 2 &&
      !/(اطلاعات|شماره|تلفن|نشانی|آدرس|توضیحات|مطابق|پست\s*الکترونیکی|ایمیل|تولد|جنسیت|تاهل|گزارش|اعتبار|نام پدر|محل تولد|وضعیت تاهل)/.test(rawSelectedName)
      ? rawSelectedName : "";
    const correctedDisplayName = selectedName ? `${selectedName} ${nationalCode}` : "";
    const correctedDealTitle = correctedDisplayName ? `معامله ${correctedDisplayName}` : "";
    const report = normalizedCreditReport(payload, config);

    // Recheck immediately before the first write to avoid updating a stale or ambiguous match.
    const matches = selectedCreditMatches(await etebaritoNationalCodeMatches(nationalCode), payload);
    if (
      matches.conflict ||
      matches.contacts.length !== 1 ||
      !matches.deals.some((item) => item.id === approvedDealId)
    ) {
      return {
        ok: false,
        blocked: true,
        error: "مخاطب یا معاملهٔ انتخابی تغییر کرده است؛ مقصد را دوباره انتخاب کنید.",
        ...matches
      };
    }

    let deal = await etebaritoDealDetail(approvedDealId, true);
    if (
      Core.text(deal?.Id) !== approvedDealId || deal?.IsDeleted ||
      Core.text(deal.ContactId || deal.PersonId || deal.Contact?.Id || deal.Person?.Id).toLowerCase() !== Core.text(matches.contacts[0].id).toLowerCase()
    ) {
      throw new Error("ارتباط معامله و مخاطب انتخابی تغییر کرده است؛ مقصد را دوباره انتخاب کنید.");
    }
    const verifiedContact = await verifiedCreditContact(matches.contacts[0].id, nationalCode);
    if (payload.approvedDealStatus && Core.text(deal.Status) !== Core.text(payload.approvedDealStatus)) {
      return { ok: false, blocked: true, error: "وضعیت معامله پس از انتخاب تغییر کرده است؛ بررسی مجدد را بزنید.", ...matches };
    }
    deal = await recoverEtebaritoStatusSnapshot(approvedDealId, deal);
    const currentStatus = Core.text(deal.Status);
    if (!["Pending", "Lost", "Won"].includes(currentStatus)) {
      throw new Error("وضعیت معامله انتخاب‌شده قابل بروزرسانی نیست.");
    }
    const closedSnapshot = closedDealSnapshot(deal);
    let reopenAttempted = false;
    let keepOpenCommitted = false;
    const keepDealOpen = payload.keepDealOpen === true && Boolean(closedSnapshot);
    if (closedSnapshot) {
      rememberEtebaritoStatusSnapshot(approvedDealId, closedSnapshot);
    }
    try {
      if (closedSnapshot) {
        reopenAttempted = true;
        deal = await reopenClosedDealForUpdate(approvedDealId);
      }
      let profileSync = {
        profileUpdated: false,
        profileFieldsAdded: [],
        nameCorrected: false,
        phoneAdded: false,
        phoneAlreadyPresent: false,
        phoneField: ""
      };
      if (payload?.sourceContactFields && typeof payload.sourceContactFields === "object") {
        try {
          profileSync = await syncEtebaritoContactProfile(
            verifiedContact,
            { ...payload.sourceContactFields, ...(provider === "olive" || replaceFields ? payload.preparedContactFields : {}), fullName: selectedName || (["etebarito", "olive"].includes(provider) ? "" : payload.sourceContactFields.fullName) },
            config,
            { preserveExistingMobile: provider !== "olive" && !replaceFields, replaceMobile: provider === "olive" || replaceFields,
              replaceBirthDate: replaceFields, correctName: Boolean(selectedName),
              forceJob: payload.integrationSource === "tamin" || (provider === "olive" || replaceFields) && Boolean(payload.preparedContactFields?.job) }
          );
        } catch (error) {
          if (selectedName || payload.integrationSource === "tamin" || provider === "olive" || replaceFields) {
            throw error;
          }
          profileSync = {
            profileUpdated: false,
            profileFieldsAdded: [],
            phoneAdded: false,
            phoneAlreadyPresent: false,
            profileWarning: error.message
          };
        }
      }
      const latestDeal = await etebaritoDealDetail(approvedDealId, true);
      if (Core.text(latestDeal?.Id) !== approvedDealId || latestDeal?.IsDeleted ||
          Core.text(latestDeal.ContactId || latestDeal.PersonId || latestDeal.Contact?.Id || latestDeal.Person?.Id).toLowerCase() !== Core.text(matches.contacts[0].id).toLowerCase() ||
          Core.text(latestDeal.Status) !== "Pending") {
        throw new Error("معامله هنگام ثبت تغییر کرده است؛ مقصد را دوباره انتخاب کنید.");
      }
      deal = latestDeal;
      const fields = dealFieldValues(deal.Fields);
      const previousRank = normalizedTitle(fields[config.creditRankFieldKey]);
      const effectiveReport = {
        ...report,
        rank: report.rank || previousRank
      };
      const rankChanged = Boolean(report.rank) && previousRank !== report.rank;
      const roleChanged = Boolean(customerRole) && normalizedTitle(fields[config.customerRoleFieldKey]) !== customerRole;
      const titleChanged = Boolean(correctedDealTitle) && normalizedTitle(deal.Title) !== correctedDealTitle;
      const selectedFields = replaceFields ? { ...preparedFields } : {};
      if (replaceFields && Object.prototype.hasOwnProperty.call(payload.preparedDealFields || {}, config.planTypeFieldKey)) {
        selectedFields[config.planTypeFieldKey] = normalizedMultiFieldValue(payload.preparedDealFields[config.planTypeFieldKey]);
      }
      if (replaceFields && Object.prototype.hasOwnProperty.call(payload.preparedDealFields || {}, config.customerStatusFieldKey)) {
        selectedFields[config.customerStatusFieldKey] = normalizedTitle(payload.preparedDealFields[config.customerStatusFieldKey]);
      }
      const fieldsChanged = Object.entries(selectedFields).some(([key, value]) => Array.isArray(value)
        ? JSON.stringify(normalizedMultiFieldValue(fields[key]).sort()) !== JSON.stringify([...value].sort())
        : normalizedTitle(fields[key]) !== value);
      const replaceSource = replaceFields && config.sourceOptionsAvailable !== false &&
        Object.prototype.hasOwnProperty.call(payload, "preparedDealSourceId");
      const sourceChanged = replaceSource && Core.text(deal.SourceId || deal.Source?.Id).replace(EMPTY_GUID, "") !== sourceId.replace(EMPTY_GUID, "");
      if (rankChanged || titleChanged || roleChanged || fieldsChanged || sourceChanged) {
        Object.assign(fields, selectedFields);
        if (rankChanged) {
          fields[config.creditRankFieldKey] = report.rank;
        }
        if (roleChanged) fields[config.customerRoleFieldKey] = customerRole;
        await apiRequest("deal/SaveDeal", {
          body: {
            Deal: {
              ...editableDealPayload(deal, fields, "Pending"),
              Title: titleChanged ? correctedDealTitle : deal.Title,
              ...(sourceChanged ? { SourceId: sourceId || EMPTY_GUID } : {})
            },
            IsWon: false
          }
        });
        const verified = await waitForDealValues(
          approvedDealId,
          config.creditRankFieldKey,
          rankChanged ? report.rank : previousRank,
          titleChanged ? correctedDealTitle : "",
          { ...selectedFields, ...(roleChanged ? { [config.customerRoleFieldKey]: customerRole } : {}) },
          sourceChanged ? sourceId : null
        );
        if (!verified) {
          throw new Error("دیدار بروزرسانی عنوان معامله، رتبه اعتباری یا نقش مشتری را تأیید نکرد.");
        }
        deal = verified;
      }

      const dealRecord = {
        id: approvedDealId,
        title: normalizedTitle(deal.Title),
        url: `https://app.didar.me/deal/${approvedDealId}`
      };
      try {
        const activity = await createCreditReportActivity({
          dealId: approvedDealId,
          contactId: matches.contacts[0].id,
          identity,
          activityTypeId: config.creditActivityTypeId,
          activityDuration: config.creditActivityDuration,
          report: effectiveReport,
          previousRank,
          isUpdate: true
        });
        if (keepDealOpen) {
          const reopenedDeal = await etebaritoDealDetail(approvedDealId, true);
          if (Core.text(reopenedDeal?.Status) !== "Pending") throw new Error("جاری‌بودن معامله پس از بروزرسانی تأیید نشد.");
          forgetEtebaritoStatusSnapshot(approvedDealId);
          keepOpenCommitted = true;
        }
        return {
          ok: true,
          updated: Boolean(closedSnapshot) || rankChanged || titleChanged || roleChanged || fieldsChanged || sourceChanged || activity.created || activity.updated || profileSync.profileUpdated,
          unchanged: !closedSnapshot && !rankChanged && !titleChanged && !roleChanged && !fieldsChanged && !sourceChanged && !activity.created && !activity.updated && !profileSync.profileUpdated,
          reopened: Boolean(closedSnapshot),
          temporarilyReopened: Boolean(closedSnapshot) && !keepOpenCommitted,
          keptOpen: keepOpenCommitted,
          restoredStatus: keepOpenCommitted ? "Pending" : closedSnapshot?.status || currentStatus,
          restoredCloseTime: keepOpenCommitted ? "" : closedSnapshot?.closeTime || "",
          activityCreated: activity.created,
          activityUpdated: Boolean(activity.updated),
          activitySkipped: activity.duplicate,
          noteCreated: activity.created,
          noteSkipped: activity.duplicate,
          previousRank,
          newRank: effectiveReport.rank,
          dealTitleUpdated: titleChanged,
          customerRoleUpdated: roleChanged,
          dealFieldsUpdated: fieldsChanged || sourceChanged,
          ...profileSync,
          deal: dealRecord
        };
      } catch (error) {
        const completedActions = [];
        if (rankChanged) {
          completedActions.push("رتبه اعتباری بروزرسانی شد");
        }
        if (titleChanged) {
          completedActions.push("عنوان معامله اصلاح شد");
        }
        if (roleChanged) completedActions.push("نقش مشتری بروزرسانی شد");
        if (fieldsChanged || sourceChanged) completedActions.push("فیلدهای انتخابی معامله بروزرسانی شدند");
        if (profileSync.profileUpdated) {
          completedActions.push("اطلاعات جدید مخاطب افزوده شد");
        } else if (profileSync.phoneAdded) {
          completedActions.push("شماره همراه جدید مخاطب افزوده شد");
        }
        const completedMessage = completedActions.length
          ? completedActions.join(" و ")
          : "اطلاعات معامله تغییری نکرد";
        return {
          ok: false,
          partial: true,
          error: `${completedMessage}، اما فعالیت ${integrationLabel} ثبت نشد: ${error.message}`,
          temporarilyReopened: Boolean(closedSnapshot),
          restoredStatus: closedSnapshot?.status || currentStatus,
          restoredCloseTime: closedSnapshot?.closeTime || "",
          previousRank,
          newRank: effectiveReport.rank,
          dealTitleUpdated: titleChanged,
          customerRoleUpdated: roleChanged,
          ...profileSync,
          deal: dealRecord
        };
      }
    } finally {
      if (closedSnapshot && reopenAttempted && !keepOpenCommitted) {
        try {
          await restoreClosedDealSnapshot(approvedDealId, closedSnapshot);
          forgetEtebaritoStatusSnapshot(approvedDealId);
        } catch (error) {
          throw new Error(`عملیات متوقف شد، اما بازگردانی وضعیت و زمان بسته‌شدن معامله ناموفق بود: ${error.message}`);
        }
      } else if (closedSnapshot) {
        forgetEtebaritoStatusSnapshot(approvedDealId);
      }
    }
  }

  function etebaritoDidarUpdate(payload) {
    const nationalCode = normalizeLookupDigits(payload?.nationalCode);
    const operationKey = `${payload?.integrationSource === "tamin" ? "tamin" : creditIntegrationProvider(payload)}:${nationalCode}:${Core.text(payload?.approvedContactId)}:${Core.text(payload?.approvedDealId)}`;
    if (activeEtebaritoUpdates.has(operationKey)) {
      return activeEtebaritoUpdates.get(operationKey);
    }
    const operation = withOperationLock(`credit-transfer:${nationalCode}`, () => performEtebaritoUpdate(payload))
      .finally(() => activeEtebaritoUpdates.delete(operationKey));
    activeEtebaritoUpdates.set(operationKey, operation);
    return operation;
  }

  function publishPageSettings() {
    if (document.documentElement) {
      document.documentElement.dataset.didarAutoPlanChecklist =
        settings.enabled && settings.autoPlanChecklist ? "true" : "false";
      document.documentElement.dataset.didarAutoAddPlanProduct =
        settings.enabled && settings.autoAddPlanProduct ? "true" : "false";
      document.documentElement.dataset.didarAutoCallChecklist =
        callSettingsReady && settings.enabled && settings.autoCallChecklist ? "true" : "false";
      if (CallChecklists) {
        let config = document.getElementById("didar-call-checklist-config");
        if (!config) {
          config = document.createElement("meta");
          config.id = "didar-call-checklist-config";
          document.documentElement.append(config);
        }
        const value = JSON.stringify({ enabled: callSettingsReady && settings.enabled && settings.autoCallChecklist,
          templates: CallChecklists.normalizeTemplates(settings.callChecklistTemplates) });
        if (config.getAttribute("content") !== value) {
          config.setAttribute("content", value);
          document.dispatchEvent(new Event("didar-quick-checklist:call-settings-updated"));
        }
      }
    }
  }

  async function loadSettings() {
    settings = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
    if (globalThis.DidarTeamChecklists?.managed()) {
      const team = await chrome.runtime.sendMessage({type:"DIDAR_TEAM_BOOT"});
      if (!team?.ok) throw new Error(team?.error || "قالب تیم بارگذاری نشد.");
      settings = {...settings, ...team.state.settings, teamChecklistVersion:team.state.version};
      document.documentElement.dataset.didarTeamChecklistVersion = String(team.state.version);
    }
    caseCallTypesEpoch += 1;
    caseCallTypes = { status: "idle", items: [], error: "" };
    callSettingsReady = true;
    cachedIdentity = null;
    cachedIdentityKey = "";
    planActivityTypesState = { status: "idle", items: [], error: "" };
    publishPageSettings();
    scan();
    scheduleCurrentDealPersistenceRecovery(true);
  }

  function handleRuntimeMessage(message, _sender, sendResponse) {
    if (["BETA_DIDAR_MOBILE_LOOKUP", "TAMIN_DIDAR_MOBILE_LOOKUP"].includes(message?.type)) {
      etebaritoMobileMatches(message.payload).then(sendResponse).catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (["BETA_DIDAR_APPEND_MOBILE_REPORT", "TAMIN_DIDAR_APPEND_MOBILE_REPORT"].includes(message?.type)) {
      etebaritoAppendMobileReport({ ...message.payload, provider: "beta" })
        .then(sendResponse).catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "TAMIN_DIDAR_GET_CONFIG") {
      etebaritoDidarConfig("beta").then(sendResponse).catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "TAMIN_DIDAR_LOOKUP") {
      etebaritoDidarLookup(taminCreditPayload(message.payload)).then(sendResponse).catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "TAMIN_DIDAR_TRANSFER" || message?.type === "TAMIN_DIDAR_UPDATE") {
      const operation = message.type === "TAMIN_DIDAR_TRANSFER" ? etebaritoDidarTransfer : etebaritoDidarUpdate;
      withOperationLock(`tamin-credit:${normalizeLookupDigits(message.payload?.nationalCode)}`, () => operation(taminCreditPayload(message.payload)))
        .then(sendResponse).catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "ETEBARITO_DIDAR_GET_CONFIG") {
      etebaritoDidarConfig(message.payload?.provider)
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "ETEBARITO_DIDAR_LOOKUP") {
      etebaritoDidarLookup(message.payload)
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "ETEBARITO_DIDAR_MOBILE_LOOKUP") {
      etebaritoMobileMatches(message.payload)
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "ETEBARITO_DIDAR_APPEND_MOBILE_REPORT") {
      etebaritoAppendMobileReport(message.payload)
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "ETEBARITO_DIDAR_TRANSFER") {
      etebaritoDidarTransfer(message.payload)
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "ETEBARITO_DIDAR_UPDATE") {
      etebaritoDidarUpdate(message.payload)
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "BETA_DIDAR_GET_CONFIG") {
      etebaritoDidarConfig("beta")
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "BETA_DIDAR_LOOKUP") {
      etebaritoDidarLookup({ ...message.payload, provider: "beta" })
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "BETA_DIDAR_TRANSFER") {
      etebaritoDidarTransfer({ ...message.payload, provider: "beta" })
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "BETA_DIDAR_UPDATE") {
      etebaritoDidarUpdate({ ...message.payload, provider: "beta" })
        .then(sendResponse)
        .catch((error) => sendResponse(errorResponse(error)));
      return true;
    }
    if (message?.type === "DIDAR_TODO_GET_STATUS") {
      preserveStableMappings();
      currentIdentity(true)
        .then((identity) =>
          sendResponse({
            ok: true,
            identity,
            settings,
            diagnostics: {
              todoLists: document.querySelectorAll("ul.todo-list").length,
              checkboxes: document.querySelectorAll('ul.todo-list input[type="checkbox"]').length,
              enhanced: document.querySelectorAll("input.didar-todo-checkbox").length,
              ready: Array.from(hitboxRecords).filter(({ input }) => input.isConnected).length,
              editorExcluded: document.querySelectorAll(
                'ul.todo-list [contenteditable="true"] input[type="checkbox"], ' +
                  'ul.todo-list .ck-editor__editable input[type="checkbox"]'
              ).length,
              resolved: document.querySelectorAll('ul.todo-list[data-didar-activity-id]').length,
              lastInteraction
            }
          })
        )
        .catch((error) => sendResponse({ ...errorResponse(error), settings }));
      return true;
    }
    if (message?.type === "DIDAR_TODO_SETTINGS_UPDATED") {
      loadSettings()
        .then(() => sendResponse({ ok: true }))
        .catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    return false;
  }

  function registerRuntimeMessageListener() {
    try {
      chrome.runtime.onMessage.removeListener(handleRuntimeMessage);
    } catch (_error) {
      // A listener from a previous extension runtime cannot always be removed.
    }
    chrome.runtime.onMessage.addListener(handleRuntimeMessage);
  }

  if (globalThis.DidarCloudClient) {
    globalThis.DidarCloudClient.install(async (message) => {
      settings = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
      return new Promise(resolve => {
        if (!handleRuntimeMessage(message, {}, resolve)) resolve({ ok: false, error: "عملیات ابری شناخته نشد." });
      });
    });
    return;
  }

  globalThis.__didarQuickChecklistRegisterMessageListener = registerRuntimeMessageListener;
  registerRuntimeMessageListener();
  chrome.storage.onChanged?.addListener((changes, areaName) => {
    if (areaName !== "local" || !("didarTeamEnvelope" in changes || Object.keys(DEFAULT_SETTINGS).some((key) => key in changes))) {
      return;
    }
    void loadSettings().catch((error) => {
      lastInteraction = `خطای اعمال تنظیمات: ${error?.message || "تنظیمات خوانده نشد"}`;
    });
  });
  loadProductActivityMappings();

  document.addEventListener("click", handleChecklistClick, true);
  document.addEventListener("click", handleProductEditorIntent, true);
  document.addEventListener("click", handleDealAddPersonRemovalIntent, true);
  document.addEventListener("click", handleContactDealCardClick, true);
  document.addEventListener("click", (event) => {
    const section = document.querySelector(".didar-pipeline-activity-filter");
    const popover = pipelineActivityPopover(section);
    if (!section || section.contains(event.target) || popover?.contains(event.target)) {
      return;
    }
    if (popover && !popover.hidden) {
      closePipelineActivityPopover(section);
    }
  }, true);
  document.addEventListener(PLAN_ACTIVITY_CREATED_EVENT, handlePlanActivityCreated);
  document.addEventListener(PLAN_ACTIVITY_DELETED_EVENT, handlePlanActivityDeleted);
  document.addEventListener(DEAL_ADD_PERSON_SELECTED_EVENT, handleDealAddPersonSelected);
  document.addEventListener(GLOBAL_SEARCH_RESULTS_EVENT, (event) => {
    if (!readGlobalSearchResultsMarker(event.target)) {
      return;
    }
    bindGlobalSearchDealRowsFromResults();
    enhanceGlobalSearchProductLabels();
  });
  window.addEventListener("resize", () => {
    scheduleHitboxPosition();
    positionPipelineActivityPopover(document.querySelector(".didar-pipeline-activity-filter"));
  });
  window.addEventListener("scroll", () => {
    scheduleHitboxPosition();
    positionPipelineActivityPopover(document.querySelector(".didar-pipeline-activity-filter"));
  }, true);
  window.addEventListener("online", () => scheduleCurrentDealPersistenceRecovery(true));
  window.addEventListener("pageshow", () => scheduleCurrentDealPersistenceRecovery(true));
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      scheduleCurrentDealPersistenceRecovery(true);
    }
  });
  window.setInterval(() => scheduleCurrentDealPersistenceRecovery(), 30000);
  const observer = new MutationObserver(scheduleScan);
  function startObserver() {
    if (!document.documentElement) {
      document.addEventListener("DOMContentLoaded", startObserver, { once: true });
      return;
    }
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["disabled", "data-didar-activity-id", "data-didar-search-deal-id", "data-didar-call-template"]
    });
    publishPageSettings();
    scan();
  }
  startObserver();
  void loadSettings();
})();
