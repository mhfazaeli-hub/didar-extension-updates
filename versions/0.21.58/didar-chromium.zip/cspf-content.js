(function initializeCspfDashboard() {
  "use strict";

  if (globalThis.__didarCspfDashboardLoaded) {
    return;
  }
  globalThis.__didarCspfDashboardLoaded = true;

  const Core = globalThis.CspfCreditCore;
  const PANEL_ID = "didar-cspf-credit-panel";
  let loading = false;
  let scheduled = 0;

  function isDashboard() {
    return /^\/auth-api\/?$/i.test(location.pathname);
  }

  function element(tag, className, value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value !== undefined) node.textContent = value;
    return node;
  }

  function metric(label, key) {
    const wrapper = element("div", "didar-cspf-panel__metric");
    const title = element("span", "didar-cspf-panel__label", label);
    const value = element("strong", "didar-cspf-panel__value", "در حال دریافت...");
    value.dataset.metric = key;
    wrapper.append(title, value);
    return wrapper;
  }

  function dashboardAnchor() {
    const exact = Array.from(document.querySelectorAll("h1,h2,h3,h4,h5,h6,p,div,span"))
      .find((node) => Core.text(node.textContent) === "خدمات پر کاربرد");
    if (exact) {
      return exact.closest("section, article, .card, .grid") || exact;
    }
    const outlet = document.querySelector("router-outlet");
    return outlet?.nextElementSibling || document.querySelector("main, .layout-main, .layout-main-container");
  }

  function createPanel() {
    const panel = element("section", "didar-cspf-panel");
    panel.id = PANEL_ID;
    panel.dir = "rtl";
    panel.setAttribute("aria-label", "خلاصه اعتبار کشوری");

    const header = element("div", "didar-cspf-panel__header");
    const titles = element("div", "didar-cspf-panel__titles");
    titles.append(
      element("h2", "didar-cspf-panel__title", "خلاصه اعتبار کشوری"),
      element("p", "didar-cspf-panel__subtitle", "محاسبه توان قسط بر مبنای ۷۰٪ تتمه سقف مجاز")
    );
    const refresh = element("button", "didar-cspf-panel__refresh", "بروزرسانی");
    refresh.type = "button";
    refresh.title = "دریافت دوباره اطلاعات از سامانه صندوق";
    refresh.addEventListener("click", () => void loadSummary(panel));
    header.append(titles, refresh);

    const metrics = element("div", "didar-cspf-panel__metrics");
    metrics.append(
      metric("دفترکل", "daftarKol"),
      metric("شماره حساب", "bankAccount"),
      metric("تتمه سقف مجاز", "remainingToman"),
      metric("توان قسط", "installmentToman")
    );
    const status = element("p", "didar-cspf-panel__status", "");
    status.setAttribute("role", "status");
    panel.append(header, metrics, status);
    return panel;
  }

  function mountPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (!isDashboard()) {
      existing?.remove();
      return null;
    }
    if (existing) {
      return existing;
    }
    const anchor = dashboardAnchor();
    if (!anchor?.parentElement) {
      return null;
    }
    const panel = createPanel();
    anchor.parentElement.insertBefore(panel, anchor);
    void loadSummary(panel);
    return panel;
  }

  function setMetric(panel, key, value) {
    const target = panel.querySelector(`[data-metric="${key}"]`);
    if (target) target.textContent = value || "ناموجود";
  }

  function setStatus(panel, value, state = "") {
    panel.dataset.state = state;
    const status = panel.querySelector(".didar-cspf-panel__status");
    if (status) status.textContent = value;
  }

  function documentFromHtml(value) {
    return new DOMParser().parseFromString(value, "text/html");
  }

  async function fetchCertificatePage(path, expectedPath, failureLabel) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch(path, {
        credentials: "include",
        cache: "no-store",
        headers: { Accept: "text/html,application/xhtml+xml" },
        signal: controller.signal
      });
      if (!response.ok) {
        throw new Error(`${failureLabel}: HTTP ${response.status}`);
      }
      const finalPath = new URL(response.url, location.origin).pathname;
      if (!expectedPath.test(finalPath)) {
        throw new Error("نشست سامانه صندوق منقضی شده است؛ دوباره وارد سامانه شوید.");
      }
      return documentFromHtml(await response.text());
    } catch (error) {
      if (error?.name === "AbortError") {
        throw new Error("پاسخ سامانه صندوق بیش از حد طول کشید؛ دوباره تلاش کنید.");
      }
      throw error;
    } finally {
      window.clearTimeout(timeout);
    }
  }

  async function certificateDocument() {
    // This mirrors the official flow: Default.aspx initializes the classic
    // ASP.NET Certificate session before MainList.aspx is requested.
    await fetchCertificatePage(
      "/Certificate/Default.aspx",
      /^\/Certificate\/(?:Default|MainList)\.aspx$/i,
      "آماده‌سازی سامانه گواهی انجام نشد"
    );
    return fetchCertificatePage(
      "/Certificate/MainList.aspx",
      /^\/Certificate\/MainList\.aspx$/i,
      "دریافت سقف مجاز انجام نشد"
    );
  }

  async function loadSummary(panel) {
    if (loading || !panel?.isConnected) {
      return;
    }
    loading = true;
    panel.classList.add("is-loading");
    setStatus(panel, "در حال دریافت اطلاعات از سامانه صندوق...");
    try {
      const identity = Core.findPensionClaims(localStorage);
      if (!identity.daftarKol || !identity.bankAccount) {
        throw new Error("اطلاعات دفترکل و حساب هنوز آماده نیست؛ یک‌بار بخش «فیش حقوقی» را باز کنید و سپس بروزرسانی را بزنید.");
      }
      const certificate = await certificateDocument();
      const remainingRials = Core.extractRemainingRials(certificate);
      if (!remainingRials) {
        throw new Error("تتمه سقف مجاز در پاسخ سامانه پیدا نشد.");
      }
      const remainingToman = Core.rialToRoundedToman(remainingRials);
      const installmentToman = Core.installmentCapacityToman(remainingToman);
      setMetric(panel, "daftarKol", identity.daftarKol);
      setMetric(panel, "bankAccount", identity.bankAccount);
      setMetric(panel, "remainingToman", `${Core.formatMoney(remainingToman)} تومان`);
      setMetric(panel, "installmentToman", `${Core.formatMoney(installmentToman)} تومان`);
      setStatus(panel, "اطلاعات از نشست جاری صندوق دریافت شد.", "ready");
    } catch (error) {
      setStatus(panel, error?.message || "دریافت اطلاعات انجام نشد.", "error");
      void globalThis.DidarDiagnostics?.report({source:"cspf",operation:"fetch",error});
      panel.querySelectorAll("[data-metric]").forEach((node) => {
        if (node.textContent === "در حال دریافت...") node.textContent = "ناموجود";
      });
    } finally {
      loading = false;
      panel.classList.remove("is-loading");
    }
  }

  function scheduleMount() {
    window.clearTimeout(scheduled);
    scheduled = window.setTimeout(mountPanel, 80);
  }

  const observer = new MutationObserver(scheduleMount);
  function start() {
    observer.observe(document.documentElement, { childList: true, subtree: true });
    scheduleMount();
    window.addEventListener("popstate", scheduleMount);
    window.addEventListener("hashchange", scheduleMount);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
