(function initializeCspfCore(root, factory) {
  "use strict";

  const api = factory(root);
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
  root.CspfCreditCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function createCspfCore(root) {
  "use strict";

  function text(value) {
    return value == null ? "" : String(value).trim();
  }

  function normalizeDigits(value) {
    return text(value)
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)));
  }

  function digits(value) {
    return normalizeDigits(value).replace(/\D/g, "");
  }

  function decodeBase64Url(value) {
    const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
    if (typeof root.atob === "function") {
      const binary = root.atob(padded);
      const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
      return new TextDecoder().decode(bytes);
    }
    if (typeof Buffer !== "undefined") {
      return Buffer.from(padded, "base64").toString("utf8");
    }
    throw new Error("رمزگشایی اطلاعات نشست در این مرورگر پشتیبانی نمی‌شود.");
  }

  function decodeJwt(value) {
    const token = text(value);
    const parts = token.split(".");
    if (parts.length !== 3) {
      return null;
    }
    try {
      const payload = JSON.parse(decodeBase64Url(parts[1]));
      return payload && typeof payload === "object" ? payload : null;
    } catch {
      return null;
    }
  }

  function claim(payload, names) {
    const wanted = new Set(names.map((name) => name.toLowerCase()));
    const entry = Object.entries(payload || {}).find(([name]) => wanted.has(name.toLowerCase()));
    return text(entry?.[1]);
  }

  function pensionClaims(payload) {
    const daftarKol = digits(claim(payload, [
      "DaftarKol", "daftarKol", "PensionaryIdentifier", "pensionaryIdentifier"
    ]));
    const bankAccount = digits(claim(payload, [
      "BankAccount", "bankAccount", "Bank", "bank", "AccountNumber", "accountNumber"
    ]));
    const nationalCode = digits(claim(payload, ["NationalCode", "nationalCode", "NCode", "nCode"]));
    const firstName = claim(payload, ["FirstName", "firstName"]);
    const lastName = claim(payload, ["LastName", "lastName"]);
    return {
      daftarKol,
      bankAccount,
      nationalCode: /^\d{10}$/.test(nationalCode) ? nationalCode : "",
      fullName: `${firstName} ${lastName}`.trim()
    };
  }

  function findPensionClaims(storage) {
    const candidates = [];
    for (let index = 0; index < Number(storage?.length || 0); index += 1) {
      const key = storage.key(index);
      const payload = decodeJwt(storage.getItem(key));
      if (!payload) {
        continue;
      }
      const values = pensionClaims(payload);
      if (values.daftarKol || values.bankAccount) {
        candidates.push({ key, payload, values });
      }
    }
    candidates.sort((left, right) => {
      const leftScore = Number(Boolean(left.values.daftarKol)) + Number(Boolean(left.values.bankAccount));
      const rightScore = Number(Boolean(right.values.daftarKol)) + Number(Boolean(right.values.bankAccount));
      return rightScore - leftScore || Number(right.key === "user-token") - Number(left.key === "user-token");
    });
    return candidates[0]?.values || { daftarKol: "", bankAccount: "", nationalCode: "", fullName: "" };
  }

  function documentText(documentNode) {
    return normalizeDigits(documentNode?.body?.innerText || documentNode?.body?.textContent || "")
      .replace(/[\u200c\u200d\u200e\u200f]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function extractRemainingRials(documentNode) {
    const value = documentText(documentNode);
    const match = value.match(/تتمه\s*سقف\s*مجاز\s*[:：]?\s*([0-9][0-9,٬،\s]*)/);
    const amount = digits(match?.[1]);
    return amount.replace(/^0+(?=\d)/, "");
  }

  function positiveBigInt(value) {
    const amount = digits(value);
    return amount ? BigInt(amount) : 0n;
  }

  function rialToRoundedToman(value) {
    return ((positiveBigInt(value) + 5n) / 10n).toString();
  }

  function installmentCapacityToman(tomanValue) {
    return ((positiveBigInt(tomanValue) * 7n + 5n) / 10n).toString();
  }

  function formatMoney(value) {
    const amount = positiveBigInt(value).toString();
    return amount.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  function buildSummary(storage, certificateDocument) {
    const identity = findPensionClaims(storage);
    const remainingRials = extractRemainingRials(certificateDocument);
    const remainingToman = rialToRoundedToman(remainingRials);
    const installmentToman = installmentCapacityToman(remainingToman);
    return { ...identity, remainingRials, remainingToman, installmentToman };
  }

  return {
    text,
    digits,
    decodeJwt,
    pensionClaims,
    findPensionClaims,
    documentText,
    extractRemainingRials,
    rialToRoundedToman,
    installmentCapacityToman,
    formatMoney,
    buildSummary
  };
});
