(function initializeDiagnosticBackground(root) {
  "use strict";
  const api = root.browser || root.chrome;
  const Core = root.DidarDiagnostics;
  const KEY = "didarDiagnosticsV1";
  let serial = Promise.resolve();
  let flushing;
  const locked = (operation) => {
    const result = serial.then(operation);
    serial = result.catch(() => {});
    return result;
  };
  const browser = /Firefox\//.test(navigator.userAgent)
    ? "firefox"
    : /Edg\//.test(navigator.userAgent)
      ? "edge"
      : /Chrome\//.test(navigator.userAgent)
        ? "chrome"
        : "unknown";
  async function read() {
    const value = (await api.storage.local.get(KEY))[KEY];
    return {
      recent: Array.isArray(value?.recent) ? value.recent.slice(-100) : [],
      queue: Array.isArray(value?.queue) ? value.queue.slice(-50) : [],
      delivery: value?.delivery || null,
    };
  }
  async function flush() {
    if (flushing) return flushing;
    flushing = (async () => {
      const url = root.DidarRelease?.diagnosticsUrl;
      if (!url) return;
      if (browser === "firefox") {
        const permissions = await api.permissions?.getAll?.();
        if (!permissions?.data_collection?.includes("technicalAndInteraction")) return;
      }
      for (let attempt = 0; attempt < 50; attempt++) {
        const item = await locked(async () => (await read()).queue[0]);
        if (!item) break;
        const response = await fetch(url, {
          method: "POST",
          credentials: "omit",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(Core.event(item)),
          signal: AbortSignal.timeout(8000),
        });
        if (!response.ok || (await response.json()).id !== item.id) {
          await locked(async () => {
            const state=await read();state.delivery={code:"HTTP_ERROR",httpStatus:response.status};
            await api.storage.local.set({[KEY]:state});
          });
          break;
        }
        await locked(async () => {
          const state = await read();
          state.delivery = {code:"SENT",httpStatus:response.status};
          state.queue = state.queue.filter((row) => row.id !== item.id);
          state.recent = state.recent.map((row) =>
            row.id === item.id ? { ...row, sent: true } : row,
          );
          await api.storage.local.set({ [KEY]: state });
        });
      }
    })()
      .catch(() => locked(async () => {
        const state=await read();state.delivery={code:"NETWORK_ERROR"};
        await api.storage.local.set({[KEY]:state});
      }).catch(()=>{}))
      .finally(() => {
        flushing = null;
      });
    return flushing;
  }
  async function record(input) {
    const value = Core.event(input, {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      extensionVersion: api.runtime.getManifest().version,
      browser,
    });
    await locked(async () => {
      const state = await read();
      state.recent = [...state.recent, { ...value, sent: false }].slice(-100);
      state.queue = [...state.queue, value].slice(-50);
      await api.storage.local.set({ [KEY]: state });
    });
    void flush();
    return value.id;
  }
  root.DidarDiagnosticBackground = { record, flush };
  api.runtime.onMessage.addListener((message, sender, respond) => {
    const source = Core.sourceForURL(sender.tab?.url);
    const popupURL = api.runtime.getURL?.("popup.html");
    const popup = sender.id === api.runtime.id && (!sender.tab || Boolean(popupURL && sender.url === popupURL));
    if (message?.type === "DIDAR_DIAGNOSTIC" && source) {
      record({ ...message.event, source })
        .then((id) => respond({ ok: true, id }))
        .catch(() => respond({ ok: false }));
      return true;
    }
    if (message?.type === "DIDAR_DIAGNOSTICS_GET" && popup) {
      flush()
        .then(() => locked(read))
        .then((state) => respond({ ok: true, ...state }))
        .catch(() => respond({ ok: false }));
      return true;
    }
    return false;
  });
  api.runtime.onStartup?.addListener(() => void flush());
  api.runtime.onInstalled?.addListener(() => void flush());
})(globalThis);
