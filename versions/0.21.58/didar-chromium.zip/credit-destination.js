(function initializeCreditDestination(root) {
  "use strict";
  if (root.DidarCreditDestination) return;
  const text = value => value == null ? "" : String(value).trim();
  const statusTitles = { Pending: "جاری", Won: "موفق", Lost: "ناموفق" };
  const savingControls = new WeakMap();

  function setBusy(container, busy) {
    if (busy) {
      if (savingControls.has(container)) return;
      const controls = new Map(Array.from(container.querySelectorAll("input, select, button"), control => [control, control.disabled]));
      savingControls.set(container, controls);
      controls.forEach((_disabled, control) => { control.disabled = true; });
    } else {
      const controls = savingControls.get(container);
      controls?.forEach((disabled, control) => { if (control.isConnected) control.disabled = disabled; });
      savingControls.delete(container);
    }
  }

  function element(tag, className, value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value !== undefined) node.textContent = value;
    return node;
  }

  function render(container, options) {
    const { lookup, onContact = () => {}, onClear = () => {}, onDeal = () => {},
      onNewDeal = () => {}, allowNewDeal = true, writeEnabled = true, reopenClosed = true } = options;
    container.replaceChildren();
    const setState = value => {
      container.classList.remove("is-error", "is-success", "is-warning", "is-loading");
      container.classList.add("etebarito-preview__result", value);
    };
    if (!lookup?.ok) {
      setState("is-error");
      container.textContent = lookup?.error || "دریافت مقصدهای ثبت از دیدار انجام نشد.";
      return "error";
    }
    const contacts = (lookup.contacts || []).filter(contact => text(contact.id));
    if (!contacts.length) {
      setState(lookup.conflict ? "is-error" : "is-success");
      container.textContent = lookup.conflict ? "نتایج جست‌وجو نیازمند بررسی مجدد هستند."
        : "مخاطبی با این کد ملی پیدا نشد. مشخصات را بررسی و مخاطب و معاملهٔ جدید را ثبت کنید.";
      return lookup.conflict ? "error" : "success";
    }
    setState("is-warning");
    container.append(element("strong", "", contacts.length > 1
      ? "چند مخاطب پیدا شدند. مخاطب صحیح و معاملهٔ او را همین‌جا انتخاب کنید."
      : "معاملهٔ جدید بسازید یا یکی از معاملات این مخاطب را انتخاب کنید."));
    const contactList = element("div", "etebarito-preview__contact-list");
    const targets = element("div", "etebarito-preview__destination-deals");
    const group = "credit-contact-" + Math.random().toString(36).slice(2);
    const writable = writeEnabled && lookup.writeEnabled !== false;
    const allDeals = lookup.deals || lookup.openDeals || [];

    function chooseContact(contact) {
      onClear();
      onContact(contact);
      targets.replaceChildren();
      const contactDeals = allDeals.filter(deal => text(deal.contactId).toLowerCase() === text(contact.id).toLowerCase());
      targets.append(element("strong", "etebarito-preview__destination-heading", "معاملات " + (contact.displayName || contact.fullName || "مخاطب انتخابی")));
      const list = element("div", "etebarito-preview__deal-list");
      list.classList.toggle("has-many", contactDeals.length > 1);
      const targetGroup = group + "-deal";
      let newRadio;
      const selectable = [];
      if (allowNewDeal) {
        const row = element("label", "etebarito-preview__deal-option etebarito-preview__new-deal");
        const radio = document.createElement("input");
        radio.type = "radio"; radio.name = targetGroup; radio.value = "new-deal"; radio.disabled = !writable;
        radio.addEventListener("change", () => {
          if (!radio.checked) return;
          onClear();
          onNewDeal(contact, contactDeals);
        });
        row.append(radio, element("strong", "", "＋ ایجاد معاملهٔ جدید برای همین مخاطب"));
        list.append(row);
        newRadio = radio;
      }
      for (const deal of contactDeals) {
        const row = element("label", "etebarito-preview__deal-option");
        row.dataset.status = text(deal.status);
        row.dataset.dealId = text(deal.id);
        const radio = document.createElement("input");
        radio.type = "radio"; radio.name = targetGroup; radio.value = text(deal.id);
        radio.disabled = !writable || !statusTitles[deal.status];
        const details = element("span", "etebarito-preview__deal-details");
        const title = element("span", "", deal.title || "معامله");
        details.append(title, element("span", "etebarito-preview__deal-status", statusTitles[deal.status] || "وضعیت نامشخص"));
        const products = (deal.products?.length ? deal.products : deal.planTypes || []).map(text).filter(Boolean);
        if (products.length) details.append(element("small", "etebarito-preview__deal-products", products.join(" · ")));
        const metadata = [deal.code && "کد " + deal.code, deal.amount && "مبلغ " + deal.amount + " ریال", deal.ownerName].filter(Boolean);
        if (metadata.length) details.append(element("small", "", metadata.join(" · ")));
        if (text(deal.url).startsWith("https://app.didar.me/")) {
          const link = element("a", "etebarito-preview__destination-link", "مشاهده معامله");
          link.href = deal.url; link.target = "_blank"; link.rel = "noreferrer";
          link.addEventListener("click", event => event.stopPropagation());
          details.append(link);
        }
        if (["Won", "Lost"].includes(deal.status)) details.append(element("small", "", reopenClosed
          ? "با تأیید بروزرسانی، معامله باز و جاری می‌شود." : "گزارش به معامله اضافه می‌شود و وضعیت بستهٔ آن حفظ می‌شود."));
        radio.addEventListener("change", () => {
          if (!radio.checked) return;
          onClear();
          onDeal(deal, contact);
        });
        row.append(radio, details);
        list.append(row);
        if (!radio.disabled) selectable.push({ radio, deal });
      }
      targets.append(list);
      if (!contactDeals.length) {
        targets.append(element("small", "", "این مخاطب معامله‌ای ندارد. گزارش در معاملهٔ جدید ثبت می‌شود."));
        if (newRadio && !newRadio.disabled) { newRadio.checked = true; onNewDeal(contact, []); }
      } else if (contactDeals.length === 1 && selectable.length === 1) {
        selectable[0].radio.checked = true;
        onDeal(selectable[0].deal, contact);
      }
    }

    for (const contact of contacts) {
      const row = element(contacts.length > 1 ? "label" : "div", "etebarito-preview__contact-option");
      row.dataset.contactId = text(contact.id);
      if (contacts.length > 1) {
        const radio = document.createElement("input");
        radio.type = "radio"; radio.name = group; radio.value = text(contact.id); radio.disabled = !writable;
        radio.addEventListener("change", () => { if (radio.checked) chooseContact(contact); });
        row.append(radio);
      }
      const details = element("span", "etebarito-preview__deal-details");
      details.append(element("strong", "", contact.displayName || contact.fullName || "مخاطب"));
      const info = [contact.mobilePhone || contact.workPhone, contact.nationalCode && "کد ملی " + contact.nationalCode, contact.ownerName].filter(Boolean);
      if (info.length) details.append(element("small", "", info.join(" · ")));
      row.append(details);
      contactList.append(row);
    }
    container.append(contactList, targets);
    if (contacts.length === 1) chooseContact(contacts[0]);
    return contacts.length === 1 && !allDeals.length ? "existing-contact" : "warning";
  }

  root.DidarCreditDestination = { render, setBusy };
})(globalThis);
