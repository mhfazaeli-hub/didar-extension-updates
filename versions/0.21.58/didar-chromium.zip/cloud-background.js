(function initializeCloudBackground() {
  "use strict";
  const api = globalThis.browser || globalThis.chrome;
  let creating = null;
  const configurations = new Map();
  let workingEndpoint = "";
  const endpointReady = api.storage.session?.get("didarCloudEndpoint")
    .then(value => { workingEndpoint = value.didarCloudEndpoint || ""; }).catch(() => {});
  const metadataPaths = new Set(["customfield/getcustomfieldlist", "pipeline/list/0", "source/getlist", "activity/getactivitytype"]);
  const clientURL = api.runtime.getURL("cloud-client.html");
  const popupURL = api.runtime.getURL("popup.html");

  async function connection() {
    const values = await api.storage.local.get({ cloudConnectionCode: "", cloudUserId: "" });
    return { code: values.cloudConnectionCode, userId: values.cloudUserId };
  }

  async function fetchCloud(route, input = {}, selected) {
    const values = selected || await connection();
    if (!values.code) throw new Error("کد اتصال تیم را در تنظیمات اتصال ابری وارد کنید.");
    const code = String(values.code).replace(/[۰-۹]/g, digit => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/[٠-٩]/g, digit => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
    await endpointReady;
    const endpoints = [...new Set([globalThis.DidarRelease.cloudApiUrl, globalThis.DidarRelease.cloudApiFallbackUrl].filter(Boolean))];
    if (endpoints.includes(workingEndpoint)) endpoints.sort(endpoint => endpoint === workingEndpoint ? -1 : 1);
    const controllers = [];
    async function request(endpoint, delay = 0) {
      const controller = new AbortController();
      controllers.push(controller);
      if (delay) await new Promise(resolve => setTimeout(resolve, delay));
      if (controller.signal.aborted) throw new Error("Cancelled redundant read");
      const timer = setTimeout(() => controller.abort(), 20000);
      try {
        const response = await fetch(endpoint + route, {
          method: "POST", credentials: "omit", redirect: "error", headers: {
            Authorization: "Bearer " + code, "Content-Type": "application/json"
          }, body: JSON.stringify({ ...input, userId: values.userId }), signal: controller.signal
        });
        const result = await response.json();
        if (typeof result?.ok !== "boolean") throw new Error("Invalid gateway response");
        if (workingEndpoint !== endpoint) {
          workingEndpoint = endpoint;
          void api.storage.session?.set({ didarCloudEndpoint: endpoint }).catch(() => {});
        }
        return { response, result };
      } finally { clearTimeout(timer); }
    }
    let received;
    const safeRead = route === "/users" || route === "/identity" ||
      route === "/request" && metadataPaths.has(String(input.path).toLowerCase());
    try {
      if (safeRead && endpoints.length > 1) {
        try { received = await Promise.any(endpoints.map((endpoint, index) => request(endpoint, index * 400))); }
        catch { received = await request(endpoints[0]); }
      } else {
        for (let attempt = 0; attempt < 3; attempt++) {
          try { received = await request(endpoints[attempt % endpoints.length]); break; }
          catch (error) {
            if (attempt === 2) throw error;
            await new Promise(resolve => setTimeout(resolve, 300 * (attempt + 1)));
          }
        }
      }
    } catch { throw new Error("ارتباط مرورگر با سرویس ابری برقرار نشد؛ اتصال شبکه را بررسی کنید."); }
    finally { controllers.forEach(controller => controller.abort()); }
    const { response, result } = received;
    if (!response.ok || !result?.ok) {
      const error = new Error(result?.error || "ارتباط با سرویس ابری انجام نشد.");
      Object.assign(error, { code: result?.code, status: response.status });
      throw error;
    }
    return result;
  }

  async function createClient() {
    if (api.offscreen) {
      const contexts = await api.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"], documentUrls: [clientURL] });
      if (!contexts.length) await api.offscreen.createDocument({ url: "cloud-client.html", reasons: ["DOM_PARSER"],
        justification: "Reuse the credit preview validation and HTML report parser for the cloud API connection." });
    } else if (!document.getElementById("didar-cloud-client")) {
      const frame = document.createElement("iframe");
      frame.id = "didar-cloud-client";
      frame.hidden = true;
      frame.src = clientURL;
      (document.body || document.documentElement).appendChild(frame);
    }
    for (let attempt = 0; attempt < 100; attempt++) {
      try {
        if ((await api.runtime.sendMessage({ type: "DIDAR_CLOUD_EXECUTE", ping: true }))?.ok) return;
      } catch { /* The document may still be loading. */ }
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    throw new Error("بخش انتقال ابری آماده نشد؛ افزونه را دوباره بارگذاری کنید.");
  }

  globalThis.DidarCloudBackground = {
    async execute(message) {
      if (!creating) creating = createClient().finally(() => { creating = null; });
      await creating;
      const run = () => api.runtime.sendMessage({ type: "DIDAR_CLOUD_EXECUTE", message });
      if (!message.type?.endsWith("_GET_CONFIG")) return run();
      const selected = await connection();
      const key = JSON.stringify({ selected, message });
      const previous = configurations.get(key);
      if (previous && Date.now() - previous.at < 60000) return previous.promise;
      const entry = { at: Date.now(), promise: run() };
      configurations.set(key, entry);
      if (configurations.size > 20) configurations.delete(configurations.keys().next().value);
      const discard = () => { if (configurations.get(key) === entry) configurations.delete(key); };
      entry.promise.then(value => { if (!value?.ok) discard(); }, discard);
      return entry.promise;
    },
    async status() { return fetchCloud("/identity"); }
  };

  api.storage.onChanged?.addListener((changes, area) => {
    if (area === "local" && ["connectionMode", "cloudConnectionCode", "cloudUserId"].some(key => changes[key])) configurations.clear();
  });

  api.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== api.runtime.id) return false;
    const fromClient = sender.url === clientURL;
    const fromPopup = sender.url === popupURL || !sender.tab;
    let operation;
    if (fromClient && message?.type === "DIDAR_CLOUD_STORAGE" && ["get", "set", "remove"].includes(message.method)) {
      operation = api.storage.local[message.method](message.value);
    } else if (fromClient && message?.type === "DIDAR_CLOUD_CONNECTION") {
      operation = connection();
    } else if (fromClient && message?.type === "DIDAR_CLOUD_API" && ["/identity", "/request"].includes(message.route)) {
      operation = fetchCloud(message.route, message.input, message.connection).then(value => message.route === "/request" ? value.value : value);
    } else if (fromPopup && message?.type === "DIDAR_CLOUD_USERS") {
      operation = fetchCloud("/users", {}, { code: String(message.code || ""), userId: "" });
    } else if (fromPopup && message?.type === "DIDAR_CLOUD_DISCONNECT") {
      configurations.clear();
      operation = api.storage.local.set({ connectionMode: "cloud", cloudConnectionCode: "", cloudUserId: "", cloudUserName: "" });
    } else if (fromPopup && message?.type === "DIDAR_CLOUD_STATUS") {
      operation = fetchCloud("/identity");
    } else return false;
    Promise.resolve(operation).then(value => respond({ ok: true, value }), error => respond({ ok: false,
      error: error.message || "اتصال ابری انجام نشد.", code: error.code, httpStatus: error.status }));
    return true;
  });
})();
