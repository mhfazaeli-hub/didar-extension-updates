(function initializeOliveBridge() {
  "use strict";
  if (globalThis.__didarOliveBridge) return;
  globalThis.__didarOliveBridge = true;
  const ORIGIN = "https://api.olivecredit.ir";
  const PREFIX = "/Olive/PersonIranCreditScoring/";
  const originalFetch = window.fetch;
  let authorization = "";
  let credentials = "same-origin";
  let csrf = {};
  let generation = 0;
  let running = false;
  const STAGES = { profile: "اطلاعات مشتری", score: "نتیجهٔ اعتبارسنجی", history: "تاریخچهٔ گزارش", pdf: "فایل PDF گزارش" };
  function requestStage(path) {
    return path.endsWith("GetPersonInfo") ? "profile" : path.endsWith("FindAll") ? "history" : path.includes("Content?") ? "pdf" : "score";
  }
  function failure(message, stage, code, details = {}) {
    const error = new Error(message);
    error.diagnostic = { stage, code, ...details };
    return error;
  }
  function remember(input, init) {
    try {
      const url = new URL(typeof input === "string" ? input : input?.url || String(input), location.href);
      if (url.origin !== ORIGIN || !url.pathname.startsWith("/Olive/")) return;
      const nativeCredentials = init?.credentials || input?.credentials || "same-origin";
      if (["omit", "same-origin", "include"].includes(nativeCredentials)) credentials = nativeCredentials;
      const headers = new Headers(input?.headers || {});
      new Headers(init?.headers || {}).forEach((value, key) => headers.set(key, value));
      const next = headers.get("authorization");
      if (next && next !== authorization) { generation += 1; authorization = next; csrf = {}; }
      for (const name of ["x-xsrf-token", "x-csrf-token"]) if (headers.has(name)) csrf[name] = headers.get(name);
    } catch {}
  }
  window.fetch = function observeOliveFetch(input, init) {
    remember(input, init);
    return Reflect.apply(originalFetch, this, arguments);
  };
  async function read(path, body, binary = false) {
    const stage = requestStage(path);
    const abort = new AbortController();
    const timeout = setTimeout(() => abort.abort(), 20000);
    try {
    const headers = new Headers(csrf);
    if (authorization) headers.set("authorization", authorization);
    if (body) headers.set("content-type", "application/json");
    const response = await originalFetch.call(window, ORIGIN + path, { method: body ? "POST" : "GET",
      headers, signal: abort.signal, credentials, cache: "no-store", ...(body ? { body: JSON.stringify(body) } : {}) });
    if (!response.ok) throw failure([401, 403].includes(response.status)
      ? "نشست الیو کردیت در دسترس نیست؛ صفحه را تازه‌سازی کنید و از ورود به سامانه مطمئن شوید."
      : `دریافت ${STAGES[stage]} الیو کردیت انجام نشد: HTTP ${response.status}${stage === "pdf" ? "؛ آماده‌بودن دانلود گزارش در خود سامانه را بررسی کنید." : ""}`,
      stage, "HTTP_ERROR", { httpStatus: response.status });
    if (!binary) return await response.json();
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.length > 10 * 1024 * 1024 || String.fromCharCode(...bytes.slice(0, 4)) !== "%PDF") throw new Error("فایل دریافتی PDF معتبر نیست یا بیش از حد بزرگ است.");
    let text = "";
    for (let i = 0; i < bytes.length; i += 32768) text += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return btoa(text);
    } catch (error) {
      if (error.name === "AbortError") throw failure(`پاسخ ${STAGES[stage]} الیو کردیت به‌موقع دریافت نشد؛ دوباره تلاش کنید.`, stage, "TIMEOUT");
      if (!error.diagnostic) error.diagnostic = { stage, code: "REQUEST_FAILED" };
      throw error;
    } finally { clearTimeout(timeout); }
  }
  document.addEventListener("didar-olive:fetch", async (event) => {
    const marker = event.target?.closest?.("meta[data-didar-olive-request]");
    if (!marker || marker.dataset.running) return;
    marker.dataset.running = "true";
    const finish = (value) => { marker.textContent = JSON.stringify(value); marker.dispatchEvent(new Event("didar-olive:result", { bubbles: true })); };
    if (running) { finish({ ok: false, error: "یک واکشی دیگر در حال انجام است." }); return; }
    running = true;
    const epoch = generation;
    const availability = {};
    try {
      const [profile, score] = await Promise.all([read("/Olive/PersonProfile/GetPersonInfo"), read(PREFIX + "Get")]);
      if (epoch !== generation) throw new Error("حساب الیو کردیت حین واکشی تغییر کرد؛ دوباره تلاش کنید.");
      if (profile?.isSuccess !== true || !profile.data) throw failure("اطلاعات پروفایل الیو کردیت کامل دریافت نشد.", "profile", "PROFILE_UNAVAILABLE");
      const rating = score?.data;
      availability.hasReport = rating?.hasReport === true;
      availability.scoreAvailable = /^\d{1,3}$/.test(String(rating?.score)) && Number(rating.score) <= 900;
      availability.rankAvailable = /^[A-E][1-3]$/.test(String(rating?.risk || "").trim().toUpperCase());
      if (score?.isSuccess !== true || !availability.hasReport || !/^[1-9]\d*$/.test(String(rating?.id))) {
        throw failure("گزارش آماده‌ای برای این مشتری در الیو کردیت وجود ندارد. آماده‌بودن دانلود PDF در خود سامانه را بررسی کنید؛ استعلام تازه خودکار ایجاد نمی‌شود.", "score", "REPORT_UNAVAILABLE");
      }
      if (!availability.scoreAvailable || !availability.rankAvailable) {
        throw failure("نتیجهٔ اعتبارسنجی الیو کردیت کامل نیست؛ امتیاز یا رتبهٔ معتبر گزارش دریافت نشد. آماده‌بودن گزارش در خود سامانه را بررسی کنید.", "score", "RESULT_INCOMPLETE");
      }
      const history = await read(PREFIX + "FindAll", { pageNumber: 1, pageSize: 5,
        sortingParams: [{ columnName: "CreatedAt", sortOrder: "Desc" }], filterParam: [], comparisonMode: "And", outputType: "List", fileName: "FileName" });
      if (history?.isSuccess !== true || !Array.isArray(history.data?.items)) throw failure("تاریخچهٔ گزارش الیو کردیت کامل دریافت نشد.", "history", "HISTORY_UNAVAILABLE");
      const row = history.data.items.find((item) => String(item.id) === String(score.data.id));
      availability.historyRowFound = Boolean(row);
      availability.identityMatches = Boolean(row) && String(row.nationalCode) === String(profile.data.nationalCode);
      if (epoch !== generation) throw new Error("حساب الیو کردیت حین واکشی تغییر کرد؛ دوباره تلاش کنید.");
      if (!availability.identityMatches) throw failure("هویت گزارش با پروفایل مشتری تطابق ندارد.", "history", "IDENTITY_MISMATCH");
      const base64 = await read(PREFIX + "Content?id=" + encodeURIComponent(score.data.id), null, true);
      if (epoch !== generation) throw new Error("حساب الیو کردیت حین واکشی تغییر کرد؛ دوباره تلاش کنید.");
      // Authentication headers stay in MAIN and are never placed in the DOM.
      finish({ ok: true, profile: { isSuccess: true, data: {
        firstName: profile.data.firstName, lastName: profile.data.lastName, fatherName: profile.data.fatherName,
        nationalCode: profile.data.nationalCode, mobileNumber: profile.data.mobileNumber, birthDate: profile.data.birthDate
      } }, score: { isSuccess: true, data: { id: score.data.id, score: score.data.score, risk: score.data.risk,
        createdAt: score.data.createdAt, hasReport: true } }, base64 });
    } catch (error) { finish({ ok: false, error: error.message || "واکشی الیو کردیت انجام نشد.",
      diagnostic: { ...error.diagnostic, availability } }); }
    finally { running = false; }
  }, true);
})();
