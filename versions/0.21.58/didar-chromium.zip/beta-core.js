(function initializeBetaCore(root) {
  "use strict";

  function text(value) {
    return value == null ? "" : String(value).trim();
  }

  function normalizeText(value) {
    return text(value)
      .normalize("NFKC")
      .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)))
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/ي/g, "ی")
      .replace(/ك/g, "ک")
      .replace(/[\u200c\u200d\u200e\u200f]/g, " ")
      .replace(/[ \t]+/g, " ")
      .trim();
  }

  function digits(value) {
    return normalizeText(value).replace(/\D/g, "");
  }

  function normalizeMobile(value) {
    let result = digits(value);
    if (result.startsWith("0098")) {
      result = `0${result.slice(4)}`;
    } else if (result.startsWith("98") && result.length === 12) {
      result = `0${result.slice(2)}`;
    } else if (result.startsWith("9") && result.length === 10) {
      result = `0${result}`;
    }
    return /^09\d{9}$/.test(result) ? result : "";
  }

  function normalizeNationalCode(value) {
    const result = digits(value);
    return /^\d{10}$/.test(result) ? result : "";
  }

  function pageText(documentNode) {
    if (documentNode?.body?.innerText) {
      return normalizeText(documentNode.body.innerText);
    }
    const clone = documentNode?.body?.cloneNode?.(true);
    clone?.querySelectorAll?.("br, p, div, section, article, li, tr, td, th, h1, h2, h3, h4, h5, h6")
      .forEach((node) => node.append("\n"));
    return normalizeText(clone?.textContent || documentNode?.body?.textContent || "");
  }

  function parseMoney(value) {
    const result = digits(value);
    return result && !/^0+$/.test(result) ? result.replace(/^0+(?=\d)/, "") : result;
  }

  function jalaliDates(value) {
    const normalized = normalizeText(value);
    return Array.from(normalized.matchAll(/\b(1[34]\d{2})\s*[\/.\-]\s*(\d{1,2})\s*[\/.\-]\s*(\d{1,2})(?:\s*-\s*(\d{1,2}:\d{2}))?/g))
      .map((match) => ({
        date: `${match[1]}/${String(Number(match[2])).padStart(2, "0")}/${String(Number(match[3])).padStart(2, "0")}`,
        time: match[4] || ""
      }));
  }

  function smallestElementContaining(documentNode, requiredTexts) {
    const candidates = Array.from(documentNode?.querySelectorAll?.("article, section, li, tr, div") || [])
      .map((node) => ({ node, value: normalizeText(node.textContent) }))
      .filter((item) => requiredTexts.every((required) => item.value.includes(required)))
      .sort((left, right) => left.value.length - right.value.length);
    return candidates[0]?.node || null;
  }

  function extractProfile(documentNode) {
    const value = pageText(documentNode);
    const identity = value.match(/تکمیل اطلاعات\s+(.+?)\s*-\s*فرزند\s+(.+?)\s*-\s*به شماره ملی\s*[:：]?\s*([0-9]{10})/);
    const birth = value.match(/تاریخ تولد\s*[:：]?\s*(1[34]\d{2}[/.\-]\d{1,2}[/.\-]\d{1,2})/);
    const issuePlace = value.match(/محل صدور\s*[:：]?\s*([^\-\n]+?)(?:\s*-\s*تاریخ تولد|$)/);
    return {
      fullName: normalizeText(identity?.[1]),
      fatherName: normalizeText(identity?.[2]),
      nationalCode: normalizeNationalCode(identity?.[3]),
      birthDateJalali: jalaliDates(birth?.[1] || "")[0]?.date || "",
      issuePlace: normalizeText(issuePlace?.[1])
    };
  }

  function extractMobile(documentNode) {
    const value = pageText(documentNode);
    const candidates = value.match(/(?:0098|\+?98|0)?9\d{9}/g) || [];
    return candidates.map(normalizeMobile).find(Boolean) || "";
  }

  function extractMonthlyCapacity(documentNode) {
    const card = smallestElementContaining(documentNode, ["الماس رفاه", "اعتبار شما در این طرح"]);
    const value = normalizeText(card?.textContent || pageText(documentNode));
    const match = value.match(/اعتبار شما در این طرح\s*[:：]?\s*([0-9,٬،\s]+)\s*ریال/);
    return parseMoney(match?.[1]);
  }

  const COMMITMENT_LABELS = ["شرایط عمومی", "چک برگشتی", "اقساط معوق", "وضعیت حیات"];

  function inquiryCells(documentNode) {
    for (const row of documentNode?.querySelectorAll?.("tr") || []) {
      const cells = Array.from(row.querySelectorAll("td"));
      const statusIndex = cells.findIndex((cell) =>
        COMMITMENT_LABELS.every((label) => normalizeText(cell.textContent).includes(label)));
      if (statusIndex >= 0) {
        return { statusCell: cells[statusIndex], resultCell: cells[statusIndex + 1] || null };
      }
    }
    return { statusCell: null, resultCell: null };
  }

  function statusFragments(cell) {
    if (!cell) return [];
    const fragments = [];
    const breaks = Array.from(cell.querySelectorAll("br"));
    for (let index = 0; index <= breaks.length && breaks.length; index += 1) {
      const range = cell.ownerDocument.createRange();
      if (index) range.setStartAfter(breaks[index - 1]);
      else range.setStart(cell, 0);
      if (index < breaks.length) range.setEndBefore(breaks[index]);
      else range.setEnd(cell, cell.childNodes.length);
      const wrapper = cell.ownerDocument.createElement("div");
      wrapper.append(range.cloneContents());
      fragments.push(wrapper);
    }
    for (const node of cell.querySelectorAll("div, p, li, span, label")) {
      const value = normalizeText(node.textContent);
      if (COMMITMENT_LABELS.filter((label) => value.includes(label)).length === 1) fragments.push(node);
    }
    return fragments;
  }

  function statusMarker(fragment, label) {
    const value = normalizeText(fragment.textContent);
    const detail = normalizeText(value.replace(label, "").replace(/^\s*[:：]\s*/, ""));
    const markers = [fragment, ...fragment.querySelectorAll("i, svg, span, img, use, b")]
      .map((node) => ["class", "data-icon", "aria-label", "title", "style", "alt", "src", "href", "fill", "stroke"]
        .map((attribute) => node.getAttribute?.(attribute) || "").join(" ").toLowerCase())
      .join(" ");
    const negativeIcon = /[✗✘❌×]/.test(value) ||
      /fa-(?:times|close|remove|xmark|ban)|glyphicon-remove|(?:^|[\s_-])(?:bi-x|mdi-close|icon-cross|icon-remove|text-danger|text-error|text-red|is-invalid|failed|failure|danger|red)(?:$|[\s_-])|#(?:dc3545|f44336|e53935)|rgb\(\s*220\s*,\s*53\s*,\s*69/.test(markers);
    const positiveIcon = /[✓✔✅☑]/.test(value) ||
      /fa-(?:check|tick)|glyphicon-ok|(?:^|[\s_-])(?:bi-check|mdi-check|icon-check|icon-ok|text-success|text-green|is-valid|success|approved|green)(?:$|[\s_-])|#(?:28a745|198754|4caf50)|rgb\(\s*40\s*,\s*167\s*,\s*69/.test(markers);
    if (negativeIcon && !positiveIcon) return "fail";
    if (positiveIcon && !negativeIcon) return "pass";
    if (/(?:عدم\s*تأیید|عدم\s*تایید|رد\s*شده|ناموفق|نامعتبر|خیر|وجود\s*دارد)/.test(detail)) return "fail";
    if (/(?:تأیید|تایید|موفق|معتبر|بله|ندارد|عادی)/.test(detail)) return "pass";
    return "unknown";
  }

  function extractCommitmentStatuses(documentNode, eligibility) {
    const { statusCell } = inquiryCells(documentNode);
    const fragments = statusFragments(statusCell);
    const statuses = COMMITMENT_LABELS.map((label) => {
      const matches = fragments.filter((fragment) => {
        const value = normalizeText(fragment.textContent);
        return value.includes(label) && COMMITMENT_LABELS.filter((item) => value.includes(item)).length === 1;
      });
      const results = new Set(matches.map((fragment) => statusMarker(fragment, label)).filter((value) => value !== "unknown"));
      const result = results.size === 1 ? [...results][0] : "unknown";
      return { label, status: result === "pass" ? "تأیید شده" : result === "fail" ? "رد شده" : "نامشخص", result };
    });
    if (eligibility) statuses.push({ label: "نتیجه استعلامات", status: eligibility });
    return statuses;
  }

  function extractDashboard(documentNode) {
    const value = pageText(documentNode);
    const dates = jalaliDates(value);
    const inquiry = dates.find((item) => item.time) || dates[0] || {};
    const valid = dates.find((item) => item.date && item.date !== inquiry.date && !item.time) || dates[1] || {};
    const { resultCell } = inquiryCells(documentNode);
    const resultText = normalizeText(resultCell?.textContent);
    const eligibilityMatch = resultText.match(/(?:مشمول\s*طرح\s*نیست|مشمول\s*نیست|عدم\s*مشمول(?:\s*طرح)?|غیر\s*مشمول(?:\s*طرح)?|مشمول\s*طرح|مشمول)/);
    const eligibility = normalizeText(eligibilityMatch?.[0]);
    return {
      inquiryDate: inquiry.date ? `${inquiry.date}${inquiry.time ? ` - ${inquiry.time}` : ""}` : "",
      validUntil: valid.date || "",
      eligibility,
      monthlyCapacityRials: extractMonthlyCapacity(documentNode),
      commitmentStatuses: extractCommitmentStatuses(documentNode, eligibility)
    };
  }

  function extractOverdue(documentNode) {
    const value = pageText(documentNode);
    const countMatch = value.match(/([0-9]+)\s*قسط\s*معوق/);
    return {
      overdueCount: Number(countMatch?.[1]) || 0,
      overdueHeadline: value.includes("قسط سررسید شده پرداخت نشده ای ندارید") ||
        value.includes("قسط سررسید شده پرداخت نشده‌ای ندارید")
        ? "قسط سررسید شده پرداخت نشده‌ای ندارید"
        : "",
      overdueSummary: value.includes("همه اقساط شما در وضعیت عادی قرار دارند")
        ? "همه اقساط شما در وضعیت عادی قرار دارند"
        : ""
    };
  }

  function purchaseTitles(documentNode) {
    const value = pageText(documentNode);
    return value
      .split(/\n+/)
      .map(normalizeText)
      .filter((item) => item.startsWith("خرید") && !/^خریدها$/.test(item));
  }

  function extractPurchases(documentNode) {
    const activeTitles = purchaseTitles(documentNode).filter((title) => !/\(حذف شده\)/.test(title));
    return {
      golrang: activeTitles.some((title) => title.includes("گلرنگ")),
      samin: activeTitles.some((title) => title.includes("ثمین")),
      activeTitles
    };
  }

  function buildCustomerReport({ dashboard, profile, messages, overdue, purchases }) {
    return {
      identity: {
        ...extractProfile(profile),
        mobile: extractMobile(messages) || extractMobile(profile) || extractMobile(dashboard)
      },
      creditReport: {
        provider: "beta",
        ...extractDashboard(dashboard),
        ...extractOverdue(overdue),
        purchases: extractPurchases(purchases)
      }
    };
  }

  const api = {
    text,
    normalizeText,
    digits,
    normalizeMobile,
    normalizeNationalCode,
    parseMoney,
    jalaliDates,
    extractProfile,
    extractMobile,
    extractDashboard,
    extractOverdue,
    extractPurchases,
    buildCustomerReport
  };

  root.BetaCreditCore = api;
  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : this);
