(function initializeTeamChecklists(root) {
  "use strict";
  const config = () => root.DidarRelease?.teamChecklists;
  const managed = () => Boolean(config()?.publicKey && config()?.url);
  function settings(value) {
    if (typeof value?.autoCallChecklist !== "boolean" || ![3, 4].includes(value.callChecklistColumns)) throw Error("تنظیمات قالب تیم معتبر نیست.");
    const templates = {};
    for (const key of ["beforePurchase", "afterPurchase"]) {
      const items = value.callChecklistTemplates?.[key];
      if (!Array.isArray(items) || items.length > 100 || items.some(item => typeof item !== "string" || !item.trim() || item.length > 300)) throw Error("متن قالب تیم معتبر نیست.");
      templates[key] = items.map(item => item.trim());
      if (new Set(templates[key]).size !== templates[key].length) throw Error("قالب تیم گزینهٔ تکراری دارد.");
    }
    return {autoCallChecklist:value.autoCallChecklist, callChecklistColumns:value.callChecklistColumns, callChecklistTemplates:templates};
  }
  const decode = value => Uint8Array.from(atob(value), char => char.charCodeAt(0));
  async function verify(envelope, publicKey = config().publicKey) {
    if (envelope?.algorithm !== "RSA-SHA256" || typeof envelope.payload !== "string" || envelope.payload.length > 200000) throw Error("امضای قالب تیم معتبر نیست.");
    const key = await root.crypto.subtle.importKey("spki", decode(publicKey), {name:"RSASSA-PKCS1-v1_5",hash:"SHA-256"}, false, ["verify"]);
    const bytes = decode(envelope.payload);
    if (!await root.crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, decode(envelope.signature), bytes)) throw Error("امضای قالب تیم تأیید نشد.");
    const value = JSON.parse(new TextDecoder().decode(bytes));
    if (value.schemaVersion !== 1 || !Number.isSafeInteger(value.version) || value.version < 1 || !Number.isFinite(Date.parse(value.publishedAt))) throw Error("نسخهٔ قالب تیم معتبر نیست.");
    return {...value, settings:settings(value.settings)};
  }
  root.DidarTeamChecklists = {managed, settings, verify};
})(globalThis);
