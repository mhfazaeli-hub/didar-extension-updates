(function initializeEtebaritoPreview() {
  "use strict";
  const chrome = globalThis.browser || globalThis.chrome;

  if (globalThis.__didarEtebaritoContentLoaded) {
    return;
  }
  globalThis.__didarEtebaritoContentLoaded = true;

  const Core = globalThis.EtebaritoCore;
  const isOlive = location.hostname === "my.olivecredit.ir";
  const integrationLabel = isOlive ? "الیو کردیت" : "اعتباریتو";
  const DEFAULT_SETTINGS = {
    etebaritoPreviewEnabled: true,
    etebaritoKeepAliveEnabled: false
  };
  const RESULTS_EVENT = "didar-etebarito:sharing-results";
  const REPORT_EVENT = "didar-etebarito:report-pdf";
  const REPORT_REQUEST_EVENT = "didar-etebarito:request-report";
  const REPORT_REQUEST_RESULT_EVENT = "didar-etebarito:request-report-result";
  const LOOKUP_STATUS_STORAGE_KEY = "etebaritoNationalCodeStatusesV1";
  const PLAN_ORDER_STORAGE_KEY = "didarEtebaritoPlanOrderV1";
  const CONTEXT_RECOVERY_STORAGE_KEY = "didarEtebaritoContextRecoveryAt";
  const AUTH_RECOVERY_STORAGE_KEY = "didarEtebaritoAuthRecoveryAt";
  const PENDING_REPORT_STORAGE_KEY = "didarEtebaritoPendingReportV1";
  const AUTH_RECOVERY_COOLDOWN_MS = 30 * 1000;
  const PENDING_REPORT_MAX_AGE_MS = 10 * 60 * 1000;
  const MAX_STORED_LOOKUP_STATUSES = 2000;
  const MAX_CONCURRENT_ROW_REQUESTS = 2;
  const rowsByReportId = new Map();
  const preparedReports = new Map();
  const latestReportById = new Map();
  const pendingRowRequests = new Map();
  const fetchTasks = new Map();
  const previewWindows = new Map();
  const dismissedPreviewIds = new Set();
  const lookupStatuses = new Map();
  const rowRequestQueue = [];
  let planOrderSaveQueue = Promise.resolve();
  let settings = { ...DEFAULT_SETTINGS };
  let pdfLibraryPromise = null;
  let activeReport = null;
  let attachButtonTimer = null;
  let attachRowActionsTimer = null;
  let activeRowRequestCount = 0;
  let authRecoveryPending = false;
  let lastInteraction = "هنوز گزارشی دریافت نشده";

  function reportKey(value) {
    return Core.text(value);
  }

  function isInvalidExtensionContext(error) {
    return /extension context invalidated|receiving end does not exist/i.test(Core.text(error?.message || error));
  }

  function invalidContextRecoveryError() {
    const now = Date.now();
    let lastRecovery = 0;
    try {
      lastRecovery = Number(window.sessionStorage.getItem(CONTEXT_RECOVERY_STORAGE_KEY)) || 0;
      window.sessionStorage.setItem(CONTEXT_RECOVERY_STORAGE_KEY, String(now));
    } catch (_error) {
      lastRecovery = 0;
    }
    if (now - lastRecovery > 10000) {
      window.setTimeout(() => window.location.reload(), 80);
      return new Error(isOlive ? "افزونه بروزرسانی شده است؛ صفحه الیو کردیت در حال تازه‌سازی خودکار است." : "افزونه بروزرسانی شده است؛ صفحه اعتباریتو در حال تازه‌سازی خودکار است.");
    }
    return new Error(`ارتباط صفحه با افزونه تازه‌سازی نشده است؛ صفحه ${integrationLabel} را یک‌بار تازه‌سازی کنید.`);
  }

  async function sendDidarMessage(message) {
    if (isOlive) message = { ...message, payload: { ...message.payload, provider: "olive" } };
    try {
      const response=await chrome.runtime.sendMessage(message);
      if (response?.ok===false && response.diagnosticId) response.error=`${response.error} — شناسهٔ پیگیری ${response.diagnosticId}`;
      return response;
    } catch (error) {
      if (isInvalidExtensionContext(error)) {
        throw invalidContextRecoveryError();
      }
      throw error;
    }
  }

  async function loadLookupStatuses() {
    const values = await chrome.storage.local.get({ [LOOKUP_STATUS_STORAGE_KEY]: {} });
    const stored = values?.[LOOKUP_STATUS_STORAGE_KEY] || {};
    lookupStatuses.clear();
    for (const [nationalCode, status] of Object.entries(stored)) {
      if (Core.normalizeNationalCode(nationalCode) && status?.state) {
        lookupStatuses.set(nationalCode, status);
      }
    }
    scheduleRowActions();
  }

  async function rememberLookupStatus(nationalCode, state, details = {}) {
    const normalized = Core.normalizeNationalCode(nationalCode);
    if (!normalized || !state) {
      return;
    }
    lookupStatuses.set(normalized, {
      state,
      checkedAt: new Date().toISOString(),
      contactCount: Number(details.contactCount || 0),
      openDealCount: Number(details.openDealCount || 0)
    });
    const retained = Array.from(lookupStatuses.entries())
      .sort((left, right) => Core.text(right[1]?.checkedAt).localeCompare(Core.text(left[1]?.checkedAt)))
      .slice(0, MAX_STORED_LOOKUP_STATUSES);
    lookupStatuses.clear();
    retained.forEach(([key, value]) => lookupStatuses.set(key, value));
    await chrome.storage.local.set({ [LOOKUP_STATUS_STORAGE_KEY]: Object.fromEntries(retained) });
    scheduleRowActions();
  }

  function lookupStateFromResult(result) {
    if (!result?.ok) {
      return "";
    }
    return result.conflict || (result.contacts || []).length || (result.deals || result.openDeals || []).length
      ? "existing"
      : "available";
  }

  function loadPdfLibrary() {
    if (!pdfLibraryPromise) {
      pdfLibraryPromise = import(chrome.runtime.getURL("vendor/pdf.min.mjs")).then((library) => {
        library.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL("vendor/pdf.worker.min.mjs");
        return library;
      });
    }
    return pdfLibraryPromise;
  }

  function base64Bytes(value) {
    const binary = atob(value);
    const bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return bytes;
  }

  async function extractReport(base64) {
    const pdfjs = await loadPdfLibrary();
    const task = pdfjs.getDocument({ data: base64Bytes(base64) });
    const documentNode = await task.promise;
    try {
      const pages = [];
      const pageCount = Math.max(1, Number(documentNode.numPages) || 1);
      for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
        const page = await documentNode.getPage(pageNumber);
        const content = await page.getTextContent();
        pages.push({
          pageNumber,
          width: Math.abs(page.view?.[2] - page.view?.[0]) || 600,
          items: content.items.map((item) => ({
            str: item.str,
            x: item.transform?.[4] || 0,
            y: item.transform?.[5] || 0,
            width: item.width || 0
          }))
        });
      }
      return {
        ...Core.extractIdentity(pages[0]?.items || [], pages[0]?.width || 600),
        overdueContracts: Core.extractOverdueContracts(pages)
      };
    } finally {
      await documentNode.destroy();
    }
  }

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) {
      node.className = className;
    }
    if (text !== undefined) {
      node.textContent = isOlive ? String(text).replaceAll("اعتباریتو", integrationLabel) : text;
    }
    return node;
  }

  function field(labelText, input) {
    const label = element("label", "etebarito-preview__field");
    label.append(element("span", "etebarito-preview__label", labelText), input);
    return label;
  }

  function optionChecklist(labelText) {
    const wrapper = element("div", "etebarito-preview__field etebarito-preview__field--wide");
    const heading = element("div", "etebarito-preview__field-heading");
    const label = element("span", "etebarito-preview__label", labelText);
    const orderStatus = element("span", "etebarito-preview__order-status");
    orderStatus.setAttribute("role", "status");
    orderStatus.setAttribute("aria-live", "polite");
    const resetOrderButton = element("button", "etebarito-preview__order-reset", "↺");
    resetOrderButton.type = "button";
    resetOrderButton.title = "بازگرداندن ترتیب پیش‌فرض طرح‌ها";
    resetOrderButton.setAttribute("aria-label", "بازگرداندن ترتیب پیش‌فرض طرح‌ها");
    resetOrderButton.hidden = true;
    const orderButton = element("button", "etebarito-preview__order-toggle", "چیدمان");
    orderButton.type = "button";
    orderButton.title = "شخصی‌سازی ترتیب نمایش طرح‌ها";
    orderButton.setAttribute("aria-pressed", "false");
    orderButton.disabled = true;
    const orderControls = element("span", "etebarito-preview__order-controls");
    orderControls.append(orderStatus, resetOrderButton, orderButton);
    heading.append(label, orderControls);
    const options = element("div", "etebarito-preview__multi-options");
    options.setAttribute("role", "group");
    options.setAttribute("aria-label", labelText);
    options.append(element("span", "etebarito-preview__option-status", "در حال دریافت گزینه‌ها..."));
    wrapper.append(heading, options);
    return { wrapper, options, orderButton, resetOrderButton, orderStatus, ordering: false };
  }

  function checklistValues(container) {
    return Array.from(container.querySelectorAll('.etebarito-preview__multi-option input[type="checkbox"]'))
      .map((checkbox) => checkbox.value);
  }

  function syncChecklistOrderControls(container) {
    const rows = Array.from(container.querySelectorAll(".etebarito-preview__multi-option"));
    rows.forEach((row, index) => {
      const earlier = row.querySelector('[data-order-direction="earlier"]');
      const later = row.querySelector('[data-order-direction="later"]');
      if (earlier) {
        earlier.disabled = index === 0;
      }
      if (later) {
        later.disabled = index === rows.length - 1;
      }
    });
  }

  function setChecklistOrdering(container, ordering) {
    container.dataset.ordering = ordering ? "true" : "false";
    container.querySelectorAll(".etebarito-preview__multi-option").forEach((row) => {
      row.draggable = ordering;
      const checkbox = row.querySelector('input[type="checkbox"]');
      if (checkbox) {
        checkbox.disabled = ordering;
      }
    });
    syncChecklistOrderControls(container);
  }

  function moveChecklistRow(container, row, direction) {
    const sibling = direction === "earlier" ? row.previousElementSibling : row.nextElementSibling;
    if (!sibling?.classList.contains("etebarito-preview__multi-option")) {
      return false;
    }
    if (direction === "earlier") {
      container.insertBefore(row, sibling);
    } else {
      container.insertBefore(sibling, row);
    }
    syncChecklistOrderControls(container);
    return true;
  }

  function populateChecklist(container, values, options = {}) {
    const selected = new Set(options.selectedValues || selectedChecklistValues(container));
    container.replaceChildren();
    for (const value of values) {
      const label = element("label", "etebarito-preview__multi-option");
      label.dataset.value = value;
      const checkbox = input("checkbox");
      checkbox.value = value;
      checkbox.checked = selected.has(value);
      const title = element("span", "etebarito-preview__multi-option-title", value);
      const dragHandle = element("span", "etebarito-preview__drag-handle", "⋮⋮");
      dragHandle.title = "برای جابه‌جایی بکشید";
      dragHandle.setAttribute("aria-hidden", "true");
      const controls = element("span", "etebarito-preview__item-order-controls");
      const earlier = element("button", "etebarito-preview__item-order-button", "→");
      earlier.type = "button";
      earlier.dataset.orderDirection = "earlier";
      earlier.title = "انتقال به اولویت بالاتر";
      earlier.setAttribute("aria-label", `انتقال ${value} به اولویت بالاتر`);
      const later = element("button", "etebarito-preview__item-order-button", "←");
      later.type = "button";
      later.dataset.orderDirection = "later";
      later.title = "انتقال به اولویت پایین‌تر";
      later.setAttribute("aria-label", `انتقال ${value} به اولویت پایین‌تر`);
      controls.append(earlier, later);
      for (const button of [earlier, later]) {
        button.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          if (moveChecklistRow(container, label, button.dataset.orderDirection)) {
            options.onOrderChange?.(checklistValues(container));
          }
        });
      }
      label.addEventListener("dragstart", (event) => {
        if (container.dataset.ordering !== "true") {
          event.preventDefault();
          return;
        }
        label.classList.add("is-dragging");
        event.dataTransfer?.setData("text/plain", value);
        if (event.dataTransfer) {
          event.dataTransfer.effectAllowed = "move";
        }
      });
      label.addEventListener("dragover", (event) => {
        if (container.dataset.ordering === "true") {
          event.preventDefault();
        }
      });
      label.addEventListener("drop", (event) => {
        event.preventDefault();
        const sourceValue = Core.text(event.dataTransfer?.getData("text/plain"));
        const source = Array.from(container.querySelectorAll(".etebarito-preview__multi-option"))
          .find((row) => row.dataset.value === sourceValue);
        if (!source || source === label) {
          return;
        }
        const rows = Array.from(container.querySelectorAll(".etebarito-preview__multi-option"));
        const sourceIndex = rows.indexOf(source);
        const targetIndex = rows.indexOf(label);
        container.insertBefore(source, sourceIndex < targetIndex ? label.nextSibling : label);
        syncChecklistOrderControls(container);
        options.onOrderChange?.(checklistValues(container));
      });
      label.addEventListener("dragend", () => label.classList.remove("is-dragging"));
      label.append(checkbox, title, dragHandle, controls);
      container.append(label);
    }
    if (!values.length) {
      container.append(element("span", "etebarito-preview__option-status", "گزینه‌ای در دیدار تعریف نشده است."));
    }
    setChecklistOrdering(container, Boolean(options.ordering));
  }

  function selectedChecklistValues(container) {
    return Array.from(container.querySelectorAll('input[type="checkbox"]:checked'))
      .map((checkbox) => checkbox.value);
  }

  function planOrderOwnerKey(config) {
    const identity = config?.identity || {};
    const account = Core.text(identity.bizDomain).toLowerCase();
    const user = Core.text(identity.id || identity.username).toLowerCase();
    return user ? `${account}:${user}` : "";
  }

  function mergePlanTypeOrder(availableValues, preferredValues) {
    const available = Array.from(new Set((availableValues || []).map((value) => Core.text(value)).filter(Boolean)));
    const byNormalizedValue = new Map(available.map((value) => [Core.normalizeText(value), value]));
    const result = [];
    const seen = new Set();
    for (const preferred of preferredValues || []) {
      const normalized = Core.normalizeText(preferred);
      const current = byNormalizedValue.get(normalized);
      if (current && !seen.has(normalized)) {
        seen.add(normalized);
        result.push(current);
      }
    }
    for (const value of available) {
      const normalized = Core.normalizeText(value);
      if (!seen.has(normalized)) {
        seen.add(normalized);
        result.push(value);
      }
    }
    return result;
  }

  function synchronizePlanTypeOrderViews(config, values, sourceContainer = null) {
    const ownerKey = planOrderOwnerKey(config);
    if (!ownerKey) {
      return;
    }
    document.querySelectorAll(".etebarito-preview__multi-options[data-plan-order-owner]").forEach((container) => {
      if (container === sourceContainer || container.dataset.planOrderOwner !== ownerKey) {
        return;
      }
      const rows = new Map(Array.from(container.querySelectorAll(".etebarito-preview__multi-option"))
        .map((row) => [Core.normalizeText(row.dataset.value), row]));
      for (const value of values) {
        const row = rows.get(Core.normalizeText(value));
        if (row) {
          container.append(row);
          rows.delete(Core.normalizeText(value));
        }
      }
      rows.forEach((row) => container.append(row));
      syncChecklistOrderControls(container);
    });
  }

  async function personalizedPlanTypeOrder(config) {
    const ownerKey = planOrderOwnerKey(config);
    if (!ownerKey) {
      return mergePlanTypeOrder(config?.planTypeOptions, []);
    }
    const stored = await chrome.storage.local.get({ [PLAN_ORDER_STORAGE_KEY]: {} });
    return mergePlanTypeOrder(
      config?.planTypeOptions,
      stored?.[PLAN_ORDER_STORAGE_KEY]?.[ownerKey]
    );
  }

  function persistPlanTypeOrder(config, values, reset = false) {
    const ownerKey = planOrderOwnerKey(config);
    if (!ownerKey) {
      return Promise.reject(new Error("شناسه کارشناس دیدار برای ذخیره ترتیب دریافت نشد."));
    }
    planOrderSaveQueue = planOrderSaveQueue.catch(() => {}).then(async () => {
      const stored = await chrome.storage.local.get({ [PLAN_ORDER_STORAGE_KEY]: {} });
      const storedPreferences = stored?.[PLAN_ORDER_STORAGE_KEY];
      const preferences = {
        ...(storedPreferences && typeof storedPreferences === "object" && !Array.isArray(storedPreferences)
          ? storedPreferences
          : {})
      };
      if (reset) {
        delete preferences[ownerKey];
      } else {
        preferences[ownerKey] = mergePlanTypeOrder(config?.planTypeOptions, values);
      }
      await chrome.storage.local.set({ [PLAN_ORDER_STORAGE_KEY]: preferences });
    });
    return planOrderSaveQueue;
  }

  function input(type = "text") {
    const node = document.createElement("input");
    node.type = type;
    node.autocomplete = "off";
    node.spellcheck = false;
    return node;
  }

  function minimizedTray() {
    let tray = document.querySelector(".etebarito-minimized-tray");
    if (!tray) {
      tray = element("div", "etebarito-minimized-tray");
      tray.setAttribute("aria-label", "پنجره‌های کمینه‌شده واکشی دیدار");
      document.documentElement.append(tray);
    }
    return tray;
  }

  function previewWindowKey(detail) {
    return reportKey(detail?.shareReportId);
  }

  function previewLabel(key) {
    const row = rowsByReportId.get(key) || {};
    const nationalCode = Core.normalizeNationalCode(row.customerNationalCode);
    return nationalCode ? `کد ملی ${nationalCode}` : `گزارش ${key.slice(0, 8)}`;
  }

  function updateMinimizedChip(preview) {
    if (!preview) {
      return;
    }
    if (!preview.minimized) {
      preview.chip?.remove();
      preview.chip = null;
      return;
    }
    if (!preview.chip) {
      preview.chip = element("div", "etebarito-minimized-window");
      preview.restoreButton = element("button", "etebarito-minimized-window__restore");
      preview.restoreButton.type = "button";
      preview.restoreButton.addEventListener("click", () => restorePreview(preview));
      const closeButton = element("button", "etebarito-minimized-window__close", "×");
      closeButton.type = "button";
      closeButton.title = "بستن این پنجره";
      closeButton.setAttribute("aria-label", "بستن این پنجره کمینه‌شده");
      closeButton.addEventListener("click", () => closePreview(preview));
      preview.chip.append(preview.restoreButton, closeButton);
      minimizedTray().append(preview.chip);
    }
    preview.chip.className = `etebarito-minimized-window is-${preview.state}`;
    preview.restoreButton.replaceChildren(
      element("strong", "", previewLabel(preview.key)),
      element("span", "", preview.statusText)
    );
    preview.restoreButton.title = `${previewLabel(preview.key)}؛ ${preview.statusText}`;
  }

  function setPreviewStatus(preview, state, statusText) {
    if (!preview) {
      return;
    }
    preview.state = state;
    preview.statusText = isOlive ? String(statusText).replaceAll("اعتباریتو", integrationLabel) : statusText;
    preview.dialog.dataset.state = state;
    updateMinimizedChip(preview);
  }

  function minimizePreview(preview) {
    if (!preview || preview.minimized) {
      return;
    }
    preview.minimized = true;
    preview.overlay.hidden = true;
    updateMinimizedChip(preview);
  }

  function restorePreview(preview) {
    if (!preview) {
      return;
    }
    const host = preview.mountHost?.isConnected ? preview.mountHost : document.documentElement;
    if (preview.overlay.parentElement !== host) {
      host.append(preview.overlay);
    }
    for (const other of previewWindows.values()) {
      if (other !== preview && !other.minimized && other.overlay.isConnected) {
        minimizePreview(other);
      }
    }
    preview.minimized = false;
    preview.overlay.hidden = false;
    updateMinimizedChip(preview);
  }

  function closePreview(preview) {
    preview?.overlay?.remove();
    preview?.chip?.remove();
    if (preview?.key) {
      previewWindows.delete(preview.key);
      dismissedPreviewIds.add(preview.key);
    }
    const tray = document.querySelector(".etebarito-minimized-tray");
    if (tray && !tray.children.length) {
      tray.remove();
    }
  }

  function ensurePreviewWindow(detail, activate = true, mountHost = null) {
    const key = previewWindowKey(detail);
    if (!key) {
      return null;
    }
    if (dismissedPreviewIds.has(key)) {
      if (!activate) {
        return null;
      }
      dismissedPreviewIds.delete(key);
    }
    let preview = previewWindows.get(key);
    if (!preview) {
      const overlay = element("div", "etebarito-preview");
      overlay.dataset.shareReportId = key;
      const dialog = element("section", "etebarito-preview__dialog");
      dialog.setAttribute("role", "dialog");
      dialog.setAttribute("aria-modal", "true");
      const header = element("header", "etebarito-preview__header");
      const heading = element("h2", "", "پیش‌نمایش انتقال به دیدار");
      const controls = element("div", "etebarito-preview__window-controls");
      const minimizeButton = element("button", "etebarito-preview__icon-button", "−");
      minimizeButton.type = "button";
      minimizeButton.title = "کوچک‌کردن پنجره و ادامه در پس‌زمینه";
      const closeButton = element("button", "etebarito-preview__icon-button", "×");
      closeButton.type = "button";
      closeButton.title = "بستن";
      controls.append(minimizeButton, closeButton);
      header.append(heading, controls);
      const content = element("div", "etebarito-preview__content");
      dialog.append(header, content);
      overlay.append(dialog);
      preview = {
        key,
        detail,
        overlay,
        dialog,
        content,
        mountHost: mountHost?.isConnected ? mountHost : document.documentElement,
        chip: null,
        minimized: false,
        rendered: false,
        state: "fetching",
        statusText: "در حال واکشی گزارش"
      };
      minimizeButton.addEventListener("click", () => minimizePreview(preview));
      closeButton.addEventListener("click", () => closePreview(preview));
      previewWindows.set(key, preview);
      preview.mountHost.append(overlay);
    } else {
      preview.detail = detail;
      if (mountHost?.isConnected) {
        preview.mountHost = mountHost;
      }
    }
    if (activate) {
      restorePreview(preview);
    }
    return preview;
  }

  function showLoadingPreview(detail, activate = true) {
    const preview = ensurePreviewWindow(detail, activate);
    if (!preview || preview.rendered) {
      return preview;
    }
    const safety = element(
      "div",
      "etebarito-preview__safety",
      "گزارش در پس‌زمینه خوانده می‌شود؛ می‌توانید این پنجره را کوچک کنید و به کار خود ادامه دهید."
    );
    const loading = element("div", "etebarito-preview__loading", preview.statusText);
    preview.content.replaceChildren(safety, loading);
    return preview;
  }

  async function didarConfig() {
    const result = await sendDidarMessage({ type: "ETEBARITO_DIDAR_GET_CONFIG" });
    if (!result?.ok) {
      throw new Error(result?.error || "تنظیمات دیدار دریافت نشد.");
    }
    return result;
  }

  function dealStatusTitle(status) {
    return {
      Pending: "جاری",
      Lost: "ناموفق",
      Won: "موفق"
    }[Core.text(status)] || "نامشخص";
  }

  function renderLookupResult(
    container,
    result,
    onDealSelect = () => {},
    targetPipelineId = "",
    onNewDealSelect = () => {}
  ) {
    container.replaceChildren();
    if (!result?.ok) {
      container.className = "etebarito-preview__result is-error";
      container.textContent = result?.error || "بررسی دیدار انجام نشد.";
      return "error";
    }

    const contacts = result.contacts || [];
    const deals = result.deals || result.openDeals || [];
    if (result.conflict || contacts.length > 1) {
      container.className = "etebarito-preview__result is-warning";
      container.textContent = "چند تطبیق یا تطبیق متناقض پیدا شد. ثبت باید دستی بررسی شود.";
      return "warning";
    }
    if (deals.length) {
      container.className = "etebarito-preview__result is-warning";
      container.append(element("strong", "", "برای این مخاطب معاملهٔ جدید بسازید یا یکی از معاملات قبلی را برای بروزرسانی انتخاب کنید."));
      const list = element("div", "etebarito-preview__deal-list");
      const groupName = `etebarito-deal-${Date.now()}-${Math.random().toString(16).slice(2)}`;
      const selectableDeals = [];
      for (const deal of deals) {
        const statusValue = Core.text(deal.status);
        const outsideTargetPipeline = Boolean(
          targetPipelineId && Core.text(deal.pipelineId) !== Core.text(targetPipelineId)
        );
        const row = element("label", "etebarito-preview__deal-option");
        row.dataset.status = statusValue;
        const selector = document.createElement("input");
        selector.type = "radio";
        selector.name = groupName;
        selector.value = Core.text(deal.id);
        selector.disabled = !["Pending", "Lost", "Won"].includes(statusValue) ||
          outsideTargetPipeline;
        if (!selector.disabled) {
          selectableDeals.push({ selector, deal });
        }
        selector.addEventListener("change", () => {
          if (selector.checked) {
            onDealSelect(deal);
          }
        });
        const details = element("span", "etebarito-preview__deal-details");
        const link = element("a", "", deal.title || "مشاهده معامله");
        link.href = deal.url;
        link.target = "_blank";
        link.rel = "noreferrer";
        link.addEventListener("click", (event) => event.stopPropagation());
        const status = element(
          "span",
          "etebarito-preview__deal-status",
          dealStatusTitle(deal.status)
        );
        status.dataset.status = statusValue;
        details.append(link, status);
        if (outsideTargetPipeline) {
          details.append(element("small", "", "این معامله خارج از کاریز پرونده اعتباری است و قابل انتخاب نیست."));
        } else if (["Won", "Lost"].includes(statusValue)) {
          details.append(element(
            "small",
            "",
            "با تأیید بروزرسانی، این معامله باز می‌شود و جاری باقی می‌ماند."
          ));
        }
        row.append(selector, details);
        list.append(row);
      }
      if (contacts.length === 1 && result.writeEnabled !== false) {
        const row = element("label", "etebarito-preview__deal-option");
        const radio = document.createElement("input");
        radio.type = "radio"; radio.name = groupName; radio.value = "new-deal";
        radio.addEventListener("change", () => { if (radio.checked) onNewDealSelect(contacts[0], deals); });
        row.append(radio, element("strong", "", "＋ ایجاد معاملهٔ جدید برای همین مخاطب"));
        list.prepend(row);
      }
      container.append(list);
      if (deals.length === 1 && selectableDeals.length === 1) {
        selectableDeals[0].selector.checked = true;
        onDealSelect(selectableDeals[0].deal);
      }
      return "warning";
    }
    if (contacts.length) {
      container.className = "etebarito-preview__result is-warning";
      container.append(element("strong", "", "مخاطب موجود با همین کد ملی پیدا شد و معامله‌ای ندارد؛ می‌توانید برای همین مخاطب معامله ایجاد کنید."));
      if (contacts[0].url) appendRecordLink(container, "مشاهده مخاطب موجود", contacts[0].url);
      return "existing-contact";
    }
    container.className = "etebarito-preview__result is-success";
    container.textContent = "مخاطب و معامله باز پیدا نشد. پس از کنترل اطلاعات می‌توانید ثبت در پرونده اعتباری را انجام دهید.";
    return "success";
  }

  function appendRecordLink(container, title, href) {
    const link = element("a", "etebarito-preview__record-link", title);
    link.href = href;
    link.target = "_blank";
    link.rel = "noreferrer";
    container.append(link);
  }

  function renderTransferResult(container, transfer) {
    container.replaceChildren();
    if (transfer?.ok && transfer?.created) {
      container.className = "etebarito-preview__result is-success";
      container.append(element(
        "strong",
        "",
        transfer.contactReused
          ? `معامله برای مخاطب موجود در ${transfer.pipelineTitle} / ${transfer.stageTitle} ساخته و گزارش ثبت شد.`
          : `مخاطب و معامله در ${transfer.pipelineTitle} / ${transfer.stageTitle} ساخته شدند.`
      ));
      appendRecordLink(container, "مشاهده مخاطب در دیدار", transfer.contact.url);
      appendRecordLink(container, "مشاهده معامله در دیدار", transfer.deal.url);
      return "complete";
    }
    if (transfer?.partial) {
      container.className = "etebarito-preview__result is-warning";
      container.append(element("strong", "", transfer.error || "ثبت معامله کامل نشد."));
      if (transfer.contact?.url) {
        appendRecordLink(container, transfer.contactReused ? "مشاهده مخاطب موجود" : "مشاهده مخاطب ساخته‌شده", transfer.contact.url);
      }
      if (transfer.deal?.url) {
        appendRecordLink(container, "مشاهده معامله ساخته‌شده", transfer.deal.url);
      }
      return "warning";
    }
    container.className = transfer?.blocked
      ? "etebarito-preview__result is-warning"
      : "etebarito-preview__result is-error";
    container.textContent = transfer?.error || "ثبت در دیدار انجام نشد.";
    return transfer?.blocked ? "warning" : "error";
  }

  function overdueSummary(contracts, sourceReport = {}) {
    const wrapper = element(
      "section",
      "etebarito-preview__credit-summary etebarito-preview__field--wide"
    );
    wrapper.append(element("h3", "", "مبالغ سررسیدشده پرداخت‌نشده"));
    if (isOlive && sourceReport.overdueStatus === "not_provided") {
      wrapper.classList.add("is-not-provided");
      wrapper.append(element("p", "", "این گزارش با اطلاعات محدود سوابق تسهیلاتی تهیه شده و جدول مبالغ سررسیدشده را ارائه نکرده است. این وضعیت به معنی نداشتن بدهی نیست."));
      return wrapper;
    }
    if (isOlive && !contracts.length) {
      const clear = sourceReport.overdueStatus === "clear";
      wrapper.classList.toggle("is-clear", clear);
      wrapper.append(element("p", "", clear ? "در گزارش الیو کردیت، مجموع مبلغ سررسیدشدهٔ پرداخت‌نشده صفر است."
        : sourceReport.overdueStatus === "present" ? "بدهی سررسیدشده در گزارش وجود دارد؛ برای جزئیات PDF بررسی شود."
          : "وضعیت بدهی سررسیدشده به‌طور قطعی خوانده نشد؛ PDF بررسی شود."));
      return wrapper;
    }
    if (!contracts.length) {
      wrapper.classList.add("is-clear");
      wrapper.append(element(
        "p",
        "",
        "در خلاصه قراردادهای متقاضی و ضامن، مبلغ پرداخت‌نشده مثبتی پیدا نشد. در بروزرسانی، نوت رفع موارد قبلی ثبت می‌شود."
      ));
      return wrapper;
    }

    const list = element("ul", "");
    for (const contract of contracts) {
      const item = element("li", "");
      item.append(
        element("strong", "", `نقش ${contract.role}: `),
        document.createTextNode(
          `${contract.contractType}، ${contract.lender}، ${Core.formatMoney(contract.amount)} ریال`
        )
      );
      list.append(item);
    }
    wrapper.append(list);
    return wrapper;
  }

  function oliveChecksSummary(report) {
    const wrapper = element("section", "etebarito-preview__credit-summary etebarito-preview__field--wide");
    wrapper.classList.toggle("is-clear", (report.checks || []).length > 0 && report.checks.every((item) => item.status === "pass"));
    wrapper.append(element("h3", "", "نتایج بررسی گزارش الیو کردیت"));
    for (const item of report.checks || []) {
      wrapper.append(element("p", "", `${item.status === "pass" ? "✅" : item.status === "fail" ? "❌" : "؟"} ${item.label}: ${item.status === "pass" ? "فاقد سابقهٔ منفی در گزارش" : item.status === "fail" ? "در گزارش سابقه ثبت شده است" : "وضعیت قطعی خوانده نشد"}`));
      if (item.detail) wrapper.append(element("p", "", item.detail));
    }
    for (const item of report.judgments || []) wrapper.append(element("p", "", `${item.title} — تعداد: ${item.count}، مبلغ کل طبق گزارش: ${Core.formatMoney(item.amount)}`));
    return wrapper;
  }

  function renderUpdateResult(container, update) {
    container.replaceChildren();
    if (update?.ok && (update?.updated || update?.unchanged)) {
      container.className = "etebarito-preview__result is-success";
      container.append(element(
        "strong",
        "",
        update.unchanged
          ? "اطلاعات اعتبارسنجی نسبت به آخرین فعالیت تغییری نداشت؛ فعالیت تکراری ثبت نشد."
          : update.keptOpen
            ? "اطلاعات و گزارش ثبت شدند و معامله باز شد؛ وضعیت معامله جاری است."
          : update.temporarilyReopened
            ? `بروزرسانی انجام شد و معامله به وضعیت «${dealStatusTitle(update.restoredStatus)}» با زمان بسته‌شدن قبلی بازگردانده شد${update.activityCreated ? "؛ فعالیت اعتباریتو نیز ثبت شد" : ""}.`
            : update.previousRank && update.newRank && update.previousRank !== update.newRank
              ? `رتبه اعتباری از «${update.previousRank}» به «${update.newRank}» تغییر کرد${update.activityCreated ? " و فعالیت اعتباریتو ثبت شد" : ""}.`
              : update.activityUpdated
                ? "متن گزارش قبلی همین استعلام اصلاح شد؛ فعالیت تکراری ثبت نشد."
              : update.activityCreated
                ? "فعالیت تکمیل‌شده اعتباریتو در معامله ثبت شد."
                : "اطلاعات بروزرسانی شد؛ فعالیت تکراری ثبت نشد."
      ));
      if (update.deal?.url) {
        appendRecordLink(container, "مشاهده معامله بروزشده", update.deal.url);
      }
      if (update.nameCorrected || update.dealTitleUpdated) {
        container.append(element(
          "p",
          "etebarito-preview__phone-note",
          [update.nameCorrected ? "نام مخاطب" : "", update.dealTitleUpdated ? "عنوان معامله" : ""]
            .filter(Boolean).join(" و ") + " مطابق نام گزارش اصلاح شد."
        ));
      }
      if (update.phoneAdded) {
        container.append(element(
          "p",
          "etebarito-preview__phone-note",
          update.phoneField === "WorkPhone"
            ? "شماره همراه اعتباریتو به‌عنوان شماره دوم مخاطب ذخیره شد."
            : "شماره همراه اعتباریتو در مخاطب ذخیره شد."
        ));
      }
      if (update.profileFieldsAdded?.length) {
        container.append(element(
          "p",
          "etebarito-preview__phone-note",
          `تغییرات مخاطب: ${update.profileFieldsAdded.join("، ")}`
        ));
      }
      if (update.phoneWarning || update.profileWarning) {
        container.append(element(
          "p",
          "etebarito-preview__phone-warning",
          update.profileWarning || update.phoneWarning
        ));
      }
      return "complete";
    }
    container.className = update?.partial
      ? "etebarito-preview__result is-warning"
      : "etebarito-preview__result is-error";
    container.textContent = update?.error || "بروزرسانی اطلاعات انجام نشد.";
    if (update?.deal?.url) {
      appendRecordLink(container, "مشاهده معامله", update.deal.url);
    }
    return update?.partial ? "warning" : "error";
  }

  async function showPreview(detail, identity, options = {}) {
    const activate = options.activate !== false;
    const preview = ensurePreviewWindow(detail, activate, options.mountHost);
    if (!preview || preview.rendered) {
      return preview;
    }
    preview.rendered = true;
    setPreviewStatus(preview, "configuring", "در حال دریافت تنظیمات دیدار");
    const row = rowsByReportId.get(reportKey(detail.shareReportId)) || {};
    const sourceReport = isOlive ? { ...row.oliveReport, provider: "olive" } : {};

    const safety = element(
      "div",
      "etebarito-preview__safety",
      "ثبت و بروزرسانی اطلاعات پس از تطبیق کد ملی و تأیید شما در پرونده اعتباری / اعتبار سنجی اولیه انجام می‌شود. در خطای شمارهٔ تکراری، می‌توانید فقط گزارش را برای مخاطب موجود ثبت کنید؛ اطلاعات او تغییر نمی‌کند."
    );
    const form = element("form", "etebarito-preview__form");
    const nameInput = input();
    nameInput.value = Core.isNameCandidate(identity.fullName)
      ? Core.nameWithNationalCode(identity.fullName, row.customerNationalCode)
      : "";
    if (!nameInput.value) {
      nameInput.placeholder = "نام در گزارش پیدا نشد؛ پیش از ثبت بررسی کنید";
    }
    const nameField = field(nameInput.value ? "نام و نام خانوادگی (اختیاری)" : "نام و نام خانوادگی (در گزارش پیدا نشد)", nameInput);
    const nationalInput = input();
    nationalInput.readOnly = true;
    nationalInput.value = Core.normalizeNationalCode(row.customerNationalCode);
    nameInput.addEventListener("blur", () => {
      nameInput.value = Core.nameWithNationalCode(nameInput.value, nationalInput.value);
    });
    const mobileInput = input("tel");
    mobileInput.inputMode = "numeric";
    mobileInput.placeholder = "09xxxxxxxxx";
    mobileInput.value = identity.mobile || "";
    const extractedMobileLabel = identity.mobile
      ? "شماره همراه استخراج‌شده (برای ثبت مخاطب جدید الزامی)"
      : "شماره همراه (فقط برای ثبت مخاطب جدید الزامی)";
    const mobileField = field(extractedMobileLabel, mobileInput);
    const birthDateInput = input();
    birthDateInput.readOnly = true;
    birthDateInput.value = identity.birthDate || "";
    const jobSelect = document.createElement("select");
    jobSelect.append(new Option("انتخاب شغل مشتری", ""));
    const jobField = field("شغل مشتری (اختیاری)", jobSelect);
    const pipelineInput = input();
    pipelineInput.readOnly = true;
    pipelineInput.value = "در حال دریافت...";
    const scoreInput = input();
    scoreInput.readOnly = true;
    scoreInput.value = Core.text(row.creditRatingScore);
    const rankSelect = document.createElement("select");
    rankSelect.disabled = true;
    rankSelect.append(new Option("در حال دریافت گزینه‌ها...", ""));
    const sourceSelect = document.createElement("select");
    sourceSelect.disabled = true;
    sourceSelect.append(new Option("در حال دریافت گزینه‌ها...", ""));
    const customerStatusSelect = document.createElement("select");
    customerStatusSelect.disabled = true;
    customerStatusSelect.append(new Option("در حال دریافت گزینه‌ها...", ""));
    const sourceField = field("نحوه آشنایی معامله (اختیاری)", sourceSelect);
    const customerStatusField = field("مشتری جدید / قدیم (اختیاری)", customerStatusSelect);
    const customerRoleSelect = document.createElement("select");
    customerRoleSelect.dataset.fieldKey = "Field_8783_4_50";
    customerRoleSelect.append(new Option("خریدار", "خریدار"), new Option("ضامن", "ضامن"));
    customerRoleSelect.value = "خریدار";
    const syncRecommendedFields = () => {
      jobField.classList.toggle(
        "is-recommended-empty",
        !jobSelect.disabled && !jobSelect.value
      );
      sourceField.classList.toggle(
        "is-recommended-empty",
        !sourceSelect.disabled && !sourceSelect.value
      );
      customerStatusField.classList.toggle(
        "is-recommended-empty",
        !customerStatusSelect.disabled && !customerStatusSelect.value
      );
    };
    jobSelect.addEventListener("change", syncRecommendedFields);
    sourceSelect.addEventListener("change", syncRecommendedFields);
    customerStatusSelect.addEventListener("change", syncRecommendedFields);
    const planType = optionChecklist("نوع طرح (اختیاری، چندانتخابی معامله)");
    let planTypeOrder = [];
    let planOrderStatusTimer = null;
    const showPlanOrderStatus = (message, isError = false) => {
      window.clearTimeout(planOrderStatusTimer);
      planType.orderStatus.textContent = message;
      planType.orderStatus.classList.toggle("is-error", isError);
      if (message) {
        planOrderStatusTimer = window.setTimeout(() => {
          planType.orderStatus.textContent = "";
          planType.orderStatus.classList.remove("is-error");
        }, 2400);
      }
    };
    const savePlanOrder = (values) => {
      planTypeOrder = values;
      synchronizePlanTypeOrderViews(config, values, planType.options);
      showPlanOrderStatus("در حال ذخیره...");
      void persistPlanTypeOrder(config, values)
        .then(() => showPlanOrderStatus("ذخیره شد"))
        .catch((error) => showPlanOrderStatus(error.message || "ذخیره نشد", true));
    };
    const renderPlanTypeOptions = (values = planTypeOrder) => {
      planTypeOrder = values;
      populateChecklist(planType.options, planTypeOrder, {
        ordering: planType.ordering,
        onOrderChange: savePlanOrder
      });
    };
    planType.orderButton.addEventListener("click", () => {
      planType.ordering = !planType.ordering;
      planType.orderButton.textContent = planType.ordering ? "پایان چیدمان" : "چیدمان";
      planType.orderButton.setAttribute("aria-pressed", String(planType.ordering));
      planType.orderButton.classList.toggle("is-active", planType.ordering);
      planType.resetOrderButton.hidden = !planType.ordering;
      setChecklistOrdering(planType.options, planType.ordering);
    });
    planType.resetOrderButton.addEventListener("click", () => {
      if (!config) {
        return;
      }
      const selectedValues = selectedChecklistValues(planType.options);
      planTypeOrder = mergePlanTypeOrder(config.planTypeOptions, []);
      synchronizePlanTypeOrderViews(config, planTypeOrder, planType.options);
      populateChecklist(planType.options, planTypeOrder, {
        ordering: planType.ordering,
        selectedValues,
        onOrderChange: savePlanOrder
      });
      showPlanOrderStatus("در حال بازنشانی...");
      void persistPlanTypeOrder(config, [], true)
        .then(() => showPlanOrderStatus("ترتیب پیش‌فرض بازگشت"))
        .catch((error) => showPlanOrderStatus(error.message || "بازنشانی نشد", true));
    });
    const contracts = Array.isArray(identity.overdueContracts) ? identity.overdueContracts : [];

    const result = element("div", "etebarito-preview__result");
    const actions = element("div", "etebarito-preview__actions");
    const cancelButton = element("button", "etebarito-preview__secondary", "بستن");
    cancelButton.type = "button";
    cancelButton.addEventListener("click", () => closePreview(preview));
    const lookupButton = element("button", "etebarito-preview__refresh", "↻");
    lookupButton.type = "button";
    lookupButton.title = "بررسی مجدد در دیدار";
    lookupButton.setAttribute("aria-label", "بررسی مجدد در دیدار");
    const transferButton = element("button", "etebarito-preview__primary", "ثبت مخاطب و معامله در پرونده اعتباری");
    transferButton.type = "button";
    transferButton.hidden = true;
    const updateButton = element("button", "etebarito-preview__primary etebarito-preview__update", "بروزرسانی اطلاعات");
    updateButton.type = "button";
    updateButton.title = `بروزرسانی اطلاعات مشتری و ثبت گزارش ${integrationLabel} در دیدار`;
    updateButton.setAttribute("aria-label", "بروزرسانی اطلاعات مشتری در دیدار");
    updateButton.hidden = true;
    const reportOnlyButton = element("button", "etebarito-preview__primary etebarito-preview__report-only", "ثبت فقط گزارش اعتباریتو برای مخاطب انتخاب‌شده");
    reportOnlyButton.type = "button";
    reportOnlyButton.hidden = true;
    reportOnlyButton.disabled = true;
    const phoneConflict = element("div", "etebarito-preview__mobile-conflict etebarito-preview__result is-warning");
    phoneConflict.hidden = true;
    actions.append(cancelButton, lookupButton, transferButton, updateButton, reportOnlyButton);

    form.append(
      result,
      phoneConflict,
      nameField,
      field("کد ملی", nationalInput),
      mobileField,
      field("تاریخ تولد شمسی (اختیاری)", birthDateInput),
      jobField,
      field("مقصد آزمایشی", pipelineInput),
      field("امتیاز اعتباری", scoreInput),
      field("رتبه اعتباری معامله (اختیاری)", rankSelect),
      sourceField,
      customerStatusField,
      field("نقش مشتری در معامله", customerRoleSelect),
      planType.wrapper,
      overdueSummary(contracts, sourceReport),
      ...(isOlive ? [oliveChecksSummary(sourceReport)] : []),
      actions
    );
    preview.content.replaceChildren(safety, form);

    let config = null;
    let approvedNationalCode = "";
    let approvedExistingContactId = "";
    let approvedNewDealIds = null;
    let approvedUpdate = null;
    let approvedMobileReport = null;
    let mobileConflictSequence = 0;
    let reportOnlySaving = false;

    const resetMobileConflict = () => {
      mobileConflictSequence += 1;
      approvedMobileReport = null;
      phoneConflict.replaceChildren();
      phoneConflict.hidden = true;
      reportOnlyButton.hidden = true;
      reportOnlyButton.disabled = true;
    };
    mobileInput.addEventListener("input", () => {
      resetMobileConflict();
      transferButton.hidden = !approvedNationalCode;
      updateButton.hidden = !approvedUpdate;
    });

    const offerMobileConflict = async (failure) => {
      if (!/duplicate\s+contacts?|تکراری.*(?:مخاطب|کانتکت)|(?:مخاطب|کانتکت|شماره).*تکراری/i.test(Core.text(failure?.error || failure?.message))) return false;
      const mobile = Core.normalizeMobile(mobileInput.value);
      if (!mobile) return false;
      resetMobileConflict();
      const sequence = mobileConflictSequence;
      phoneConflict.hidden = false;
      phoneConflict.textContent = "در حال یافتن مخاطب و معامله‌های متصل به این شماره همراه...";
      transferButton.hidden = true;
      updateButton.hidden = true;
      try {
        const matches = await sendDidarMessage({ type: "ETEBARITO_DIDAR_MOBILE_LOOKUP", payload: { mobile } });
        if (sequence !== mobileConflictSequence || mobile !== Core.normalizeMobile(mobileInput.value)) return false;
        phoneConflict.replaceChildren();
        if (!matches.ok || !(matches.contacts || []).length) {
          phoneConflict.textContent = matches.error || "برای این شماره، مخاطب قابل مشاهده پیدا نشد؛ شماره و دسترسی به مخاطب را بررسی کنید.";
          return true;
        }
        phoneConflict.append(element("strong", "", "این شماره به مخاطب موجود متصل است؛ مقصد ثبت فقط گزارش اعتباریتو را انتخاب کنید."));
        phoneConflict.append(element("p", "", `صاحب گزارش: ${Core.nameWithNationalCode(identity.fullName, nationalInput.value)}. نام، کد ملی، شماره همراه، رتبه و سایر اطلاعات مخاطب و معامله تغییر نمی‌کنند.`));
        const groupName = `mobile-report-${Date.now()}-${sequence}`;
        const list = element("div", "etebarito-preview__deal-list");
        for (const contact of matches.contacts) {
          const heading = element("div", "etebarito-preview__mobile-contact");
          appendRecordLink(heading, contact.displayName || "مشاهده مخاطب", contact.url);
          heading.append(element("small", "", [contact.nationalCode && `کد ملی ${contact.nationalCode}`, `شماره ${mobile}`].filter(Boolean).join(" · ")));
          list.append(heading);
          const deals = (matches.deals || []).filter((deal) => Core.text(deal.contactId).toLowerCase() === Core.text(contact.id).toLowerCase());
          for (const deal of deals.length ? deals : [null]) {
            const option = element("label", "etebarito-preview__deal-option");
            if (deal) option.dataset.status = deal.status;
            const radio = input("radio");
            radio.name = groupName;
            radio.value = `${contact.id}:${deal?.id || ""}`;
            const caption = element("span", "etebarito-preview__deal-details");
            if (deal) {
              const link = element("a", "", deal.title || "مشاهده معامله");
              link.href = deal.url;
              link.target = "_blank";
              link.rel = "noreferrer";
              link.addEventListener("click", (event) => event.stopPropagation());
              caption.append(link, element("span", "etebarito-preview__deal-status", dealStatusTitle(deal.status)));
              if (deal.code) caption.append(element("small", "", `کد معامله ${deal.code}`));
            } else {
              caption.textContent = "این مخاطب معامله ندارد؛ گزارش فقط در فعالیت‌های خود مخاطب ثبت شود.";
            }
            radio.addEventListener("change", () => {
              if (!radio.checked || reportOnlySaving) return;
              approvedMobileReport = { mobile, contactId: contact.id, contactName: contact.displayName, dealId: deal?.id || "", dealTitle: deal?.title || "" };
              reportOnlyButton.disabled = false;
            });
            option.append(radio, caption);
            list.append(option);
          }
        }
        phoneConflict.append(list);
        reportOnlyButton.hidden = false;
        setPreviewStatus(preview, "warning", "شماره تکراری؛ مقصد ثبت فقط گزارش را انتخاب کنید");
        return true;
      } catch (error) {
        if (sequence === mobileConflictSequence) phoneConflict.textContent = `بررسی صاحب شماره ناموفق بود: ${error.message}`;
        return true;
      }
    };

    reportOnlyButton.addEventListener("click", async () => {
      const selection = approvedMobileReport;
      if (reportOnlySaving || !selection || selection.mobile !== Core.normalizeMobile(mobileInput.value)) return;
      const confirmed = window.confirm(`گزارش ${integrationLabel} متعلق به «${Core.nameWithNationalCode(identity.fullName, nationalInput.value)}» فقط به‌صورت فعالیت برای مخاطب «${selection.contactName}»${selection.dealId ? ` در «${selection.dealTitle}»` : "، بدون معامله"} ثبت شود؟ اطلاعات مخاطب و معامله تغییر نمی‌کنند.`);
      if (!confirmed) return;
      reportOnlySaving = true;
      [reportOnlyButton, lookupButton, transferButton, updateButton, mobileInput].forEach((control) => { control.disabled = true; });
      phoneConflict.querySelectorAll('input[type="radio"]').forEach((radio) => { radio.disabled = true; });
      result.className = "etebarito-preview__result is-loading";
      result.textContent = `در حال ثبت فقط گزارش ${integrationLabel}...`;
      try {
        const response = await sendDidarMessage({
          type: "ETEBARITO_DIDAR_APPEND_MOBILE_REPORT",
          payload: {
            confirmReportOnly: true,
            mobile: selection.mobile,
            approvedContactId: selection.contactId,
            approvedDealId: selection.dealId,
            reportSubject: { fullName: Core.normalizeText(identity.fullName), nationalCode: Core.normalizeNationalCode(nationalInput.value) },
            creditReport: { ...sourceReport, reportUniqCode: Core.digits(row.reportUniqCode), creditScore: Core.text(row.creditRatingScore), creditRank: Core.normalizeText(row.creditRank), overdueContracts: contracts }
          }
        });
        if (!response.ok) throw new Error(response.error || "ثبت گزارش انجام نشد.");
        result.className = "etebarito-preview__result is-success";
        result.replaceChildren(element("strong", "", response.activitySkipped ? "این گزارش قبلاً برای همین مقصد ثبت شده است." : "گزارش اعتباریتو به‌صورت فعالیت ثبت شد؛ اطلاعات مخاطب و معامله تغییر نکردند."));
        appendRecordLink(result, "مشاهده مخاطب در دیدار", response.contact.url);
        if (response.deal) appendRecordLink(result, "مشاهده معامله در دیدار", response.deal.url);
        resetMobileConflict();
        setPreviewStatus(preview, "complete", "ثبت فقط گزارش اعتباریتو انجام شد");
      } catch (error) {
        result.className = "etebarito-preview__result is-error";
        result.textContent = error.message;
        setPreviewStatus(preview, "error", "ثبت گزارش تأیید نشد");
      } finally {
        reportOnlySaving = false;
        [lookupButton, transferButton, updateButton, mobileInput].forEach((control) => { control.disabled = false; });
        phoneConflict.querySelectorAll('input[type="radio"]').forEach((radio) => { radio.disabled = false; });
        reportOnlyButton.disabled = !approvedMobileReport;
      }
    });

    const preparedPayload = () => ({
      nationalCode: Core.normalizeNationalCode(nationalInput.value),
      fullName: Core.nameWithoutIdentifier(nameInput.value),
      sourceContactFields: {
        fullName: Core.isNameCandidate(identity.fullName) ? Core.normalizeText(identity.fullName) : "",
        nationalCode: Core.normalizeNationalCode(nationalInput.value),
        birthDateJalali: Core.text(identity.birthDate),
        mobile: isOlive ? Core.normalizeMobile(mobileInput.value) : approvedUpdate
          ? (Core.normalizeMobile(approvedUpdate.didarMobile) || Core.normalizeMobile(mobileInput.value))
          : Core.normalizeMobile(identity.mobile)
      },
      preparedContactFields: {
        birthDateJalali: Core.text(birthDateInput.value),
        mobile: Core.normalizeMobile(mobileInput.value),
        job: jobSelect.value
      },
      preparedDealSourceId: sourceSelect.value,
      preparedDealFields: {
        [config?.planTypeFieldKey || "Field_8783_9_4"]: selectedChecklistValues(planType.options),
        [config?.creditRankFieldKey || "Field_8783_4_49"]: rankSelect.value,
        [config?.customerStatusFieldKey || "Field_8783_4_12"]: customerStatusSelect.value,
        [config?.customerRoleFieldKey || "Field_8783_4_50"]: customerRoleSelect.value
      },
      creditReport: {
        ...sourceReport,
        reportUniqCode: Core.digits(row.reportUniqCode),
        creditScore: Core.text(row.creditRatingScore),
        creditRank: Core.normalizeText(rankSelect.value || row.creditRank),
        overdueContracts: contracts
      }
    });

    const validatePreparedPayload = (payload, requireMobile = false) => {
      if (!payload.nationalCode) {
        return "کد ملی ده‌رقمی معتبر در گزارش پیدا نشد.";
      }
      if (payload.fullName && (
        !Core.isNameCandidate(payload.fullName) ||
        (identity.fatherName && Core.normalizeText(payload.fullName) === Core.normalizeText(identity.fatherName))
      )) {
        return "نام و نام خانوادگی معتبر مشتری را وارد کنید؛ نام پدر یا عنوان فیلد پذیرفته نمی‌شود.";
      }
      if (requireMobile && !/^09\d{9}$/.test(payload.preparedContactFields.mobile)) {
        return "شماره همراه معتبر یازده‌رقمی وارد کنید.";
      }
      return "";
    };

    try {
      config = await didarConfig();
      if (config.customerRoleFieldKey !== "Field_8783_4_50" ||
          !["خریدار", "ضامن"].every((role) => config.customerRoleOptions?.includes(role))) {
        throw new Error("تنظیمات نقش مشتری دریافت نشد؛ افزونه را بروزرسانی و تب دیدار را تازه‌سازی کنید.");
      }
      for (const option of config.jobOptions || []) {
        jobSelect.append(new Option(option, option));
      }
      rankSelect.replaceChildren(new Option("انتخاب رتبه اعتباری", ""));
      for (const option of config.creditRankOptions || []) {
        rankSelect.append(new Option(option, option));
      }
      const extractedRank = Core.normalizeText(row.creditRank);
      const matchingRank = (config.creditRankOptions || []).find(
        (option) => Core.normalizeText(option) === extractedRank
      );
      if (matchingRank) {
        rankSelect.value = matchingRank;
      }
      rankSelect.disabled = false;
      if (config.sourceOptionsAvailable === false) {
        sourceSelect.replaceChildren(new Option("دسترسی دریافت گزینه‌ها وجود ندارد", ""));
        sourceSelect.disabled = true;
      } else {
        sourceSelect.replaceChildren(new Option("انتخاب نحوه آشنایی", ""));
        for (const source of config.sourceOptions || []) {
          sourceSelect.append(new Option(source.title, source.id));
        }
        sourceSelect.disabled = false;
      }
      customerStatusSelect.replaceChildren(new Option("انتخاب وضعیت مشتری", ""));
      for (const option of config.customerStatusOptions || []) {
        customerStatusSelect.append(new Option(option, option));
      }
      customerStatusSelect.disabled = false;
      syncRecommendedFields();
      try {
        planTypeOrder = await personalizedPlanTypeOrder(config);
      } catch (_error) {
        planTypeOrder = mergePlanTypeOrder(config.planTypeOptions, []);
        showPlanOrderStatus("ترتیب ذخیره‌شده خوانده نشد", true);
      }
      renderPlanTypeOptions();
      planType.options.dataset.planOrderOwner = planOrderOwnerKey(config);
      planType.orderButton.disabled = false;
      pipelineInput.value = `${config.pipelineTitle} / ${config.stageTitle}`;
      setPreviewStatus(
        preview,
        "ready",
        config.warnings?.length ? "آماده بررسی؛ نحوه آشنایی محدود است" : "آماده بررسی خودکار"
      );
    } catch (error) {
      pipelineInput.value = "اتصال به دیدار برقرار نیست";
      result.className = "etebarito-preview__result is-error";
      result.textContent = error.message;
      setPreviewStatus(preview, "error", "دریافت تنظیمات دیدار ناموفق بود");
    }

    const applyExistingContact = (contact) => {
      if (!contact) {
        return;
      }
      const contactName = Core.nameWithoutIdentifier(contact.fullName);
      const contactIsFather = identity.fatherName &&
        Core.normalizeText(contactName) === Core.normalizeText(identity.fatherName);
      const reportNameValid = Core.isNameCandidate(identity.fullName);
      const contactNameValid = Core.isNameCandidate(contactName) && !contactIsFather;
      if (reportNameValid && (!contactNameValid || Core.normalizeText(contactName) !== Core.normalizeText(identity.fullName))) {
        nameInput.value = Core.nameWithNationalCode(identity.fullName, nationalInput.value);
        nameField.querySelector(".etebarito-preview__label").textContent =
          "نام و نام خانوادگی (از گزارش؛ با نام مخاطب دیدار مغایرت دارد)";
      } else if (contactNameValid) {
        nameInput.value = Core.nameWithNationalCode(contact.fullName, nationalInput.value);
        nameField.querySelector(".etebarito-preview__label").textContent = "نام و نام خانوادگی (ثبت‌شده در دیدار)";
      } else if (contactIsFather) {
        nameInput.value = "";
        nameField.querySelector(".etebarito-preview__label").textContent =
          "نام و نام خانوادگی (نام پدر در دیدار ثبت شده؛ نام مشتری را بررسی کنید)";
      }
      const didarMobile = Core.normalizeMobile(contact.mobilePhone || contact.workPhone);
      mobileInput.value = isOlive ? Core.text(mobileInput.value) || Core.normalizeMobile(identity.mobile) || didarMobile
        : didarMobile || Core.text(mobileInput.value) || Core.normalizeMobile(identity.mobile);
      mobileInput.readOnly = !isOlive && Boolean(didarMobile);
      mobileField.querySelector(".etebarito-preview__label").textContent =
        isOlive ? "شماره همراه (قابل ویرایش و جایگزینی)" : didarMobile ? "شماره همراه ثبت‌شده در دیدار" : "شماره همراه مخاطب در دیدار ثبت نشده؛ می‌توانید وارد کنید";
      if (contact.birthDateJalali && (!isOlive || !identity.birthDate)) {
        birthDateInput.value = contact.birthDateJalali || "";
      }
      if (contact.job && Array.from(jobSelect.options).some((option) => option.value === contact.job)) {
        jobSelect.value = contact.job;
      }
      syncRecommendedFields();
      return didarMobile;
    };

    const applyExistingDeal = (deal) => {
      customerRoleSelect.value = Array.from(customerRoleSelect.options).some((option) => option.value === deal.customerRole)
        ? deal.customerRole : "خریدار";
      if (
        !Core.normalizeText(row.creditRank) &&
        deal.rank &&
        Array.from(rankSelect.options).some((option) => option.value === deal.rank)
      ) {
        rankSelect.value = deal.rank;
      }
      if (Array.from(sourceSelect.options).some((option) => option.value === deal.sourceId)) {
        sourceSelect.value = deal.sourceId;
      }
      if (Array.from(customerStatusSelect.options).some(
        (option) => option.value === deal.customerStatus
      )) {
        customerStatusSelect.value = deal.customerStatus;
      }
      const selectedPlans = new Set(deal.planTypes || []);
      planType.options.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
        checkbox.checked = selectedPlans.has(checkbox.value);
      });
      syncRecommendedFields();
    };

    const runLookup = async () => {
      resetMobileConflict();
      nameInput.value = Core.nameWithNationalCode(nameInput.value, nationalInput.value);
      const payload = preparedPayload();
      if (!payload.nationalCode) {
        result.className = "etebarito-preview__result is-error";
        result.textContent = "کد ملی ده‌رقمی معتبر در گزارش پیدا نشد.";
        return;
      }
      approvedNationalCode = "";
      approvedExistingContactId = "";
      approvedNewDealIds = null;
      approvedUpdate = null;
      const enteredMobile = Core.text(mobileInput.value);
      mobileInput.readOnly = false;
      mobileInput.value = enteredMobile || identity.mobile || "";
      mobileField.querySelector(".etebarito-preview__label").textContent = extractedMobileLabel;
      transferButton.hidden = true;
      updateButton.hidden = true;
      lookupButton.disabled = true;
      result.className = "etebarito-preview__result is-loading";
      result.textContent = "در حال بررسی کد ملی در کانتکت‌ها و معاملات باز...";
      setPreviewStatus(preview, "checking", "در حال بررسی تکراری‌ها");
      try {
        const lookup = await sendDidarMessage({
          type: "ETEBARITO_DIDAR_LOOKUP",
          payload
        });
        if ((lookup.contacts || []).length === 1) {
          applyExistingContact(lookup.contacts[0]);
        }
        const lookupState = renderLookupResult(
          result,
          lookup,
          (deal) => {
            approvedNewDealIds = null;
            approvedNationalCode = "";
            approvedExistingContactId = "";
            transferButton.hidden = true;
            const contact = (lookup.contacts || []).find(
              (item) => Core.text(item.id) === Core.text(deal.contactId)
            ) || (lookup.contacts || [])[0];
            const didarMobile = applyExistingContact(contact);
            applyExistingDeal(deal);
            approvedUpdate = {
              nationalCode: payload.nationalCode,
              dealId: deal.id,
              status: deal.status,
              didarMobile
            };
            updateButton.textContent = ["Lost", "Won"].includes(deal.status)
              ? "بروزرسانی و بازکردن معامله"
              : "بروزرسانی اطلاعات";
            updateButton.hidden = false;
          },
          config?.pipelineId,
          (contact, deals) => {
            if (config?.writeEnabled === false) return;
            applyExistingContact(contact);
            approvedUpdate = null; updateButton.hidden = true;
            approvedNationalCode = payload.nationalCode;
            approvedExistingContactId = Core.text(contact.id);
            approvedNewDealIds = deals.map((deal) => Core.text(deal.id));
            transferButton.textContent = "ایجاد معاملهٔ جدید برای همین مخاطب";
            transferButton.hidden = false;
          }
        );
        const storedState = lookupStateFromResult(lookup);
        if (lookup.diagnosticId) result.append(element("small", "etebarito-preview__tracking", `شناسهٔ پیگیری ${lookup.diagnosticId}`));
        if (storedState) {
          await rememberLookupStatus(payload.nationalCode, storedState, {
            contactCount: (lookup.contacts || []).length,
            openDealCount: (lookup.openDeals || []).length,
            dealCount: (lookup.deals || []).length
          });
        }
        if (["success", "existing-contact"].includes(lookupState) && lookup.writeEnabled !== false && config?.writeEnabled !== false) {
          approvedNationalCode = payload.nationalCode;
          approvedExistingContactId = lookupState === "existing-contact" ? Core.text(lookup.contacts[0].id) : "";
          transferButton.textContent = approvedExistingContactId ? "ایجاد معامله برای مخاطب موجود" : "ثبت مخاطب و معامله در پرونده اعتباری";
          transferButton.hidden = false;
        }
        setPreviewStatus(
          preview,
          ["success", "existing-contact"].includes(lookupState) ? "complete" : lookupState,
          ["success", "existing-contact"].includes(lookupState)
            ? "بررسی تمام شد؛ نتیجه آماده است"
            : lookupState === "warning"
              ? "بررسی تمام شد؛ مورد قابل توجه پیدا شد"
              : "بررسی تکراری‌ها ناموفق بود"
        );
        lastInteraction = "بررسی تکراری‌ها انجام شد";
      } catch (error) {
        renderLookupResult(result, { ok: false, error: error.message });
        setPreviewStatus(preview, "error", "بررسی تکراری‌ها ناموفق بود");
      } finally {
        lookupButton.disabled = false;
      }
    };

    lookupButton.addEventListener("click", () => void runLookup());

    transferButton.addEventListener("click", async () => {
      const payload = preparedPayload();
      if (approvedExistingContactId) payload.approvedContactId = approvedExistingContactId;
      if (approvedNewDealIds) { payload.confirmNewDeal = true; payload.approvedExistingDealIds = approvedNewDealIds; }
      const validationError = validatePreparedPayload(payload, !approvedExistingContactId) ||
        (approvedExistingContactId && Core.text(mobileInput.value) && !payload.preparedContactFields.mobile ? "شماره همراه معتبر یازده‌رقمی وارد کنید." : "");
      if (validationError) {
        result.className = "etebarito-preview__result is-error";
        result.textContent = validationError;
        if (validationError.includes("شماره همراه")) {
          mobileInput.readOnly = false;
          mobileInput.focus();
        }
        return;
      }
      if (!approvedNationalCode || payload.nationalCode !== approvedNationalCode) {
        transferButton.hidden = true;
        result.className = "etebarito-preview__result is-warning";
        result.textContent = "اطلاعات تغییر کرده است؛ بررسی تکراری‌ها را دوباره انجام دهید.";
        return;
      }
      const confirmed = window.confirm(
        approvedExistingContactId
          ? `برای مخاطب موجود «${[payload.fullName, payload.nationalCode].filter(Boolean).join(" ")}» یک معامله در پرونده اعتباری / اعتبار سنجی اولیه با اطلاعات و گزارش جدید ایجاد شود؟`
          : `مخاطب «${[payload.fullName, payload.nationalCode].filter(Boolean).join(" ")}» و یک معامله باز در پرونده اعتباری / اعتبار سنجی اولیه ساخته شود؟`
      );
      if (!confirmed) {
        return;
      }

      lookupButton.disabled = true;
      transferButton.disabled = true;
      result.className = "etebarito-preview__result is-loading";
      result.textContent = approvedExistingContactId ? "در حال ایجاد معامله و ثبت گزارش برای مخاطب موجود..." : "در حال بررسی نهایی و ثبت مخاطب و معامله در پرونده اعتباری...";
      setPreviewStatus(preview, "checking", "در حال ثبت در پرونده اعتباری");
      try {
        const transfer = await sendDidarMessage({
          type: "ETEBARITO_DIDAR_TRANSFER",
          payload
        });
        let transferState = renderTransferResult(result, transfer);
        if (!transfer.ok && await offerMobileConflict(transfer)) transferState = "warning";
        if (transferState === "complete") {
          await rememberLookupStatus(payload.nationalCode, transfer.contactReused ? "existing" : "created", {
            contactCount: 1,
            openDealCount: 1
          });
        } else if (transfer?.blocked) {
          await rememberLookupStatus(payload.nationalCode, "existing", {
            contactCount: (transfer.contacts || []).length,
            openDealCount: (transfer.openDeals || []).length
          });
        } else if (transfer?.partial) {
          await rememberLookupStatus(payload.nationalCode, "partial", { contactCount: 1 });
        }
        setPreviewStatus(
          preview,
          transferState,
          transferState === "complete"
            ? "ثبت مخاطب و معامله انجام شد"
            : transferState === "warning"
              ? "ثبت نیازمند بررسی است"
              : "ثبت در دیدار ناموفق بود"
        );
        if (transferState === "complete" || transfer?.partial || transfer?.blocked) {
          approvedNationalCode = "";
          transferButton.hidden = true;
        }
      } catch (error) {
        renderTransferResult(result, { ok: false, error: error.message });
        const offered = await offerMobileConflict(error);
        setPreviewStatus(preview, offered ? "warning" : "error", offered ? "شماره تکراری؛ مقصد گزارش را بررسی کنید" : "ثبت در دیدار ناموفق بود");
      } finally {
        lookupButton.disabled = false;
        transferButton.disabled = false;
      }
    });

    updateButton.addEventListener("click", async () => {
      const payload = preparedPayload();
      const validationError = validatePreparedPayload(payload);
      if (validationError) {
        result.className = "etebarito-preview__result is-error";
        result.textContent = validationError;
        return;
      }
      if (
        !approvedUpdate ||
        approvedUpdate.nationalCode !== payload.nationalCode
      ) {
        updateButton.hidden = true;
        result.className = "etebarito-preview__result is-warning";
        result.textContent = "تطبیق قبلی معتبر نیست؛ ابتدا دکمه بررسی مجدد را بزنید.";
        return;
      }
      const nameCorrectionClause = payload.fullName
        ? `نام مخاطب و عنوان معامله در صورت مغایرت با «${Core.nameWithNationalCode(payload.fullName, payload.nationalCode)}» اصلاح شوند، `
        : "";
      const oliveProfileClause = isOlive ? `شمارهٔ همراه انتخاب‌شده${identity.birthDate ? ` و تاریخ تولد ${identity.birthDate} از پروفایل الیو` : ""} در مخاطب ثبت شوند، ` : "";
      const confirmed = window.confirm(
        ["Lost", "Won"].includes(approvedUpdate.status)
          ? `این معامله ${dealStatusTitle(approvedUpdate.status)} باز شود و جاری بماند، ${nameCorrectionClause}${oliveProfileClause}اطلاعات و گزارش بروزرسانی شوند؟`
          : `${nameCorrectionClause}${oliveProfileClause}اطلاعات بروزرسانی و گزارش در یک فعالیت تکمیل‌شده ${integrationLabel} ثبت شود؟`
      );
      if (!confirmed) {
        return;
      }

      lookupButton.disabled = true;
      updateButton.disabled = true;
      transferButton.disabled = true;
      result.className = "etebarito-preview__result is-loading";
      result.textContent = `در حال بروزرسانی اطلاعات و ثبت فعالیت ${integrationLabel}...`;
      setPreviewStatus(preview, "checking", "در حال بروزرسانی اطلاعات");
      try {
        const update = await sendDidarMessage({
          type: "ETEBARITO_DIDAR_UPDATE",
          payload: {
            ...payload,
            approvedDealId: approvedUpdate.dealId,
            approvedDealStatus: approvedUpdate.status,
            keepDealOpen: ["Lost", "Won"].includes(approvedUpdate.status)
          }
        });
        let updateState = renderUpdateResult(result, update);
        if (!update.ok && await offerMobileConflict(update)) updateState = "warning";
        setPreviewStatus(
          preview,
          updateState,
          updateState === "complete"
            ? "بروزرسانی و ثبت فعالیت اعتباریتو انجام شد"
            : updateState === "warning"
              ? "بروزرسانی نیازمند بررسی است"
              : "بروزرسانی اطلاعات ناموفق بود"
        );
        if (updateState === "complete") {
          await rememberLookupStatus(payload.nationalCode, "existing", {
            contactCount: 1,
            openDealCount: update.restoredStatus === "Pending" ? 1 : 0
          });
        }
        approvedUpdate = null;
        updateButton.hidden = true;
      } catch (error) {
        renderUpdateResult(result, { ok: false, error: error.message });
        const offered = await offerMobileConflict(error);
        setPreviewStatus(preview, offered ? "warning" : "error", offered ? "شماره تکراری؛ مقصد گزارش را بررسی کنید" : "بروزرسانی اطلاعات ناموفق بود");
      } finally {
        lookupButton.disabled = false;
        updateButton.disabled = false;
        transferButton.disabled = false;
      }
    });

    if (config && nationalInput.value) {
      void runLookup();
    }

    if (activate && !preview.minimized) {
      lookupButton.focus();
    }
    return preview;
  }

  function findNativeDownloadButton() {
    return Array.from(document.querySelectorAll("button, a")).find((candidate) => {
      const title = Core.normalizeText(candidate.textContent);
      return title === "دانلود گزارش" || title.includes("دانلود گزارش");
    });
  }

  function rowCandidates() {
    return Array.from(document.querySelectorAll("tbody tr, [role='row']")).filter((row) =>
      row.querySelector("td, [role='cell']") && !row.closest("thead")
    );
  }

  function rowMatchesReport(domRow, reportRow) {
    const rowDigits = Core.digits(domRow.textContent);
    const uniqueCode = Core.digits(reportRow?.reportUniqCode);
    if (uniqueCode && rowDigits.includes(uniqueCode)) {
      return true;
    }
    const nationalCode = Core.normalizeNationalCode(reportRow?.customerNationalCode);
    const rank = Core.normalizeText(reportRow?.creditRank);
    return Boolean(
      nationalCode &&
      rowDigits.includes(nationalCode) &&
      (!rank || Core.normalizeText(domRow.textContent).includes(rank))
    );
  }

  function actionCellForRow(domRow) {
    const cells = Array.from(domRow.querySelectorAll(":scope > td, :scope > [role='cell']"));
    return cells.find((cell) =>
      !Core.normalizeText(cell.textContent) && cell.querySelector("button, a, svg, i")
    ) || cells.at(-1) || null;
  }

  function decorateRowLookupStatus(domRow, actionCell, reportRow) {
    const nationalCode = Core.normalizeNationalCode(reportRow?.customerNationalCode);
    const status = lookupStatuses.get(nationalCode);
    const lookupClasses = [
      "etebarito-row--didar-existing",
      "etebarito-row--didar-created",
      "etebarito-row--didar-available",
      "etebarito-row--didar-partial"
    ];
    const desiredClass = ["existing", "created", "available", "partial"].includes(status?.state)
      ? `etebarito-row--didar-${status.state}`
      : "";
    lookupClasses.forEach((className) => {
      if (className !== desiredClass && domRow.classList.contains(className)) {
        domRow.classList.remove(className);
      }
    });
    const cells = Array.from(domRow.querySelectorAll(":scope > td, :scope > [role='cell']"));
    cells.forEach((cell) => {
      if (desiredClass) {
        const desiredState = Core.text(status.state);
        if (cell.dataset.didarLookupState !== desiredState) {
          cell.dataset.didarLookupState = desiredState;
        }
      } else if (cell.dataset.didarLookupState) {
        delete cell.dataset.didarLookupState;
      }
    });
    actionCell.querySelector(".etebarito-row-didar-status")?.remove();
    if (!desiredClass) {
      return;
    }
    if (!domRow.classList.contains(desiredClass)) {
      domRow.classList.add(desiredClass);
    }
    domRow.title = status.checkedAt
      ? `آخرین بررسی ذخیره‌شده: ${new Date(status.checkedAt).toLocaleString("fa-IR")}`
      : "وضعیت تطبیق دیدار";
  }

  function setRowButtonState(button, state, title = "") {
    button.dataset.state = state;
    button.classList.toggle("is-error", state === "error");
    button.classList.toggle("is-ready", state === "ready");
    const labels = {
      queued: "در صف واکشی",
      loading: "در حال واکشی...",
      parsing: "در حال خواندن...",
      ready: "مشاهده نتیجه",
      error: "خطای واکشی",
      idle: "واکشی دیدار"
    };
    const text = labels[state] || labels.idle;
    if (button.textContent !== text) {
      button.textContent = text;
    }
    button.disabled = ["queued", "loading", "parsing"].includes(state);
    button.title = title || "واکشی مستقیم اطلاعات همین فرد برای بررسی و انتقال به دیدار";
  }

  function syncTaskRowButtons(shareReportId) {
    const key = reportKey(shareReportId);
    const task = fetchTasks.get(key);
    document.querySelectorAll(".etebarito-row-fetch").forEach((button) => {
      if (reportKey(button.dataset.shareReportId) === key) {
        setRowButtonState(button, task?.state || "idle", task?.error || "");
      }
    });
  }

  function retryTask(task) {
    if (!task || task.state !== "error") {
      return;
    }
    task.error = "";
    task.state = "queued";
    syncTaskRowButtons(task.shareReportId);
    const preview = ensurePreviewWindow({ shareReportId: task.shareReportId });
    if (preview) {
      preview.rendered = false;
      setPreviewStatus(preview, "fetching", "در صف واکشی گزارش");
      showLoadingPreview({ shareReportId: task.shareReportId });
    }
    rowRequestQueue.push(task.shareReportId);
    scheduleRowActions();
    processRowRequestQueue();
  }

  function showRowFetchError(message) {
    document.querySelector(".etebarito-row-fetch-error")?.remove();
    const alert = element(
      "div",
      "etebarito-row-fetch-error",
      `واکشی گزارش انجام نشد: ${Core.text(message) || "خطای نامشخص"}`
    );
    alert.setAttribute("role", "alert");
    document.documentElement.append(alert);
    setTimeout(() => alert.remove(), 8000);
  }

  function finishRowRequest(shareReportId, error = "") {
    const key = reportKey(shareReportId);
    const pending = pendingRowRequests.get(key);
    if (!pending) {
      return;
    }
    clearTimeout(pending.timeoutId);
    pending.marker?.remove();
    pendingRowRequests.delete(key);
    activeRowRequestCount = Math.max(0, activeRowRequestCount - 1);
    const task = fetchTasks.get(key);
    if (task) {
      if (error) {
        task.state = "error";
        task.error = error;
      } else if (latestReportById.get(key)?.identity) {
        task.state = "ready";
        task.error = "";
      }
    }
    syncTaskRowButtons(key);
    const preview = previewWindows.get(key);
    if (error && preview) {
      setPreviewStatus(preview, "error", "واکشی گزارش ناموفق بود");
      if (!preview.rendered) {
        const message = element("div", "etebarito-preview__fetch-error", error);
        const retryButton = element("button", "etebarito-preview__primary", "تلاش مجدد");
        retryButton.type = "button";
        retryButton.addEventListener("click", () => retryTask(task));
        preview.content.replaceChildren(message, retryButton);
      }
    }
    if (error) {
      showRowFetchError(error);
    }
    scheduleRowActions();
    processRowRequestQueue();
  }

  function removeRowActions() {
    document.querySelectorAll(".etebarito-row-fetch").forEach((button) => button.remove());
    document.querySelectorAll(".etebarito-row-action-cell").forEach((cell) =>
      cell.classList.remove("etebarito-row-action-cell")
    );
    rowRequestQueue.length = 0;
    for (const [shareReportId] of pendingRowRequests) {
      finishRowRequest(shareReportId, "قابلیت واکشی غیرفعال شد.");
    }
    fetchTasks.clear();
    for (const preview of Array.from(previewWindows.values())) {
      closePreview(preview);
    }
  }

  function startRowRequest(task) {
    const shareReportId = task.shareReportId;
    const requestId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    task.state = "loading";
    syncTaskRowButtons(shareReportId);
    const preview = previewWindows.get(shareReportId);
    if (preview) {
      setPreviewStatus(preview, "fetching", "در حال واکشی گزارش");
      preview.content.querySelector(".etebarito-preview__loading")?.replaceChildren("در حال واکشی گزارش...");
    }
    activeRowRequestCount += 1;
    const timeoutId = setTimeout(() => {
      finishRowRequest(shareReportId, "زمان واکشی گزارش به پایان رسید. دوباره تلاش کنید.");
    }, 90000);
    const marker = element("meta");
    marker.dataset.didarEtebaritoReportRequest = requestId;
    marker.textContent = JSON.stringify({ requestId, shareReportId });
    document.documentElement.append(marker);
    pendingRowRequests.set(shareReportId, { requestId, timeoutId, marker });
    lastInteraction = "درخواست مستقیم گزارش از صف ارسال شد";
    scheduleRowActions();
    marker.dispatchEvent(new Event(REPORT_REQUEST_EVENT, { bubbles: true }));
  }

  function processRowRequestQueue() {
    if (!settings.etebaritoPreviewEnabled || authRecoveryPending) {
      return;
    }
    while (activeRowRequestCount < MAX_CONCURRENT_ROW_REQUESTS && rowRequestQueue.length) {
      const shareReportId = rowRequestQueue.shift();
      const task = fetchTasks.get(shareReportId);
      if (!task || task.state !== "queued" || pendingRowRequests.has(shareReportId)) {
        continue;
      }
      startRowRequest(task);
    }
  }

  function recoverExpiredPortalSession(shareReportId) {
    const now = Date.now();
    let lastRecovery = 0;
    try {
      lastRecovery = Number(window.sessionStorage.getItem(AUTH_RECOVERY_STORAGE_KEY)) || 0;
      window.sessionStorage.setItem(
        PENDING_REPORT_STORAGE_KEY,
        JSON.stringify({ shareReportId: reportKey(shareReportId), requestedAt: now })
      );
    } catch {}
    authRecoveryPending = true;
    if (now - lastRecovery <= AUTH_RECOVERY_COOLDOWN_MS) {
      return "نشست اعتباریتو منقضی شده است؛ لطفاً دوباره وارد اعتباریتو شوید و به صفحه گزارش‌ها برگردید.";
    }
    try {
      window.sessionStorage.setItem(AUTH_RECOVERY_STORAGE_KEY, String(now));
    } catch {}
    window.setTimeout(() => window.location.reload(), 700);
    return "نشست اعتباریتو منقضی شده است؛ صفحه برای ورود مجدد تازه‌سازی می‌شود و سپس همین گزارش دوباره واکشی خواهد شد.";
  }

  function restorePendingReportRequest() {
    if (!settings.etebaritoPreviewEnabled || authRecoveryPending) {
      return;
    }
    let pending = null;
    try {
      pending = JSON.parse(window.sessionStorage.getItem(PENDING_REPORT_STORAGE_KEY) || "null");
    } catch {}
    const shareReportId = reportKey(pending?.shareReportId);
    const requestedAt = Number(pending?.requestedAt) || 0;
    if (!shareReportId || Date.now() - requestedAt > PENDING_REPORT_MAX_AGE_MS) {
      try {
        window.sessionStorage.removeItem(PENDING_REPORT_STORAGE_KEY);
      } catch {}
      return;
    }
    if (!rowsByReportId.has(shareReportId)) {
      return;
    }
    try {
      window.sessionStorage.removeItem(PENDING_REPORT_STORAGE_KEY);
    } catch {}
    if (latestReportById.get(shareReportId)?.identity || fetchTasks.has(shareReportId)) {
      return;
    }
    const task = {
      shareReportId,
      row: rowsByReportId.get(shareReportId) || {},
      state: "queued",
      error: "",
      createdAt: Date.now()
    };
    fetchTasks.set(shareReportId, task);
    showLoadingPreview({ shareReportId });
    syncTaskRowButtons(shareReportId);
    rowRequestQueue.push(shareReportId);
    lastInteraction = "واکشی گزارش پس از بازیابی نشست از سر گرفته شد";
    processRowRequestQueue();
  }

  async function handleRowFetchClick(event) {
    event.preventDefault();
    event.stopPropagation();
    const button = event.currentTarget;
    const shareReportId = reportKey(button.dataset.shareReportId);
    if (!shareReportId) {
      return;
    }
    const cached = latestReportById.get(shareReportId);
    if (cached?.identity && !cached.error && !cached.loading) {
      lastInteraction = "گزارش ردیف از حافظه آماده باز شد";
      await showPreview(cached.detail, cached.identity);
      return;
    }
    const existingTask = fetchTasks.get(shareReportId);
    if (existingTask && ["queued", "loading", "parsing"].includes(existingTask.state)) {
      const preview = previewWindows.get(shareReportId) || showLoadingPreview({ shareReportId });
      restorePreview(preview);
      return;
    }
    if (existingTask?.state === "error") {
      retryTask(existingTask);
      return;
    }
    const task = {
      shareReportId,
      row: rowsByReportId.get(shareReportId) || {},
      state: "queued",
      error: "",
      createdAt: Date.now()
    };
    fetchTasks.set(shareReportId, task);
    showLoadingPreview({ shareReportId });
    syncTaskRowButtons(shareReportId);
    rowRequestQueue.push(shareReportId);
    lastInteraction = "گزارش به صف واکشی اضافه شد";
    scheduleRowActions();
    processRowRequestQueue();
  }

  function ensureRowActions() {
    const knownRows = Array.from(rowsByReportId.values());
    const validIds = new Set(knownRows.map((row) => reportKey(row.shareReportId)).filter(Boolean));
    document.querySelectorAll(".etebarito-row-fetch").forEach((button) => {
      if (!settings.etebaritoPreviewEnabled || !validIds.has(reportKey(button.dataset.shareReportId))) {
        button.remove();
      }
    });
    if (!settings.etebaritoPreviewEnabled || !knownRows.length) {
      return;
    }

    const domRows = rowCandidates();
    const claimedRows = new Set();
    knownRows.forEach((reportRow) => {
      let domRow = domRows.find((candidate) =>
        !claimedRows.has(candidate) && rowMatchesReport(candidate, reportRow)
      );
      if (!domRow) {
        return;
      }
      claimedRows.add(domRow);
      const actionCell = actionCellForRow(domRow);
      const shareReportId = reportKey(reportRow.shareReportId);
      if (!actionCell || !shareReportId) {
        return;
      }
      actionCell.classList.add("etebarito-row-action-cell");
      let button = actionCell.querySelector(".etebarito-row-fetch");
      if (!button) {
        button = element("button", "etebarito-row-fetch");
        button.type = "button";
        button.addEventListener("click", handleRowFetchClick);
        actionCell.append(button);
      }
      button.dataset.shareReportId = shareReportId;
      const task = fetchTasks.get(shareReportId);
      setRowButtonState(button, task?.state || "idle", task?.error || "");
      decorateRowLookupStatus(domRow, actionCell, reportRow);
    });
  }

  function scheduleRowActions() {
    if (attachRowActionsTimer !== null) {
      return;
    }
    attachRowActionsTimer = setTimeout(() => {
      attachRowActionsTimer = null;
      ensureRowActions();
    }, 60);
  }

  function removeNativeFetchButton() {
    document.querySelector(".etebarito-preview-trigger")?.remove();
  }

  function openPreparedPreview() {
    if (!activeReport?.identity || activeReport.error || activeReport.loading) {
      return;
    }
    lastInteraction = "پیش‌نمایش به درخواست کارشناس باز شد";
    const nativeDialog = findNativeDownloadButton()?.closest(
      '[role="dialog"], dialog, [aria-modal="true"], .modal, .ant-modal, .MuiModal-root, .ReactModal__Content'
    );
    void showPreview(activeReport.detail, activeReport.identity, { mountHost: nativeDialog });
  }

  function setButtonState(button, { disabled, text, title }) {
    if (button.disabled !== disabled) {
      button.disabled = disabled;
    }
    if (button.textContent !== text) {
      button.textContent = text;
    }
    if (button.title !== title) {
      button.title = title;
    }
  }

  function ensureNativeFetchButton() {
    const downloadButton = findNativeDownloadButton();
    const existing = document.querySelector(".etebarito-preview-trigger");
    if (!settings.etebaritoPreviewEnabled || !activeReport || !downloadButton?.isConnected) {
      existing?.remove();
      return;
    }

    const button = existing || element("button", "etebarito-preview-trigger");
    button.type = "button";
    button.removeEventListener("click", openPreparedPreview);
    button.addEventListener("click", openPreparedPreview);

    if (activeReport.loading) {
      setButtonState(button, {
        disabled: true,
        text: "در حال آماده‌سازی...",
        title: "گزارش در حال خواندن است"
      });
    } else if (activeReport.error) {
      setButtonState(button, { disabled: true, text: "واکشی ناموفق", title: activeReport.error });
    } else {
      setButtonState(button, {
        disabled: false,
        text: "واکشی برای دیدار",
        title: "خواندن اختیاری اطلاعات همین گزارش برای بررسی در دیدار"
      });
    }

    const actionContainer = downloadButton.parentElement;
    if (!actionContainer) {
      return;
    }
    if (button.parentElement !== actionContainer || button.nextElementSibling !== downloadButton) {
      actionContainer.insertBefore(button, downloadButton);
    }
  }

  function scheduleNativeFetchButton() {
    if (attachButtonTimer !== null) {
      clearTimeout(attachButtonTimer);
    }
    attachButtonTimer = setTimeout(() => {
      attachButtonTimer = null;
      ensureNativeFetchButton();
    }, 40);
  }

  async function handleReport(event) {
    if (!settings.etebaritoPreviewEnabled) {
      return;
    }
    const detail = event.detail || {};
    const key = `${reportKey(detail.shareReportId)}:${Core.text(detail.base64).length}`;
    if (!detail.base64) {
      return;
    }
    let report = preparedReports.get(key);
    if (!report) {
      report = { detail, identity: null, error: "", loading: false };
      preparedReports.set(key, report);
    } else {
      report.detail = detail;
    }
    activeReport = report;
    latestReportById.set(reportKey(detail.shareReportId), report);
    const task = fetchTasks.get(reportKey(detail.shareReportId));
    lastInteraction = "گزارش دریافت شد";
    ensureNativeFetchButton();
    if (report.identity) {
      if (task) {
        task.state = "ready";
        task.error = "";
        syncTaskRowButtons(detail.shareReportId);
        void showPreview(report.detail, report.identity, { activate: false });
      }
      if (pendingRowRequests.has(reportKey(detail.shareReportId))) {
        finishRowRequest(detail.shareReportId);
      }
      return;
    }
    if (report.loading) {
      return;
    }
    report.loading = true;
    if (task) {
      task.state = "parsing";
      syncTaskRowButtons(detail.shareReportId);
      const preview = previewWindows.get(reportKey(detail.shareReportId));
      setPreviewStatus(preview, "parsing", "در حال استخراج اطلاعات گزارش");
      preview?.content.querySelector(".etebarito-preview__loading")?.replaceChildren(
        "گزارش دریافت شد؛ در حال استخراج اطلاعات..."
      );
      scheduleRowActions();
    }
    ensureNativeFetchButton();
    try {
      report.identity = await extractReport(detail.base64);
      report.error = "";
      lastInteraction = report.identity.mobile
        ? "گزارش آماده واکشی اختیاری است"
        : "گزارش آماده است؛ شماره فقط برای ثبت مخاطب جدید لازم است";
    } catch (error) {
      report.error = error.message;
      void globalThis.DidarDiagnostics?.report({source:"etebarito",operation:"fetch",stage:"parse",code:"PDF_PARSE_FAILED"});
      lastInteraction = `خطای استخراج گزارش: ${error.message}`;
    } finally {
      report.loading = false;
      ensureNativeFetchButton();
    }
    if (pendingRowRequests.has(reportKey(detail.shareReportId))) {
      if (report.identity && !report.error) {
        if (task) {
          task.state = "ready";
          task.error = "";
          syncTaskRowButtons(detail.shareReportId);
          void showPreview(report.detail, report.identity, { activate: false });
        }
        finishRowRequest(detail.shareReportId);
      } else {
        finishRowRequest(detail.shareReportId, report.error || "گزارش قابل خواندن نبود.");
      }
    } else if (task) {
      task.state = report.identity && !report.error ? "ready" : "error";
      task.error = report.error || "";
      syncTaskRowButtons(detail.shareReportId);
      if (report.identity && !report.error) {
        void showPreview(report.detail, report.identity, { activate: false });
      } else {
        setPreviewStatus(
          previewWindows.get(reportKey(detail.shareReportId)),
          "error",
          "استخراج اطلاعات گزارش ناموفق بود"
        );
      }
      scheduleRowActions();
    }
  }

  document.addEventListener(RESULTS_EVENT, (event) => {
    for (const row of event.detail?.rows || []) {
      rowsByReportId.set(reportKey(row.shareReportId), row);
    }
    scheduleRowActions();
    restorePendingReportRequest();
  });
  globalThis.DidarCreditPreview = {
    recoverInvalidContext: invalidContextRecoveryError,
    async openExternal({ row, identity }) {
      if (!isOlive) throw new Error("منبع گزارش پشتیبانی نمی‌شود.");
      rowsByReportId.set(reportKey(row.shareReportId), row);
      return showPreview({ shareReportId: row.shareReportId }, identity, { activate: true });
    }
  };
  document.addEventListener(REPORT_EVENT, (event) => void handleReport(event));
  document.addEventListener(REPORT_REQUEST_RESULT_EVENT, (event) => {
    let detail = event.detail || {};
    const marker = event.target?.closest?.("meta[data-didar-etebarito-report-request]");
    if (marker) {
      try {
        detail = JSON.parse(marker.textContent || "{}");
      } catch {
        detail = {};
      }
    }
    const pending = pendingRowRequests.get(reportKey(detail.shareReportId));
    if (!pending || pending.requestId !== reportKey(detail.requestId) || detail.ok) {
      marker?.remove();
      return;
    }
    const authExpired = Boolean(detail.authExpired) || /HTTP\s+(?:401|403)\b/i.test(Core.text(detail.error));
    const error = authExpired
      ? recoverExpiredPortalSession(detail.shareReportId)
      : (detail.error || "واکشی گزارش انجام نشد.");
    finishRowRequest(detail.shareReportId, error);
    marker?.remove();
  });

  function publishKeepAliveSetting() {
    if (document.documentElement) {
      document.documentElement.dataset.didarEtebaritoKeepAlive =
        settings.etebaritoKeepAliveEnabled ? "true" : "false";
    }
  }

  function applySettings(values) {
    settings = { ...DEFAULT_SETTINGS, ...values };
    publishKeepAliveSetting();
    if (settings.etebaritoPreviewEnabled) {
      scheduleNativeFetchButton();
      scheduleRowActions();
      restorePendingReportRequest();
    } else {
      removeNativeFetchButton();
      removeRowActions();
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "ETEBARITO_PREVIEW_GET_STATUS") {
      sendResponse({
        ok: true,
        portal: true,
        settings,
        diagnostics: { capturedRows: rowsByReportId.size, lastInteraction }
      });
      return false;
    }
    if (message?.type === "DIDAR_TODO_SETTINGS_UPDATED") {
      chrome.storage.local
        .get(DEFAULT_SETTINGS)
        .then((values) => {
          applySettings(values);
          sendResponse({ ok: true });
        })
        .catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    return false;
  });

  void chrome.storage.local.get(DEFAULT_SETTINGS).then((values) => {
    applySettings(values);
  });
  chrome.storage.onChanged?.addListener((changes, areaName) => {
    if (areaName !== "local") {
      return;
    }
    const relevant = Object.keys(DEFAULT_SETTINGS).some((key) => key in changes);
    if (!relevant) {
      return;
    }
    void chrome.storage.local.get(DEFAULT_SETTINGS).then(applySettings);
  });
  void loadLookupStatuses().catch(() => {});

  const nativeReportObserver = new MutationObserver(() => {
    scheduleNativeFetchButton();
    scheduleRowActions();
  });
  function observeNativeReportDialog() {
    if (!document.documentElement) {
      return;
    }
    nativeReportObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class"]
    });
  }
  if (document.documentElement) {
    observeNativeReportDialog();
  } else {
    document.addEventListener("DOMContentLoaded", observeNativeReportDialog, { once: true });
  }
})();
