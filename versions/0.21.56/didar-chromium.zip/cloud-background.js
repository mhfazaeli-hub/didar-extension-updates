(function initializeCloudBackground() {
  "use strict";
  const api = globalThis.browser || globalThis.chrome;
  let creating = null;
  const clientURL = api.runtime.getURL("cloud-client.html");
  const popupURL = api.runtime.getURL("popup.html");

  async function connection() {
    const values = await api.storage.local.get({ cloudConnectionCode: "", cloudUserId: "" });
    return { code: values.cloudConnectionCode, userId: values.cloudUserId };
  }

  async function fetchCloud(route, input = {}, selected) {
    const values = selected || await connection();
    if (!values.code) throw new Error("کد اتصال تیم را در تنظیمات اتصال ابری وارد کنید.");
    const code = String(values.code).replace(/[۰-۹]/g, digit => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
      .replace(/[٠-٩]/g, digit => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
    let response;
    const endpoints = [globalThis.DidarRelease.cloudApiUrl, globalThis.DidarRelease.cloudApiFallbackUrl].filter(Boolean);
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        response = await fetch(endpoints[attempt % endpoints.length] + route, {
          method: "POST", credentials: "omit", redirect: "error", headers: {
            Authorization: "Bearer " + code, "Content-Type": "application/json"
          }, body: JSON.stringify({ ...input, userId: values.userId }), signal: AbortSignal.timeout(20000)
        });
        break;
      } catch {
        if (attempt === 2) throw new Error("ارتباط مرورگر با سرویس ابری برقرار نشد؛ اتصال شبکه را بررسی کنید.");
        await new Promise(resolve => setTimeout(resolve, 300 * (attempt + 1)));
      }
    }
    const result = await response.json();
    if (!response.ok || !result?.ok) {
      const error = new Error(result?.error || "ارتباط با سرویس ابری انجام نشد.");
      Object.assign(error, { code: result?.code, status: response.status });
      throw error;
    }
    return result;
  }

  async function createClient() {
    if (api.offscreen) {
      const contexts = await api.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"], documentUrls: [clientURL] });
      if (!contexts.length) await api.offscreen.createDocument({ url: "cloud-client.html", reasons: ["DOM_PARSER"],
        justification: "Reuse the credit preview validation and HTML report parser for the cloud API connection." });
    } else if (!document.getElementById("didar-cloud-client")) {
      const frame = document.createElement("iframe");
      frame.id = "didar-cloud-client";
      frame.hidden = true;
      frame.src = clientURL;
      (document.body || document.documentElement).appendChild(frame);
    }
    for (let attempt = 0; attempt < 100; attempt++) {
      try {
        if ((await api.runtime.sendMessage({ type: "DIDAR_CLOUD_EXECUTE", ping: true }))?.ok) return;
      } catch { /* The document may still be loading. */ }
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    throw new Error("بخش انتقال ابری آماده نشد؛ افزونه را دوباره بارگذاری کنید.");
  }

  globalThis.DidarCloudBackground = {
    async execute(message) {
      if (!creating) creating = createClient().finally(() => { creating = null; });
      await creating;
      return api.runtime.sendMessage({ type: "DIDAR_CLOUD_EXECUTE", message });
    },
    async status() { return fetchCloud("/identity"); }
  };

  api.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== api.runtime.id) return false;
    const fromClient = sender.url === clientURL;
    const fromPopup = sender.url === popupURL || !sender.tab;
    let operation;
    if (fromClient && message?.type === "DIDAR_CLOUD_STORAGE" && ["get", "set", "remove"].includes(message.method)) {
      operation = api.storage.local[message.method](message.value);
    } else if (fromClient && message?.type === "DIDAR_CLOUD_CONNECTION") {
      operation = connection();
    } else if (fromClient && message?.type === "DIDAR_CLOUD_API" && ["/identity", "/request"].includes(message.route)) {
      operation = fetchCloud(message.route, message.input, message.connection).then(value => message.route === "/request" ? value.value : value);
    } else if (fromPopup && message?.type === "DIDAR_CLOUD_USERS") {
      operation = fetchCloud("/users", {}, { code: String(message.code || ""), userId: "" });
    } else if (fromPopup && message?.type === "DIDAR_CLOUD_STATUS") {
      operation = fetchCloud("/identity");
    } else return false;
    Promise.resolve(operation).then(value => respond({ ok: true, value }), error => respond({ ok: false,
      error: error.message || "اتصال ابری انجام نشد.", code: error.code, httpStatus: error.status }));
    return true;
  });
})();
