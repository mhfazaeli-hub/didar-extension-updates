(function initializeBetaDidarIntegration() {
  "use strict";
  const chrome = globalThis.browser || globalThis.chrome;

  if (globalThis.__didarBetaIntegrationLoaded) {
    return;
  }
  globalThis.__didarBetaIntegrationLoaded = true;

  const Core = globalThis.BetaCreditCore;
  const Tamin = globalThis.TaminCreditCore;
  const IS_CSPF = location.hostname === "eservices.cspf.ir";
  const IS_TAMIN = location.hostname === "eservices.tamin.ir";
  const INTEGRATION_SOURCE = IS_CSPF ? "cspf" : IS_TAMIN ? "tamin" : "beta";
  const MESSAGE_PREFIX = INTEGRATION_SOURCE.toUpperCase();
  const ACTIVITY_TITLE = IS_CSPF ? "کشوری" : "اعتبارسنجی بتا";
  const LAUNCHER_TITLE = IS_CSPF ? "انتقال کشوری به دیدار" : IS_TAMIN ? "انتقال تأمین اجتماعی به دیدار" : "انتقال بتا به دیدار";
  const PLAN_ORDER_KEY = "didarBetaPlanOrderV1";
  const DEFAULT_JOB = IS_CSPF ? "بازنشسته کشوری" : "بازنشسته تأمین اجتماعی";
  const PAGE_URLS = {
    dashboard: "/customer",
    profile: "/customers/account/completeprofile",
    messages: "/customers/customerreport/messagereportindex",
    overdue: "/customers/installments/overdued",
    purchases: "/customers/customerreport"
  };

  function element(tag, className, value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value !== undefined) node.textContent = value;
    return node;
  }

  function field(labelText, input, wide = false) {
    const label = element("label", `etebarito-preview__field${wide ? " etebarito-preview__field--wide" : ""}`);
    label.append(element("span", "etebarito-preview__label", labelText), input);
    return label;
  }

  function errorText(error) {
    if (error && typeof error === "object") void globalThis.DidarDiagnostics?.report({ source: INTEGRATION_SOURCE, operation: "fetch", error });
    return Core.text(error?.message || error || "خطای نامشخص");
  }

  async function sendDidar(type, payload) {
    try {
      const response = await chrome.runtime.sendMessage({ type: type.replace(/^BETA_/, `${MESSAGE_PREFIX}_`), payload });
      if (response?.ok===false && response.diagnosticId) response.error=`${response.error} — شناسهٔ پیگیری ${response.diagnosticId}`;
      return response;
    } catch (error) {
      if (/extension context invalidated/i.test(errorText(error))) {
        window.setTimeout(() => window.location.reload(), 80);
        throw new Error("افزونه بروزرسانی شده است؛ صفحه در حال تازه‌سازی خودکار است.");
      }
      throw error;
    }
  }

  function documentFromHtml(value) {
    return new DOMParser().parseFromString(value, "text/html");
  }

  async function fetchPage(path) {
    const response = await fetch(new URL(path, location.origin), {
      credentials: "include",
      cache: "no-store",
      headers: { Accept: "text/html,application/xhtml+xml" }
    });
    if (!response.ok) {
      throw new Error(`دریافت اطلاعات بتا انجام نشد: HTTP ${response.status}`);
    }
    const finalPath = new URL(response.url).pathname.toLowerCase();
    if (/login|signin|account\/(?:index|login)/.test(finalPath)) {
      throw new Error("نشست مشتری در سامانه بتا منقضی شده است؛ دوباره وارد حساب مشتری شوید.");
    }
    return documentFromHtml(await response.text());
  }

  async function fetchCustomerReport() {
    if (IS_TAMIN) return Tamin.fetchCustomerReport({ document, location });
    const entries = await Promise.all(Object.entries(PAGE_URLS).map(async ([key, path]) => [key, await fetchPage(path)]));
    const report = Core.buildCustomerReport(Object.fromEntries(entries));
    if (!report.identity.nationalCode) {
      throw new Error("کد ملی مشتری از صفحه پروفایل بتا استخراج نشد.");
    }
    return report;
  }

  function dealStatusTitle(value) {
    return value === "Won" ? "موفق" : value === "Lost" ? "ناموفق" : value === "Pending" ? "جاری" : value || "نامشخص";
  }

  function appendRecordLink(container, title, href) {
    const link = element("a", "etebarito-preview__record-link", title);
    link.href = href;
    link.target = "_blank";
    link.rel = "noreferrer";
    container.append(link);
  }

  function renderOperationResult(container, response, action) {
    container.replaceChildren();
    if (response?.ok) {
      container.className = "etebarito-preview__result is-success";
      const message = action === "create"
        ? response.contactReused
          ? `معامله برای مخاطب موجود در ${response.pipelineTitle} / ${response.stageTitle} ساخته و فعالیت اعتبارسنجی بتا ثبت شد.`
          : `مخاطب و معامله در ${response.pipelineTitle} / ${response.stageTitle} ساخته و فعالیت اعتبارسنجی بتا ثبت شد.`
        : response.unchanged
          ? "این گزارش قبلاً ثبت شده و اطلاعات جدیدی برای بروزرسانی وجود نداشت."
          : response.keptOpen
            ? "اطلاعات و گزارش ثبت شدند و معامله باز شد؛ وضعیت معامله جاری است."
          : response.temporarilyReopened
            ? `اطلاعات بروزرسانی شد و معامله با وضعیت «${dealStatusTitle(response.restoredStatus)}» و زمان بسته‌شدن قبلی بازگردانده شد.`
            : "اطلاعات بروزرسانی و فعالیت تکمیل‌شده اعتبارسنجی بتا ثبت شد.";
      container.append(element("strong", "", message));
      if (response.activityUpdated) {
        container.append(element("p", "etebarito-preview__phone-note",
          "گزارش قبلی همین استعلام در دیدار اصلاح شد؛ فعالیت تکراری ساخته نشد."));
      }
      if (response.contact?.url) appendRecordLink(container, "مشاهده مخاطب در دیدار", response.contact.url);
      if (response.deal?.url) appendRecordLink(container, "مشاهده معامله در دیدار", response.deal.url);
      if (response.profileFieldsAdded?.length) {
        container.append(element("p", "etebarito-preview__phone-note", `اطلاعات افزوده‌شده به مخاطب: ${response.profileFieldsAdded.join("، ")}`));
      }
      if (response.phoneWarning || response.profileWarning) {
        container.append(element("p", "etebarito-preview__phone-warning", response.profileWarning || response.phoneWarning));
      }
      return;
    }
    container.className = response?.partial || response?.blocked
      ? "etebarito-preview__result is-warning"
      : "etebarito-preview__result is-error";
    container.append(element("strong", "", response?.error || "عملیات دیدار انجام نشد."));
    if (response?.contact?.url) appendRecordLink(container, "مشاهده مخاطب", response.contact.url);
    if (response?.deal?.url) appendRecordLink(container, "مشاهده معامله", response.deal.url);
  }

  function reportSummary(report) {
    const wrapper = element("section", "etebarito-preview__credit-summary etebarito-preview__field--wide");
    if (IS_CSPF) {
      const amounts = globalThis.CspfCreditCore.formatAmounts(report.remainingRials);
      wrapper.append(
        element("p", "", `${amounts.warning ? "❌ " : ""}تتمه سقف مجاز: ${amounts.remaining} تومان`),
        element("p", "", `توان قسط (۷۰٪ تتمه): ${amounts.installment} تومان`)
      );
      if (amounts.warning) wrapper.append(element("p", "etebarito-preview__phone-warning", amounts.warning));
      return wrapper;
    }
    wrapper.append(element("h3", "", "خلاصه گزارش بتا"));
    if (IS_TAMIN) {
      wrapper.append(element("p", "", "منبع: سامانه خدمات غیرحضوری تأمین اجتماعی"));
      wrapper.append(element("p", "", `توان قسط: ${(BigInt(report.monthlyCapacityRials) / 10n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")} تومان`));
      wrapper.append(element("p", "", "توان قسط فقط در فعالیت اعتبارسنجی بتا ثبت می‌شود."));
      return wrapper;
    }
    const capacity = report.monthlyCapacityRials
      ? (BigInt(report.monthlyCapacityRials) / 10n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
      : "ثبت نشده";
    wrapper.append(element("p", "", `تاریخ استعلام: ${report.inquiryDate || "ثبت نشده"}`));
    wrapper.append(element("p", "", `اعتبار نتیجه تا: ${report.validUntil || "ثبت نشده"}`));
    wrapper.append(element("p", "", `وضعیت طرح: ${report.eligibility || "ثبت نشده"}`));
    for (const item of report.commitmentStatuses || []) {
      if (!["شرایط عمومی", "چک برگشتی", "اقساط معوق", "وضعیت حیات"].includes(item.label)) continue;
      const marker = item.result === "pass" ? "✅" : item.result === "fail" ? "❌" : "❔";
      wrapper.append(element("p", "", `${marker} ${item.label}: ${item.status || "نامشخص"}`));
    }
    wrapper.append(element("p", "", `توان قسط ماهیانه الماس رفاه: ${capacity} تومان`));
    wrapper.append(element("p", "", `${report.overdueCount} قسط معوق؛ ${report.overdueHeadline || report.overdueSummary || "وضعیت نامشخص"}`));
    wrapper.append(element("p", "", `خرید گلرنگ: ${report.purchases.golrang ? "دارد" : "ندارد"} | خرید ثمین: ${report.purchases.samin ? "دارد" : "ندارد"}`));
    return wrapper;
  }

  function reportIsReliable(report) {
    if (IS_CSPF) return report?.provider === "cspf" && /^-?\d{1,30}$/.test(report.remainingRials);
    if (IS_TAMIN) return report?.sourceSystem === "tamin" && /^\d+$/.test(Core.text(report.monthlyCapacityRials));
    const labels = ["شرایط عمومی", "چک برگشتی", "اقساط معوق", "وضعیت حیات"];
    return /مشمول/.test(Core.normalizeText(report?.eligibility)) && labels.every((label) =>
      (report?.commitmentStatuses || []).some((item) =>
        item.label === label && ["pass", "fail"].includes(item.result)));
  }

  function ownerKey(config) {
    return [Core.text(config?.identity?.bizDomain || config?.identity?.account), Core.text(config?.identity?.id)].filter(Boolean).join(":") || "default";
  }

  async function orderedPlans(config) {
    const values = await chrome.storage.local.get({ [PLAN_ORDER_KEY]: {} });
    const saved = values?.[PLAN_ORDER_KEY]?.[ownerKey(config)] || [];
    const allowed = new Set(config.planTypeOptions || []);
    return [...saved.filter((item) => allowed.has(item)), ...(config.planTypeOptions || []).filter((item) => !saved.includes(item))];
  }

  async function savePlanOrder(config, values) {
    const stored = await chrome.storage.local.get({ [PLAN_ORDER_KEY]: {} });
    const all = { ...(stored?.[PLAN_ORDER_KEY] || {}), [ownerKey(config)]: values };
    await chrome.storage.local.set({ [PLAN_ORDER_KEY]: all });
  }

  function renderDeals(container, lookup, config, onSelect, onNewDealSelect = () => {}, onContactSelect = () => {}, onClear = () => {}) {
    return globalThis.DidarCreditDestination.render(container, {
      lookup, writeEnabled: config.writeEnabled !== false, onDeal: onSelect,
      onNewDeal: onNewDealSelect, onContact: onContactSelect, onClear
    });
  }

  async function openPreview(data) {
    const reliableReport = reportIsReliable(data.creditReport);
    document.querySelector(".beta-didar-preview")?.remove();
    const overlay = element("div", "etebarito-preview beta-didar-preview");
    const dialog = element("section", "etebarito-preview__dialog");
    const header = element("header", "etebarito-preview__header");
    header.append(element("strong", "", `پیش‌نمایش ${LAUNCHER_TITLE}`));
    const close = element("button", "etebarito-preview__icon-button", "×");
    close.type = "button";
    close.title = "بستن";
    close.addEventListener("click", () => overlay.remove());
    header.append(close);
    const content = element("div", "etebarito-preview__content");
    const safety = element("p", "etebarito-preview__safety", "ثبت فقط پس از تطبیق کد ملی و تأیید کارشناس انجام می‌شود؛ مقصد پرونده اعتباری / اعتبار سنجی اولیه است.");
    const result = element("div", "etebarito-preview__result is-loading", "در حال دریافت تنظیمات دیدار و بررسی کد ملی...");
    const form = element("form", "etebarito-preview__form");
    form.addEventListener("submit", (event) => event.preventDefault());

    const name = document.createElement("input");
    name.value = data.identity.fullName;
    const national = document.createElement("input");
    national.value = data.identity.nationalCode;
    national.readOnly = true;
    const dealTitle = document.createElement("input");
    dealTitle.readOnly = true;
    const syncDealTitle = () => {
      const fullName = Core.normalizeText(name.value).replace(/(?:\s*\d{10})+$/, "").trim();
      dealTitle.value = fullName ? `معامله ${fullName} ${national.value}` : "";
    };
    name.addEventListener("input", syncDealTitle);
    name.addEventListener("blur", () => {
      name.value = [Core.normalizeText(name.value).replace(/(?:\s*\d{10})+$/, "").trim(), national.value].filter(Boolean).join(" ");
      syncDealTitle();
    });
    syncDealTitle();
    const mobile = document.createElement("input");
    mobile.value = data.identity.mobile;
    const birth = document.createElement("input");
    birth.value = data.identity.birthDateJalali;
    const destination = document.createElement("input");
    destination.readOnly = true;
    const job = document.createElement("select");
    const score = document.createElement("input");
    score.value = "";
    score.disabled = true;
    score.placeholder = "فاقد امتیاز اعتباری";
    const rank = document.createElement("input");
    rank.value = "";
    rank.disabled = true;
    rank.placeholder = "فاقد رتبه اعتباری";
    const source = document.createElement("select");
    const customerStatus = document.createElement("select");
    const customerRole = document.createElement("select");
    customerRole.dataset.fieldKey = "Field_8783_4_50";
    customerRole.append(new Option("خریدار", "خریدار"), new Option("ضامن", "ضامن"));
    customerRole.value = "خریدار";
    const summary = element("details", "etebarito-preview__report-summary");
    summary.open = true;
    summary.append(element("summary", "", `خلاصهٔ گزارش فعالیت «${ACTIVITY_TITLE}»`), reportSummary(data.creditReport));

    const planWrapper = element("div", "etebarito-preview__field etebarito-preview__field--wide");
    const planHeading = element("div", "etebarito-preview__field-heading");
    planHeading.append(element("span", "etebarito-preview__label", "نوع طرح (اختیاری، چندانتخابی معامله)"));
    const planOrderButton = element("button", "etebarito-preview__order-toggle", "چیدمان");
    planOrderButton.type = "button";
    planHeading.append(planOrderButton);
    const plans = element("div", "etebarito-preview__multi-options");
    planWrapper.append(planHeading, plans);

    form.append(
      field("نام و نام خانوادگی (اختیاری)", name),
      field("کد ملی", national),
      field("شماره همراه", mobile),
      field("تاریخ تولد شمسی (اختیاری)", birth),
      field("شغل مشتری", job),
      field("مقصد آزمایشی", destination),
      field("امتیاز اعتباری", score),
      field("رتبه اعتباری معامله", rank),
      field("نحوه آشنایی معامله (اختیاری)", source),
      field("مشتری جدید / قدیم (اختیاری)", customerStatus),
      field("نقش مشتری در معامله", customerRole),
      field("عنوان معامله از نام و کد ملی", dealTitle),
      planWrapper,
      summary
    );

    const actions = element("div", "etebarito-preview__actions");
    const cancel = element("button", "etebarito-preview__secondary", "بستن");
    cancel.type = "button";
    cancel.addEventListener("click", () => overlay.remove());
    const refresh = element("button", "etebarito-preview__refresh", "↻");
    refresh.type = "button";
    refresh.title = "بررسی مجدد مشتری در دیدار";
    const create = element("button", "etebarito-preview__primary", "ثبت مخاطب و معامله در پرونده اعتباری");
    create.type = "button";
    create.hidden = true;
    const update = element("button", "etebarito-preview__primary etebarito-preview__update", "بروزرسانی اطلاعات");
    update.type = "button";
    update.hidden = true;
    const phoneConflict = element("div", "etebarito-preview__result etebarito-preview__mobile-conflict");
    phoneConflict.hidden = true;
    const mobileSave = element("button", "etebarito-preview__primary etebarito-preview__report-only", "ثبت گزارش در معاملهٔ انتخابی");
    mobileSave.type = "button"; mobileSave.hidden = true; mobileSave.disabled = true;
    actions.append(cancel, refresh, create, update, mobileSave);
    content.append(safety, result, phoneConflict, form, actions);
    dialog.append(header, content);
    overlay.append(dialog);
    document.body.append(overlay);

    let config = null;
    let approvedCreateCode = "";
    let approvedExistingContactId = "";
    let approvedNewDealIds = null;
    let approvedUpdate = null;
    let ordering = false;
    let mobileSelection = null;
    let mobileSequence = 0;
    let mobileSaving = false;

    const planValues = () => Array.from(plans.querySelectorAll('input[type="checkbox"]:checked')).map((item) => item.value);
    const renderPlanOptions = async (values, selected = new Set()) => {
      plans.replaceChildren();
      for (const option of values) {
        const row = element("label", "etebarito-preview__multi-option");
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = option;
        checkbox.checked = selected.has(option);
        const title = element("span", "etebarito-preview__multi-option-title", option);
        const controls = element("span", "etebarito-preview__item-order-controls");
        for (const [caption, delta] of [["→", -1], ["←", 1]]) {
          const button = element("button", "etebarito-preview__item-order-button", caption);
          button.type = "button";
          button.hidden = !ordering;
          button.addEventListener("click", async () => {
            const rows = Array.from(plans.querySelectorAll(".etebarito-preview__multi-option"));
            const index = rows.indexOf(row);
            const target = index + delta;
            if (target < 0 || target >= rows.length) return;
            if (delta < 0) plans.insertBefore(row, rows[target]);
            else plans.insertBefore(rows[target], row);
            await savePlanOrder(config, Array.from(plans.querySelectorAll('input[type="checkbox"]')).map((item) => item.value));
          });
          controls.append(button);
        }
        row.append(checkbox, title, controls);
        plans.append(row);
      }
    };

    planOrderButton.addEventListener("click", () => {
      ordering = !ordering;
      planOrderButton.classList.toggle("is-active", ordering);
      planOrderButton.textContent = ordering ? "پایان چیدمان" : "چیدمان";
      plans.querySelectorAll(".etebarito-preview__item-order-button").forEach((button) => { button.hidden = !ordering; });
    });

    const preparedPayload = () => ({
      provider: IS_CSPF ? "cspf" : "beta",
      replaceContactFields: true,
      nationalCode: Core.normalizeNationalCode(national.value),
      fullName: Core.normalizeText(name.value),
      preparedContactFields: {
        mobile: Core.normalizeMobile(mobile.value),
        birthDateJalali: Core.normalizeText(birth.value),
        job: Core.normalizeText(job.value)
      },
      sourceContactFields: {
        fullName: Core.normalizeText(name.value),
        nationalCode: Core.normalizeNationalCode(national.value),
        mobile: Core.normalizeMobile(mobile.value),
        birthDateJalali: Core.normalizeText(birth.value),
        job: Core.normalizeText(job.value)
      },
      preparedDealSourceId: source.value,
      preparedDealFields: {
        [config.planTypeFieldKey]: planValues(),
        [config.creditRankFieldKey]: "",
        [config.customerStatusFieldKey]: customerStatus.value,
        [config.customerRoleFieldKey || "Field_8783_4_50"]: customerRole.value
      },
      creditReport: data.creditReport
    });

    const clearMobileOffer = () => {
      mobileSequence++; mobileSelection = null;
      phoneConflict.hidden = true; phoneConflict.replaceChildren();
      mobileSave.hidden = true; mobileSave.disabled = true;
    };
    mobile.addEventListener("input", () => {
      clearMobileOffer(); create.hidden = !approvedCreateCode; update.hidden = !approvedUpdate;
    });
    const offerMobileConflict = async failure => {
      if (IS_CSPF) return false;
      if (!/duplicate\s+contacts?|تکراری.*(?:مخاطب|کانتکت)|(?:مخاطب|کانتکت|شماره).*تکراری/i.test(Core.text(failure?.error || failure?.message))) return false;
      const selectedMobile = Core.normalizeMobile(mobile.value);
      if (!selectedMobile) return false;
      clearMobileOffer();
      const sequence = mobileSequence;
      phoneConflict.hidden = false;
      phoneConflict.textContent = "در حال دریافت معاملات صاحب شماره...";
      create.hidden = true; update.hidden = true;
      try {
        const lookup = await sendDidar("BETA_DIDAR_MOBILE_LOOKUP", { mobile: selectedMobile });
        if (sequence !== mobileSequence || selectedMobile !== Core.normalizeMobile(mobile.value)) return true;
        const approve = (contact, deal, previous = []) => {
          mobileSelection = { mobile: selectedMobile, contactId: contact.id, contactName: contact.displayName,
            dealId: deal?.id || "", createDeal: !deal, previousIds: previous.map(item => item.id) };
          mobileSave.disabled = false;
          mobileSave.textContent = deal ? "ثبت گزارش در معاملهٔ انتخابی" : "ایجاد معامله و ثبت گزارش";
        };
        globalThis.DidarCreditDestination.render(phoneConflict, {
          lookup, reopenClosed: false,
          onClear() { mobileSelection = null; mobileSave.disabled = true; },
          onDeal(deal, contact) { approve(contact, deal); },
          onNewDeal(contact, previous) { approve(contact, null, previous); }
        });
        phoneConflict.append(element("p", "", "گزارش با هویت صاحب استعلام در معاملهٔ انتخابی ثبت می‌شود و مشخصات هویتی صاحب شماره حفظ می‌شوند."));
        mobileSave.hidden = false;
      } catch (error) { phoneConflict.textContent = errorText(error); }
      return true;
    };
    mobileSave.addEventListener("click", async () => {
      const selection = mobileSelection;
      if (mobileSaving || !selection || selection.mobile !== Core.normalizeMobile(mobile.value)) return;
      if (!window.confirm(`گزارش در ${selection.createDeal ? "معاملهٔ جدید برای" : "معاملهٔ انتخابیِ"} «${selection.contactName}» ثبت شود؟`)) return;
      globalThis.DidarCreditDestination.setBusy(dialog, true);
      mobileSaving = true; mobileSave.disabled = true; refresh.disabled = true;
      try {
        if (IS_TAMIN) await Tamin.verifyCurrentReport(data, { document, location });
        const payload = preparedPayload();
        const response = await sendDidar("BETA_DIDAR_APPEND_MOBILE_REPORT", {
          provider: "beta", confirmReportOnly: true, mobile: selection.mobile,
          approvedContactId: selection.contactId, approvedDealId: selection.dealId,
          createDeal: selection.createDeal, approvedExistingDealIds: selection.previousIds,
          ...(selection.createDeal ? { preparedDealFields: payload.preparedDealFields,
            preparedDealSourceId: payload.preparedDealSourceId } : {}), creditReport: payload.creditReport,
          reportSubject: { fullName: data.identity.fullName, nationalCode: payload.nationalCode }
        });
        if (!response.ok) {
          if (response.partial && response.deal?.id) { selection.dealId = response.deal.id; selection.createDeal = false; }
          throw new Error(response.error || "گزارش ثبت نشد.");
        }
        result.className = "etebarito-preview__result is-success";
        result.replaceChildren(element("strong", "", "گزارش در معاملهٔ انتخابی ثبت شد."));
        if (response.deal?.url) appendRecordLink(result, "مشاهده معامله", response.deal.url);
        clearMobileOffer();
      } catch (error) { result.className = "etebarito-preview__result is-error"; result.textContent = errorText(error); }
      finally { globalThis.DidarCreditDestination.setBusy(dialog, false); mobileSaving = false; mobileSave.disabled = !mobileSelection; refresh.disabled = false; }
    });

    const applyContact = (contact) => {
      if (!contact) return;
      name.value = data.identity.fullName || contact.fullName || contact.displayName || "";
      const didarMobile = Core.normalizeMobile(contact.mobilePhone || contact.workPhone);
      if (!IS_CSPF && didarMobile) mobile.value = didarMobile;
      mobile.readOnly = false;
      if (contact.birthDateJalali) birth.value = contact.birthDateJalali;
      if (!IS_TAMIN && !IS_CSPF && contact.job && Array.from(job.options).some((option) => option.value === contact.job)) job.value = contact.job;
      syncDealTitle();
    };

    const applyDeal = (deal) => {
      customerRole.value = Array.from(customerRole.options).some((option) => option.value === deal.customerRole)
        ? deal.customerRole : "خریدار";
      if (Array.from(source.options).some((option) => option.value === deal.sourceId)) source.value = deal.sourceId;
      if (Array.from(customerStatus.options).some((option) => option.value === deal.customerStatus)) customerStatus.value = deal.customerStatus;
      const selected = new Set(deal.planTypes || []);
      plans.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => { checkbox.checked = selected.has(checkbox.value); });
    };

    const runLookup = async () => {
      if (!config && !await loadConfiguration()) return;
      clearMobileOffer();
      approvedCreateCode = "";
      approvedExistingContactId = "";
      approvedNewDealIds = null;
      approvedUpdate = null;
      create.hidden = true;
      update.hidden = true;
      refresh.disabled = true;
      result.className = "etebarito-preview__result is-loading";
      result.textContent = "در حال بررسی کد ملی در دیدار...";
      try {
        const lookup = await sendDidar("BETA_DIDAR_LOOKUP", preparedPayload());
        const state = renderDeals(result, lookup, config, (deal, contact) => {
          if (!reliableReport || lookup.writeEnabled === false || config.writeEnabled === false) return;
          approvedNewDealIds = null; approvedCreateCode = ""; approvedExistingContactId = ""; create.hidden = true;
          applyDeal(deal);
          approvedUpdate = { dealId: deal.id, contactId: contact.id, status: deal.status, nationalCode: national.value };
          update.textContent = ["Won", "Lost"].includes(deal.status) ? "بروزرسانی و بازکردن معامله" : "بروزرسانی اطلاعات";
          update.hidden = false;
        }, (contact, deals) => {
          if (!reliableReport) return;
          approvedUpdate = null; update.hidden = true;
          approvedCreateCode = Core.normalizeNationalCode(national.value);
          approvedExistingContactId = Core.text(contact.id);
          approvedNewDealIds = deals.map((deal) => Core.text(deal.id));
          create.textContent = "ایجاد معاملهٔ جدید برای همین مخاطب"; create.hidden = false;
        }, applyContact, () => {
          approvedCreateCode = ""; approvedExistingContactId = ""; approvedNewDealIds = null;
          approvedUpdate = null; create.hidden = true; update.hidden = true;
        });
        if (lookup.diagnosticId) result.append(element("small", "etebarito-preview__tracking", `شناسهٔ پیگیری ${lookup.diagnosticId}`));
        if (["success", "existing-contact"].includes(state) && lookup.writeEnabled !== false && config.writeEnabled !== false) {
          approvedCreateCode = Core.normalizeNationalCode(national.value);
          approvedExistingContactId = state === "existing-contact" ? Core.text(lookup.contacts[0].id) : "";
          create.textContent = approvedExistingContactId ? "ایجاد معامله برای مخاطب موجود" : "ثبت مخاطب و معامله در پرونده اعتباری";
          create.hidden = false;
        }
        if (!reliableReport) {
          approvedCreateCode = "";
          approvedUpdate = null;
          create.hidden = true;
          update.hidden = true;
          result.className = "etebarito-preview__result is-warning";
          result.append(element("p", "etebarito-preview__phone-warning",
            "وضعیت یکی از استعلام‌های بتا قابل تشخیص نیست؛ برای جلوگیری از ثبت گزارش نادرست، انتقال متوقف شد."));
        }
      } catch (error) {
        result.className = "etebarito-preview__result is-error";
        result.textContent = errorText(error);
      } finally {
        refresh.disabled = false;
      }
    };

    refresh.addEventListener("click", () => void runLookup());

    create.addEventListener("click", async () => {
      if (!reliableReport) return;
      const payload = preparedPayload();
      if (approvedExistingContactId) payload.approvedContactId = approvedExistingContactId;
      if (approvedExistingContactId) payload.confirmContactSelection = true;
      if (approvedNewDealIds) { payload.confirmNewDeal = true; payload.approvedExistingDealIds = approvedNewDealIds; }
      if (!payload.nationalCode || (!approvedExistingContactId && !payload.preparedContactFields.mobile) ||
          (Core.text(mobile.value) && !payload.preparedContactFields.mobile)) {
        result.className = "etebarito-preview__result is-error";
        result.textContent = "کد ملی و شماره همراه معتبر برای ثبت الزامی است.";
        return;
      }
      if (approvedCreateCode !== payload.nationalCode) {
        result.className = "etebarito-preview__result is-warning";
        result.textContent = "اطلاعات تغییر کرده است؛ بررسی مجدد را بزنید.";
        return;
      }
      if (!window.confirm(approvedExistingContactId
        ? `برای مخاطب موجود «${payload.fullName} ${payload.nationalCode}» معامله پرونده اعتباری با اطلاعات و گزارش جدید ایجاد شود؟`
        : `مخاطب «${payload.fullName} ${payload.nationalCode}» و معامله پرونده اعتباری ساخته شود؟`)) return;
      globalThis.DidarCreditDestination.setBusy(dialog, true);
      create.disabled = true;
      refresh.disabled = true;
      result.className = "etebarito-preview__result is-loading";
      result.textContent = approvedExistingContactId
        ? `در حال ایجاد معامله و ثبت فعالیت «${ACTIVITY_TITLE}» برای مخاطب موجود...`
        : `در حال ثبت مخاطب، معامله و فعالیت «${ACTIVITY_TITLE}»...`;
      try {
        if (IS_TAMIN) await Tamin.verifyCurrentReport(data, { document, location });
        if (IS_CSPF) await data.verify();
        const response = await sendDidar("BETA_DIDAR_TRANSFER", payload);
        renderOperationResult(result, response, "create");
        if (!response.ok) { globalThis.DidarCreditDestination.setBusy(dialog, false); await offerMobileConflict(response); }
        approvedCreateCode = "";
        create.hidden = true;
      } catch (error) {
        renderOperationResult(result, { ok: false, error: errorText(error) }, "create");
        globalThis.DidarCreditDestination.setBusy(dialog, false);
        await offerMobileConflict(error);
      } finally {
        globalThis.DidarCreditDestination.setBusy(dialog, false);
        create.disabled = false;
        refresh.disabled = false;
      }
    });

    update.addEventListener("click", async () => {
      if (!reliableReport) return;
      const payload = preparedPayload();
      if (!approvedUpdate || approvedUpdate.nationalCode !== payload.nationalCode) {
        result.className = "etebarito-preview__result is-warning";
        result.textContent = "معامله انتخاب‌شده معتبر نیست؛ بررسی مجدد را بزنید.";
        return;
      }
      const question = ["Won", "Lost"].includes(approvedUpdate.status)
        ? "معاملهٔ بسته باز شود و جاری بماند و اطلاعات و گزارش اعتبارسنجی در آن بروزرسانی شوند؟"
        : `اطلاعات مشتری بروزرسانی و گزارش در فعالیت «${ACTIVITY_TITLE}» ثبت شود؟`;
      if (!window.confirm(IS_TAMIN ? `${question}\nشغل مشتری «بازنشسته تأمین اجتماعی» ثبت می‌شود و توان قسط فقط در فعالیت اعتبارسنجی بتا قرار می‌گیرد.` : question)) return;
      globalThis.DidarCreditDestination.setBusy(dialog, true);
      update.disabled = true;
      refresh.disabled = true;
      result.className = "etebarito-preview__result is-loading";
      result.textContent = `در حال بروزرسانی اطلاعات و ثبت فعالیت «${ACTIVITY_TITLE}»...`;
      try {
        if (IS_TAMIN) await Tamin.verifyCurrentReport(data, { document, location });
        if (IS_CSPF) await data.verify();
        const response = await sendDidar("BETA_DIDAR_UPDATE", {
          ...payload,
          approvedDealId: approvedUpdate.dealId,
          approvedContactId: approvedUpdate.contactId,
          confirmContactSelection: true,
          approvedDealStatus: approvedUpdate.status,
          keepDealOpen: ["Won", "Lost"].includes(approvedUpdate.status)
        });
        renderOperationResult(result, response, "update");
        if (!response.ok) { globalThis.DidarCreditDestination.setBusy(dialog, false); await offerMobileConflict(response); }
        approvedUpdate = null;
        update.hidden = true;
      } catch (error) {
        renderOperationResult(result, { ok: false, error: errorText(error) }, "update");
        globalThis.DidarCreditDestination.setBusy(dialog, false);
        await offerMobileConflict(error);
      } finally {
        globalThis.DidarCreditDestination.setBusy(dialog, false);
        update.disabled = false;
        refresh.disabled = false;
      }
    });

    async function loadConfiguration() {
      refresh.disabled = true;
      try {
        config = await sendDidar("BETA_DIDAR_GET_CONFIG");
        if (!config?.ok) throw new Error(config?.error || "تنظیمات دیدار دریافت نشد.");
        if (config.customerRoleFieldKey !== "Field_8783_4_50" ||
            !["خریدار", "ضامن"].every((role) => config.customerRoleOptions?.includes(role))) {
          throw new Error("تنظیمات نقش مشتری دریافت نشد؛ افزونه را بروزرسانی و تب دیدار را تازه‌سازی کنید.");
        }
        destination.value = `${config.pipelineTitle} / ${config.stageTitle}`;
        job.replaceChildren(new Option("انتخاب شغل مشتری", ""));
        for (const option of config.jobOptions || []) job.append(new Option(option, option));
        const defaultJob = (config.jobOptions || []).find((option) => Core.normalizeText(option) === Core.normalizeText(DEFAULT_JOB)) ||
          (!IS_CSPF && (config.jobOptions || []).find((option) => /بازنشسته.*تامین اجتماعی|بازنشسته.*تأمین اجتماعی/.test(Core.normalizeText(option))));
        if (defaultJob) job.value = defaultJob;
        if (IS_TAMIN) {
          if (!defaultJob) throw new Error("گزینهٔ شغلی «بازنشسته تأمین اجتماعی» در دیدار پیدا نشد؛ انتقال متوقف است.");
          job.disabled = true;
        }
        source.replaceChildren(new Option("انتخاب نحوه آشنایی", ""));
        for (const option of config.sourceOptions || []) source.append(new Option(option.title, option.id));
        source.disabled = config.sourceOptionsAvailable === false;
        customerStatus.disabled = false;
        customerStatus.replaceChildren(new Option("انتخاب وضعیت مشتری", ""));
        for (const option of config.customerStatusOptions || []) customerStatus.append(new Option(option, option));
        await renderPlanOptions(await orderedPlans(config));
        return true;
      } catch (error) {
        config = null;
        destination.value = "تنظیمات دیدار دریافت نشد";
        for (const control of [source, customerStatus]) {
          control.replaceChildren(new Option("دریافت انجام نشد؛ بررسی مجدد را بزنید", ""));
          control.disabled = true;
        }
        plans.textContent = "گزینه‌های طرح دریافت نشدند؛ بررسی مجدد را بزنید.";
        result.className = "etebarito-preview__result is-error";
        result.textContent = errorText(error);
        return false;
      } finally { refresh.disabled = false; }
    }

    if (await loadConfiguration()) await runLookup();
  }

  function ensureLauncher() {
    if (typeof location === "undefined" || typeof document === "undefined") return;
    if (IS_TAMIN && !Tamin.isWagePage(location)) {
      document.querySelector(".beta-didar-launcher")?.remove();
      document.querySelector(".beta-didar-preview")?.remove();
      return;
    }
    if (!document.body || document.querySelector(".beta-didar-launcher")) return;
    if (!IS_TAMIN && !/^\/customer(?:s\/|\/|$)/i.test(location.pathname)) return;
    const button = element("button", "beta-didar-launcher", LAUNCHER_TITLE);
    button.type = "button";
    button.title = "واکشی اطلاعات مشتری و انتقال به دیدار";
    button.addEventListener("click", async () => {
      button.disabled = true;
      button.textContent = "در حال واکشی اطلاعات...";
      try {
        const report = await fetchCustomerReport();
        if (!IS_TAMIN || Tamin.isWagePage(location)) await openPreview(report);
      } catch (error) {
        window.alert(errorText(error));
      } finally {
        button.disabled = false;
        button.textContent = LAUNCHER_TITLE;
      }
    });
    document.body.append(button);
  }

  if (IS_CSPF) {
    globalThis.DidarOpenCspfPreview = openPreview;
    return;
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", ensureLauncher, { once: true });
  } else {
    ensureLauncher();
  }
  if (IS_TAMIN) {
    window.addEventListener("hashchange", ensureLauncher);
    const observer = new MutationObserver(() => ensureLauncher());
    observer.observe(document.documentElement, { childList: true, subtree: true });
    window.addEventListener("pagehide", () => observer.disconnect(), { once: true });
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== (IS_TAMIN ? "TAMIN_DIDAR_GET_STATUS" : "BETA_DIDAR_GET_STATUS")) {
      return false;
    }
    sendResponse({
      ok: true,
      diagnostics: {
        launcherReady: Boolean(document.querySelector(".beta-didar-launcher")),
        previewOpen: Boolean(document.querySelector(".beta-didar-preview"))
      }
    });
    return false;
  });
})();
