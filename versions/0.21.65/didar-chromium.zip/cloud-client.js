(function initializeCloudClient() {
  "use strict";
  const api = globalThis.browser || globalThis.chrome;
  let queue = Promise.resolve();
  let connection = null;
  let executionKey = "";
  const readPaths = new Set(["customfield/getcustomfieldlist", "pipeline/list/0", "source/getlist", "activity/getactivitytype",
    "contact/search", "contact/getcontactdetail", "deal/search", "search/search", "deal/getdealdetail_v2",
    "deal/getdealdetail", "activity/getactivitybyid", "activity/getdetailactivities"]);
  async function send(message) {
    const read = message.type === "DIDAR_CLOUD_CONNECTION" ||
      message.type === "DIDAR_CLOUD_STORAGE" && message.method === "get" ||
      message.type === "DIDAR_CLOUD_API" && (message.route === "/identity" || readPaths.has(String(message.input?.path).toLowerCase()));
    let timer;
    let result;
    try {
      const operation = api.runtime.sendMessage(message);
      result = read ? await Promise.race([operation, new Promise((_resolve, reject) => {
        timer = setTimeout(() => reject(Object.assign(new Error("پاسخ خواندن اطلاعات اتصال ابری بیش از حد طول کشید؛ بررسی مجدد را بزنید."),
          { code: "TIMEOUT", endpoint: message.input?.path || "" })), 15000);
      })]) : await operation;
    } finally { clearTimeout(timer); }
    if (!result?.ok) {
      const error = new Error(result?.error || "پاسخ اتصال ابری دریافت نشد.");
      Object.assign(error, { code: result?.code, status: result?.httpStatus, endpoint: result?.endpoint });
      throw error;
    }
    return result.value;
  }
  const storage = {};
  for (const method of ["get", "set", "remove"]) {
    storage[method] = value => send({ type: "DIDAR_CLOUD_STORAGE", method, value });
  }
  globalThis.DidarCloudExtensionAPI = { runtime: api.runtime, storage: { local: storage, onChanged: {} } };
  globalThis.DidarCloudClient = {
    request(path, options) {
      return send({ type: "DIDAR_CLOUD_API", route: "/request", connection, input: { path, options, executionKey } });
    },
    async identity() {
      const value = await send({ type: "DIDAR_CLOUD_API", route: "/identity", connection, input: {} });
      return value.identity;
    },
    install(handler) {
      api.runtime.onMessage.addListener((message, sender, respond) => {
        if (message?.type !== "DIDAR_CLOUD_EXECUTE" || sender.id !== api.runtime.id || sender.tab) return false;
        if (message.ping) { respond({ ok: true }); return false; }
        const operation = queue.then(async () => {
          connection = await send({ type: "DIDAR_CLOUD_CONNECTION" });
          const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify(message.message)));
          executionKey = Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
          localStorage.setItem("account", "cloud-credit");
          return handler(message.message);
        });
        queue = operation.catch(() => {});
        operation.then(respond, error => respond({ ok: false, error: error.message, code: error.code,
          httpStatus: error.status, endpoint: error.endpoint }));
        return true;
      });
    }
  };
})();
