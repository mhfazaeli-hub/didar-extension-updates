(function initializePopup() {
  "use strict";
  const chrome = globalThis.browser || globalThis.chrome;
  const Calls = globalThis.DidarCallChecklists;
  const teamManaged = Boolean(globalThis.DidarTeamChecklists?.managed());
  let teamManager = false;
  let teamVersion = 0;

  const DEFAULT_SETTINGS = {
    enabled: true,
    confirmBeforeSave: false,
    autoPlanChecklist: true,
    autoCallChecklist: true,
    callChecklistColumns: 3,
    callChecklistTemplates: Calls.defaultTemplates(),
    autoAddPlanProduct: false,
    etebaritoPreviewEnabled: false,
    etebaritoKeepAliveEnabled: true,
    connectionMode: "automatic",
    manualToken: "",
    manualBizDomain: ""
  };
  const RECEIVER_MISSING_PATTERN = /Receiving end does not exist|Could not establish connection/i;

  const elements = {
    appSubtitle: document.getElementById("appSubtitle"),
    form: document.getElementById("settingsForm"),
    enabled: document.getElementById("enabled"),
    confirmBeforeSave: document.getElementById("confirmBeforeSave"),
    autoPlanChecklist: document.getElementById("autoPlanChecklist"),
    autoCallChecklist: document.getElementById("autoCallChecklist"),
    callChecklistColumns: document.getElementById("callChecklistColumns"),
    beforePurchaseItems: document.getElementById("beforePurchaseItems"),
    afterPurchaseItems: document.getElementById("afterPurchaseItems"),
    autoAddPlanProduct: document.getElementById("autoAddPlanProduct"),
    etebaritoPreviewEnabled: document.getElementById("etebaritoPreviewEnabled"),
    etebaritoKeepAliveEnabled: document.getElementById("etebaritoKeepAliveEnabled"),
    manualFields: document.getElementById("manualFields"),
    manualToken: document.getElementById("manualToken"),
    manualBizDomain: document.getElementById("manualBizDomain"),
    statusDot: document.getElementById("statusDot"),
    statusTitle: document.getElementById("statusTitle"),
    userName: document.getElementById("userName"),
    userAccount: document.getElementById("userAccount"),
    diagnostics: document.getElementById("diagnostics"),
    lastInteraction: document.getElementById("lastInteraction"),
    refreshButton: document.getElementById("refreshButton"),
    formMessage: document.getElementById("formMessage"),
    submitButton: document.querySelector('.primary-button[type="submit"]')
  };
  elements.appSubtitle.textContent =
    `نسخه ${chrome.runtime.getManifest().version} · ذخیره با هویت کاربر جاری`;

  function selectedMode() {
    return document.querySelector('input[name="connectionMode"]:checked')?.value || "automatic";
  }

  function showManualFields() {
    elements.manualFields.hidden = selectedMode() !== "manual";
  }

  function setStatus(type, title, name = "", account = "") {
    elements.statusDot.className = `status-dot is-${type}`;
    elements.statusTitle.textContent = title;
    elements.userName.textContent = name || (type === "loading" ? "..." : "شناسایی نشد");
    elements.userAccount.textContent = account;
  }

  function setFormMessage(message, error = false) {
    elements.formMessage.textContent = message;
    elements.formMessage.classList.toggle("is-error", error);
  }

  async function activeSupportedTab(required = true) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (
      !tab?.id ||
      (!tab.url?.startsWith("https://app.didar.me/") &&
        !tab.url?.startsWith("https://etebaritoapp.ics24.ir/") &&
        !tab.url?.startsWith("https://my.olivecredit.ir/") &&
        !tab.url?.startsWith("https://beta.bkr724.ir/") &&
        !tab.url?.startsWith("https://eservices.tamin.ir/view/"))
    ) {
      if (!required) return null;
      throw new Error("ابتدا یک صفحه از دیدار یا سامانه اعتبارسنجی را باز کنید.");
    }
    return tab;
  }

  function isReceiverMissing(error) {
    return RECEIVER_MISSING_PATTERN.test(String(error?.message || error || ""));
  }

  async function restoreActiveReceiver(tab) {
    const isOlive = tab.url.startsWith("https://my.olivecredit.ir/");
    const isPortal = isOlive || tab.url.startsWith("https://etebaritoapp.ics24.ir/");
    const isTamin = tab.url.startsWith("https://eservices.tamin.ir/view/");
    const isBeta = isTamin || tab.url.startsWith("https://beta.bkr724.ir/");
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (marker) => {
        delete globalThis[marker];
      },
      args: [isPortal
        ? "__didarEtebaritoContentLoaded"
        : isBeta
          ? "__didarBetaIntegrationLoaded"
          : "__didarQuickChecklistContentLoaded"]
    });
    if (!isBeta) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: isOlive ? ["olive-page-context.js"] : isPortal ? ["etebarito-page-context.js"] : ["page-context.js"],
        world: "MAIN"
      });
    }
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: isOlive ? ["etebarito-core.js", "olive-core.js", "etebarito-content.js", "olive-content.js"] : isPortal
        ? ["etebarito-core.js", "etebarito-content.js"]
        : isBeta
          ? (isTamin ? ["beta-core.js", "tamin-core.js", "beta-content.js"] : ["beta-core.js", "beta-content.js"])
          : ["core.js", "plan-board.js", "content.js"]
    });
    try {
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: isOlive ? ["etebarito-content.css", "olive-content.css"] : isPortal
          ? ["etebarito-content.css"]
          : isBeta
            ? ["etebarito-content.css", "beta-content.css"]
            : ["content.css", "plan-board.css"]
      });
    } catch (_error) {
      // The receiver works even when Chrome refuses to insert an already loaded stylesheet.
    }
  }

  async function sendToTab(tab, message) {
    try {
      return await chrome.tabs.sendMessage(tab.id, message);
    } catch (error) {
      if (!isReceiverMissing(error)) {
        throw error;
      }
      await restoreActiveReceiver(tab);
      return chrome.tabs.sendMessage(tab.id, message);
    }
  }

  async function sendToActiveTab(message) {
    const tab = await activeSupportedTab();
    return sendToTab(tab, message);
  }

  async function refreshStatus() {
    setStatus("loading", "در حال بررسی اتصال");
    try {
      const tab = await activeSupportedTab(false);
      const isOlive = Boolean(tab?.url.startsWith("https://my.olivecredit.ir/"));
      const isPortal = isOlive || Boolean(tab?.url.startsWith("https://etebaritoapp.ics24.ir/"));
      const isTamin = Boolean(tab?.url.startsWith("https://eservices.tamin.ir/view/"));
      const isBeta = isTamin || Boolean(tab?.url.startsWith("https://beta.bkr724.ir/"));
      const result = tab ? await sendToTab(tab, {
        type: isPortal
          ? "ETEBARITO_PREVIEW_GET_STATUS"
          : isBeta
            ? (isTamin ? "TAMIN_DIDAR_GET_STATUS" : "BETA_DIDAR_GET_STATUS")
            : "DIDAR_TODO_GET_STATUS"
      }) : await chrome.runtime.sendMessage({ type: "DIDAR_POPUP_GET_STATUS" });
      if (!result?.ok) {
        throw new Error(result?.error || "اتصال برقرار نشد.");
      }
      if (isPortal) {
        const didar = await chrome.runtime.sendMessage({ type: "ETEBARITO_DIDAR_GET_CONFIG", ...(isOlive ? { payload: { provider: "olive" } } : {}) });
        if (!didar?.ok) {
          throw new Error(didar?.error || "تب معتبر دیدار پیدا نشد.");
        }
        const mode = didar.identity?.connectionMode === "manual" ? "اتصال دستی" : "نشست همین مرورگر";
        setStatus(
          "ready",
          `${isOlive ? "الیو کردیت" : "اعتباریتو"} و دیدار متصل · ${mode}`,
          didar.identity?.displayName || "کاربر دیدار",
          didar.identity?.username || "مقصد: پرونده اعتباری / اعتبار سنجی اولیه"
        );
        const diagnostics = result.diagnostics || {};
        elements.diagnostics.textContent = `نتایج شناسایی‌شده: ${diagnostics.capturedRows || 0}`;
        elements.lastInteraction.textContent = `آخرین رویداد: ${diagnostics.lastInteraction || "نامشخص"}`;
        return;
      }
      if (isBeta) {
        const didar = await chrome.runtime.sendMessage({ type: isTamin ? "TAMIN_DIDAR_GET_CONFIG" : "BETA_DIDAR_GET_CONFIG" });
        if (!didar?.ok) {
          throw new Error(didar?.error || "تب معتبر دیدار پیدا نشد.");
        }
        const mode = didar.identity?.connectionMode === "manual" ? "اتصال دستی" : "نشست همین مرورگر";
        setStatus(
          "ready",
          `${isTamin ? "تأمین اجتماعی" : "بتا"} و دیدار متصل · ${mode}`,
          didar.identity?.displayName || "کاربر دیدار",
          didar.identity?.username || "مقصد: پرونده اعتباری / اعتبار سنجی اولیه"
        );
        elements.diagnostics.textContent = result.diagnostics?.launcherReady
          ? "دکمه انتقال بتا آماده است"
          : "صفحه مشتری بتا آماده انتقال نیست";
        elements.lastInteraction.textContent = result.diagnostics?.previewOpen
          ? "پنجره انتقال باز است"
          : "پنجره انتقال بسته است";
        return;
      }
      const mode = result.identity.connectionMode === "manual" ? "اتصال دستی" : "نشست همین مرورگر";
      setStatus(
        "ready",
        `متصل · ${mode}${tab ? "" : " · تب دیدار در پس‌زمینه"}`,
        result.identity.displayName,
        result.identity.username
      );
      const diagnostics = result.diagnostics || {};
      elements.diagnostics.textContent =
        `شناسایی: ${diagnostics.checkboxes || 0} مربع، ` +
        `${diagnostics.ready || 0} آماده کلیک، ${diagnostics.resolved || 0} فعالیت متصل، ` +
        `${diagnostics.editorExcluded || 0} داخل ویرایشگر`;
      elements.lastInteraction.textContent = `آخرین رویداد: ${diagnostics.lastInteraction || "نامشخص"}`;
    } catch (error) {
      setStatus("error", "اتصال برقرار نیست", error.message);
      elements.diagnostics.textContent = "";
      elements.lastInteraction.textContent = "";
    }
  }

  async function load() {
    const values = { ...DEFAULT_SETTINGS, ...(await chrome.storage.local.get(DEFAULT_SETTINGS)) };
    if (teamManaged) {
      try { Object.assign(values, await loadTeam(false)); }
      catch (error) { document.getElementById("teamChecklistStatus").textContent = error.message; }
    }
    elements.enabled.checked = values.enabled;
    elements.confirmBeforeSave.checked = values.confirmBeforeSave;
    elements.autoPlanChecklist.checked = values.autoPlanChecklist;
    elements.autoCallChecklist.checked = values.autoCallChecklist;
    elements.callChecklistColumns.value = String(Calls.columns(values.callChecklistColumns));
    const templates = Calls.normalizeTemplates(values.callChecklistTemplates);
    elements.beforePurchaseItems.value = templates.beforePurchase.join("\n");
    elements.afterPurchaseItems.value = templates.afterPurchase.join("\n");
    elements.autoAddPlanProduct.checked = values.autoAddPlanProduct;
    elements.etebaritoPreviewEnabled.checked = values.etebaritoPreviewEnabled;
    elements.etebaritoKeepAliveEnabled.checked = values.etebaritoKeepAliveEnabled;
    const modeInput = document.querySelector(
      `input[name="connectionMode"][value="${values.connectionMode}"]`
    );
    if (modeInput) {
      modeInput.checked = true;
    }
    elements.manualToken.value = values.manualToken;
    elements.manualBizDomain.value = values.manualBizDomain;
    showManualFields();
    await refreshStatus();
  }

  document.querySelectorAll('input[name="connectionMode"]').forEach((input) => {
    input.addEventListener("change", showManualFields);
  });
  elements.refreshButton.addEventListener("click", refreshStatus);
  function callSettingsFromForm() {
    return { autoCallChecklist: elements.autoCallChecklist.checked,
      callChecklistColumns: Calls.columns(elements.callChecklistColumns.value),
      callChecklistTemplates: { beforePurchase: Calls.itemsFromLines(elements.beforePurchaseItems.value),
        afterPurchase: Calls.itemsFromLines(elements.afterPurchaseItems.value) } };
  }
  const teamControls = [elements.autoCallChecklist, elements.callChecklistColumns, elements.beforePurchaseItems, elements.afterPurchaseItems];
  function lockTeamControls() {
    teamControls.forEach(control => { control.disabled = teamManaged && !teamManager; });
    document.getElementById("uploadCallBackup").disabled = teamManaged && !teamManager;
  }
  async function loadTeam(refresh) {
    const result = await chrome.runtime.sendMessage({type:refresh ? "DIDAR_TEAM_SYNC" : "DIDAR_TEAM_BOOT"});
    if (!result?.ok) throw Error(result?.error || "قالب تیم دریافت نشد.");
    teamVersion = result.state.version;
    document.getElementById("teamChecklistStatus").textContent = `قالب تیم نسخهٔ ${teamVersion} · ${result.receivedAt ? new Date(result.receivedAt).toLocaleString("fa-IR") : "قالب همراه افزونه"}${result.error ? " · " + result.error : ""}`;
    teamManager = result.manager === true;
    lockTeamControls();
    document.getElementById("publishTeamChecklist").hidden = !teamManager;
    const stored = await chrome.storage.local.get("teamChecklistDraft");
    if (!refresh && teamManager && stored.teamChecklistDraft?.baseVersion === teamVersion) return stored.teamChecklistDraft.settings;
    return result.state.settings;
  }
  function showCallSettings(value) {
    elements.autoCallChecklist.checked = value.autoCallChecklist;
    elements.callChecklistColumns.value = String(value.callChecklistColumns);
    elements.beforePurchaseItems.value = value.callChecklistTemplates.beforePurchase.join("\n");
    elements.afterPurchaseItems.value = value.callChecklistTemplates.afterPurchase.join("\n");
  }
  if (teamManaged) {
    lockTeamControls();
    document.querySelector(".call-settings > p:last-child").textContent = "قالب مرکزی برای همهٔ کارشناسان یکسان است. با رمز انتشار می‌توانید در همین مرورگر ناشر شوید. دسترسی ناشر ۱۵ دقیقه معتبر است. ذخیرهٔ تنظیمات، پیش‌نویس را نگه می‌دارد؛ انتشار، نسخهٔ تیم را بروزرسانی می‌کند. متن و تیک فعالیت‌های قبلی حفظ می‌شوند.";
    document.getElementById("teamPublisherControls").hidden = false;
    for (const [id,type] of [["unlockTeamPublisher","DIDAR_TEAM_UNLOCK"],["lockTeamPublisher","DIDAR_TEAM_LOCK"]]) {
      document.getElementById(id).addEventListener("click",async () => {
        const input = document.getElementById("teamPublisherCode");
        const code = input.value;
        input.value = "";
        try {
          const result = await chrome.runtime.sendMessage({type,code});
          if (!result?.ok) throw Error(result?.error || "ورود ناشر انجام نشد.");
          showCallSettings(await loadTeam(false));
          setFormMessage(result.manager ? "دسترسی انتشار فعال شد." : "از حالت ناشر خارج شدید.");
        } catch (error) { setFormMessage(error.message,true); }
      });
    }
    document.getElementById("refreshTeamChecklist").hidden = false;
    document.getElementById("refreshTeamChecklist").addEventListener("click", async () => {
      try { showCallSettings(await loadTeam(true)); setFormMessage("قالب تیم بررسی شد."); }
      catch (error) { setFormMessage(error.message,true); }
    });
    document.getElementById("publishTeamChecklist").addEventListener("click", async event => {
      if (!teamManager || !window.confirm("این قالب برای همهٔ کارشناسان منتشر شود؟")) return;
      event.target.disabled = true;
      try {
        const result = await chrome.runtime.sendMessage({type:"DIDAR_TEAM_PUBLISH",settings:callSettingsFromForm(),expectedVersion:teamVersion});
        if (!result?.ok) throw Error(result?.error || "انتشار قالب انجام نشد.");
        await chrome.storage.local.remove("teamChecklistDraft");
        showCallSettings(await loadTeam(false));
        setFormMessage("قالب تیم منتشر شد؛ همکاران می‌توانند بروزرسانی چک‌لیست را بزنند.");
      } catch (error) { setFormMessage(error.message,true); }
      finally { event.target.disabled = false; }
    });
  }
  const backupFile = document.getElementById("callBackupFile");
  document.getElementById("downloadCallBackup").addEventListener("click", () => {
    try {
      const blob = new Blob([Calls.exportBackup(callSettingsFromForm())], { type: "application/json;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `didar-call-checklists-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.append(link); link.click(); link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setFormMessage("فایل پشتیبان برای دانلود آماده شد.");
    } catch (error) { setFormMessage(error.message, true); }
  });
  document.getElementById("uploadCallBackup").addEventListener("click", () => backupFile.click());
  backupFile.addEventListener("change", async () => {
    const file = backupFile.files?.[0];
    if (!file) return;
    try {
      if (file.size > 512 * 1024) throw new Error("حداکثر حجم فایل پشتیبان ۵۱۲ کیلوبایت است.");
      const imported = Calls.importBackup(await file.text());
      if (teamManaged && !teamManager) throw Error("ویرایش قالب تیم فقط برای ناشر مجاز است.");
      await chrome.storage.local.set(teamManaged ? {teamChecklistDraft:{baseVersion:teamVersion,settings:imported}} : imported);
      elements.autoCallChecklist.checked = imported.autoCallChecklist;
      elements.callChecklistColumns.value = String(imported.callChecklistColumns);
      elements.beforePurchaseItems.value = imported.callChecklistTemplates.beforePurchase.join("\n");
      elements.afterPurchaseItems.value = imported.callChecklistTemplates.afterPurchase.join("\n");
      await sendToActiveTab({ type: "DIDAR_TODO_SETTINGS_UPDATED" }).catch(() => {});
      setFormMessage(teamManaged ? "قالب در پیش‌نویس مدیر قرار گرفت؛ برای اشتراک با تیم انتشار را بزنید." : "پشتیبان بارگذاری و تنظیمات چک‌لیست ذخیره شد.");
    } catch (error) { setFormMessage(error.message || "بارگذاری فایل انجام نشد.", true); }
    finally { backupFile.value = ""; }
  });
  elements.form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const mode = selectedMode();
    let callChecklistTemplates;
    try {
      callChecklistTemplates = {
        beforePurchase: Calls.itemsFromLines(elements.beforePurchaseItems.value),
        afterPurchase: Calls.itemsFromLines(elements.afterPurchaseItems.value)
      };
    } catch (error) {
      setFormMessage(error.message, true);
      return;
    }
    const values = {
      enabled: elements.enabled.checked,
      confirmBeforeSave: elements.confirmBeforeSave.checked,
      autoPlanChecklist: elements.autoPlanChecklist.checked,
      autoCallChecklist: elements.autoCallChecklist.checked,
      callChecklistColumns: Calls.columns(elements.callChecklistColumns.value),
      callChecklistTemplates,
      autoAddPlanProduct: elements.autoAddPlanProduct.checked,
      etebaritoPreviewEnabled: elements.etebaritoPreviewEnabled.checked,
      etebaritoKeepAliveEnabled: elements.etebaritoKeepAliveEnabled.checked,
      connectionMode: mode,
      manualToken: elements.manualToken.value.trim(),
      manualBizDomain: elements.manualBizDomain.value.trim()
    };
    if (mode === "manual" && (!values.manualToken || !values.manualBizDomain)) {
      setFormMessage("برای اتصال دستی، هر دو مقدار لازم است.", true);
      return;
    }

    elements.submitButton.disabled = true;
    if (teamManaged) {
      if (teamManager) values.teamChecklistDraft = {baseVersion:teamVersion,settings:callSettingsFromForm()};
      delete values.autoCallChecklist;
      delete values.callChecklistColumns;
      delete values.callChecklistTemplates;
    }
    setFormMessage("در حال ذخیره...");
    try {
      await chrome.storage.local.set(values);
      await sendToActiveTab({ type: "DIDAR_TODO_SETTINGS_UPDATED" }).catch(() => {});
      setFormMessage("تنظیمات ذخیره شد.");
      await refreshStatus();
    } catch (error) {
      setFormMessage(error.message || "ذخیره تنظیمات انجام نشد.", true);
    } finally {
      elements.submitButton.disabled = false;
    }
  });

  void load();
})();
