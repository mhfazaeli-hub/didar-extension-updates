$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Get-UpdateRoot {
    return [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'DidarQuickChecklist'))
}

function Assert-UpdatePath([string]$Path) {
    $resolved = [IO.Path]::GetFullPath($Path)
    $prefix = (Get-UpdateRoot).TrimEnd('\') + '\'
    if (-not $resolved.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Updater path is outside its installation directory.'
    }
    return $resolved
}

function Get-RemoteBytes([string]$Url, [int]$MaximumBytes) {
    $uri = [Uri]$Url
    $config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'updater-config.json') -Raw | ConvertFrom-Json
    if ($uri.Scheme -ne 'https' -or -not $Url.StartsWith($config.baseUrl + '/', [StringComparison]::Ordinal)) {
        throw 'Update URL is outside the configured HTTPS release location.'
    }
    $request = [Net.HttpWebRequest]::Create($uri)
    $request.Timeout = 30000
    $request.ReadWriteTimeout = 30000
    $request.AllowAutoRedirect = $false
    $request.UserAgent = 'DidarQuickChecklist-Updater/1'
    $response = $null
    $stream = $null
    $memory = New-Object IO.MemoryStream
    try {
        $response = $request.GetResponse()
        if ([int]$response.StatusCode -ne 200 -or $response.ContentLength -gt $MaximumBytes) {
            throw 'Update response has an invalid status or size.'
        }
        $stream = $response.GetResponseStream()
        $buffer = New-Object byte[] 65536
        while (($count = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            if ($memory.Length + $count -gt $MaximumBytes) { throw 'Update response is too large.' }
            $memory.Write($buffer, 0, $count)
        }
        return ,$memory.ToArray()
    } finally {
        if ($stream) { $stream.Dispose() }
        if ($response) { $response.Dispose() }
        $memory.Dispose()
    }
}

function Read-Release([byte[]]$Bytes, [string]$PublicKeyXml) {
    $envelope = [Text.Encoding]::UTF8.GetString($Bytes) | ConvertFrom-Json
    if ($envelope.algorithm -ne 'RSA-SHA256') { throw 'Unsupported update signature.' }
    $payload = [Convert]::FromBase64String($envelope.payload)
    $signature = [Convert]::FromBase64String($envelope.signature)
    $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
    try {
        $rsa.FromXmlString($PublicKeyXml)
        if (-not $rsa.VerifyData($payload, 'SHA256', $signature)) { throw 'Update signature verification failed.' }
    } finally { $rsa.Dispose() }
    $release = [Text.Encoding]::UTF8.GetString($payload) | ConvertFrom-Json
    if ($release.schemaVersion -ne 1 -or $release.version -notmatch '^\d{1,5}(\.\d{1,5}){1,3}$' -or
        $release.chromium.sha256 -notmatch '^[a-f0-9]{64}$') { throw 'Invalid release metadata.' }
    return $release
}

function Expand-VerifiedPackage([string]$ZipPath, [string]$Destination) {
    $destinationPath = (Assert-UpdatePath $Destination).TrimEnd('\') + '\'
    $archive = [IO.Compression.ZipFile]::OpenRead($ZipPath)
    $seen = New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $total = 0L
    try {
        if ($archive.Entries.Count -gt 300) { throw 'Too many files in update package.' }
        foreach ($entry in $archive.Entries) {
            $name = $entry.FullName.Replace('/', '\')
            if (-not $name -or $name.Contains(':') -or $name.StartsWith('\') -or
                (($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000) { throw 'Invalid update archive entry.' }
            $target = [IO.Path]::GetFullPath((Join-Path $destinationPath $name))
            if (-not $target.StartsWith($destinationPath, [StringComparison]::OrdinalIgnoreCase) -or -not $seen.Add($target)) {
                throw 'Unsafe or duplicate update archive path.'
            }
            $total += $entry.Length
            if ($total -gt 50MB) { throw 'Uncompressed update is too large.' }
            if ($name.EndsWith('\')) { [IO.Directory]::CreateDirectory($target) | Out-Null; continue }
            [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target)) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $target, $false)
        }
    } finally { $archive.Dispose() }
}

function Invoke-TeamUpdate([string]$Command) {
    if ($Command -notin @('check', 'update')) { throw 'Unsupported updater command.' }
    $config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'updater-config.json') -Raw | ConvertFrom-Json
    $root = Get-UpdateRoot
    [IO.Directory]::CreateDirectory($root) | Out-Null
    $lock = $null
    $staging = $null
    try {
        # The OS releases this lock even if the browser or native host terminates.
        try {
            $lock = New-Object IO.FileStream((Join-Path $root 'update.lock'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        } catch {
            throw 'Another update is running. Try again after it finishes.'
        }
        $target = Assert-UpdatePath (Join-Path $root 'extension')
        $journalPath = Join-Path $root 'pending-swap.json'
        if (Test-Path -LiteralPath $journalPath) {
            $journal = Get-Content -LiteralPath $journalPath -Raw | ConvertFrom-Json
            if ($journal.backup -notmatch '^previous-[a-f0-9]{32}$') { throw 'Invalid interrupted update journal.' }
            $previous = Assert-UpdatePath (Join-Path $root $journal.backup)
            if (-not (Test-Path -LiteralPath $target) -and (Test-Path -LiteralPath $previous)) {
                $previousManifest = Get-Content -LiteralPath (Join-Path $previous 'manifest.json') -Raw | ConvertFrom-Json
                if ($previousManifest.key -ne $config.extensionKey) { throw 'Recovery package identity is incorrect.' }
                Move-Item -LiteralPath $previous -Destination $target
            }
            Remove-Item -LiteralPath (Assert-UpdatePath $journalPath) -Force
        }
        $bytes = Get-RemoteBytes ($config.baseUrl + '/updates/chromium.json') 262144
        $release = Read-Release $bytes $config.publicKeyXml
        $manifestPath = Join-Path $target 'manifest.json'
        $installed = '0.0.0'
        if (Test-Path -LiteralPath $manifestPath) {
            $current = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
            if ($current.key -ne $config.extensionKey) { throw 'Installed extension key does not match this updater.' }
            $installed = $current.version
        }
        $newer = [Version]$release.version -gt [Version]$installed
        if ($Command -eq 'check' -or -not $newer) {
            return @{ ok = $true; version = $release.version; installedVersion = $installed; updateAvailable = $newer; updated = $false }
        }
        $staging = Assert-UpdatePath (Join-Path $root ('staging-' + [Guid]::NewGuid().ToString('N')))
        [IO.Directory]::CreateDirectory($staging) | Out-Null
        $zipPath = Join-Path $staging 'package.zip'
        [IO.File]::WriteAllBytes($zipPath, (Get-RemoteBytes $release.chromium.url 20MB))
        $hasher = [Security.Cryptography.SHA256]::Create()
        $packageStream = [IO.File]::OpenRead($zipPath)
        try { $hash = [BitConverter]::ToString($hasher.ComputeHash($packageStream)).Replace('-', '').ToLowerInvariant() }
        finally { $packageStream.Dispose(); $hasher.Dispose() }
        if ($hash -ne $release.chromium.sha256) {
            throw 'Downloaded update hash does not match the signed release.'
        }
        $expanded = Join-Path $staging 'extension'
        Expand-VerifiedPackage $zipPath $expanded
        $next = Get-Content -LiteralPath (Join-Path $expanded 'manifest.json') -Raw | ConvertFrom-Json
        if ($next.version -ne $release.version -or $next.key -ne $config.extensionKey -or $next.manifest_version -ne 3) {
            throw 'Update package identity or version is incorrect.'
        }
        $backup = Assert-UpdatePath (Join-Path $root ('previous-' + [Guid]::NewGuid().ToString('N')))
        $journalTemporary = Assert-UpdatePath ($journalPath + '.tmp')
        [IO.File]::WriteAllText($journalTemporary, (@{ backup = [IO.Path]::GetFileName($backup) } | ConvertTo-Json))
        Move-Item -LiteralPath $journalTemporary -Destination $journalPath -Force
        $moved = $false
        try {
            if (Test-Path -LiteralPath $target) { Move-Item -LiteralPath $target -Destination $backup; $moved = $true }
            Move-Item -LiteralPath $expanded -Destination $target
        } catch {
            if ($moved -and -not (Test-Path -LiteralPath $target)) { Move-Item -LiteralPath $backup -Destination $target }
            throw
        }
        Remove-Item -LiteralPath (Assert-UpdatePath $journalPath) -Force
        return @{ ok = $true; version = $release.version; installedVersion = $release.version; updateAvailable = $false; updated = $true }
    } finally {
        if ($staging -and (Test-Path -LiteralPath $staging)) {
            $verifiedStaging = Assert-UpdatePath $staging
            Remove-Item -LiteralPath $verifiedStaging -Recurse -Force
        }
        if ($lock) { $lock.Dispose() }
    }
}
