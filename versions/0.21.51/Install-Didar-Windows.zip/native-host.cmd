@echo off
set "didarHostScript=%~dp0..\extension\team-updater\native-host.ps1"
if not exist "%didarHostScript%" set "didarHostScript=%~dp0native-host.ps1"
powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%didarHostScript%" %*
