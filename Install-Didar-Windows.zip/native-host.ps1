param([string]$Origin)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'updater-common.ps1')
$inputStream = [Console]::OpenStandardInput()
$outputStream = [Console]::OpenStandardOutput()
function Read-Exact([int]$Length) {
    $buffer = New-Object byte[] $Length
    $position = 0
    while ($position -lt $Length) {
        $read = $inputStream.Read($buffer, $position, $Length - $position)
        if ($read -eq 0) { throw 'Unexpected end of native message.' }
        $position += $read
    }
    return ,$buffer
}
try {
    $config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'updater-config.json') -Raw | ConvertFrom-Json
    if ($Origin -ne ('chrome-extension://' + $config.extensionId + '/')) { throw 'Unrecognized extension origin.' }
    $header = Read-Exact 4
    $length = [BitConverter]::ToUInt32($header, 0)
    if ($length -gt 4096 -or $length -eq 0) { throw 'Invalid native message size.' }
    $request = [Text.Encoding]::UTF8.GetString((Read-Exact $length)) | ConvertFrom-Json
    $result = Invoke-TeamUpdate $request.command
} catch { $result = @{ ok = $false; error = $_.Exception.Message } }
$body = [Text.Encoding]::UTF8.GetBytes(($result | ConvertTo-Json -Compress -Depth 8))
$outputStream.Write([BitConverter]::GetBytes([uint32]$body.Length), 0, 4)
$outputStream.Write($body, 0, $body.Length)
$outputStream.Flush()
