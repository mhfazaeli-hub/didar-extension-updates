$ErrorActionPreference = 'Stop'
$source = $PSScriptRoot
$root = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'DidarQuickChecklist'))
$hostFolder = Join-Path $root 'host'
[IO.Directory]::CreateDirectory($hostFolder) | Out-Null
foreach ($name in @('native-host.ps1', 'native-host.cmd', 'updater-common.ps1', 'updater-config.json')) {
    Copy-Item -LiteralPath (Join-Path $source $name) -Destination (Join-Path $hostFolder $name) -Force
}
$config = Get-Content -LiteralPath (Join-Path $hostFolder 'updater-config.json') -Raw | ConvertFrom-Json
$manifest = @{
    name = $config.nativeHost
    description = 'Didar Quick Checklist team updater'
    path = (Join-Path $hostFolder 'native-host.cmd')
    type = 'stdio'
    allowed_origins = @(('chrome-extension://' + $config.extensionId + '/'))
}
$hostManifest = Join-Path $hostFolder 'native-host.json'
[IO.File]::WriteAllText($hostManifest, ($manifest | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding($false)))
foreach ($browser in @('Google\Chrome', 'Microsoft\Edge')) {
    $registryPath = 'HKCU:\Software\' + $browser + '\NativeMessagingHosts\' + $config.nativeHost
    New-Item -Path $registryPath -Force | Out-Null
    Set-Item -LiteralPath $registryPath -Value $hostManifest
}
. (Join-Path $hostFolder 'updater-common.ps1')
$result = Invoke-TeamUpdate 'update'
if (-not $result.ok) { throw 'Initial installation failed.' }
$instructions = @"
Didar Quick Checklist $($result.installedVersion) is ready.

In Chrome open chrome://extensions .
In Edge open edge://extensions .
Turn on Developer mode, click Load unpacked, and choose this folder:

$(Join-Path $root 'extension')

Keep this folder in place. Future updates are installed using the update button
in the extension popup. Chrome and Edge can use the same installed folder.
Firefox uses the signed XPI download from the team's distribution page.
"@
$instructionsPath = Join-Path $root 'INSTALL.txt'
[IO.File]::WriteAllText($instructionsPath, $instructions, (New-Object Text.UTF8Encoding($false)))
Write-Output $instructions
